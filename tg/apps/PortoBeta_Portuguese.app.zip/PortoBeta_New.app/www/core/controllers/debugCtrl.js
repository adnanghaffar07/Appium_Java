angular.module('controllers', [])
    .controller('DebugCtrl', DebugCtrl);

function DebugCtrl(TripsServices, LoggerUtil, StringUtil, FileUtil, $ionicLoading, ApplicationStateManager, DeviceFactory, ValidationUtil, $scope, $ionicHistory, $timeout, PhoneSwitchType, BridgeIntentType, $state, $translate, HttpProxy, PopupUtil, AppConfigServices, CordovaBroadcaster, GlobalConstants, WebServiceUrls, LocalStorage, ApplicationMode, LocalStorageKeys, DeviceInfoUtil, ListenerUtil, LoadingUtil, MediaUtil, MockFactory) {
    $scope.backClick = backClick;
    $scope.changeUrls = changeUrls;
    $scope.refreshLocales = refreshLocales;
    $scope.localeTagModeChanged = localeTagModeChanged;
    $scope.debugLoadingChanged = debugLoadingChanged;
    $scope.policyOwnerChanged = policyOwnerChanged;
    $scope.changeStateDebug = changeStateDebug;
    $scope.t2NotificationChange = t2NotificationChange;
    $scope.applicationState = {};

    // telemetry override
    $scope.startClick = startClick;
    $scope.pauseClick = pauseClick;
    $scope.resumeClick = resumeClick;
    $scope.stopClick = stopClick;
    $scope.getTripInfoClick = getTripInfoClick;
    $scope.clearLogs = clearLogs;
    $scope.sendIntentDebug = sendIntentDebug;
    $scope.testOnNewIntent = testOnNewIntent;
    $scope.sendFakeTrip = sendFakeTrip;
    $scope.changeApplicationStateSwitch = changeApplicationStateSwitch;
    $scope.saveLogsIntent = saveLogsIntent;

    $scope.clearLocalStorageClick = clearLocalStorageClick;
    $scope.playAcc = playAcc;
    $scope.playBrake = playBrake;

    $scope.refreshIntentLogs = refreshIntentLogs;

    $scope.showDebugLoading = LoadingUtil.showDebugLoading;
    $scope.isPolicyOwner = LocalStorage.getBoolean(LocalStorageKeys.LOGIN_POLICY_OWNER, false);

    $scope.tetheringStatus = DeviceFactory.tetheringStatus;

    getSavedDebugIntentParameters();
    setupInitialApplicationState();
    getGitVersion();
    // UserToken
    $scope.userToken = LocalStorage.get(LocalStorageKeys.USER_TOKEN);


    $scope.config = {
        baseURL: GlobalConstants.BASE_URL,
        collectorURL: GlobalConstants.COLLECTOR_URL,
        collectorURLT2: GlobalConstants.COLLECTOR_URL_T2,
        machineURL: GlobalConstants.BASE_URL_PROMO,
        appVersion: GlobalConstants.API_VERSION,
        userId: LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID),
        sendUserCredentialStatus: LocalStorage.get(LocalStorageKeys.SEND_USER_CREDENTIAL_STATE)
    };

    var deviceinfo = DeviceInfoUtil.getDeviceInfo();
    $scope.deviceversion = deviceinfo.version;
    $scope.devicemodel = deviceinfo.model;

    $scope.showLocaleTags = (LocalStorage.get(LocalStorageKeys.DEBUG_SHOW_LOCALES_TAG) == "true");
    $scope.changeMode = changeMode;
    $scope.sendNotificationLink = sendNotificationLink;
    $scope.sendHardAccleration = sendHardAccleration;
    $scope.sendHardDeceleration = sendHardDeceleration;

    loadLocalStorage();

    function loadLocalStorage() {
        $scope.entries = [];
        var entry = null;
        for (var key in window.localStorage) {
            entry = {
                key: key,
                data: LocalStorage.get(key)
            }
            $scope.entries.push(entry);
        }


        $scope.toggleGroup = function (group) {
            if ($scope.isGroupShown(group)) {
                $scope.shownGroup = null;
            } else {
                $scope.shownGroup = group;
            }
        };
        $scope.isGroupShown = function (group) {
            return $scope.shownGroup === group;
        };
    }

    function changeUrls(pBaseURL, pCollectorURL, pCollectorURLT2, pMachineURL) {
        var changed = false;
        var current = LocalStorage.get(LocalStorageKeys.BASE_URL_OVERRIDE);
        if (current != pBaseURL && pBaseURL != GlobalConstants.BASE_URL) {
            LocalStorage.set(LocalStorageKeys.BASE_URL_OVERRIDE, pBaseURL);
            changed = true;
        }

        current = LocalStorage.get(LocalStorageKeys.COLLECTOR_URL_OVERRIDE);
        if (current != pCollectorURL && pCollectorURL != GlobalConstants.COLLECTOR_URL) {
            LocalStorage.set(LocalStorageKeys.COLLECTOR_URL_OVERRIDE, pCollectorURL);
            changed = true;
        }
        current = LocalStorage.get(LocalStorageKeys.COLLECTOR_URL_T2_OVERRIDE);
        if (current != pCollectorURLT2 && pCollectorURLT2 != GlobalConstants.COLLECTOR_URL_T2) {
            LocalStorage.set(LocalStorageKeys.COLLECTOR_URL_T2_OVERRIDE, pCollectorURLT2);
            changed = true;
        }

        current = LocalStorage.get(LocalStorageKeys.PROMUTUEL_MACHINE_URL_OVERRIDE);
        if (current != pMachineURL && pMachineURL != GlobalConstants.BASE_URL_PROMO) {
            LocalStorage.set(LocalStorageKeys.PROMUTUEL_MACHINE_URL_OVERRIDE, pMachineURL);
            changed = true;
        }

        if (changed) {
            PopupUtil.showSimpleAlert("URL CHANGED", "<p>Reboot the app for the change to take place</p>");
            GlobalConstants.init();
            CordovaBroadcaster.sendPlatformReady(); // refresh the URl to the native side too
        }
    }

    function refreshIntentLogs(pTag) {
        $scope.intentLogs = LoggerUtil.getLogs(undefined, pTag);
    }

    function backClick() {
        $ionicHistory.goBack();
    }

    function clearLocalStorageClick() {
        window.localStorage.clear();
    }

    function clearLogs() {
        LoggerUtil.clearLogs();
        refreshIntentLogs();
    }

    function sendFakeTrip(pDuration, pPerfectTripFlag) {

        pDuration = ValidationUtil.setDefaultValue(pDuration, 120);

        var trip = null;
        if (true == pPerfectTripFlag) {
            trip = MockFactory.getPerfectTrip();
        } else {
            trip = MockFactory.getTrip();
        }

        trip.device_trip_id = "FAKE";
        trip.end = moment().format("X");
        trip.start = moment().subtract(pDuration, 'seconds').format("X");

        trip.user_id = $scope.config.userId;

        HttpProxy.post(GlobalConstants.COLLECTOR_URL, trip).then(function (pResponse) {
            PopupUtil.showSimpleAlert("SUCCESS", StringUtil.format("<p>{0} </p><p>{1}</p>", "Trip sent succesfully", JSON.stringify(pResponse)));
        }, function (pError) {
            PopupUtil.showSimpleAlert("Error", StringUtil.format("<p>{0} </p><p>{1}</p>", "Error while sending Trip", JSON.stringify(pError)));
        });
    }

    function startClick() {
        CordovaBroadcaster.startTrip();
    }

    function pauseClick() {
        CordovaBroadcaster.pauseTrip();
    }

    function resumeClick() {
        CordovaBroadcaster.resumeTrip();
    }

    function stopClick() {
        CordovaBroadcaster.stopTrip();
    }

    function playAcc() {
        var applicationDir = FileUtil.getApplicationDirectory();
        var url = applicationDir + 'www/client/sounds/hac.mp3';
        playSounds(url);
    }

    function playBrake() {
        var applicationDir = FileUtil.getApplicationDirectory();
        var url = applicationDir + 'www/client/sounds/hbr.mp3';
        playSounds(url);
    }

    function sendNotificationLink() {
        ListenerUtil.playEvent('NOTIFICATION_LINK', {
            'tripId': '1111-2222-3333-4444'
        });
    }

    function sendHardAccleration() {
        ListenerUtil.playEvent('ACTION_ACCELERATION');
    }

    function sendHardDeceleration() {
        ListenerUtil.playEvent('ACTION_DECELERATION');
        var url = '/android_asset/www/client/sounds/brake.wav';
        playSounds(url);
    }

    function playSounds(url) {
        var my_media = new Media(url,
            // success callback
            function () {},
            // error callback
            function (err) {
                alert("playAudio():Audio Error: " + JSON.stringify(err));
            }
        );

        my_media.play();
        return my_media;
    }

    function setupInitialApplicationState() {
        $scope.applicationState[BridgeIntentType.WIFI_STATE] = ApplicationStateManager.getState(PhoneSwitchType.WIFI);
        $scope.applicationState[BridgeIntentType.BLUETOOTH_STATE] = ApplicationStateManager.getState(PhoneSwitchType.BLUETOOTH);
        $scope.applicationState[BridgeIntentType.GPS_STATE] = ApplicationStateManager.getState(PhoneSwitchType.GPS);
        $scope.applicationState[BridgeIntentType.AIRPLANE_MODE_STATE] = ApplicationStateManager.getState(PhoneSwitchType.AIRPLANE_MODE);
        $scope.applicationState[BridgeIntentType.CELLULAR_DATA_STATE] = ApplicationStateManager.getState(PhoneSwitchType.CELLULAR_DATA);
    }

    function changeApplicationStateSwitch(pEventType) {
        var json = {};
        json[pEventType.toLowerCase()] = $scope.applicationState[pEventType];
        testOnNewIntent(pEventType, JSON.stringify(json));
    }

    function getTripInfoClick() {
        CordovaBroadcaster.requestTripInformation();
    }

    function sendIntentDebug(pAction, pExtrasAsJsonString) {
        saveIntentParameters(pAction, pExtrasAsJsonString);
        var extras = JSON.parse(pExtrasAsJsonString);
        var json = {
            action: pAction,
            extras: extras
        };
        window.webintent.sendBroadcast(json,
            function () {},
            function (args) {});


    }

    function testOnNewIntent(pAction, pExtrasAsJsonString) {
        saveIntentParameters(pAction, pExtrasAsJsonString);
        var extras = JSON.parse(pExtrasAsJsonString);
        var json = {
            Action: pAction,
            extras: extras
        };

        //alert("JSON Action: " + json.Action + "JSON extras: " + json.extras);

        window.webintent.testOnNewIntent(json);
    }


    function changeStateDebug(pState, pStateParams) {
        if (true == ValidationUtil.isEmpty(pState)) {
            PopupUtil.showSimpleAlert(null, "pState is empty");
        } else {
            $state.go(pState, pStateParams);
        }
    }
    
    //To set T2 notification
    function t2NotificationChange(pValue){
        CordovaBroadcaster.actionT2Notification(pValue);
    }

    function getSavedDebugIntentParameters() {
        //alert("getSavedDebugIntentParameters");
        $scope.debugIntent = {
            "action": LocalStorage.get(LocalStorageKeys.DEBUG_INTENT_ACTION),
            "extras": LocalStorage.get(LocalStorageKeys.DEBUG_INTENT_EXTRAS)
        };
    }

    function saveIntentParameters(pAction, pExtrasAsJsonString) {
        LocalStorage.set(LocalStorageKeys.DEBUG_INTENT_ACTION, pAction);
        LocalStorage.set(LocalStorageKeys.DEBUG_INTENT_EXTRAS, pExtrasAsJsonString);
    }

    function refreshLocales() {
        $translate.refresh().then(function () {
            $ionicLoading.show({
                template: 'Locales refreshed',
                noBackdrop: true,
                duration: 1000
            });
        });
    }


    function localeTagModeChanged(pValue) {
        LocalStorage.set(LocalStorageKeys.DEBUG_SHOW_LOCALES_TAG, pValue);

        $translate.refresh().then(function () {
            $ionicLoading.show({
                template: 'Locales Tag Mode changed',
                noBackdrop: true,
                duration: 1000
            });
        });
    }

    function debugLoadingChanged(pValue) {
        LoadingUtil.showDebugLoading = pValue;
    }

    function policyOwnerChanged(pValue) {
        LocalStorage.setBoolean(LocalStorageKeys.LOGIN_POLICY_OWNER, pValue);
    }

    // START GIT VERISON


    function getGitVersion() {
        HttpProxy.get(GlobalConstants.BASE_URL + WebServiceUrls.GET_GIT_VERSION).then(onGitVersionSuccess, onGitVersionFail);
    }

    function onGitVersionSuccess(pResponse) {
        var serverVersion = StringUtil.format("Branch : {0}, Revision : {1}", pResponse.data.branch, pResponse.data.version.substring(0, 7));
        displayGitVersion(serverVersion);
    }

    function onGitVersionFail(pError) {
        var serverVersion = "Unable to reach " + WebServiceUrls.GET_GIT_VERSION;
        displayGitVersion(serverVersion);
    }


    function displayGitVersion(pGitServerVersion) {
        try {
            var infoFile = cordova.file.applicationDirectory;
            if (ionic.Platform.isIOS()) {
                infoFile = infoFile + 'www/';
            }
            var fileName = 'build.info';
            FileUtil.checkIfFileExist(infoFile, fileName)
                .then(function (response) {
                    FileUtil.readFile(infoFile, fileName)
                        .then(function (gitCommitCode) {
                            var text = "\n" + pGitServerVersion + "\n" + gitCommitCode;
                            LoggerUtil.log("DEBUG", text);
                            $scope.infoFile = text;
                        });

                }, function (error) {
                    var text = "\n" + pGitServerVersion + "\n" + 'Do not exist';
                    LoggerUtil.log("DEBUG", text);
                    $scope.infoFile = text;
                });
        } catch (e) {
            var text = "\n" + pGitServerVersion + "\n" + 'Do not exist';
            LoggerUtil.log("DEBUG", text);
            $scope.infoFile = text;
        }
    }
    // END GIT VERISON


    var mode = LocalStorage.get(LocalStorageKeys.APP_MODE);
    if (mode === ApplicationMode.CLIENT) {
        $scope.mode = ApplicationMode.TBYB;
    } else {
        $scope.mode = ApplicationMode.CLIENT;
    }

    function changeMode() {
        var mode = LocalStorage.get(LocalStorageKeys.APP_MODE);
        if (mode === ApplicationMode.CLIENT) {
            $scope.mode = ApplicationMode.CLIENT;
            LocalStorage.set(LocalStorageKeys.APP_MODE, ApplicationMode.TBYB);
        } else {
            $scope.mode = ApplicationMode.TBYB;
            LocalStorage.set(LocalStorageKeys.APP_MODE, ApplicationMode.CLIENT);
        }
    }
    setNotificationListner();
    setAccelListner();
    setBrakingListner();

    function setAccelListner() {
        ListenerUtil.registerListener('ACTION_ACCELERATION', null, acclerationCallBack);
    }

    function setBrakingListner() {
        ListenerUtil.registerListener('ACTION_DECELERATION', null, decelerationCallBack);
    }

    function setNotificationListner() {
        ListenerUtil.registerListener(BridgeIntentType.NOTIFICATION_LINK, null, notificationCallback);
    }

    function acclerationCallBack(info) {
        playAcc();
    }

    function decelerationCallBack(info) {
        playBrake();
    }

    function notificationCallback(info) {
        //Check if the user creds are available or not.
        //Auto login the user.
        //Redirect to detail trip page.
        $state.go('tab.detailedTrip');
        //alert(info);
    }

    function saveLogsIntent() {
        CordovaBroadcaster.setTelemetryLogs(true);
    }

    //         var deviceinfo=DeviceInfoUtil.getDeviceInfo();

}
