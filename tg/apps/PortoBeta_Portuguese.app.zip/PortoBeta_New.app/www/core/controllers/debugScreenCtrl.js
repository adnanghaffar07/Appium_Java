angular.module('controllers')
    .controller('DebugScreenCtrl', DebugScreenCtrl);

function DebugScreenCtrl($ionicHistory, $translate, $ionicLoading, $scope, LocalStorage, LocalStorageKeys, LoggerUtil, GlobalConstants) {
    $scope.goBack = goBack;
    $scope.clearLocalStorageClick = clearLocalStorageClick;
    $scope.showLocalStorage = showLocalStorage;
    $scope.closeLocalStorage = closeLocalStorage;
    $scope.showConsole = showConsole;
    $scope.closeConsole = closeConsole;
    $scope.showEnvironment = showEnvironment;
    $scope.closeEnvironment = closeEnvironment;
    $scope.enableDisableLocales = enableDisableLocales;

    $scope.$on("$ionicView.loaded", ionicViewLoaded);


    /*
        FUNCTION : ionicViewLoaded
    */
    function ionicViewLoaded() {
        verifyLocalStorage();
        verifyLocales();
    }

    /*
    FUNCTION : goBack
    RETURN TO PREVIOUS PAGE (SETTINGS)
    */
    function goBack() {
        console.log("TEST");
        $ionicHistory.goBack();
    }

    /*
        FUNCTION : clearLocalStorageClick
        CLEARS LOCAL STORAGE MEMORY
    */
    function clearLocalStorageClick() {
        window.localStorage.clear();
        verifyLocalStorage();
    }

    /*
        FUNCTION : showLocalStorage
        SHOWS THE LOCALSTORAGE OBJECT
    */
    function showLocalStorage() {
        $scope.localStorage = window.localStorage;
        $("#debug-localStorage").fadeIn(0);
    }

    /*
        FUNCTION : closeLocalStorage
        CLOSES THE LOCALSTORAGE OBJECT
    */
    function closeLocalStorage() {
        $("#debug-localStorage").fadeOut(0);
    }

    /*
        FUNCTION : showConsole
        SHOWS ALL THE LOGS IN A CONSOLE LIKE UI
    */
    function showConsole() {
        var rawLogs = LoggerUtil.getLogs();
        var array = rawLogs.split("\n");
        $scope.logs = array;
        $('#debug-console').fadeIn(0);
    }

    /*
        FUNCTION : closeConsole
        CLOSE THE LOGS WINDOW
    */
    function closeConsole() {
        $('#debug-console').fadeOut(0);
    }

    /*
        FUNCTION : verifyLocalStorage
        VERIFY IF THE LOCALSTORAGE OBJECT IS EMPTY
    */
    function verifyLocalStorage() {
        if (window.localStorage.length > 0) {
            $scope.lsFull = true;
        } else {
            $scope.lsFull = false;
        }
    }

    /*
        FUNCTION : showEnvironment
        SHOW URLS TO BE ABLE TO KNOW THE ENVIRONMENT WHICH APP IS CALLING
    */
    function showEnvironment() {
        $scope.environentUrls = {
            baseURL: GlobalConstants.BASE_URL,
            collectorURL: GlobalConstants.COLLECTOR_URL,
            collectorURLT2: GlobalConstants.COLLECTOR_URL_T2,
            zendeskUrl: GlobalConstants.ZENDESK_API
        };
        $("#debug-environment").fadeIn(0);
    }

    /*
        FUNCTION : closeEnvironment
        CLOSE ENVIRONMENT URLS WINDOW
    */
    function closeEnvironment() {
        $("#debug-environment").fadeOut(0);
    }

    /*
        FUNCTION : enableDisableLocales
        ENABLE OR DISABLE LOCALES IN APP SO WE CAN SEE THE L18N-KEY
    */
    function enableDisableLocales(pValue) {
        LocalStorage.set(LocalStorageKeys.DEBUG_SHOW_LOCALES_TAG, pValue);

        $translate.refresh().then(function () {
            $ionicLoading.show({
                template: 'Locales Tag Mode changed',
                noBackdrop: true,
                duration: 1000
            });
        });

        verifyLocales();
    }

    function verifyLocales() {
        $scope.showLocaleTags = (LocalStorage.get(LocalStorageKeys.DEBUG_SHOW_LOCALES_TAG) == "true");
    }
}
