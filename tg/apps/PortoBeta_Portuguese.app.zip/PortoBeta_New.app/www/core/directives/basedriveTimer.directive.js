angular.module('services').directive('basedriveTimer', function ($timeout, $translate) {
    return {
        restrict: 'A',
        link: function ($scope, element, attrs) { 

          console.log(attrs);

          var timer = new GoodTimer();
          var timer_access = $translate.instant('mission_access_in');
          
          function getTotalSeconds(time) {

              var new_time = time * 1000;

              var first = new Date();
              var second = new Date(new_time);

              var diference = parseInt((second.getTime() - first.getTime() ) / 1000);

              return diference;
          }

          var seconds = getTotalSeconds(attrs.timervalue);


          timer.init(0, seconds, function () {
            $(element).html(timer_access + ' ' + timer.getFromMaxTimeFormated(seconds));
          });
          
          timer.start();
        }
    };
});