angular.module('services').directive('basedriveHeart', function ($timeout) {
    return {
        restrict: 'A',
        link: function ($scope, element, attrs) { 

          var score = - (parseInt(attrs.size) / 100);
          var arrow;

          if (attrs.arrow !== undefined) {
            try {
              arrow = new ProgressBar.Path(attrs.arrow, {
                easing: 'easeInOut',
                duration: 400
              });
              arrow.animate(0);
            } catch(e) {

            }
          }

          var bar = new ProgressBar.Path(attrs.basedriveHeart, {
            easing: 'easeOut',
            duration: 1400
          });
          
          bar.animate(0);

          setTimeout(function() {
            bar.animate(score);
          },500);

          if (-score >= 0.96) {

            var number = 1;
            var time = 1350;

            if (-score < 1) { 
              number = 1 - ((score + 1 ) * 10 );
            }

            if (number < 1) {
              time = 1350 + (30 * ((1 - number) * 10));
            }
            setTimeout(function() {
              try {
                arrow.animate(number);
              } catch(e) {
              }
            }, time);
          }



        }
    };
});