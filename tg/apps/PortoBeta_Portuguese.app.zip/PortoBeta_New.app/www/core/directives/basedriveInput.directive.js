angular.module('services').directive('basedriveInput', function ($timeout) {
    return {
        restrict: 'A',
        link: function ($scope, element, attrs) { 
          element.on('click', function(event) { 
            $timeout(function () {
              $(element).find('input').focus();
            }, 500);
          });
        }
    };
});