angular.module('constants')
    .constant("DrivingModeOptions", [{
		className : 'driver',
		imgName : 'driver.png', 
		labelKey: 'dash_label_driver'
	},
	{
		className : 'passenger',
		imgName : 'passenger.png', 
		labelKey: 'dash_label_passenger'
	},
	{
		className : 'bus',
		imgName : 'bus.png', 
		labelKey: 'dash_label_bus'
	},
	{
		className : 'taxi',
		imgName : 'taxi.png', 
		labelKey: 'dash_label_taxi'
	},
	{
		className : 'plane',
		imgName : 'plane.png', 
		labelKey: 'dash_label_plane'
	},
	{
		className : 'bike',
		imgName : 'bike.png', 
		labelKey: 'dash_label_bike'
	},
	{
		className : 'walk',
		imgName : 'walk.png', 
		labelKey: 'dash_label_walk'
	},
	{
		className : 'boat',
		imgName : 'boat.png', 
		labelKey: 'dash_label_boat'
	},
	{
		className : 'motorcycle',
		imgName : 'motorcycle.png', 
		labelKey: 'dash_label_motorcycle'
	},
	{
		className : 'train',
		imgName : 'train.png', 
		labelKey: 'dash_label_train'
	},
	{
		className : 'other',
		imgName : 'other.png', 
		labelKey: 'dash_label_other'
	}
	]);