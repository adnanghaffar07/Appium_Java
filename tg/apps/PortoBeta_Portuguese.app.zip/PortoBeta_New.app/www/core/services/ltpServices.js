angular.module('services')
    .service('LtpServices', LtpServices);

function LtpServices($q, HttpProxy, GlobalConstants, WebServiceUrls) {

    this.linkToPolicy = linkToPolicy;
    this.smsValidation = smsValidation;
    this.validateCode = validateCode;

    /*
        Name : linkToPolicy
        Desc : Call Server and External server to verify policy information and link user to his policy
    */
    function linkToPolicy(pJsonParams) {
        var q = $q.defer();
        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.LINK_TO_POLICY, pJsonParams)
            .then(function (pResponse) {
                q.resolve(pResponse.data);
            }, function (error) {
                q.reject(error);
            });
        return q.promise;
    }

    /*
        Name : smsValidation
        Desc : Validate phone number and send SMS PIN
    */
    function smsValidation(pJsonParams) {
        var q = $q.defer();
        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.SMS_VALIDATION, pJsonParams)
            .then(function (pResponse) {
                q.resolve(pResponse.data);
            }, function (error) {
                q.reject(error);
            });
        return q.promise;
    }

    /*
        Name : validateCode
        Desc : Validate SMS PIN
    */
    function validateCode(pJsonParams) {
        var q = $q.defer();
        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.VALIDATE_CODE, pJsonParams)
            .then(function (pResponse) {
                q.resolve(pResponse.data);
            }, function (error) {
                q.reject(error);
            });
        return q.promise;
    }
}
