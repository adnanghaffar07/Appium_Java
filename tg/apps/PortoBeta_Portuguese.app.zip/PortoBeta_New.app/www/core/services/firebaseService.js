angular.module('services')
    .service('FirebaseService', FirebaseService);

function FirebaseService() {

    this.logEvent = logEvent;

    function logEvent(content, obj) {

        try {
            console.log("Trying to send " + content + " the object " + JSON.stringify(obj) + " to Firebase");

            window.FirebasePlugin.logEvent(content, obj, function(success) {
                console.log("Success Firebase " + success);
            }, function(error) {
                console.log("Error Firebase " + error);
            });
            
        } catch(e) {
            console.log("Error Firebase");
        }
    }
}
