angular.module('services')
    .factory('RegisterServices', RegisterServices);

function RegisterServices($q, HttpProxy, WebServiceUrls, GlobalConstants, ValidationUtil, LocalStorage, LocalStorageKeys) {

    function register(pEmail, pPassword, pLang) {
        var q = $q.defer();
        // Preparing call to WS
        var jsonParams = {
            User: {
                email: pEmail,
                password: pPassword,
                language: pLang
            }

        };
        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.REGISTER, jsonParams)
            .then(function (response) {
                    LocalStorage.set(LocalStorageKeys.LOGIN_EMAIL, pEmail);
                    LocalStorage.set(LocalStorageKeys.LOGIN_PASSWORD, pPassword);
                    q.resolve(response);
                },
                function (error) {
                    q.reject(error.data);
                });
        return q.promise;
    }

    return {
        register: register
    };
}
