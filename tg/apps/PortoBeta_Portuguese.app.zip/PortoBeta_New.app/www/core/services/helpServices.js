angular.module('services')
.factory('HelpServices',HelpServices);

function HelpServices($q,HttpProxy,WebServiceUrls, GlobalConstants){

	function getHelp(callback) {
        HttpProxy.get(GlobalConstants.BASE_URL + WebServiceUrls.GET_HELP, null, false)
            .then(function (response) {
                return callback(response);
            },
                function (err) {
                    return callback(null, err);
                });
    }
	function getfaqs(){
		   var q = $q.defer();
        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.GET_FAQS,null,false)
            .then(function (response) {
                q.resolve(response.data);
            }, function (error) {
                q.reject(error.data);
            });
        return q.promise;
	}
	function getTutorial(){
		   var q = $q.defer();
        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.GET_TUTORIALS,null,false)
            .then(function (response) {
                q.resolve(response.data);
            }, function (error) {
                q.reject(error.data);
            });
        return q.promise;
	}

	return {
		getHelp:getHelp,
		getfaqs:getfaqs,
		getTutorial:getTutorial
	};

};