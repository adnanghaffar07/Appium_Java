angular.module('services')
    .service('AssistancePlaceholderService', AssistancePlaceholderService);

function AssistancePlaceholderService($q, StringUtil, GlobalConstants, WebServiceUrls, ClientType) {

    this.get = get;

    function get(url, params) {
        var q = $q.defer();

        if (url === GlobalConstants.BASE_URL + WebServiceUrls.GET_ASSISTANCE_OPTIONS) {
            var response = {
                data: [
                    {
                        title: 'Roadside Assistance',
                        description: 'When calling, please be prepared to provide your vehicle Identification Number (VIN).',
                        type: 'phone',
                        action: '+552799999999',
                        order: 1
                    },
                    {
                        title: 'Claims Agent',
                        description: 'When calling, please be prepared to provide your vehicle Identification Number (VIN).',
                        type: 'website',
                        action: 'http://google.com.br/',
                        order: 2
                    },
                    {
                        title: 'Designated Driver',
                        description: 'One of our experienced drivers will chauffeur you and your guests to the final destination in your own vehicle. Once there, our second driver will depart with your chauffeur.',
                        type: 'email',
                        action: 'contact@google.com',
                        order: 3
                    }
                ]
            };

            q.resolve(response);
        } else {
            q.reject('invalid page');
        }

        return q.promise;
    }

}