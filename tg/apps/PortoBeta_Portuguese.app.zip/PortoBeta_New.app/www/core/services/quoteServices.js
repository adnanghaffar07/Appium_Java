angular.module('services')
    .factory('QuoteServices', function ($q, $http, $rootScope, $timeout, WebServiceUrls, GlobalConstants, PlaceholderServices, HttpProxy, LocalStorage, LocalStorageKeys) {
        return {
            getQuotes: function () {
                var UID = LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID);
                var q = $q.defer();
                HttpProxy.get(GlobalConstants.PAS_URL + WebServiceUrls.APPLICATION_USERS + UID + WebServiceUrls.CREATE_QUOTE).then(function (response) {
                    q.resolve(response);
                }, function (error) {
                    q.reject(error.data);
                });
                return q.promise;
            },
            getQuote: function (quoteId) {
                var q = $q.defer();
                HttpProxy.get(GlobalConstants.PAS_URL + WebServiceUrls.CREATE_QUOTE + "/" + quoteId).then(function (response) {
                    q.resolve(response);
                }, function (error) {
                    q.reject(error.data);
                });
                return q.promise;
            },
            deleteQuote: function (quoteid) {
                var q = $q.defer();
                HttpProxy.delete(GlobalConstants.PAS_URL + WebServiceUrls.CREATE_QUOTE + '/' + quoteid).then(function (response) {
                    q.resolve(response);
                }, function (error) {
                    q.reject(error.data);
                });
                return q.promise;
            },
            createQuote: function (quote) {
                var q = $q.defer();
                HttpProxy.post(GlobalConstants.PAS_URL + WebServiceUrls.CREATE_QUOTE, quote).then(function (response) {
                    q.resolve(response);
                }, function (error) {
                    q.reject(error.data);
                });
                return q.promise;
            },
            getQuotePricePerMileRatings: function () {
                var q = $q.defer();
                var quote_id = '/' + LocalStorage.getObject(LocalStorageKeys.QUOTE_ID);
                HttpProxy.get(GlobalConstants.PAS_URL + WebServiceUrls.CREATE_QUOTE + quote_id).then(function (response) {
                    q.resolve(response);
                }, function (error) {
                    q.reject(error.data);
                });
                return q.promise;
            },
            purchaseQuote: function (paymentDetails) {
                var q = $q.defer();
                var quote_id = '/' + LocalStorage.getObject(LocalStorageKeys.QUOTE_ID);
                HttpProxy.post(GlobalConstants.PAS_URL + WebServiceUrls.CREATE_QUOTE + quote_id + WebServiceUrls.QUOTE_PURCHASE, paymentDetails).then(function (response) {
                    q.resolve(response);
                }, function (error) {
                    q.reject(error.data);
                });
                return q.promise;
            },
            getPremiums: function () {
                var q = $q.defer();
                HttpProxy.get(GlobalConstants.PAS_URL + WebServiceUrls.PAS_BILLING + WebServiceUrls.PREMIUMS).then(function (response) {
                    q.resolve(response);
                }, function (error) {
                    q.reject(error.data);
                });
                return q.promise;
            },
            getInsurances: function () {
                var q = $q.defer();
                HttpProxy.get(GlobalConstants.PAS_URL + WebServiceUrls.APPLICATION + WebServiceUrls.INSURANCES).then(function (response) {
                    q.resolve(response);
                }, function (error) {
                    q.reject(error.data);
                });
                return q.promise;
            },
            saveQuoteSimulations: function (quoteId, insuranceDetails) {
                var q = $q.defer();
                HttpProxy.post(GlobalConstants.PAS_URL + WebServiceUrls.CREATE_QUOTE + '/'+quoteId + WebServiceUrls.QUOTE_SIMULATIONS, insuranceDetails).then(function (response) {
                    q.resolve(response);
                }, function (error) {
                    q.reject(error.data);
                });
                return q.promise;
            },
            logQuote: function (quote) {
                var q = $q.defer();
                HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.GAQ_LOG, quote).then(function (response) {
                    q.resolve(response);
                }, function (error) {
                    q.reject(error.data);
                });
                return q.promise;
            }
        }
    });
