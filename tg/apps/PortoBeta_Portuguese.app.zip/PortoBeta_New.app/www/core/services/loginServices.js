angular.module('services')
    .service('LoginServices', LoginServices);

function LoginServices($q, $rootScope, $ionicHistory, HttpProxy, OfflineLoginFactory, SocialConstants, SocialUserService, PushNotificationUtil, LocalStorage, WebServiceUrls, DeviceFactory, CordovaBroadcaster, ErrorType, GlobalConstants, LocalStorageKeys, ScoresUtil, AppConfigServices, BooleanConstant, LoginType, ApiErrorCode, CommunicationService, ListenerUtil, BannerType, ApplicationStateManager) {

    this.login = login; // return the sessionId calls the LoginServices
    this.logout = logout; // deletes session server side
    this.forgotPassword = forgotPassword;
    this.changePassword = changePassword;
    this.facebookLogin = facebookLogin;
    this.googleLogin = googleLogin;
    this.forgotPasswordNew = forgotPasswordNew;
    this.sendUserInformation = sendUserInformation;
    this.setDeviceEndPoint = setDeviceEndPoint;
    this.getCreationDate = getCreationDate;
    this.registerForPushNotification = registerForPushNotification;
    this.loginPas = loginPas;

    function loginPas(jsonParams) {
        var q = $q.defer();

        HttpProxy.post(GlobalConstants.PAS_URL + WebServiceUrls.PAS_LOGIN, jsonParams).then(function (response) {
            q.resolve(response.data);
        }, function (error) {
            q.reject(error.data);
        });
        return q.promise;
    }

    function login(pEmail, pPass, pMode) {
        var q = $q.defer();
        // Preparing call to WS
        var jsonParams = {
            mode: pMode,
            User: {
                email: pEmail,
                password: pPass,
                mode: pMode,
                first_login: true
            }
        };

        // Call to WS
        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.LOGIN, jsonParams)
            .then(function (response) {
                    registerForPushNotification();
                    // if new user -> clear avatar.
                    if (LocalStorage.get(LocalStorageKeys.LOGIN_EMAIL, pEmail) != pEmail) {
                        HttpProxy.clearLocalData();
                        LocalStorage.clear(LocalStorageKeys.TBYB_CREATION_TIMESTAMP);
                        LocalStorage.clear(LocalStorageKeys.LAST_LOGIN_TIMESTAMP);
                    }
                    HttpProxy.setDataLocal(response.data.application_type_id, response, pEmail, pPass);
                    OfflineLoginFactory.saveLoginCredentials(response.data.application_type_id, pEmail, pPass);
                    sendUserInformation();
                    //ApplicationStateManager.playBLEEvent();

                    q.resolve(response);
                },
                function (pError) {
                    if (pError.data.api_error_code == ApiErrorCode.CONSENT_REQUIRED) {
                        if (pError.hasOwnProperty("headers")) {
                            var token = pError.headers('Set-token');
                            if (token) {
                                HttpProxy.setDataLocal(pMode, pError, pEmail, pPass);
                            }
                        }
                    }
                    q.reject(pError);

                });
        return q.promise;
    }

    function sendUserInformation() {

        DeviceFactory.getDevices()
            .then(function (pDevices) {
                LocalStorage.set(LocalStorageKeys.DEVICE_TYPE, pDevices[0].Device.DeviceModel.type);
                CordovaBroadcaster.sendUserInformation(
                    LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID),
                    LocalStorage.get(LocalStorageKeys.USER_TOKEN),
                    pDevices);

            }, function (pError) {
                CordovaBroadcaster.sendUserInformation(
                    LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID),
                    LocalStorage.get(LocalStorageKeys.USER_TOKEN),
                    null);
            });
        loadCommunicationOptions();
    }

    function loadCommunicationOptions() {
        CommunicationService.getCommunicationOptions().then(function (pResponse) {
            console.log('data2', pResponse);
            var vrOptions = {};
            if (Object.keys(pResponse.data).length > 0) {
                vrOptions = pResponse.data;
            }

            vrOptions.score = vrOptions.score == BooleanConstant.FALSE ? false : true;
            vrOptions.hac = vrOptions.hac == BooleanConstant.FALSE ? false : true;
            vrOptions.hbr = vrOptions.hbr == BooleanConstant.FALSE ? false : true;
            vrOptions.osp = vrOptions.osp == BooleanConstant.FALSE ? false : true;
            CordovaBroadcaster.updateTripProcessNotification(vrOptions.score, vrOptions.hac, vrOptions.osp, vrOptions.hbr);
        }, function (pError) {
            console.log("~Error in fetching communication options.");
        });
    }

    function registerForPushNotification() {
        PushNotificationUtil.register().then(function (reponse) {
                var deviceType = 'android';
                if (ionic.Platform.isIOS()) {
                    deviceType = 'ios';
                }
                console.log(reponse);
                var registrationId = reponse;
                setDeviceEndPoint(registrationId, deviceType).then(function (response) {
                    //                    //alert(response);
                    //                    //TODO something
                }, function (error) {
                    //                    //alert(error);
                    //                    //TODO something.
                });
            },
            function (error) {
                //alert(error + JSON.stringify(error));
            });
    }

    function forgotPassword(pEmail, pCallback) {
        var scope = this;
        if (!pEmail) {
            var error = {
                'i18n-key': 'invalidEmail'
            };
            return pCallback(error);
        }

        var jsonParams = {};
        jsonParams['email'] = pEmail;
        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.FORGOT_PASSWORD, jsonParams)
            .then(function (response) {
                    return pCallback(null, response.data);
                },
                function (error) {
                    return pCallback(error.data);
                    return false;
                });
    }

    function forgotPasswordNew(pEmail) {
        var q = $q.defer();
        var jsonParams = {};
        jsonParams['email'] = pEmail;
        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.FORGOT_PASSWORD, jsonParams)
            .then(function (response) {
                    // HttpProxy.clearLocalData();
                    //CordovaBroadcaster.clearUserInformation();
                    q.resolve(response);
                },
                function (error) {
                    q.reject(error);

                });
        return q.promise;

    }

    function changePassword(oldPassword, newPassword) {
        var q = $q.defer();
        var scope = this;
        if (!oldPassword || !newPassword) {
            var error = {
                'i18n-key': 'allFieldsMandatory'
            };
            q.reject(error);
        }
        var jsonParams = {};
        jsonParams['old_password'] = oldPassword;
        jsonParams['new_password'] = newPassword;
        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.MODIFY_PASSWORD, jsonParams)
            .then(function (response) {
                    //if (ScoresUtil.validateServerStatus(response.data.code, true)) {
                    q.resolve(response.data);
                    //}
                },
                function (error) {
                    q.reject(error.data);

                });
        return q.promise;
    }

    function logout() {
        var q = $q.defer();
        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.LOGOUT)
            .then(function (response) {

                    var isBrowser = LocalStorage.get(LocalStorageKeys.IS_IN_BROWSER);
                    var appVersion;

                    if (isBrowser == "false") {
                        appVersion = LocalStorage.get(LocalStorageKeys.BUILD_NUMBER);
                    }

                    $ionicHistory.clearCache();
                    PushNotificationUtil.unregister();
                    checkifGoogle();
                    HttpProxy.clearLocalData();
                    CordovaBroadcaster.clearUserInformation();
                    SocialUserService.logoutGoolge("");

                    if (appVersion) {
                        LocalStorage.set(LocalStorageKeys.IS_IN_BROWSER, isBrowser);
                        LocalStorage.set(LocalStorageKeys.BUILD_NUMBER, appVersion);
                    }

                    q.resolve(response);
                },
                function (error) {
                    q.reject(error);

                });
        return q.promise;
    }

    function facebookLogin(jsonParams) {
        var q = $q.defer();
        AppConfigServices.getConfigValue("register_require_display_name")
            .then(function (result) {
                    if (result == BooleanConstant.TRUE) {
                        jsonParams.User["display_name"] = "";
                    }
                    HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.FACEBOOK_LOGIN, jsonParams)
                        .then(function (response) {
                                registerForPushNotification();
                                // if new user -> clear avatar.
                                if (LocalStorage.get(LocalStorageKeys.LOGIN_EMAIL, jsonParams.User["email"]) != jsonParams.User["email"]) {
                                    HttpProxy.clearLocalData();
                                    LocalStorage.clear(LocalStorageKeys.TBYB_CREATION_TIMESTAMP);
                                    LocalStorage.clear(LocalStorageKeys.LAST_LOGIN_TIMESTAMP);
                                }
                                sendUserInformation();

                                HttpProxy.setDataLocal(response.data.application_type_id, response, jsonParams.User.email);
                                OfflineLoginFactory.saveLoginCredentials(response.data.application_type_id, jsonParams.User.email, "");

                                //LocalStorage.set(LocalStorageKeys.LOGIN_USER_ID, response.data.accountId);
                                q.resolve(response.data);
                            },
                            function (error) {
                                if (error.hasOwnProperty("headers")) {
                                    var token = error.headers('Set-token');
                                    if (token) {
                                        HttpProxy.setDataLocal(LoginType.TBYB_RB, error, jsonParams.email);
                                    }
                                }
                                q.reject(error);
                            });
                },
                function (error) {
                    q.reject(error);
                }
            );

        return q.promise;
    }

    function googleLogin(jsonParams) {
        var q = $q.defer();
        AppConfigServices.getConfigValue("register_require_display_name")
            .then(function (result) {
                    if (result == BooleanConstant.TRUE) {
                        jsonParams.User["display_name"] = "";
                    }
                    HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.GOOGLE_LOGIN, jsonParams)
                        .then(function (response) {
                                registerForPushNotification();
                                // if new user -> clear avatar.
                                if (LocalStorage.get(LocalStorageKeys.LOGIN_EMAIL, jsonParams.User["email"]) != jsonParams.User["email"]) {
                                    HttpProxy.clearLocalData();
                                    LocalStorage.clear(LocalStorageKeys.TBYB_CREATION_TIMESTAMP);
                                    LocalStorage.clear(LocalStorageKeys.LAST_LOGIN_TIMESTAMP);
                                }
                                sendUserInformation();
                                HttpProxy.setDataLocal(response.data.application_type_id, response, jsonParams.User.email);
                                OfflineLoginFactory.saveLoginCredentials(response.data.application_type_id, jsonParams.User.email, "");
                                q.resolve(response.data);
                            },
                            function (error) {
                                if (error.hasOwnProperty("headers")) {
                                    var token = error.headers('Set-token');
                                    if (token) {
                                        HttpProxy.setDataLocal(LoginType.TBYB_RB, error, jsonParams.email);
                                    }
                                }
                                q.reject(error);
                            });

                },
                function (error) {
                    q.reject(error);
                }
            );

        return q.promise;
    }

    function setDeviceEndPoint(deviceID, deviceType) {
        var jsonParams = {
            'device_registration_id': deviceID,
            'device_type': deviceType
        };
        var q = $q.defer();
        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.SET_AWS_END_POINT, jsonParams)
            .then(function (response) {
                q.resolve(response.data);
            }, function (error) {
                q.reject(error.data);
            });
        return q.promise;
    }

    function checkifGoogle() {
        //var flag = LocalStorage.get(LocalStorageKeys.LOGIN_TYPE);
        var token = LocalStorage.get(LocalStorageKeys.ACCESS_TOKEN, "");
        if (token.length > 0 && token != "null" && token != "") {
            console.log("TOKEN G+", token, token.length > 0 && token != "null" && token != "");
            SocialUserService.logoutGoolge(token);
        }
    }

    function getCreationDate() {
        var q = $q.defer();
        HttpProxy.get(GlobalConstants.BASE_URL + WebServiceUrls.GET_CREATION_DATE).then(function (response) {
            q.resolve(response.data);
        }, function (error) {
            q.reject(error.data);
        });
        return q.promise;
    }
}
