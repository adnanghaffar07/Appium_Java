angular.module('services')
    .service('TelemetryServices', TelemetryServices);

function TelemetryServices($q, HttpProxy, GlobalConstants, WebServiceUrls) {

    this.getDevices = getDevices;

    function getDevices() {
        var q = $q.defer();
        HttpProxy.get(GlobalConstants.BASE_URL + WebServiceUrls.GET_DEVICES)
            .then(function (pResponse) {
                mDevices = pResponse.data;
                q.resolve(pResponse.data);
            }, function (error) {
                q.reject(error);
            });
        return q.promise;
    }

}
