angular.module('services')
    .factory('LeaderBoardServices', LeaderBoardServices);

function LeaderBoardServices(HttpProxy, $q, GlobalConstants, WebServiceUrls) {
    return {
        getGeneralRankings: function (pCallback, searchtext) {
            var jsonParams = {
                search: searchtext
            };

            HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.GET_GENERAL_RANKINGS, jsonParams).then(function (response) {
                    return pCallback(response.data);
                },
                function (err) {
                    return pCallback(null, err);
                });
        },
        getLeaderBoard: function (ltype, pagervalue) {
            var q = $q.defer();
            var jsonParams = {
                type: ltype
            };
            var pager = "/page:" + pagervalue;
            HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.GET_GENERAL_RANKINGS + pager, jsonParams).then(function (response) {
                    q.resolve(response.data);
                },
                function (err) {
                    q.reject(err.data);
                });
            return q.promise;
        },
        getLeaderBoardUsers: function () {
            var q = $q.defer();
            HttpProxy.get(GlobalConstants.BASE_URL + WebServiceUrls.GET_LEADERBOARD_USERS).then(function (response) {
                    q.resolve(response.data);
                },
                function (err) {
                    q.reject(err.data);
                });
            return q.promise;
        },
        addFriend: function (id) {
            var q = $q.defer();
            var jsonParams = {
                favorite_user_id: id
            };
            HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.ADD_FAVORITE, jsonParams).then(function (response) {
                q.resolve(response.data);
            },
                function (err) {
                    q.reject(err.data);
                });
            return q.promise;
        },
        removeFriend: function (id) {
            var q = $q.defer();
            var jsonParams = {
                favorite_user_id: id
            };
            HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.REMOVE_FAVORITE, jsonParams).then(function (response) {
                q.resolve(response.data);
            },
                function (err) {
                    q.reject(err.data);
                });
            return q.promise;
        },
        getFriendsList: function (pagervalue) {
            var q = $q.defer();
            var pager = "/page:" + pagervalue;
            HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.GET_FAVORITES+pager).then(function (response) {
                q.resolve(response.data);
            },
                function (err) {
                    q.reject(err.data);
                });
            return q.promise;
        },
        searchFavorites:function (searchText,pagerval) {
            var q = $q.defer();
            var jsonParams = {
                user_text: searchText
            };
            var pager = "/page:"+pagerval;// + pagervalue;
            HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.SEARCH_FAVORITES+pager,jsonParams).then(function (response) {
                q.resolve(response.data);
            },
                function (err) {
                    q.reject(err.data);
                });
            return q.promise;
        },
        inviteFriend: function (username) {
            var q = $q.defer();
            var jsonParams = {
                username: username
            };
            HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.INVITE_FRIEND, jsonParams).then(function (response) {
                    q.resolve(response.data);
                },
                function (err) {
                    q.reject(err.data);
                });
            return q.promise;
        },
        getInvites: function (status) {
            var q = $q.defer();
            HttpProxy.get(GlobalConstants.BASE_URL + WebServiceUrls.GET_INVITES).then(function (response) {
                    q.resolve(response.data);
                },
                function (err) {
                    q.reject(err.data);
                });
            return q.promise;
        },
        invitationStatus: function (status) {
            var q = $q.defer();
            var jsonParams = {
                invite_accepted: status
            };
            HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.INVITATION_STATUS, jsonParams).then(function (response) {
                    q.resolve(response.data);
                },
                function (err) {
                    q.reject(err.data);
                });
            return q.promise;
        },
        addFavorite: function (userid) {
            var q = $q.defer();
            // Preparing call to WS
            var jsonParams = {
                favorite_user_id: userid
            };
            HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.ADD_FAVORITE, jsonParams)
                .then(function (response) {
                        q.resolve(response);
                    },
                    function (error) {
                        q.reject(error);
                    });
            return q.promise;
        },
        removeFavorite: function (userid) {
            var q = $q.defer();
            // Preparing call to WS
            var jsonParams = {
                favorite_user_id: userid
            };
            HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.REMOVE_FAVORITE, jsonParams)
                .then(function (response) {
                        q.resolve(response);
                    },
                    function (error) {
                        q.reject(error);
                    });
            return q.promise;
        },
        getFavorites: function (isWithScore) {
            var q = $q.defer();
            HttpProxy.get(GlobalConstants.BASE_URL + WebServiceUrls.GET_FAVORITES).then(function (response) {
                q.resolve(response);
            }, function (error) {
                q.reject(error);
            });
            return q.promise;
        },
        getFavoriteRankings: function (pCallback, searchtext) {
            var jsonParams = {
                search: searchtext
            };
            HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.GET_FAVORITE_RANKINGS, jsonParams).then(function (response) {
                    return pCallback(response.data);
                },
                function (err) {
                    return pCallback(null, err);
                });
        }
    };
}
