angular.module('services')
    .factory('AppDocumentServices', AppDocumentServices);

function AppDocumentServices($q, HttpProxy, GlobalConstants, WebServiceUrls) {

    function getDocument(documentName) {
        var q = $q.defer();
        var url = GlobalConstants.BASE_URL + WebServiceUrls.GET_DOCUMENT + '/' + documentName;
        HttpProxy.get(url)
            .then(function (response) {
                    q.resolve(response.data);
                },
                function (error) {
                    q.reject(error.data);
                }
            );
        return q.promise;
    }

    function getAllDocuments() {
        var q = $q.defer();
        HttpProxy.get(GlobalConstants.BASE_URL + WebServiceUrls.GET_ALL_DOCUMENTS, null, true)
            .then(function (response) {
                q.resolve(response.data);
            }, function (error) {
                q.reject(error.data);
            });

        return q.promise;
    }

    function getImages(pTag) {
        var q = $q.defer();

        var jsonParams = {
            tag: pTag
        };

        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.GET_IMAGES, jsonParams, false)
            .then(function (response) {
                // success
                q.resolve(response.data);
            }, function (error) {
                // fail
                q.reject(error.data);
            });

        return q.promise;
    }

    return {
        getDocument: getDocument,
        getAllDocuments: getAllDocuments,
        getImages: getImages
    };
}
