angular.module('services')
    .service('ConsentServices', ConsentServices);

function ConsentServices(HttpProxy, WebServiceUrls, GlobalConstants, ConsentStatus) {

    this.getAppDocument = getAppDocument;
    this.recordConsent = recordConsent;

    function getAppDocument(pDocumentId) {
        return HttpProxy.get(GlobalConstants.BASE_URL + WebServiceUrls.GET_DOCUMENT + "/" + pDocumentId);
    }

    function recordConsent(pStatus, appdocumentid, pCallBack) {
        var url = GlobalConstants.BASE_URL + WebServiceUrls.RECORD_CONSENT;
        // Preparing call to WS
        var jsonParams = {
            app_document_id: appdocumentid,
            accepted: pStatus
        };

        HttpProxy.post(url, jsonParams, false).then(function (response) {
                return pCallBack(null);
            },
            function (pError) {
                return pCallBack(pError);
            });
    }
}
