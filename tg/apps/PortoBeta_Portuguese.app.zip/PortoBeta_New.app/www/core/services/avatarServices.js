angular.module('services')
    .service('AvatarServices', AvatarServices);

function AvatarServices($q, HttpProxy, AvatarCache, GlobalConstants, WebServiceUrls) {
    this.getAvatar = getAvatar;
    this.setAvatar = setAvatar;

    function getAvatar(pUserName) {
        return AvatarCache.getAvatar(pUserName);
    }

    function setAvatar(pM, pA) {
        var q = $q.defer();
        var jsonParams = {
            avatar: pA
        };
        if (pM) {
            jsonParams['mode'] = pM;
        }

        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.UPDATE_AVATAR, jsonParams)
            .then(function (response) {
                q.resolve(response);
            }, function (error) {
                q.reject(error);
            });

        return q.promise;
    }
}
