angular.module('services')
    .service('FaqPlaceholderService', FaqPlaceholderService);

function FaqPlaceholderService($q, StringUtil, GlobalConstants, WebServiceUrls, ClientType) {

    this.get = get;

    function get(url, params) {
        var q = $q.defer();

        if (url === GlobalConstants.BASE_URL + WebServiceUrls.GET_FAQS) {
            var imagePath = "./client/images/faq-icons/";
            var imageType = ".png";
            var response = {
                data: [
                    {
                        slug: 'information_management',
                        icon: imagePath + '1' + imageType,
                        articles: [
                            'faq_information_management_1',
                            'faq_information_management_2',
                            'faq_information_management_3',
                            'faq_information_management_4',
                            'faq_information_management_5'
                        ]
                    },
                    {
                        slug: 'program_details',
                        icon: imagePath + '2' + imageType,
                        articles: [
                            'faq_program_details_1',
                            'faq_program_details_2',
                            'faq_program_details_3',
                            'faq_program_details_4',
                            'faq_program_details_5',
                            'faq_program_details_6'
                        ]
                    },
                    {
                        slug: 'technical_support',
                        icon: imagePath + '3' + imageType,
                        articles: [
                            'faq_technical_support_1',
                            'faq_technical_support_2',
                            'faq_technical_support_3'
                        ]
                    },
                    {
                        slug: 'insurance_savings',
                        icon: imagePath + '4' + imageType,
                        articles: [
                            'faq_insurance_savings_1',
                            'faq_insurance_savings_2',
                            'faq_insurance_savings_3',
                            'faq_insurance_savings_4'
                        ]
                    },
                    {
                            slug: 'register_information',
                        icon: imagePath + '5' + imageType,
                        articles: [
                            'faq_register_information_1',
                            'faq_register_information_2',
                            'faq_register_information_3',
                            'faq_register_information_4'
                        ]
                    }//,
                    // {
                    //     slug: 'personal_privacy',
                    //     icon: imagePath + '6' + imageType,
                    //     articles: []
                    // },
                    // {
                    //     slug: 'insurance',
                    //     icon: imagePath + '7' + imageType,
                    //     articles: []
                    // }
                ]
            };

            q.resolve(response);
        } else {
            q.reject('invalid page');
        }

        return q.promise;
    }

}