﻿angular.module('services')
    .factory('PrizesServices', PrizesServices);

function PrizesServices($timeout, HttpProxy, $q, GlobalConstants, WebServiceUrls, LocalStorage, LocalStorageKeys,PlaceholderServices) {
    return {
        getActiveChallenges: function () {
             var q = $q.defer();
            HttpProxy.get(GlobalConstants.BASE_URL + WebServiceUrls.GET_ACTIVE_CHALLENGES,null,false).then(function (response) {
                return q.resolve(response.data);
            },
                function (err) {
                    return q.reject(err.data);
                });
            return q.promise;
        },
        getWonChallenges: function () {
             var q = $q.defer();
            HttpProxy.get(GlobalConstants.BASE_URL + WebServiceUrls.GET_WON_CHALLENGES,null,false).then(function (response) {
                return q.resolve(response.data);
            },
                function (err) {
                    return q.reject(err.data);
                });
            return q.promise;
        },
        getLostChallenges: function () {
             var q = $q.defer();
            HttpProxy.get(GlobalConstants.BASE_URL + WebServiceUrls.GET_LOST_CHALLENGES,null,false).then(function (response) {
                return q.resolve(response.data);
            },
                function (err) {
                    return q.reject(err.data);
                });
            return q.promise;
        },
        getModifiedContests:function(pCallback,modifieddate){          
               var jsonParams = {"modified" : modifieddate};
            
       HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.GET_MODIFIED_CONTESTS,jsonParams).then(function (response) {
                return pCallback(response.data);
            },
        function (err) {
            return pCallback(null, err);
        });
            
        },     
        getNewContestNotif:function(lastcontestid){
            var q = $q.defer();
            var jsonParams = {"lastContestId" : lastcontestid};
               HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.GET_NEW_CONTEST_NOTIF,jsonParams).then(function (response) {
                q.resolve(response.data);
                }
                , function (error) {
                q.reject(error);
                });
               return q.promise;
        },
        getChallengeDetails:function(contestid){
            var q = $q.defer();
            var jsonParams = {"challenge_id":contestid};
            HttpProxy.post(GlobalConstants.BASE_URL+WebServiceUrls.GET_CHALLENGE_DETAILS,jsonParams).then(function(response){
                q.resolve(response.data);
            },function(error){
                q.reject(error);
            });
            return q.promise;            
        },
        deleteLostChallenge:function(contestid){
            var q = $q.defer();
            var jsonParams = {"challenge_id":contestid};
            HttpProxy.post(GlobalConstants.BASE_URL+WebServiceUrls.HIDE_CHALLENGE,jsonParams).then(function(response){
                q.resolve(response.data);
            },function(error){
                q.reject(error);
            });
            return q.promise;            
        }
    };
}