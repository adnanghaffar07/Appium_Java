angular.module('services')
    .service("AppSetupServices", AppSetupServices);

function AppSetupServices($q, HttpProxy, GlobalConstants, WebServiceUrls, PlaceholderServices) {
    this.getThemeColors = getThemeColors;

    function getThemeColors() {
        var q = $q.defer();

        PlaceholderServices.get(GlobalConstants.BASE_URL + WebServiceUrls.GET_THEME_COLORS).then(function (data) {
            q.resolve(data);
        });

        return q.promise;
    }
}
