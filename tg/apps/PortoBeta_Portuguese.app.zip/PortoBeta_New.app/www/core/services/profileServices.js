angular.module('services')
    .service('ProfileServices', ProfileServices);

function ProfileServices($q, LocalStorage, LocalStorageKeys, HttpProxy, GlobalConstants, WebServiceUrls, TokenConstants, PlaceholderServices) {

    this.setVehicleProfile = setVehicleProfile;
    this.setGeneralProfile = setGeneralProfile;
    this.getPersonalProfile = getPersonalProfile;
    this.setPersonalProfile = setPersonalProfile;
    this.getVehicleMakeYear = getVehicleMakeYear;
    this.getVehicleMake = getVehicleMake;
    this.getVehicleModel = getVehicleModel;
    this.saveProfile = saveProfile;
    this.getVehicleInfoByVIN = getVehicleInfoByVIN;
    this.getStatesList = getStatesList;
    this.setExtraDataGPlus = setExtraDataGPlus;
    this.getProfileData_tbyb = getProfileData_tbyb;
    this.getProfileData_client = getProfileData_client;
    this.getVehicleTypes = getVehicleTypes;
    this.getVehicleMoreDetails = getVehicleMoreDetails;
    this.getPrimaryVehicles = getPrimaryVehicles;
    this.getAnnualKMs = getAnnualKMs;
    this.getDistanceDriven = getDistanceDriven;
    this.getTypeOfAccidents = getTypeOfAccidents;
    this.linkFacebookProfile = linkFacebookProfile;
    this.disconnectFacebook = disconnectFacebook;
    this.getProfile = getProfile;
    this.getDriverTypes = getDriverTypes;
    this.getMaritalStatus = getMaritalStatus;
    this.setPhoneInfo = setPhoneInfo;

    function saveProfile(pMode, profileData) {
        var q = $q.defer();
        var jsonParams = {
            "mode": pMode,
            "User": profileData.user,
            //"Address": profileData.Address,
            "Insurance": profileData.Insurance,
        };
        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.SET_PROFILE, jsonParams)
            .then(function (response) {
                    q.resolve(response.data);
                },
                function (error) {
                    q.reject(error);
                });
        return q.promise;
    }

    function getProfile() {
        var q = $q.defer();
        HttpProxy.get(GlobalConstants.BASE_URL + WebServiceUrls.GET_PROFILE)
            .then(function (response) {
                    LocalStorage.set(LocalStorageKeys.PROFILE_CREATION_DATE, moment(response.data.User.created));
                    q.resolve(response.data);
                },
                function (error) {
                    q.reject(error.data);
                });
        return q.promise;
    }

    function setVehicleProfile(vehicledata, pCallback) {
        var q = $q.defer();
        var jsonParams = {
            'VehicleProfile': vehicledata

        };
        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.SET_VEHICLE_PROFILE, jsonParams)
            .then(function (response) {
                    q.resolve(response.data);
                },
                function (error) {
                    q.reject(error.data);
                });
        return q.promise;
    }

    function setGeneralProfile(generalData, userData) {
        var q = $q.defer();
        var jsonParams = {
            'GeneralProfile': generalData,
            'User': userData
        };
        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.SET_GENERAL_PROFILE, jsonParams)
            .then(function (response) {
                    q.resolve(response.data);
                },
                function (error) {
                    q.reject(error.data);
                });
        return q.promise;
    }

    function getPersonalProfile(pCache) {
        var q = $q.defer();
        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.GET_PERSONAL_PROFILE, null, pCache)
            .then(function (response) {
                    q.resolve(response.data);
                },
                function (error) {
                    q.reject(error.data);
                });
        return q.promise;
    }

    function setPersonalProfile(personalData, userData) {
        var q = $q.defer();
        var url = GlobalConstants.BASE_URL + WebServiceUrls.SET_PERSONAL_PROFILE;
        var jsonParams = {};
        if (personalData) {
            jsonParams['PersonalProfile'] = personalData;
        }
        if (userData) {
            jsonParams['User'] = userData;
        }

        HttpProxy.post(url, jsonParams).then(function (response) {
                q.resolve(response.data);
            },
            function (error) {
                q.reject(error.data);
            });
        return q.promise;
    };

    function getVehicleMakeYear() {
        var q = $q.defer();
        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.GET_VEHICLE_YEARS, null)
            .then(function (response) {
                    q.resolve(response.data);
                },
                function (error) {
                    q.reject(error.data);
                });
        return q.promise;
    }

    function getVehicleMake(year) {
        var q = $q.defer();
        var url = GlobalConstants.BASE_URL + WebServiceUrls.GET_VEHICLE_MAKE;
        var jsonParams = {
            year: year
        };
        HttpProxy.post(url, jsonParams).then(function (response) {
                q.resolve(response.data);
            },
            function (error) {
                q.reject(error.data);
            });
        return q.promise;
    }

    function getVehicleModel(year, make) {
        var q = $q.defer();
        var jsonParams = {
            year: year,
            make: make
        };
        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.GET_VEHICLE_MODELS, jsonParams)
            .then(function (response) {
                    q.resolve(response.data);
                },
                function (error) {
                    q.reject(error.data);
                });
        return q.promise;
    }

    function getVehicleInfoByVIN(vin) {
        var q = $q.defer();
        var jsonParams = {
            vin: vin
        };
        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.GET_VEHICLEINFO_BY_VIN, jsonParams)
            .then(function (response) {
                    q.resolve(response.data);
                },
                function (error) {
                    q.reject(error);
                });
        return q.promise;
    }

    function getStatesList(pCountry) {
        var jsonParams = {
            country_name: pCountry
        };
        var q = $q.defer();
        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.GET_STATES_LIST, jsonParams)
            .then(function (response) {
                    q.resolve(response.data);
                },
                function (error) {
                    q.reject(error);
                });
        return q.promise;
    }

    function setExtraDataGPlus(gplusaccesstoken, gplusrefreshtoken, email) {
        var q = $q.defer();
        var jsonParams = [{
            prop_name: TokenConstants.G_ACCESS_TOKEN_CONS,
            prop_value: gplusaccesstoken
        }, {
            prop_name: TokenConstants.G_REFRESH_TOKEN_CONS,
            prop_value: gplusrefreshtoken
        }, {
            prop_name: TokenConstants.G_CONST_EMAIL,
            prop_value: email
        }];
        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.SET_EXTRA_DATA, jsonParams)
            .then(function (response) {
                    q.resolve(response.data);
                },
                function (error) {
                    q.reject(error);
                });
        return q.promise;
    }

    function getProfileData_tbyb() {
        // 1- get vehicle profile data
        // 2- get personal profile data
        // 3- create profileData json and return it

        var q = $q.defer();
        HttpProxy.get(GlobalConstants.BASE_URL + WebServiceUrls.GET_VEHICLE_PROFILE).then(function (vehicleProfile) {
            HttpProxy.get(GlobalConstants.BASE_URL + WebServiceUrls.GET_PERSONAL_PROFILE).then(function (personalProfile) {
                var toReturn = {
                    vehicleProfile: vehicleProfile.data.VehicleProfile,
                    userProfile: vehicleProfile.data.User,
                    personalProfile: personalProfile.data.PersonalProfile
                };
                q.resolve(toReturn);
            }, function (error) {
                // ERROR
                q.reject(error);
            });
        }, function (error) {
            // ERROR
            q.reject(error);
        });

        return q.promise;
    }

    function getProfileData_client(user_data) {
        // 1- get vehicle profile data
        // 2- get personal profile data
        // 3- create profileData json and return it

        var q = $q.defer();
        var userId = LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID);
        HttpProxy.get(GlobalConstants.PAS_URL + WebServiceUrls.APPLICATION_USERS + userId + WebServiceUrls.GET_PAS_POLICY_INFO).then(function (vehicleProfile) {

            var toReturn = {
                VehicleProfile: vehicleProfile.data.data[0],
                User: user_data ? user_data.User : null,
                Address:  user_data ? user_data.Address : null
            };
            q.resolve(toReturn);
        }, function (error) {
            // ERROR
            q.reject(error);
        });

        return q.promise;
    }

    function getVehicleTypes() {
        var q = $q.defer();
        PlaceholderServices.get(GlobalConstants.BASE_URL + WebServiceUrls.GET_VEHICLE_TYPES).then(function (response) {
            q.resolve(response.data);
        }, function (error) {
            q.reject(error.data);
        });
        return q.promise;
    }

    function getVehicleMoreDetails() {
        var q = $q.defer();
        PlaceholderServices.get(GlobalConstants.BASE_URL + WebServiceUrls.GET_VEHICLE_MORE_DETAILS).then(function (response) {
            q.resolve(response.data);
        }, function (error) {
            q.reject(error.data);
        });
        return q.promise;
    }

    function getPrimaryVehicles() {
        var q = $q.defer();
        PlaceholderServices.get(GlobalConstants.BASE_URL + WebServiceUrls.GET_PRIMARY_VEHICLES).then(function (response) {
            q.resolve(response.data);
        }, function (error) {
            q.reject(error.data);
        });
        return q.promise;
    }

    function getAnnualKMs() {
        var q = $q.defer();
        PlaceholderServices.get(GlobalConstants.BASE_URL + WebServiceUrls.GET_ANNUAL_KMS).then(function (response) {
            q.resolve(response.data);
        }, function (error) {
            q.reject(error.data);
        });
        return q.promise;
    }

    function getDistanceDriven() {
        var q = $q.defer();
        PlaceholderServices.get(GlobalConstants.BASE_URL + WebServiceUrls.GET_DISTANCE_DRIVEN).then(function (response) {
            q.resolve(response.data);
        }, function (error) {
            q.reject(error.data);
        });
        return q.promise;
    }

    function getTypeOfAccidents() {
        var q = $q.defer();
        PlaceholderServices.get(GlobalConstants.BASE_URL + WebServiceUrls.GET_TYPE_OF_ACCIDENTS).then(function (response) {
            q.resolve(response.data);
        }, function (error) {
            q.reject(error.data);
        });
        return q.promise;
    }

    function linkFacebookProfile(accessToken, facebookId) {
        var q = $q.defer();
        var jsonParams = {};
        jsonParams["User"] = {};
        jsonParams["User"]['facebook_id'] = facebookId;
        jsonParams["User"]['access_token'] = accessToken;
        var url = GlobalConstants.BASE_URL + WebServiceUrls.LINK_FACEBOOK;
        HttpProxy.post(url, jsonParams).then(function (response) {
                q.resolve(response.data);
            },
            function (error) {
                q.reject(error.data);
            });
        return q.promise;
    }


    function disconnectFacebook() {
        var q = $q.defer();
        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.DISCONNECT_FACEBOOK).then(function (response) {
                q.resolve(response.data);
            },
            function (error) {
                q.reject(error.data);
            });
        return q.promise;
    }

    function getDriverTypes() {
        var q = $q.defer();
        HttpProxy.get(GlobalConstants.PAS_URL + WebServiceUrls.PAS_CORE + WebServiceUrls.DRIVER_TYPES).then(function (response) {
            q.resolve(response.data);
        }, function (error) {
            q.reject(error.data);
        });
        return q.promise;
    }

    function getMaritalStatus() {
        var q = $q.defer();
        HttpProxy.get(GlobalConstants.PAS_URL + WebServiceUrls.PAS_CORE + WebServiceUrls.MARITAL_STATUSES).then(function (response) {
            q.resolve(response.data);
        }, function (error) {
            q.reject(error.data);
        });
        return q.promise;
    }

    function setPhoneInfo(data) {
        var q = $q.defer();
        var jsonParams = data;

        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.SET_PHONE_INFO, jsonParams).then(function (response) {
            q.resolve(response.data);
        },
        function (error) {
            q.reject(error.data);
        });
        return q.promise;
    }
}
