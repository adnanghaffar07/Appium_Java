angular.module('services')
    .service('InsuranceServices', InsuranceServices);

function InsuranceServices($q, HttpProxy, GlobalConstants, WebServiceUrls, PlaceholderServices, LocalStorage, LocalStorageKeys) {

    this.getRepairShops = getRepairShops;
    this.getInvoices = getInvoices;
    this.getInvoice = getInvoice;
    this.claimTypes = claimTypes;
    this.getClaims = getClaims;
    this.submitClaim = submitClaim;
    this.postPicture = postPicture;
    this.deletePicture = deletePicture;
    this.getPicture = getPicture;
    this.getVehicleDetails=getVehicleDetails;

    function getRepairShops(curentPosition) {
        var q = $q.defer();
        HttpProxy.post(GlobalConstants.PAS_URL + WebServiceUrls.GET_REPAIR_SHOPS, curentPosition)
            .then(function (response) {
                    q.resolve(response.data);
                },
                function (error) {
                    q.reject(error.data.data);
                });
        return q.promise;
    }

    function getInvoices() {
        var q = $q.defer();
        var PID = LocalStorage.get(LocalStorageKeys.POLICY_ID);
        HttpProxy.get(GlobalConstants.PAS_URL + WebServiceUrls.PAS_CORE + WebServiceUrls.POLICIES + PID + WebServiceUrls.PAS_BILLING + WebServiceUrls.GET_INVOICES)
            .then(function (response) {
                    q.resolve(response.data);
                },
                function (error) {
                    q.reject(error.data.data);
                });
        return q.promise;
    }

    function getInvoice(invoiceData) {
        var q = $q.defer();
        HttpProxy.get(GlobalConstants.PAS_URL + WebServiceUrls.PAS_BILLING + WebServiceUrls.GET_INVOICES + invoiceData.invoice_id)
            .then(function (response) {
                    q.resolve(response.data);
                },
                function (error) {
                    q.reject(error.data.data);
                });
        return q.promise;
    }

    function getClaims(pPage) {
        var q = $q.defer();
        var PID = LocalStorage.get(LocalStorageKeys.POLICY_ID);
        HttpProxy.get(GlobalConstants.PAS_URL + WebServiceUrls.PAS_CORE + WebServiceUrls.POLICIES + PID + WebServiceUrls.PAS_CLAIM + WebServiceUrls.GET_SET_CLAIMS + "?page=" + pPage)
            .then(function (response) {
                    q.resolve(response.data.data);
                },
                function (error) {
                    q.reject(error.data.data);
                });
        return q.promise;
    }

    function submitClaim(claimData) {
        var q = $q.defer();
        var PID = LocalStorage.get(LocalStorageKeys.POLICY_ID);
        HttpProxy.post(GlobalConstants.PAS_URL + WebServiceUrls.PAS_CORE + WebServiceUrls.POLICIES + PID + WebServiceUrls.PAS_CLAIM + WebServiceUrls.GET_SET_CLAIMS,claimData)
            .then(function (response) {
                    q.resolve(response.data);
                },
                function (error) {
                    q.reject(error.data.data);
                });
        return q.promise;
    }

    function claimTypes() {
        var q = $q.defer();
        HttpProxy.get(GlobalConstants.PAS_URL + WebServiceUrls.PAS_CLAIM + WebServiceUrls.CLAIM_TYPES)
            .then(function (response) {
                    q.resolve(response.data);
                },
                function (error) {
                    q.reject(error.data.data);
                });
        return q.promise;
    }
    function postPicture(pictureData) {
        var q = $q.defer();
        HttpProxy.post(GlobalConstants.PAS_URL + WebServiceUrls.PAS_CLAIM + WebServiceUrls.POLICY_PICTURES ,pictureData)
            .then(function (response) {
                    q.resolve(response.data);
                },
                function (error) {
                    q.reject(error.data);
                });
        return q.promise;
    }
    function deletePicture(pictureData) {
        var q = $q.defer();
        HttpProxy.delete(GlobalConstants.PAS_URL + WebServiceUrls.PAS_CLAIM + WebServiceUrls.POLICY_PICTURES + pictureData.id)
            .then(function (response) {
                    q.resolve(response.data);
                },
                function (error) {
                    q.reject(error.data);
                });
        return q.promise;
    }
    function getPicture(id) {
        var q = $q.defer();
        HttpProxy.get(GlobalConstants.PAS_URL + WebServiceUrls.PAS_CLAIM + WebServiceUrls.POLICY_PICTURES + id)
            .then(function (response) {
                    q.resolve(response.data);
                },
                function (error) {
                    q.reject(error.data.data);
                });
        return q.promise;
    }
    function getVehicleDetails(){
        var q = $q.defer();
        var PID = LocalStorage.get(LocalStorageKeys.POLICY_ID);
        HttpProxy.get(GlobalConstants.PAS_URL + WebServiceUrls.PAS_CORE+WebServiceUrls.POLICIES + PID + WebServiceUrls.CLAIM_VEHICLES)
            .then(function (response) {
                    q.resolve(response.data.data);
                },
                function (error) {
                    q.reject(error.data.data);
                });
        return q.promise;
    }
};
