angular.module('services')
    .service('ScoresServices', ScoresServices);


function ScoresServices($q, $translate, HttpProxy, ValidationUtil, ScoreType, $rootScope, $timeout, GlobalConstants, DateUtil, WebServiceUrls, LocalStorage, LocalStorageKeys, PopupUtil, StringUtil, PlaceholderServices, LoadingUtil, NetworkConnectionUtil, ConnectionConstants, ApiStatusCode) {
    this.getDailyScores = getDailyScores;
    this.getOverallScores = getOverallScores;
    this.getOverallDrivingScores = getOverallDrivingScores;
    this.getDailyScores_currentMonth = getDailyScores_currentMonth;
    this.getLastTripInfoAndScore = getLastTripInfoAndScore;
    this.getOtherTripsInfoAndScore = getOtherTripsInfoAndScore;

    this.getLastTripInfoAndScoreByVehicle = getLastTripInfoAndScoreByVehicle;
    this.getOtherTripsInfoAndScoreByVehicle = getOtherTripsInfoAndScoreByVehicle;


    /*
        Name: getOverallDrivingScores
        Desc: Initialize a score object by phase
        Param: Callback function
    */
    /*
        Name: getOverallDrivingScores
        Desc: Initialize a score object by phase
        Param: Callback function
    */
    function getOverallDrivingScores(pCallback) {
        getOverallDrivingScoresGlobalPhase(new OverallDrivingScores(), pCallback);
    }

    /*
        Name: getOverallDrivingScoresGlobalPhase
        Desc: Fetch scores data for Global phase (365 days)
        Param: score object pScoreData
        Param: Callback function
    */
    function getOverallDrivingScoresGlobalPhase(pScoreData, pCallback) {
        //        var jsonParams = {
        //            "start_date": moment(moment("1990-01-01").format("YYYY-MM-DD")).utc().format("YYYY-MM-DDThh:mm:ss"),
        //            "end_date": moment(moment().format("YYYY-MM-DD")).utc().format("YYYY-MM-DDThh:mm:ss")
        //        };
        var jsonParams = {
            "start_date": moment(moment("1990-01-01").format("YYYY-MM-DD")).utc().format("YYYY-MM-DD"),
            "end_date": moment(moment().format("YYYY-MM-DD")).utc().format("YYYY-MM-DD")
        };

        console.log(88888888, jsonParams);

        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.GET_SCORE, jsonParams)
            .then(function (response) {
                if ((angular.isDefined(response.data.data) && angular.isDefined(response.data.data.distance)) || angular.isDefined(response.data.distance)) {
                    pScoreData.global.score = response.data.data.score_average;
                    pScoreData.global.hbr = response.data.data.score_braking;
                    pScoreData.global.hac = response.data.data.score_acceleration;
                    pScoreData.global.spd = response.data.data.score_speed;
                    pScoreData.global.hco = response.data.data.score_turn;
                    pScoreData.global.distance = response.data.data.distance;
                    pScoreData.global.endTime = response.data.data.end_time;
                    if (!angular.isUndefined(response.data.data.score_distracted_driving)) {
                        pScoreData.global.dd = response.data.data.score_distracted_driving;
                    } else {
                        pScoreData.global.dd = null;
                    }
                }
                getOverallDrivingScoresLastTripPhase(pScoreData, pCallback);
            });
    }

    /*
        Name: getOverallDrivingScoresLastTripPhase
        Desc: Fetch scores data for Last Trip phase
        Param: score object pScoreData
        Param: Callback function
    */
    function getOverallDrivingScoresLastTripPhase(pScoreData, pCallback) {
        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.GET_LAST_TRIP)
            .then(function (response) {
                console.log("GET LAST TRIP", response);
                if (angular.isDefined(response.data.data) && angular.isDefined(response.data.data.distance)) {
                    console.log(99999999, response.data.data);
                    pScoreData.lastTrip.score = response.data.data.score_average;
                    pScoreData.lastTrip.hbr = response.data.data.score_braking;
                    pScoreData.lastTrip.hac = response.data.data.score_acceleration;
                    pScoreData.lastTrip.spd = response.data.data.score_speed;
                    pScoreData.lastTrip.hco = response.data.data.score_turn;
                    pScoreData.lastTrip.distance = response.data.data.distance;
                    pScoreData.lastTrip.startTime = response.data.data.start_time;
                    pScoreData.lastTrip.endTime = response.data.data.end_time;
                    if (!angular.isUndefined(response.data.data.score_distracted_driving)) {
                        pScoreData.lastTrip.dd = response.data.data.score_distracted_driving;
                    } else {
                        pScoreData.lastTrip.dd = null;
                    }
                }
                getOverallDrivingScoresLastMonthPhase(pScoreData, pCallback);
            });
    }

    /*
        Name: getOverallDrivingScoresLastMonthPhase
        Desc: Fetch scores data for Last Month phase
        Param: score object pScoreData
        Param: Callback function
    */
    function getOverallDrivingScoresLastMonthPhase(pScoreData, pCallback) {

        //        var jsonParams = {
        //            "start_date": moment(moment().subtract(30, "days").format("YYYY-MM-DD")).utc().format("YYYY-MM-DDThh:mm:ss"),
        //            "end_date": moment(moment().format("YYYY-MM-DD")).utc().format("YYYY-MM-DDThh:mm:ss")
        //        };

        var jsonParams = {
            "start_date": moment(moment().subtract(30, "days").format("YYYY-MM-DD")).utc().format("YYYY-MM-DD"),
            "end_date": moment(moment().format("YYYY-MM-DD")).utc().format("YYYY-MM-DD")
        };



        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.GET_SCORE, jsonParams)
            .then(function (response) {
                if (angular.isDefined(response.data.data) && angular.isDefined(response.data.data.distance)) {
                    pScoreData.lastMonth.score = response.data.data.score_average;
                    pScoreData.lastMonth.hbr = response.data.data.score_braking;
                    pScoreData.lastMonth.hac = response.data.data.score_acceleration;
                    pScoreData.lastMonth.spd = response.data.data.score_speed;
                    pScoreData.lastMonth.hco = response.data.data.score_turn;
                    pScoreData.lastMonth.distance = response.data.data.distance;
                    if (!angular.isUndefined(response.data.data.score_distracted_driving)) {
                        pScoreData.lastMonth.dd = response.data.data.score_distracted_driving;
                    } else {
                        pScoreData.lastMonth.dd = null;
                    }
                }
                getOverallDrivingScoresLastWeekPhase(pScoreData, pCallback);
            });
    }

    /*
        Name: getOverallDrivingScoresLastWeekPhase
        Desc: Fetch scores data for Last Week phase
        Param: score object pScoreData
        Param: Callback function
    */
    function getOverallDrivingScoresLastWeekPhase(pScoreData, pCallback) {

        //        var jsonParams = {
        //            "start_date": moment(moment().subtract(7, "days").format("YYYY-MM-DD")).utc().format("YYYY-MM-DDThh:mm:ss"),
        //            "end_date": moment(moment().format("YYYY-MM-DD")).utc().format("YYYY-MM-DDThh:mm:ss")
        //        };

        var jsonParams = {
            "start_date": moment(moment().subtract(7, "days").format("YYYY-MM-DD")).utc().format("YYYY-MM-DD"),
            "end_date": moment(moment().format("YYYY-MM-DD")).utc().format("YYYY-MM-DD")
        };



        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.GET_SCORE, jsonParams)
            .then(function (response) {

                console.log(response, 'lastweek');

                if (angular.isDefined(response.data.data) && angular.isDefined(response.data.data.distance)) {
                    pScoreData.lastWeek.score = response.data.data.score_average;
                    pScoreData.lastWeek.hbr = response.data.data.score_braking;
                    pScoreData.lastWeek.hac = response.data.data.score_acceleration;
                    pScoreData.lastWeek.spd = response.data.data.score_speed;
                    pScoreData.lastWeek.hco = response.data.data.score_turn;
                    pScoreData.lastWeek.distance = response.data.data.distance;
                    if (!angular.isUndefined(response.data.data.score_distracted_driving)) {
                        pScoreData.lastWeek.dd = response.data.data.score_distracted_driving;
                    } else {
                        pScoreData.lastWeek.dd = null;
                    }
                }
                pCallback(pScoreData);
            });
    }

    function getDailyScores(startdate, enddate, callback, errCallBack) {
        var url = GlobalConstants.BASE_URL + WebServiceUrls.GET_DAILY_SCORES;

        // var jsonParams = {
        //     "start_date": startdate,
        //     "end_date": enddate
        // };
        var jsonParams = {
            "start_date": moment(moment().subtract(30, "days").format("YYYY-MM-DD")).utc().format("YYYY-MM-DDThh:mm:ss"),
            "end_date": moment(moment().add(1, "days").format("YYYY-MM-DD")).utc().format("YYYY-MM-DDThh:mm:ss")
        };

        HttpProxy.post(url, jsonParams).then(function (data) {
            return callback(data);
        }, function (error) {
            LoadingUtil.hideLoader();
            NetworkConnectionUtil.getConnectionType().then(function (connectionType) {
                if (connectionType) {
                    if ($rootScope.popUp) {
                        $rootScope.popUp.close();
                    }
                    return errCallBack(error);
                    //PopupUtil.showSimpleAlert($translate.instant("error"), $translate.instant("request_time_out"));
                    // PopupUtil.showSimpleAlert($translate.instant("noNetworkTitle"), $translate.instant('checkNetworkConnection'));
                }

            });

        });
    }

    function getOverallScores(startdate, enddate, callback, errCallBack) {
        var url = GlobalConstants.BASE_URL + WebServiceUrls.GET_OVERALL_SCORES;

        // var jsonParams = {
        //     "start_date": startdate,
        //     "end_date": enddate
        // };
        var jsonParams = {
            "start_date": moment(moment().subtract(30, "days").format("YYYY-MM-DD")).utc().format("YYYY-MM-DDThh:mm:ss"),
            "end_date": moment(moment().add(1, "days").format("YYYY-MM-DD")).utc().format("YYYY-MM-DDThh:mm:ss")
        };

        HttpProxy.post(url, jsonParams).then(function (data) {
            return callback(data);
        }, function (error) {
            LoadingUtil.hideLoader();
            NetworkConnectionUtil.getConnectionType().then(function (connectionType) {
                if (connectionType) {
                    if ($rootScope.popUp) {
                        $rootScope.popUp.close();
                    }
                    return errCallBack(error);
                    //PopupUtil.showSimpleAlert($translate.instant("error"), $translate.instant("request_time_out"));
                    // PopupUtil.showSimpleAlert($translate.instant("noNetworkTitle"), $translate.instant('checkNetworkConnection'));
                }

            });

        });
    }

    function getDailyScores_currentMonth() {
        var q = $q.defer();
        var jsonParams = {
            "start_date": moment(moment().subtract(30, "days").format("YYYY-MM-DD")).utc().format("YYYY-MM-DDThh:mm:ss"),
            "end_date": moment(moment().add(1, "days").format("YYYY-MM-DD")).utc().format("YYYY-MM-DDThh:mm:ss")
        };

        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.GET_DAILY_DETAILS_FROM_DATES, jsonParams).then(function (data) {
            q.resolve(data);
        }, function (error) {
            q.reject(error);
        });

        return q.promise;
    }


    function getLastTripInfoAndScore(pScoreData, pCallback) {
        // Get Last Trip Infos
        var q = $q.defer();
        var scoreData = new OverallDrivingInfo();
        return getOverallTripsInfoLastTripPhase(scoreData, pCallback);
    }

    function getOtherTripsInfoAndScore(pScoreData, pCallback) {
        // Get Last Week, Last Month and Lifetime Trips Infos
        var scoreData = pScoreData;
        return getOverallTripsInfoGlobalPhase(scoreData, pCallback);
    }

    function getOverallTripsInfoGlobalPhase(pScoreData, pCallback) {
        var jsonParams = {
            "start_date": moment(moment("1900-01-01").format("YYYY-MM-DD")).utc().format("YYYY-MM-DDThh:mm:ss"),
            "end_date": moment(moment().format("YYYY-MM-DD")).utc().format("YYYY-MM-DDThh:mm:ss")
        };
        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.GET_TRIPS_DETAILS_FROM_DATES, jsonParams).then(function (response) {
            if (angular.isDefined(response.data.data))
                response.data = response.data.data;

            if (response.data.length == 0) {

                pScoreData.global.cost = 0;
                pScoreData.global.distance = 0;

                pScoreData.global.trip_date = 0;
                pScoreData.global.free_miles_earned = 0;
                pScoreData.global.free_miles_consumed = 0;
                pScoreData.global.safe_miles_driven = 0;

                pScoreData.global.price_per_category.safe_interstate = 0;
                pScoreData.global.price_per_category.safe_other = 0;
                pScoreData.global.price_per_category.aggressive = 0;
                pScoreData.global.price_per_category.risky = 0;
                pScoreData.global.price_per_category.dangerous = 0;
                pScoreData.global.distance_per_category.safe_interstate = 0;
                pScoreData.global.distance_per_category.safe_other = 0;
                pScoreData.global.distance_per_category.aggressive = 0;
                pScoreData.global.distance_per_category.risky = 0;
                pScoreData.global.distance_per_category.dangerous = 0;
                pScoreData.global.break_points = [];
                pScoreData.global.date = 0;
            } else {
                pScoreData.global.cost = response.data.cost;
                pScoreData.global.distance = Math.round(response.data.distance * 100) / 100;

                pScoreData.global.trip_count = response.data.trip_count;
                pScoreData.global.last_trip_date = response.data.last_trip_date;
                pScoreData.global.first_trip_date = response.data.first_trip_date;
                pScoreData.global.free_miles_earned = response.data.free_miles_earned;
                pScoreData.global.free_miles_consumed = response.data.free_miles_consumed;
                pScoreData.global.safe_miles_driven = Math.round(response.data.safe_miles_driven * 100) / 100;

                pScoreData.global.price_per_category.safe_interstate = response.data.price_per_category.safe_interstate;
                pScoreData.global.price_per_category.safe_other = response.data.price_per_category.safe_other;
                pScoreData.global.price_per_category.aggressive = response.data.price_per_category.aggressive;
                pScoreData.global.price_per_category.risky = response.data.price_per_category.risky;
                pScoreData.global.price_per_category.dangerous = response.data.price_per_category.dangerous;
                pScoreData.global.distance_per_category.safe_interstate = Math.round(response.data.distance_per_category.safe_interstate * 100) / 100;
                pScoreData.global.distance_per_category.safe_other = Math.round(response.data.distance_per_category.safe_other * 100) / 100;
                pScoreData.global.distance_per_category.aggressive = Math.round(response.data.distance_per_category.aggressive * 100) / 100;
                pScoreData.global.distance_per_category.risky = Math.round(response.data.distance_per_category.risky * 100) / 100;
                pScoreData.global.distance_per_category.dangerous = Math.round(response.data.distance_per_category.dangerous * 100) / 100;
                if (angular.isDefined(response.data.breakdown))
                    pScoreData.global.break_points = response.data.breakdown;
                if (angular.isDefined(response.data.break_down))
                    pScoreData.global.break_points = response.data.break_down;
                var globalDate;
                var creationDate = moment(LocalStorage.get(LocalStorageKeys.PROFILE_CREATION_DATE));
                var lastYearDate = moment().subtract(365, "days");
                var isAfter = moment(lastYearDate).isAfter(moment(creationDate));
                if (isAfter) {
                    globalDate = lastYearDate;
                } else {
                    globalDate = creationDate;
                }
                pScoreData.global.date_from = globalDate;
            }

            getOverallTripsInfoMonthPhase(pScoreData, pCallback);
        });
    }

    function getOverallTripsInfoMonthPhase(pScoreData, pCallback) {
        var jsonParams = {
            "start_date": moment(moment().subtract(30, "days").format("YYYY-MM-DD")).utc().format("YYYY-MM-DDThh:mm:ss"),
            "end_date": moment(moment().format("YYYY-MM-DD")).utc().format("YYYY-MM-DDThh:mm:ss")
        };

        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.GET_TRIPS_DETAILS_FROM_DATES, jsonParams).then(function (response) {
            if (angular.isDefined(response.data.data))
                response.data = response.data.data;

            if (response.data.length == 0) {
                pScoreData.lastMonth.cost = 0;
                pScoreData.lastMonth.distance = 0;

                pScoreData.lastMonth.trip_date = 0;
                pScoreData.lastMonth.free_miles_earned = 0;
                pScoreData.lastMonth.free_miles_consumed = 0;
                pScoreData.lastMonth.safe_miles_driven = 0;

                pScoreData.lastMonth.price_per_category.safe_interstate = 0;
                pScoreData.lastMonth.price_per_category.safe_other = 0;
                pScoreData.lastMonth.price_per_category.aggressive = 0;
                pScoreData.lastMonth.price_per_category.risky = 0;
                pScoreData.lastMonth.price_per_category.dangerous = 0;
                pScoreData.lastMonth.price_per_mile_current.safe_interstate = 0;
                pScoreData.lastMonth.price_per_mile_current.safe_other = 0;
                pScoreData.lastMonth.price_per_mile_current.aggressive = 0;
                pScoreData.lastMonth.price_per_mile_current.risky = 0;
                pScoreData.lastMonth.price_per_mile_current.dangerous = 0;
                pScoreData.lastMonth.distance_per_category.safe_interstate = 0;
                pScoreData.lastMonth.distance_per_category.safe_other = 0;
                pScoreData.lastMonth.distance_per_category.aggressive = 0;
                pScoreData.lastMonth.distance_per_category.risky = 0;
                pScoreData.lastMonth.distance_per_category.dangerous = 0;
                pScoreData.lastMonth.break_points = [];
                pScoreData.lastMonth.date = 0;
            } else {
                pScoreData.lastMonth.cost = response.data.cost;
                pScoreData.lastMonth.distance = Math.round(response.data.distance * 100) / 100;

                pScoreData.lastMonth.trip_count = response.data.trip_count;
                pScoreData.lastMonth.last_trip_date = response.data.last_trip_date;
                pScoreData.lastMonth.first_trip_date = response.data.first_trip_date;
                pScoreData.lastMonth.free_miles_earned = response.data.free_miles_earned;
                pScoreData.lastMonth.free_miles_consumed = response.data.free_miles_consumed;
                pScoreData.lastMonth.safe_miles_driven = Math.round(response.data.safe_miles_driven * 100) / 100;

                pScoreData.lastMonth.price_per_category.safe_interstate = response.data.price_per_category.safe_interstate;
                pScoreData.lastMonth.price_per_category.safe_other = response.data.price_per_category.safe_other;
                pScoreData.lastMonth.price_per_category.aggressive = response.data.price_per_category.aggressive;
                pScoreData.lastMonth.price_per_category.risky = response.data.price_per_category.risky;
                pScoreData.lastMonth.price_per_category.dangerous = response.data.price_per_category.dangerous;
                pScoreData.lastMonth.price_per_mile_current.safe_interstate = response.data.price_per_mile_current.safe_interstate;
                pScoreData.lastMonth.price_per_mile_current.safe_other = response.data.price_per_mile_current.safe_other;
                pScoreData.lastMonth.price_per_mile_current.aggressive = response.data.price_per_mile_current.aggressive;
                pScoreData.lastMonth.price_per_mile_current.risky = response.data.price_per_mile_current.risky;
                pScoreData.lastMonth.price_per_mile_current.dangerous = response.data.price_per_mile_current.dangerous;
                pScoreData.lastMonth.distance_per_category.safe_interstate = Math.round(response.data.distance_per_category.safe_interstate * 100) / 100;
                pScoreData.lastMonth.distance_per_category.safe_other = Math.round(response.data.distance_per_category.safe_other * 100) / 100;
                pScoreData.lastMonth.distance_per_category.aggressive = Math.round(response.data.distance_per_category.aggressive * 100) / 100;
                pScoreData.lastMonth.distance_per_category.risky = Math.round(response.data.distance_per_category.risky * 100) / 100;
                pScoreData.lastMonth.distance_per_category.dangerous = Math.round(response.data.distance_per_category.dangerous * 100) / 100;
                if (angular.isDefined(response.data.breakdown))
                    pScoreData.lastMonth.break_points = response.data.breakdown;
                if (angular.isDefined(response.data.break_down))
                    pScoreData.lastMonth.break_points = response.data.break_down;
                pScoreData.lastMonth.date_from = moment().subtract(30, "days").format("YYYY-MM-DD");
                pScoreData.lastMonth.date_to = moment().subtract(1, "days").format("YYYY-MM-DD");
            }
            getOverallTripsInfoWeekPhase(pScoreData, pCallback);
        });
    }

    function getOverallTripsInfoWeekPhase(pScoreData, pCallback) {
        var jsonParams = {
            "start_date": moment(moment().subtract(7, "days").format("YYYY-MM-DD")).utc().format("YYYY-MM-DDThh:mm:ss"),
            "end_date": moment(moment().format("YYYY-MM-DD")).utc().format("YYYY-MM-DDThh:mm:ss")
        };

        console.log(999999999, jsonParams);

        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.GET_TRIPS_DETAILS_FROM_DATES, jsonParams).then(function (response) {
            if (angular.isDefined(response.data.data))
                response.data = response.data.data;
            if (response.data.length == 0) {
                pScoreData.lastWeek.cost = 0;
                pScoreData.lastWeek.distance = 0;

                pScoreData.lastWeek.trip_date = 0;
                pScoreData.lastWeek.free_miles_earned = 0;
                pScoreData.lastWeek.free_miles_consumed = 0;
                pScoreData.lastWeek.safe_miles_driven = 0;

                pScoreData.lastWeek.price_per_category.safe_interstate = 0;
                pScoreData.lastWeek.price_per_category.safe_other = 0;
                pScoreData.lastWeek.price_per_category.aggressive = 0;
                pScoreData.lastWeek.price_per_category.risky = 0;
                pScoreData.lastWeek.price_per_category.dangerous = 0;
                pScoreData.lastWeek.price_per_mile_current.safe_interstate = 0;
                pScoreData.lastWeek.price_per_mile_current.safe_other = 0;
                pScoreData.lastWeek.price_per_mile_current.aggressive = 0;
                pScoreData.lastWeek.price_per_mile_current.risky = 0;
                pScoreData.lastWeek.price_per_mile_current.dangerous = 0;
                pScoreData.lastWeek.distance_per_category.safe_interstate = 0;
                pScoreData.lastWeek.distance_per_category.safe_other = 0;
                pScoreData.lastWeek.distance_per_category.aggressive = 0;
                pScoreData.lastWeek.distance_per_category.risky = 0;
                pScoreData.lastWeek.distance_per_category.dangerous = 0;
                pScoreData.lastWeek.break_points = [];
                pScoreData.lastWeek.date = 0;
            } else {
                pScoreData.lastWeek.cost = response.data.cost;
                pScoreData.lastWeek.distance = Math.round(response.data.distance * 100) / 100;

                pScoreData.lastWeek.trip_count = response.data.trip_count;
                pScoreData.lastWeek.last_trip_date = response.data.last_trip_date;
                pScoreData.lastWeek.first_trip_date = response.data.first_trip_date;
                pScoreData.lastWeek.free_miles_earned = response.data.free_miles_earned;
                pScoreData.lastWeek.free_miles_consumed = response.data.free_miles_consumed;
                pScoreData.lastWeek.safe_miles_driven = Math.round(response.data.safe_miles_driven * 100) / 100;

                pScoreData.lastWeek.price_per_category.safe_interstate = response.data.price_per_category.safe_interstate;
                pScoreData.lastWeek.price_per_category.safe_other = response.data.price_per_category.safe_other;
                pScoreData.lastWeek.price_per_category.aggressive = response.data.price_per_category.aggressive;
                pScoreData.lastWeek.price_per_category.risky = response.data.price_per_category.risky;
                pScoreData.lastWeek.price_per_category.dangerous = response.data.price_per_category.dangerous;
                pScoreData.lastWeek.price_per_mile_current.safe_interstate = response.data.price_per_mile_current.safe_interstate;
                pScoreData.lastWeek.price_per_mile_current.safe_other = response.data.price_per_mile_current.safe_other;
                pScoreData.lastWeek.price_per_mile_current.aggressive = response.data.price_per_mile_current.aggressive;
                pScoreData.lastWeek.price_per_mile_current.risky = response.data.price_per_mile_current.risky;
                pScoreData.lastWeek.price_per_mile_current.dangerous = response.data.price_per_mile_current.dangerous;
                pScoreData.lastWeek.distance_per_category.safe_interstate = Math.round(response.data.distance_per_category.safe_interstate * 100) / 100;
                pScoreData.lastWeek.distance_per_category.safe_other = Math.round(response.data.distance_per_category.safe_other * 100) / 100;
                pScoreData.lastWeek.distance_per_category.aggressive = Math.round(response.data.distance_per_category.aggressive * 100) / 100;
                pScoreData.lastWeek.distance_per_category.risky = Math.round(response.data.distance_per_category.risky * 100) / 100;
                pScoreData.lastWeek.distance_per_category.dangerous = Math.round(response.data.distance_per_category.dangerous * 100) / 100;
                if (angular.isDefined(response.data.breakdown))
                    pScoreData.lastWeek.break_points = response.data.breakdown;
                if (angular.isDefined(response.data.break_down))
                    pScoreData.lastWeek.break_points = response.data.break_down;
                pScoreData.lastWeek.date_from = moment().subtract(7, "days").format("YYYY-MM-DD");
                pScoreData.lastWeek.date_to = moment().subtract(1, "days").format("YYYY-MM-DD");
            }
            getOverallTripsInfoLastTripPhase(pScoreData, pCallback);
        });
    }

    function getOverallTripsInfoLastTripPhase(pScoreData, pCallback) {
        HttpProxy.get(GlobalConstants.BASE_URL + WebServiceUrls.GET_LAST_TRIP_DETAILS).then(function (response) {
            if (angular.isDefined(response.data.data))
                response.data = response.data.data;

            if (response.data.length == 0) {
                pScoreData.lastTrip.cost = 0;
                pScoreData.lastTrip.distance = 0;

                pScoreData.lastTrip.trip_date = 0;
                pScoreData.lastTrip.free_miles_earned = 0;
                pScoreData.lastTrip.free_miles_consumed = 0;
                pScoreData.lastTrip.safe_miles_driven = 0;

                pScoreData.lastTrip.price_per_category.safe_interstate = 0;
                pScoreData.lastTrip.price_per_category.safe_other = 0;
                pScoreData.lastTrip.price_per_category.aggressive = 0;
                pScoreData.lastTrip.price_per_category.risky = 0;
                pScoreData.lastTrip.price_per_category.dangerous = 0;
                pScoreData.lastTrip.price_per_mile_current.safe_interstate = 0;
                pScoreData.lastTrip.price_per_mile_current.safe_other = 0;
                pScoreData.lastTrip.price_per_mile_current.aggressive = 0;
                pScoreData.lastTrip.price_per_mile_current.risky = 0;
                pScoreData.lastTrip.price_per_mile_current.dangerous = 0;
                pScoreData.lastTrip.distance_per_category.safe_interstate = 0;
                pScoreData.lastTrip.distance_per_category.safe_other = 0;
                pScoreData.lastTrip.distance_per_category.aggressive = 0;
                pScoreData.lastTrip.distance_per_category.risky = 0;
                pScoreData.lastTrip.distance_per_category.dangerous = 0;
                pScoreData.lastTrip.break_points = [];
                pScoreData.lastTrip.date = 0;
                pScoreData.lastTrip.start_location = null;
                pScoreData.global.end_location = null;
                pScoreData.lastTrip.trip_id = null;
            } else {
                pScoreData.lastTrip.cost = response.data.cost;
                pScoreData.lastTrip.distance = Math.round(response.data.distance * 100) / 100;

                pScoreData.lastTrip.trip_date = response.data.trip_date;
                pScoreData.lastTrip.free_miles_earned = response.data.free_miles_earned;
                pScoreData.lastTrip.free_miles_consumed = response.data.free_miles_consumed;
                pScoreData.lastTrip.safe_miles_driven = Math.round(response.data.safe_miles_driven * 100) / 100;

                pScoreData.lastTrip.price_per_category.safe_interstate = response.data.price_per_category.safe_interstate;
                pScoreData.lastTrip.price_per_category.safe_other = response.data.price_per_category.safe_other;
                pScoreData.lastTrip.price_per_category.aggressive = response.data.price_per_category.aggressive;
                pScoreData.lastTrip.price_per_category.risky = response.data.price_per_category.risky;
                pScoreData.lastTrip.price_per_category.dangerous = response.data.price_per_category.dangerous;
                pScoreData.lastTrip.price_per_mile_current.safe_interstate = response.data.price_per_mile_current.safe_interstate;
                pScoreData.lastTrip.price_per_mile_current.safe_other = response.data.price_per_mile_current.safe_other;
                pScoreData.lastTrip.price_per_mile_current.aggressive = response.data.price_per_mile_current.aggressive;
                pScoreData.lastTrip.price_per_mile_current.risky = response.data.price_per_mile_current.risky;
                pScoreData.lastTrip.price_per_mile_current.dangerous = response.data.price_per_mile_current.dangerous;
                pScoreData.lastTrip.distance_per_category.safe_interstate = Math.round(response.data.distance_per_category.safe_interstate * 100) / 100;
                pScoreData.lastTrip.distance_per_category.safe_other = Math.round(response.data.distance_per_category.safe_other * 100) / 100;
                pScoreData.lastTrip.distance_per_category.aggressive = Math.round(response.data.distance_per_category.aggressive * 100) / 100;
                pScoreData.lastTrip.distance_per_category.risky = Math.round(response.data.distance_per_category.risky * 100) / 100;
                pScoreData.lastTrip.distance_per_category.dangerous = Math.round(response.data.distance_per_category.dangerous * 100) / 100;
                if (angular.isDefined(response.data.breakdown))
                    pScoreData.lastTrip.break_points = response.data.breakdown;
                if (angular.isDefined(response.data.break_down))
                    pScoreData.lastTrip.break_points = response.data.break_down;
                pScoreData.lastTrip.date = DateUtil.getLocalTimeFromUtc(moment(response.data.last_trip_date));
                pScoreData.lastTrip.start_location = response.data.start_location;
                pScoreData.lastTrip.end_location = response.data.end_location;
                pScoreData.lastTrip.price_per_mile_current = response.data.price_per_mile_current;
                pScoreData.lastTrip.trip_id = response.data.trip_id;
            }
            pCallback(pScoreData);
        });
    }

    function getOtherTripsInfoAndScoreByVehicle(pScoreData, pCallback, pVehicleId) {
        // Get Last Week, Last Month and Lifetime Trips Infos by vehilce Id
        var scoreData = pScoreData;
        return getOverallTripsInfoGlobalPhaseByVehicle(scoreData, pCallback, pVehicleId);
    }

    function getOverallTripsInfoGlobalPhaseByVehicle(pScoreData, pCallback, pVehicleId) {
        var jsonParams = {
            "start_date": moment(moment("1900-01-01").format("YYYY-MM-DD")).utc().format("YYYY-MM-DDThh:mm:ss"),
            "end_date": moment(moment().format("YYYY-MM-DD")).utc().format("YYYY-MM-DDThh:mm:ss"),
            "car_id": pVehicleId
        };
        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.GET_TRIPS_DETAILS_FROM_DATES_VEHICLE, jsonParams).then(function (response) {
            if (response.data.length == 0) {
                pScoreData.global.cost = 0;
                pScoreData.global.distance = 0;

                pScoreData.global.trip_date = 0;
                pScoreData.global.free_miles_earned = 0;
                pScoreData.global.free_miles_consumed = 0;
                pScoreData.global.safe_miles_driven = 0;

                pScoreData.global.price_per_category.safe_interstate = 0;
                pScoreData.global.price_per_category.safe_other = 0;
                pScoreData.global.price_per_category.aggressive = 0;
                pScoreData.global.price_per_category.risky = 0;
                pScoreData.global.price_per_category.dangerous = 0;
                pScoreData.global.distance_per_category.safe_interstate = 0;
                pScoreData.global.distance_per_category.safe_other = 0;
                pScoreData.global.distance_per_category.aggressive = 0;
                pScoreData.global.distance_per_category.risky = 0;
                pScoreData.global.distance_per_category.dangerous = 0;
                pScoreData.global.break_points = [];
                pScoreData.global.date = 0;
            } else {
                if (angular.isDefined(response.data.data))
                    response.data = response.data.data;
                pScoreData.global.cost = response.data.cost;
                pScoreData.global.distance = Math.round(response.data.distance * 100) / 100;

                pScoreData.global.trip_count = response.data.trip_count;
                pScoreData.global.last_trip_date = response.data.last_trip_date;
                pScoreData.global.first_trip_date = response.data.first_trip_date;
                pScoreData.global.free_miles_earned = response.data.free_miles_earned;
                pScoreData.global.free_miles_consumed = response.data.free_miles_consumed;
                pScoreData.global.safe_miles_driven = Math.round(response.data.safe_miles_driven * 100) / 100;

                pScoreData.global.price_per_category.safe_interstate = response.data.price_per_category.safe_interstate;
                pScoreData.global.price_per_category.safe_other = response.data.price_per_category.safe_other;
                pScoreData.global.price_per_category.aggressive = response.data.price_per_category.aggressive;
                pScoreData.global.price_per_category.risky = response.data.price_per_category.risky;
                pScoreData.global.price_per_category.dangerous = response.data.price_per_category.dangerous;
                pScoreData.global.distance_per_category.safe_interstate = Math.round(response.data.distance_per_category.safe_interstate * 100) / 100;
                pScoreData.global.distance_per_category.safe_other = Math.round(response.data.distance_per_category.safe_other * 100) / 100;
                pScoreData.global.distance_per_category.aggressive = Math.round(response.data.distance_per_category.aggressive * 100) / 100;
                pScoreData.global.distance_per_category.risky = Math.round(response.data.distance_per_category.risky * 100) / 100;
                pScoreData.global.distance_per_category.dangerous = Math.round(response.data.distance_per_category.dangerous * 100) / 100;
                if (angular.isDefined(response.data.breakdown))
                    pScoreData.global.break_points = response.data.breakdown;
                if (angular.isDefined(response.data.break_down))
                    pScoreData.global.break_points = response.data.break_down;
                pScoreData.global.date_from = '2015-07-12';
            }

            getOverallTripsInfoMonthPhaseByVehicle(pScoreData, pCallback, pVehicleId);
        });
    }

    function getOverallTripsInfoMonthPhaseByVehicle(pScoreData, pCallback, pVehicleId) {
        var jsonParams = {
            "start_date": moment(moment().subtract(30, "days").format("YYYY-MM-DD")).utc().format("YYYY-MM-DDThh:mm:ss"),
            "end_date": moment(moment().format("YYYY-MM-DD")).utc().format("YYYY-MM-DDThh:mm:ss"),
            "car_id": pVehicleId
        };

        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.GET_TRIPS_DETAILS_FROM_DATES_VEHICLE, jsonParams).then(function (response) {
            if (response.data.length == 0) {
                pScoreData.lastMonth.cost = 0;
                pScoreData.lastMonth.distance = 0;

                pScoreData.lastMonth.trip_date = 0;
                pScoreData.lastMonth.free_miles_earned = 0;
                pScoreData.lastMonth.free_miles_consumed = 0;
                pScoreData.lastMonth.safe_miles_driven = 0;

                pScoreData.lastMonth.price_per_category.safe_interstate = 0;
                pScoreData.lastMonth.price_per_category.safe_other = 0;
                pScoreData.lastMonth.price_per_category.aggressive = 0;
                pScoreData.lastMonth.price_per_category.risky = 0;
                pScoreData.lastMonth.price_per_category.dangerous = 0;
                pScoreData.lastMonth.distance_per_category.safe_interstate = 0;
                pScoreData.lastMonth.distance_per_category.safe_other = 0;
                pScoreData.lastMonth.distance_per_category.aggressive = 0;
                pScoreData.lastMonth.distance_per_category.risky = 0;
                pScoreData.lastMonth.distance_per_category.dangerous = 0;
                pScoreData.lastMonth.break_points = [];
                pScoreData.lastMonth.date = 0;
            } else {
                if (angular.isDefined(response.data.data))
                    response.data = response.data.data;
                pScoreData.lastMonth.cost = response.data.cost;
                pScoreData.lastMonth.distance = Math.round(response.data.distance * 100) / 100;

                pScoreData.lastMonth.trip_count = response.data.trip_count;
                pScoreData.lastMonth.last_trip_date = response.data.last_trip_date;
                pScoreData.lastMonth.first_trip_date = response.data.first_trip_date;
                pScoreData.lastMonth.free_miles_earned = response.data.free_miles_earned;
                pScoreData.lastMonth.free_miles_consumed = response.data.free_miles_consumed;
                pScoreData.lastMonth.safe_miles_driven = Math.round(response.data.safe_miles_driven * 100) / 100;

                pScoreData.lastMonth.price_per_category.safe_interstate = response.data.price_per_category.safe_interstate;
                pScoreData.lastMonth.price_per_category.safe_other = response.data.price_per_category.safe_other;
                pScoreData.lastMonth.price_per_category.aggressive = response.data.price_per_category.aggressive;
                pScoreData.lastMonth.price_per_category.risky = response.data.price_per_category.risky;
                pScoreData.lastMonth.price_per_category.dangerous = response.data.price_per_category.dangerous;
                pScoreData.lastMonth.distance_per_category.safe_interstate = Math.round(response.data.distance_per_category.safe_interstate * 100) / 100;
                pScoreData.lastMonth.distance_per_category.safe_other = Math.round(response.data.distance_per_category.safe_other * 100) / 100;
                pScoreData.lastMonth.distance_per_category.aggressive = Math.round(response.data.distance_per_category.aggressive * 100) / 100;
                pScoreData.lastMonth.distance_per_category.risky = Math.round(response.data.distance_per_category.risky * 100) / 100;
                pScoreData.lastMonth.distance_per_category.dangerous = Math.round(response.data.distance_per_category.dangerous * 100) / 100;
                if (angular.isDefined(response.data.breakdown))
                    pScoreData.lastMonth.break_points = response.data.breakdown;
                if (angular.isDefined(response.data.break_down))
                    pScoreData.lastMonth.break_points = response.data.break_down;
                pScoreData.lastMonth.date_from = moment().subtract(30, "days").format("YYYY-MM-DD");
                pScoreData.lastMonth.date_to = moment().subtract(1, "days").format("YYYY-MM-DD");
            }
            getOverallTripsInfoWeekPhaseByVehicle(pScoreData, pCallback, pVehicleId);
        });
    }

    function getOverallTripsInfoWeekPhaseByVehicle(pScoreData, pCallback, pVehicleId) {
        var jsonParams = {
            "start_date": moment(moment().subtract(7, "days").format("YYYY-MM-DD")).utc().format("YYYY-MM-DDThh:mm:ss"),
            "end_date": moment(moment().format("YYYY-MM-DD")).utc().format("YYYY-MM-DDThh:mm:ss"),
            "car_id": pVehicleId
        };

        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.GET_TRIPS_DETAILS_FROM_DATES_VEHICLE, jsonParams).then(function (response) {
            if (angular.isDefined(response.data.data))
                response.data = response.data.data;
            if (response.data.length == 0) {
                pScoreData.lastWeek.cost = 0;
                pScoreData.lastWeek.distance = 0;

                pScoreData.lastWeek.trip_date = 0;
                pScoreData.lastWeek.free_miles_earned = 0;
                pScoreData.lastWeek.free_miles_consumed = 0;
                pScoreData.lastWeek.safe_miles_driven = 0;

                pScoreData.lastWeek.price_per_category.safe_interstate = 0;
                pScoreData.lastWeek.price_per_category.safe_other = 0;
                pScoreData.lastWeek.price_per_category.aggressive = 0;
                pScoreData.lastWeek.price_per_category.risky = 0;
                pScoreData.lastWeek.price_per_category.dangerous = 0;
                pScoreData.lastWeek.distance_per_category.safe_interstate = 0;
                pScoreData.lastWeek.distance_per_category.safe_other = 0;
                pScoreData.lastWeek.distance_per_category.aggressive = 0;
                pScoreData.lastWeek.distance_per_category.risky = 0;
                pScoreData.lastWeek.distance_per_category.dangerous = 0;
                pScoreData.lastWeek.break_points = [];
                pScoreData.lastWeek.date = 0;
            } else {
                pScoreData.lastWeek.cost = response.data.cost;
                pScoreData.lastWeek.distance = Math.round(response.data.distance * 100) / 100;

                pScoreData.lastWeek.trip_count = response.data.trip_count;
                pScoreData.lastWeek.last_trip_date = response.data.last_trip_date;
                pScoreData.lastWeek.first_trip_date = response.data.first_trip_date;
                pScoreData.lastWeek.free_miles_earned = response.data.free_miles_earned;
                pScoreData.lastWeek.free_miles_consumed = response.data.free_miles_consumed;
                pScoreData.lastWeek.safe_miles_driven = Math.round(response.data.safe_miles_driven * 100) / 100;

                pScoreData.lastWeek.price_per_category.safe_interstate = response.data.price_per_category.safe_interstate;
                pScoreData.lastWeek.price_per_category.safe_other = response.data.price_per_category.safe_other;
                pScoreData.lastWeek.price_per_category.aggressive = response.data.price_per_category.aggressive;
                pScoreData.lastWeek.price_per_category.risky = response.data.price_per_category.risky;
                pScoreData.lastWeek.price_per_category.dangerous = response.data.price_per_category.dangerous;
                pScoreData.lastWeek.distance_per_category.safe_interstate = Math.round(response.data.distance_per_category.safe_interstate * 100) / 100;
                pScoreData.lastWeek.distance_per_category.safe_other = Math.round(response.data.distance_per_category.safe_other * 100) / 100;
                pScoreData.lastWeek.distance_per_category.aggressive = Math.round(response.data.distance_per_category.aggressive * 100) / 100;
                pScoreData.lastWeek.distance_per_category.risky = Math.round(response.data.distance_per_category.risky * 100) / 100;
                pScoreData.lastWeek.distance_per_category.dangerous = Math.round(response.data.distance_per_category.dangerous * 100) / 100;
                if (angular.isDefined(response.data.breakdown))
                    pScoreData.lastWeek.break_points = response.data.breakdown;
                if (angular.isDefined(response.data.break_down))
                    pScoreData.lastWeek.break_points = response.data.break_down;
                pScoreData.lastWeek.date_from = moment().subtract(7, "days").format("YYYY-MM-DD");
                pScoreData.lastWeek.date_to = moment().subtract(1, "days").format("YYYY-MM-DD");
            }
            pCallback(pScoreData);
        });
    }

    function getLastTripInfoAndScoreByVehicle(pVehicleId) {
        var q = $q.defer();
        var jsonParams = {
            "car_id": pVehicleId
        };
        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.GET_LAST_TRIP_DETAILS_VEHICLE, jsonParams).then(function (response) {
            var pScoreData = new OverallDrivingInfo();

            if (angular.isDefined(response.data.data))
                response.data = response.data.data;
            if (response.data.length == 0) {
                pScoreData.lastTrip.cost = 0;
                pScoreData.lastTrip.distance = 0;

                pScoreData.lastTrip.trip_date = 0;
                pScoreData.lastTrip.free_miles_earned = 0;
                pScoreData.lastTrip.free_miles_consumed = 0;
                pScoreData.lastTrip.safe_miles_driven = 0;

                pScoreData.lastTrip.price_per_category.safe_interstate = 0;
                pScoreData.lastTrip.price_per_category.safe_other = 0;
                pScoreData.lastTrip.price_per_category.aggressive = 0;
                pScoreData.lastTrip.price_per_category.risky = 0;
                pScoreData.lastTrip.price_per_category.dangerous = 0;
                pScoreData.lastTrip.distance_per_category.safe_interstate = 0;
                pScoreData.lastTrip.distance_per_category.safe_other = 0;
                pScoreData.lastTrip.distance_per_category.aggressive = 0;
                pScoreData.lastTrip.distance_per_category.risky = 0;
                pScoreData.lastTrip.distance_per_category.dangerous = 0;
                pScoreData.lastTrip.break_points = [];
                pScoreData.lastTrip.date = 0;
                pScoreData.lastTrip.start_location = null;
                pScoreData.global.end_location = null;
                pScoreData.lastTrip.trip_id = null;
            } else {
                pScoreData.lastTrip.cost = response.data.cost;
                pScoreData.lastTrip.distance = Math.round(response.data.distance * 100) / 100;

                pScoreData.lastTrip.trip_date = response.data.trip_date;
                pScoreData.lastTrip.free_miles_earned = response.data.free_miles_earned;
                pScoreData.lastTrip.free_miles_consumed = response.data.free_miles_consumed;
                pScoreData.lastTrip.safe_miles_driven = Math.round(response.data.safe_miles_driven * 100) / 100;

                pScoreData.lastTrip.price_per_category.safe_interstate = response.data.price_per_category.safe_interstate;
                pScoreData.lastTrip.price_per_category.safe_other = response.data.price_per_category.safe_other;
                pScoreData.lastTrip.price_per_category.aggressive = response.data.price_per_category.aggressive;
                pScoreData.lastTrip.price_per_category.risky = response.data.price_per_category.risky;
                pScoreData.lastTrip.price_per_category.dangerous = response.data.price_per_category.dangerous;
                pScoreData.lastTrip.distance_per_category.safe_interstate = Math.round(response.data.distance_per_category.safe_interstate * 100) / 100;
                pScoreData.lastTrip.distance_per_category.safe_other = Math.round(response.data.distance_per_category.safe_other * 100) / 100;
                pScoreData.lastTrip.distance_per_category.aggressive = Math.round(response.data.distance_per_category.aggressive * 100) / 100;
                pScoreData.lastTrip.distance_per_category.risky = Math.round(response.data.distance_per_category.risky * 100) / 100;
                pScoreData.lastTrip.distance_per_category.dangerous = Math.round(response.data.distance_per_category.dangerous * 100) / 100;
                if (angular.isDefined(response.data.breakdown))
                    pScoreData.lastTrip.break_points = response.data.breakdown;
                if (angular.isDefined(response.data.break_down))
                    pScoreData.lastTrip.break_points = response.data.break_down;
                pScoreData.lastTrip.date = DateUtil.getLocalTimeFromUtc(moment(response.data.last_trip_date));
                pScoreData.lastTrip.start_location = response.data.start_location;
                pScoreData.lastTrip.end_location = response.data.end_location;
                pScoreData.lastTrip.price_per_mile_current = response.data.price_per_mile_current;
                pScoreData.lastTrip.trip_id = response.data.trip_id;
            }
            console.log("$$$$$$$$$$$$", pScoreData);
            q.resolve(pScoreData);
        }, function (error) {
            q.reject(error);
        });
        return q.promise;
    }
}
