angular.module('services', [])
    .service('TripsServices', TripsServices);

function TripsServices($q, HttpProxy, LocalStorage, PlaceholderServices, TripsUtil, LocalStorageKeys, DateUtil, GlobalConstants, WebServiceUrls, $timeout) {

    this.getTrips = getTrips;
    this.getTrip = getTrip;
    this.getSegmentsColors = getSegmentsColors;
    this.getNewTripNotif = getNewTripNotif;
    this.getTripsByVehicleId = getTripsByVehicleId;
    this.getTripTypes = getTripTypes;
    this.setTransportType = setTransportType;

    function getTrips(pStartDate, pEndDate, isSimple, ismeta) {
        var q = $q.defer();

        // var jsonParams = {
        //     start_date: moment(pStartDate).format("YYYY-MM-DD HH:mm:ss"),
        //     end_date: moment(pEndDate).format("YYYY-MM-DD HH:mm:ss"),
        //     is_simple: isSimple
        // };
        if (typeof (ismeta) == "undefined") {
            ismeta = true;
        }
        pStartDate = moment(moment(pStartDate).format("YYYY-MM-DD")).utc().format("YYYY-MM-DDThh:mm:ss");
        //console.log(444555666, pStartDate);
        pEndDate = moment(moment(pEndDate).add(1, "days").format("YYYY-MM-DD")).utc().format("YYYY-MM-DDThh:mm:ss");
        // pStartDate = DateUtil.getUtcDate(pStartDate);
        // pEndDate = DateUtil.getUtcDate(pEndDate);
        var jsonParams = {
            start_date: pStartDate,
            end_date: pEndDate,
            is_simple: isSimple,
            return_meta: ismeta
        };

        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.GET_TRIPS, jsonParams)
            .then(function (response) {
                for (var i = 0; i < response.data.length; i++) {
                    //DateUtil.convertToEST(trip.startTime);
                    //DateUtil.convertToEST(trip.endTime);
                    //response.data[i].startTime = DateUtil.formatDateAsUTC(response.data[i].startTime);
                    //response.data[i].endTime = DateUtil.formatDateAsUTC(response.data[i].endTime);
                }

                q.resolve(response);
            }, function (pError) {
                q.reject(pError);
            });
        return q.promise;
    }

    function getTrip(pTripId) {
        var q = $q.defer();
        var jsonParams = {
            trip_id: pTripId
        };

        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.GET_TRIP, jsonParams)
            .then(function (response) {
                q.resolve(response.data);
            }, function (pError) {
                q.reject(pError);
            });
        return q.promise;
    }

    function getSegmentsColors() {
        var q = $q.defer();
        HttpProxy.get(GlobalConstants.BASE_URL + WebServiceUrls.GET_SEGMENTS_COLORS).then(function (data) {
            q.resolve(data);
        }, function (error) {
            q.reject(error);
        });

        return q.promise;
    }

    function getNewTripNotif(pTripId) {
        var q = $q.defer();
        var jsonParams = {
            last_trip_id: pTripId
        };

        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.GET_NEW_TRIP_NOTIF2, jsonParams).then(function (data) {
             if(Object.keys(data.data).length > 0){
             if(angular.isUndefined(data.trip_id) && angular.isDefined(data.data.data.trip_id)){
                data = data.data.data;
            }
             }else{
                 data.trip_id="";
             }
            q.resolve(data);
        }, function (error) {
            q.reject(error);
        });
        return q.promise;
    }

    function getTripsByVehicleId(pStartDate, pEndDate, pCarId) {
        var q = $q.defer();

        var jsonParams = {
            car_id: pCarId,
            start_date: moment(moment(pStartDate).format("YYYY-MM-DD")).utc().format("YYYY-MM-DDThh:mm:ss"),
            end_date: moment(moment(pEndDate).add(1, "days").format("YYYY-MM-DD")).utc().format("YYYY-MM-DDThh:mm:ss"),
            is_simple: true
        };

        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.GET_TRIPS_BY_VEHICLE_ID, jsonParams)
            .then(function (response) {
                for (var i = 0; i < response.data.length; i++) {
                    response.data[i].startTime = DateUtil.formatDateAsUTC(response.data[i].startTime);
                    response.data[i].endTime = DateUtil.formatDateAsUTC(response.data[i].endTime);
                }

                q.resolve(response);
            }, function (pError) {
                q.reject(pError);
            });
        return q.promise;
    }

    function getTripTypes() {
        var q = $q.defer();

        HttpProxy.get(GlobalConstants.BASE_URL + WebServiceUrls.GET_TRIPS_TYPES)
            .then(function (response) {
                q.resolve(response.data);
            }, function (pError) {
                q.reject(pError);
            });
        return q.promise;
    }

    function setTransportType(pTripTypeId, pTripId) {
        var q = $q.defer();

        var jsonParams = {
            "transportType_id": pTripTypeId,
            "trip_id": pTripId
        }

        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.SET_TRANSPORT_TYPE, jsonParams)
            .then(function (response) {
                q.resolve(response);
            }, function (pError) {
                q.reject(pError);
            });
        return q.promise;
    }
}
