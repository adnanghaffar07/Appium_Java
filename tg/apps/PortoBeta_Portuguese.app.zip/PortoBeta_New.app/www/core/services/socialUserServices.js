(function () {
    angular.module('services')
        .factory('SocialUserService', SocialUserService);

    function SocialUserService($q, $http, $cordovaFacebook, $cordovaOauth, SocialConstants, HttpProxy, AppConfigServices, GlobalConstants, StringUtil, $timeout, BooleanConstant, LocalStorageKeys) {

        var ref = "",
            handleclickcall = "";
        /**
         * This function is used to open the google login page
         */
        function loginGoogle(hasRefreshToken) {
            var q = $q.defer();

            getGoogleApiKeys().then(function (response) {
                window.plugins.googleplus.trySilentLogin({
                        'webClientId': response.googleClientID
                    },
                    function (obj) {
                        console.log("#### SILENT LOGIN SUCCESS ####", obj);
                        q.resolve(obj);
                        //alert('silent login success: ' + JSON.stringify(obj));
                    },
                    function (msg) {
                        console.log("#### SILENT LOGIN ERROR, WILL TRY HARD LOGIN", msg);
                        // error, call the login function to get the auth screen
                        window.plugins.googleplus.login({
                                'webClientId': response.googleClientID
                            },
                            function (obj) {
                                console.log("### HARD LOGIN SUCCESS ###", obj);
                                q.resolve(obj);
                                //alert('hard login success: ' + JSON.stringify(obj));
                            },
                            function (msg) {
                                console.log("### HARD LOGIN ERROR ###", msg);
                                q.reject(msg);
                            }
                        );
                    }
                );
            });

            return q.promise;
        }


        /**
         * This fucntion is used to revoke the goolge access token so that its not expired
         */
        function revokeGoogleAccess(refreshToken) {
            var q = $q.defer();
            getGoogleApiKeys().then(function (reponse) {
                googleRevokeTokenCore(q, refreshToken, reponse.googleClientID, reponse.googleAPIKey);
            }, function (error) {
                googleRevokeTokenCore(q, refreshToken, SocialConstants.GOOGLE_API, SocialConstants.GOOGLE_SECRET);
            });

            return q.promise;
        }


        /**
         * This function is used to open facebook login using oAuth
         */
        function loginFacebookOAuth() {
            var q = $q.defer();
            //			AppConfigServices.getConfigValue('facebook_app_id').then(function (facebookAppId) {
            //				if(facebookAppId){
            //					loginFacebookCore(q,facebookAppId);
            //				}else{
            //					loginFacebookCore(q,SocialConstants.FACEBOOK_APP_ID);
            //				}
            //		}, function (error) {
            //				loginFacebookCore(q,SocialConstants.FACEBOOK_APP_ID);
            //				});
            //			return q.promise;
            
            
            // 1. get connection status.
            // --> If status is Connected, then return information
            // --> if status is Expired, then trigger the login plugin.
            
            facebookConnectPlugin.getLoginStatus(function(response){
                if(response.status === 'connected'){
                    q.resolve(response);
                } else {
                    facebookConnectPlugin.login(['public_profile, email'], function (response) {
                        //success
                        q.resolve(response);
                    }, function (error) {
                        //fail
                        q.reject(error);
                    });
                }
            }, function(error){
                //fail
                q.reject(error);
            });

            return q.promise;
        }


        function loginFacebookCore(pQ, appId) {
            if (handleclickcall.length == 0) {
                handleclickcall = BooleanConstant.TRUE;
                var languageKey = window.localStorage[LocalStorageKeys.CURRENT_LOCALE_KEY];
                if (angular.isUndefined(languageKey)) {
                    languageKey = "en_US"; // default value   
                } else {
                    languageKey = languageKey.replace('-', '_');
                }
                $cordovaOauth.facebook(appId, ["email", "user_friends"], {
                    redirect_uri: SocialConstants.FACEBOOK_REDIRECT_URL,
                    locale: languageKey
                }).then(function (response) {
                    pQ.resolve(response);
                }, function (error) {
                    pQ.reject(error);
                });
                $timeout(function () {
                    handleclickcall = "";
                }, 1000);
            } else {
                pQ.resolve("");
            }
        }

        /**
         * This function is ussed to get teh facebook user meta data
         * @params accessToken
         */
        function getFacebookUserData(accessToken) {
            delete $http.defaults.headers.common["Authorization"];
            delete $http.defaults.headers.common["User-Token"];
            var q = $q.defer();
            var url = SocialConstants.FACEBOOK_PROFILE + accessToken;
            HttpProxy.get(url).then(function (response) {
                if (!angular.isDefined(response.data.email)) {
                    q.reject(response.data);
                } else {
                    q.resolve(response.data);
                }
            }, function (error) {
                q.reject(error.data);
            });
            return q.promise;
        }

        /**
         * This function is ussed to get teh facebook user meta data
         * @params accessToken
         */
        function getFacebookFriends(accessToken) {
            var q = $q.defer();
            var url = SocialConstants.GET_FRIENDS + accessToken;
            HttpProxy.get(url).then(function (response) {
                q.resolve(response.data);
            }, function (error) {
                q.reject(error.data);
            });
            return q.promise;
        }
        /**
         * This function is used to get google users meta data
         * @params accessToken
         */
        function getGoogleUserData(accessToken) {
            var q = $q.defer();
            delete $http.defaults.headers.common["Authorization"];
            delete $http.defaults.headers.common["User-Token"];
            var url = SocialConstants.GOOGLE_PROFILE + accessToken;
            $http({
                    method: "get",
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    url: url
                })
                .then(function (response) {
                    q.resolve(response.data);
                }, function (error) {
                    q.reject(error);
                });
            // HttpProxy.get(url).then(function (response) {
            // 	q.resolve(response.data);
            // }, function (error) {
            // 		q.reject(error.data);
            // 	});
            return q.promise;
        }

        function openGoolgeInAppBrowser(pQ, clientId, clientSecret, hasRefreshToken) {
            if (handleclickcall.length == 0) {
                handleclickcall = BooleanConstant.TRUE;
                var redirectURl = SocialConstants.GOOGLE_REDIRECT_URL;
                var url = SocialConstants.GOOGLE_TOKEN_URL;
                var languageKey = window.localStorage[LocalStorageKeys.CURRENT_LOCALE_KEY];
                if (angular.isUndefined(languageKey)) {
                    languageKey = "en"; // default value   
                } else {
                    languageKey = languageKey.split('-')[0];
                }
                var refrenceUrl = 'https://accounts.google.com/o/oauth2/auth?client_id=' + clientId + '&redirect_uri=' + redirectURl + '&scope=' + encodeURIComponent('https://www.googleapis.com/auth/plus.me https://www.googleapis.com/auth/plus.profile.emails.read https://www.googleapis.com/auth/userinfo.profile') + '&approval_prompt=force&response_type=code&hl=' + languageKey;
                var clearCache = '';
                if (!hasRefreshToken || hasRefreshToken == 'undefined') {
                    refrenceUrl = refrenceUrl + 'access_type=offline';
                    clearCache = ', clearsessioncache=yes';
                }
                ref = window.open(refrenceUrl, '_blank', 'location=no' + clearCache);
                ref.addEventListener('loadstart', function (event) {
                    if ((event.url).startsWith(redirectURl)) {
                        var requestToken = (event.url).split("code=")[1];
                        var data = "client_id=" + clientId +
                            "&grant_type=authorization_code" +
                            "&client_secret=" + clientSecret +
                            "&redirect_uri=" + redirectURl +
                            "&code=" + requestToken;
                        $http({
                                method: "post",
                                headers: {
                                    'Content-Type': 'application/x-www-form-urlencoded'
                                },
                                url: url,
                                data: data
                            })
                            .success(function (data) {
                                pQ.resolve(data);
                            }).error(function (data, status) {
                                logoutGoolge();
                                pQ.reject(data);
                            });
                        ref.close();
                    }
                });
                $timeout(function () {
                    handleclickcall = "";
                }, 1000);
            }
        }

        function googleRevokeTokenCore(pQ, refreshToken, clientId, clientSecret) {
            var data = "client_id=" + clientId +
                "&grant_type=refresh_token" +
                "&client_secret=" + clientSecret +
                "&refresh_token=" + refreshToken;
            var url = SocialConstants.GOOGLE_TOKEN_URL;
            $http({
                    method: "post",
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    url: url,
                    data: data
                })
                .then(function (response) {
                    pQ.resolve(response.data);
                }, function (error) {
                    pQ.reject(error);
                });
        }

        function getGoogleApiKeys() {
            var q = $q.defer();
            AppConfigServices.getConfigValue('google_app_id').then(function (googleCliendId) {
                AppConfigServices.getConfigValue('google_app_secret').then(function (googleSecret) {
                    q.resolve({
                        'googleClientID': googleCliendId,
                        'googleAPIKey': googleSecret
                    });
                }, function (error) {
                    q.reject(false);
                });
            }, function (error) {
                q.reject(false);
            });
            return q.promise;
        }

        function getValidAddress(address) {

            var q = $q.defer();
            var data = address;
            var url = SocialConstants.GOOGLE_VALIDATE_ADDRESS + data;
            $http({
                    method: "get",
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    url: url
                })
                .then(function (response) {
                    q.resolve(response.data);
                }, function (error) {
                    q.reject(error);
                });

            return q.promise;
        }

        function logoutGoolge(token) {
            //cordova.InAppBrowser.open('https://accounts.google.com/logout', '_blank', 'hidden=yes');
            // var q = $q.defer();
            // var url = 'https://accounts.google.com/o/oauth2/revoke';
            // $http({method: "get", url: url , params : {token : token}})
            // .then(function(response){
            // 	q.resolve(response.data);
            // },function(error){
            // 	q.reject(error);
            // });

            try {
                window.plugins.googleplus.logout(
                    function (msg) {
                      console.log(msg, 'logout');
                    }
                );
            } catch(e) {
                console.log(e, 'logout');
            }
        }

        if (typeof String.prototype.startsWith != 'function') {
            String.prototype.startsWith = function (str) {
                return this.indexOf(str) == 0;
            };
        }

        return {
            loginGoogle: loginGoogle,
            loginFacebookOAuth: loginFacebookOAuth,
            getFacebookUserData: getFacebookUserData,
            getGoogleUserData: getGoogleUserData,
            openGoolgeInAppBrowser: openGoolgeInAppBrowser,
            revokeGoogleAccess: revokeGoogleAccess,
            getValidAddress: getValidAddress,
            logoutGoolge: logoutGoolge,
            getFacebookFriends: getFacebookFriends
        };
    }
})();
