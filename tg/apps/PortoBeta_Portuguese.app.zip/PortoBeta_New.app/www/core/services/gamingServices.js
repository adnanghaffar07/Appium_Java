angular.module('services')
    .service('GamingServices', GamingServices);

function GamingServices($q, HttpProxy, PlaceholderServices, GlobalConstants, WebServiceUrls) {

    this.getDashboardGamingData = getDashboardGamingData;
    this.getMissionsData = getMissionsData;
    this.getBadgesData = getBadgesData;
    this.getCoinsHistory = getCoinsHistory;
    this.getCoinsTotal = getCoinsTotal;
    this.alertCoinTag = alertCoinTag;
    this.getRankings = getRankings;
    this.removeFriend = removeFriend;
    this.searchFriends = searchFriends;
    this.addFriend = addFriend;

    /*
        Name: getDashboardGamingData
        Desc: Fetch all dashboard needed gamification data
        return: Returns Badge progress, Action progress, Coins amount, Rebate % and Rankings
    */
    function getDashboardGamingData() {
        var q = $q.defer();
        HttpProxy.get(GlobalConstants.BASE_URL + WebServiceUrls.GET_DASH_GAMING_DATA)
            .then(function (pResponse) {
                q.resolve(pResponse.data);
            }, function (error) {
                q.reject(error);
            });
        return q.promise;
    }

    /*
        Name: getMissionsData
        Desc: Fetch missions list for Mission screen
        return: Returns Missions with user progress
    */
    function getMissionsData() {
        var q = $q.defer();
        HttpProxy.get(GlobalConstants.BASE_URL + WebServiceUrls.GET_MISSIONS_DATA)
            .then(function (pResponse) {
                q.resolve(pResponse.data);
            }, function (error) {
                q.reject(error);
            });
        return q.promise;
    }

    /*
        Name: getBadgesData
        Desc: Fetch badges list for Badges screen
        return: Returns Badges with user progress
    */
    function getBadgesData() {
        var q = $q.defer();
        HttpProxy.get(GlobalConstants.BASE_URL + WebServiceUrls.GET_BADGES_DATA)
            .then(function (pResponse) {
                q.resolve(pResponse.data);
            }, function (error) {
                q.reject(error);
            });
        return q.promise;
    }

    /*
        Name: getCoinsHistory
        Desc: Fetch data for coins history screen
        return: Earned and Spent coins data
    */
    function getCoinsHistory() {
        var q = $q.defer();
        HttpProxy.get(GlobalConstants.BASE_URL + WebServiceUrls.GET_COINS_HISTORY)
            .then(function (pResponse) {
                q.resolve(pResponse.data);
            }, function (error) {
                q.reject(error);
            });
        return q.promise;
    }

    /**
     * Name: getCoinsTotal
     * Desc: Fetch the coins total
     * return: Coins total
     */
    function getCoinsTotal() {
        var q = $q.defer();
        HttpProxy.get(GlobalConstants.BASE_URL + WebServiceUrls.GET_COINS_TOTAL)
            .then(function (response) {
                q.resolve(response.data);
            }, function (error) {
                q.reject(error);
            });
        return q.promise;
    }

    function alertCoinTag(tag) {
        var q = $q.defer();
        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.ALERT_COIN_TAG, {tag: tag})
            .then(function (response) {
                q.resolve(response.data);
            }, function (error) {
                q.reject(error);
            });
        return q.promise;
    }

    /*
        Name: getRankings
        Desc: Fetch data friends and community
        return: Get friends and community 
    */
    function getRankings() {
        var q = $q.defer();
        HttpProxy.get(GlobalConstants.BASE_URL + WebServiceUrls.GET_RANKING)
            .then(function (pResponse) {
                q.resolve(pResponse.data);
            }, function (error) {
                q.reject(error);
            });
        return q.promise;
    }


    /*
        Name: addFriend
        Desc: add new friends to my profile
        return: object with success or error
        params: id
    */

    function addFriend(params) {
        var q = $q.defer();
        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.ADD_FRIEND, params)
            .then(function (pResponse) {
                q.resolve(pResponse.data);
            }, function (error) {
                q.reject(error);
            });
        return q.promise;
    }

    /*
        Name: removeFriend
        Desc: remove friends from my profile
        return: object with success or error
        params: id
    */

    function removeFriend(params) {
        var q = $q.defer();
        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.REMOVE_FRIEND, params)
            .then(function (pResponse) {
                q.resolve(pResponse.data);
            }, function (error) {
                q.reject(error);
            });
        return q.promise;
    }

    /*
        Name: searchFriends
        Desc: search friends
        return: object with list of friends
        params: q (query)
    */

    function searchFriends(params) {
        var q = $q.defer();
        HttpProxy.get(GlobalConstants.BASE_URL + WebServiceUrls.SEARCH_FRIEND + "?q=" + params.q)
            .then(function (pResponse) {
                q.resolve(pResponse.data);
            }, function (error) {
                q.reject(error);
            });
        return q.promise;
    }
}
