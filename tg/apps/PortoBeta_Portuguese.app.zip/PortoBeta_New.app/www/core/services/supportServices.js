angular.module('services')
    .factory('SupportServices', SupportServices);

function SupportServices($q, HttpProxy, WebServiceUrls, GlobalConstants, BooleanConstant, AssistancePlaceholderService) {

    var assistanceItems = [];

    /**
     * Get the assistance options in backend.
     */
    function getAssistanceOptions() {
        var q = $q.defer();
        AssistancePlaceholderService.get(GlobalConstants.BASE_URL + WebServiceUrls.GET_ASSISTANCE_OPTIONS)
            .then(function (response) {
                console.log('data', response.data);
                q.resolve(response.data);
            }, function (err) {
                q.reject(err);
            });
        return q.promise;
    }

    /**
     * Parse the item.action and return the correct action parsed.
     * @param action
     * @returns {{type: string, action: string}} the parsed data.
     */
    function getAction(action) {
        if (action.hasOwnProperty('website')) {
            return {
                type: 'website',
                action: action['website']
            };
        } else if (action.hasOwnProperty('email')) {
            return {
                type: 'email',
                action: action['email']
            };
        } else if (action.hasOwnProperty('phone')) {
            return {
                type: 'phone',
                action: action['phone']
            };
        }

        throw new Error('Invalid action');
    }

    /**
     * Order two items.
     * @param a The item A to order.
     * @param b The item B to order.
     * @returns {number} -1 if b > a and 1 if a < b.
     */
    function sortAssistanceOption(a, b) {
        return a.order <= b.order ? -1 : 1;
    }

    return {
        getAssistanceOptions: getAssistanceOptions,
    }
}