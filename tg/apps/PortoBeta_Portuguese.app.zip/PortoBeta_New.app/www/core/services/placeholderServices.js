angular.module('services')
    .service('PlaceholderServices', PlaceholderServices);

function PlaceholderServices($q, StringUtil, GlobalConstants, WebServiceUrls, ClientType) {

    this.get = get;
    this.post = post;


    function post(pUrl, pJsonParams) {
        return innerRequest(pUrl, pJsonParams);
    }

    function get(pUrl, pJsonParams) {
        return innerRequest(pUrl, pJsonParams);
    }

    function innerRequest(pUrl, pJsonParams) {
        var q = $q.defer();
        var response = {
            data: null
        };

        if (pUrl == GlobalConstants.BASE_URL + WebServiceUrls.GET_DASH_GAMING_DATA) {
            response.data = {
                coins: {
                    value: 351
                },
                rebate: {
                    value: 15
                },
                actions: {
                    total: 8,
                    unlocked: 4
                },
                badges: {
                    total: 6,
                    unlocked: 5
                },
                ranking: [
                    {
                        id: "123456789456123",
                        name: "Erica Ramirez",
                        username: "Flower123",
                        is_current: false,
                        position: 25,
                        score: 89,
                        picture: null
                    },
                    {
                        id: "878451321861315",
                        name: "Mike Natchos",
                        username: "Doritos",
                        is_current: true,
                        position: 26,
                        score: 88,
                        picture: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDABALDA4MChAODQ4SERATGCgaGBYWGDEjJR0oOjM9PDkzODdASFxOQERXRTc4UG1RV19iZ2hnPk1xeXBkeFxlZ2P/2wBDARESEhgVGC8aGi9jQjhCY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2P/wAARCAEsASwDASIAAhEBAxEB/8QAGwAAAgMBAQEAAAAAAAAAAAAAAwQBAgUABgf/xAA6EAABBAEDAgQDBwMDBAMBAAABAAIDEQQSITEFQRMiUWEUcYEGMkJSkaGxI8HwM2LRFXLh8TSCorL/xAAaAQADAQEBAQAAAAAAAAAAAAAAAQIDBAUG/8QAJBEBAQACAgMAAQUBAQAAAAAAAAECEQMxBBIhQRMiIzJRBWH/2gAMAwEAAhEDEQA/AKIjShqWlSY7VcIbSrhMhApVQrICVZVUpklcoXICVC5QmHLlyhAcuXKEBKhS1rnGmi1Pkj3kcCPQFK5SHMbVeeFOh3NbILsyJrjoaT78JbIz3CttI427rP8AUafptExOAurQ1lP6g8kW4mvdd/1BxuyQU/ej9NqWutZ0edoFu3BTcWRHKPK76FXMtouNgyhdai1SErlC5ASuUKUBylQpCAlcuUpBC5SupBopcpXIBBSCoKhQoZpRWlLtKK0oAwVgqAqwTJZSoXJhKlQuQEqFy5AQuXKEBIrupMbvRXhje7zcD1rlFEZcdUgJFcKMs9dNMcP9KFzrLGUfnslpXuvS8N/RaD4XSu8rDR7JebGLRRsn5LG21tIzXDk7BAkOptdrtNyQlp4KXfEb4RFaKEC9/wCUN7qFi0d8Z9EJzCqToJsxrSVLZi0jfZVczdULDaqJsa+NnmwxxBs0CeyfbKxxIa4Gu4XmQSCjw5DmvDbod1crK4vRWutLY+TFI0Br7d6HlMWrZrKVVSmSwUhQpCRpXLlKA5cuXJByhcuQCBVSruQyVKlgd0VhS9ojHIBlpRAUBpRWlAEUqoKsmTlKhcgJXLlBQEErmNL30Nq5Qnv3rf5DurQjXII2F2t3YKcsvw0xx/J6EGQ6eSNqWi2BjWBoC7DxRAygPMeSmtApRprso8BopKTAei0ZGABJSgBFhys+WIOF0lXxgA7LRcQlZmiilpW2ZIwEcJZ7E+4IEjEGQe1DLQmpGoBCcTQ9AKBNGWeYbhMldfYqozsL4mQYHh3NLexMn4ht6dIXnp2eE7W3dp/ZHwc8xSCyS38vZXKzyj0gVggwytlaHNuvdGCpmsFIUKQkaVKhSgIXLlyAhcuXIBJyC7ZGcgvUmralp3QyVIKAaY5GaUoxyOxyAYBVwgtciAoC65cFKYQhTSaG97+SKgga5Xc+UX7FTldRWM3QJg8Df7oPI5W70HBqP4lw3cKbfp6rIw8Z+bmaAXBjzZHsvaQxBjGtaKDRQU4zbXK6jmw8eikxWEVceFppj7UlPHpG9fRZc+xK18g+UrLnbZKixrjSLigy8I720l5Qa9lLQnJsUF+6NKEFxSMvIKS7uUxMlnJwVRxQ7VnFUKpFWcBIwsdwVmU6OQtPIK0QUvmxWBKORsU4zsaXRsineHtv+q3gvFY0ro5Gua6iCvYYsnjQMfd2PRVGdgwVlVSmSVy5cgOULlyA5QuXIBG7CG5QHLiUgE5VtXchlI12voo7HpVEYUA6xyM1yUYUZjkAyCrWhNRQEBx4URMqLVyCf2XSAhhrlO4WPqYOCOCFGbTBodEwWwMMnJO1rXCFjt0QtHsiA2rx6Rld1ZVPClQ4qklZeCkpButCQXaRmAAU1tiSlZVlIzfdWjLuCs+fgqK1hCZ2yVJ3RpnblB7pKDkFhLOFJuU7JSQoFDcqFXVSE0VRWoOaWngqKUhNFIOjMchb77L0PRJrgLD2KyMllgOHKd6GSJXbmiqjOxv2ptUtSqSva61W11oJZQotdaAkqFFqtoDOU2iPjLeyGQpCpVCEQqhQatK7QoBpEYUARgKYY0obEdhQF2NR2NKG0ozXBAc9uw25PqtbprC1hBo6iCvLO6t4vUGwxEeHem/ze69PizBga29h3UZdtcemw37uwXNO6iM2wHi1zR5lcZrqjnBVlfQ5+qUfMKJskD0RacxHkd5TukJihTZ25Db/AFS7sgu37pWtZNCu3CQytiUwJr5SmUdVhJUZc330MFElb5kFxpS0DncljZKNJuUOhaaapSgqz3AD3QHuJ4TRaupCENXdXaa5QlL/ALhROmZLMaZxkcGMI3JVHbghIZJHhD2TRXswQQCDYPdSvO9B6rRbiZDvLxG49vZeiVs3KFZQgIXLioKAgldaglQgj78UOGyTmwyOAtFs7fUIeVlw48DpZnANb+6gMaSIt5CARS1ficXIxxO1zdOnURe4CycnPxHxtfGXaroiuEGq4qrZ2g1qH6oUs7THbHA3sEqG2mbWjyG/nH6pqOZh/E39VisYjNakem2yRp4cD9Vn9U6nGMd0UDw5ztnEdglZixuLLqbZIFH03F/ssx0jdLxQOrj23VSFR8CYR5bJHC6O3zXu4HESduQV4GEmR0LGAagdj9bXuumgvdFqJNgAn9FGbXB6RuzAFJNN25VCqOkGq/RUjQeS4jZY+VK6iNRr0tE6jnlr9DAXOPDQNysrJlmDdUmll9id0msmkzTH2QhO71tJTTv1diPkg/FEHcUPUKdLjYZNfKs/dI4+S11WRRWrBB4tFu4QKzciIncBJSNpenm6e5sZLhS89nN0PKKcuyDygudStI7lKSSizunE2iF1ldYS+pz9gqu0g054v3KekbN2D3XJbQavt6gq8byDTkaGx+yzsyxqHunwbSeYwkurfa0JpR4YyUiN5ewcOqlq4XXcqOVjZ3eLHsDY3A+axnbGk702AyzNeR5WGz/ZWye2XLNGZP8Anv6BSM2YflP0SPTQIVaSXx0v5WfoVHx8n5GfugtHaUJL46T8rV3xz/yNTBCHrE7NpCHj17pfqGdJluALvI3ge/qpZkSZVQ0dTjWq7TOVj40UIJZbuGi6v5qTZbCQL/Rc40K/VSTZJ7DYIRKDEDyDY7JqKdjtjsUly0g8FQ1tHYphrNc31H6rnzhmzaLlnaD+Y/qjxNsBIxXuc9pDiTfZVzsKOARvglMrXMBf5a0OPLbWj0XB+O6g1jr8OManV+y7rs0EUceHjStlZHduadi48n/PRPEsiPSdAmJefMBTV6/oZc6WMncOca+S8fiYr3Bj3CmuOxPp3K9j9nnahin/AGnb0U5xeD0rjTSUmXkhxvsm3C2kJQMO6DjHc5zGyT357pqb+ExsLF8WaLx8gj8XcnsPQJuDprQ3VJTnHffshdSgbk4r4XOLSeD6Hsnj87GX3p4XOla7Kc6nAOcS0XdDsrwtL2OsWW90xN03KY7zRhwb+IEFST4WMYqpzjbnIysPDG7JXpdsaXo/s5O/xgx27SsCOHW+jdL1XRMLwm6yKAGylpW7lNDse/qvD9YIEpAXt5TeKR7LxHWv9UoyLjnxhTuNFKO5TMotLFu6aau5xjgJHJSp5AG4I3PumBuNJ4Kr8MfwuFe4VSs7KvhE6HAkafmrHY16KYo/Dbp/Uqzm2ErTk0swoOUdJB/MKRmBAzTQaUjvTNd98+trX6Np8KQBw1Xx7LO8MSs8v3xf1VsGUwzhw+Sti9CFyrG8PYHDgq6RoUKVCAhcpUIBfpsQjjdO/YDg/wApfJndM8yHvswegR8x4puMw+Vot3/CUBtxeeG7BSaknlaGjtyhhS82VwCYcBujxs2tViZbkzXZK05A9KO1ultKrG6n/JFDDI9rGjzPIaEG9H9nsJ3/AE7UBTst9X/tCwpMWDC64Ys9pMEchDwO47f2XvYoBhQYjQKbDQP8fyvJ/a8MPVvGYNpGi/mNlePSL2b6ngNx8eF7W00se5t+mnb+Vb7LSanxtDr0k37bcJvr+Qx3TsMNP3oXf/yP+FifZmd0fVWM/C41X0KWU+Kwv175u7SqaQHWrR8KSwu9lKug5XgNO9V6LLypZTekagtOaNpbVbJdzGVVJLxecnbO7aqCSdjku33XppYI38krocTGY8U3U5JpvTP6V0kveJJG030XoixsbQ1ooBEY1rGgNFKjgSq0y9t1WW24pPqvFdaNyFe4yxWOAF4jrAuZyWTTi+xgyDdBc1MPCGRaZUEN3RBsF1Lki0m1NqoV2tQWkhJ9QPlb807VJHqB8rfmnE5dE9WxC4HS7Yqq4HdWxeg6eScRhPe00gYIrDir8qYSpoKhWVUGhQrKEEy3lwFHeR5sqstMaGjsrs8znSHgbBAe7U4qVKjlEaFVoR42WUyFiZTbV+BasG0AFYN1PA7BS005jdLPcrU+zmMMnrMdi2xeYrPd/C9V9i8XTjzZTh986QfYIKtzMZqxZvZhIXz7rmczJdG1lktuyR+y+kyx68eVv5mEfsvlvURUqrG6T67lv+NPNmc/DwQ4/djI/wDwUr0J+nq+P7vH8qj59eJjkn7pAP8ACt0Njn9Wg0jYOBPtury6Th2+kRJho2SsZpHEjdO5WcXnK6UANsrLnl32TOVkbEBZWRLV7orTDHSr5jqoFXjm0CxyUg+bSbQJMo9ipba29PHltdpaD5iEwDuFhdGeHTmzqdps+wW4zchVGWUkRmuuEiux3Xi+qfeNr1fVJw0aQeV5LqTrcUsl8U1GLJyUG90eQblLuagsu3KVVu6IAgogBWXUppI9OvZI5/3B806UnnC4gfdVGeXRBWjAL+FXuiRDz3YKtlj29Bhf/Ej+SYQcQVixf9oKMpO9oUFSoKCQoUqEyZcxDGBg7JcblWkfqeSuYLKRrsanIWULKDGyyE41tNpTarGOA7q8baaXHuo03QRCOG9lKwpLDQByV9E6Hi/C9Kgj2vTZPqvB9Og+M6rBFWxeLX0xjQ1oaOAKCtnarPK2DHklf91jS4/RfLuoEPOsjnde8+1WT4HSXMH3pnBv05K8FJ54iO4TVx/ZYU8T+np4C2vs+w/FRvBNF7Qa97/9rCAL3BuwJP6Ld+zpLsyEAeXULPyFBPPouPt7i6+SFLLtVqZHUErI67WcahzS8rNyJfdMzkgFZmS6imuKSy87pUuJKh7rKJjx6nhJe9Nvoj248UrnbE0bT0PVIZJfDbKNfYHa0vhxAMAIV8jpMLj4kdAnfSmj5ewupZG+68/lu1klbWXATHT309o2s8rDnJAKDl0z5NibQwGuGxBVcgF16kIO08FNNWIp6M0AhLA7o0b0gLpUUrXagoGw3JTM/wBE/NOOSmV/pFNnWd3RoG6n03vsFRsbnte5osMFk+i0OkQB8wceGC/qqrPHvbZY0NaGjgCgpKlQkSFUqxVUEgqFK5MMIbo8bUKMWmY29kjHgZ3TAG6rG3S1XA2+azrWLMHLioJppd67BWdsKCDO6gG+icK1v/YrGMmfLkEeVjaHz/yl7def+xuN4PSfEPMjrW+4hrS47ACyrjKvG/bHK8TNbAD5Ym7j3O/8UvNA0U51PIOVmSzH8bia9EkUqvH4G+IOvTt9FqfZ14bktYQA5rtRJ9K/5ASDBZWnhMDJfF2sjTaWWXxpjj929ZI6237IDH6pC08qY3a8RhJvbkJa3Nla4fhKiVbswFosLDyHebdegyBqj9bWR8O187nPIAYO/ATt1DxINYXEBoJJT2FGQ4Ejb1XNLYmHTf8AuPFBO4nhyMabDY42k7+qzuf+L0aimA2A+irNkOjsjuhRuALntcN9gEDIlDWhoJAANkJe9o0WzJzICQdlnl13abnkHhkNbVpFw/q+yvG0WFchvOySeKK1JWl10PmkMtlPFfNVtFLaqUh5CqWnlQQmg1HNY3RdSz2kgppjramFyUCZpk8rRZJpEJV4Wa3ivVCabw8JsGLIwgF8gOr/AISfRfvSD2C2Gg+qyunN8POnjHawP1TROq01UqygppVUKVyCVpQrpKaWTxCGGgNkAlE1NwssoMbdk3E2gpq5BB6K7R39FUBXPlapW4feJ7BKvuSUNHJNBHedMXud1fo0ByurQMAvzWrxZ5V9F6VAMfp0EbeA0IH2hyvhekykGnSDQ368/ta0WgNaAOAKXkvtjlasiLGado26j8z/AOP5VJeXkNuQ1LioG5U1pBYhZT0f4R6FLQtTANbHhZ1rG/02UmNzHbirF+6iWw6hxaT6fJ4bmkA6SQCfpz+6dmcHOBb3490ooWF2thBuwFkdQa6OWxuDutWDcOAI43KTzwDHR/VHcOfKwJpi99AnTfHqrTdQkij0gFrPzA2VEsVScc7j5JmPD+IiLCORsU5jFWl8fqwfTCSGj9StBseuQMc40RdLBk6fPjZFOY4AHmlpxTSOGtoJc3YO/sn6RO6b+Ge5zgXihwlZYZA8AAGyiszJYnO8Zj3XVU2qQpeoMa4HQ+we4T0X7gZWPaCCQLSWQOHOP1KPmZweD4TDv3csbIMjzT3EntujSbaIXtcTpOylrCTSBC2j7ptppPRBmOuFdoIaihupQ8dgkAwU5gxl5J+SSOxr1Wrg0Ghw7iiE0U2AlGxMZ1GQhoBewOv67/2TeoE0Clst3hzQSdtRYfr/AOkJGVSrKCmlUrlxXJkgbzMb2JCSezS9wdsQTadc2yCjzdLlz3/EYwaQ8ecXVO7/APP1QGRG2ymeBSrE2haI0d1FayLNG/yXHzOAUjyt+ahmwc8/IJQUHJfbqW99iMUyZsk5GzBX+fsvNyuty999jsXwOkiQ8yG/8/ZafhlW+SALPAXzfq+V8VnTTD8biR8uy9z1vJ+F6VO8GnOGhvzK+cSu8ydEDPKswWVVGiCitYZibsrHlS0U1dyVCzELyGgbUFoRnyBl3XcrObs1GxpfP96+3yU2LlPRPLDXAKjMAcweXburEeUFc6nx1acDCna58ln1W302AaBeyUfim9Q4tauE2mAgKoeRp8ETo/6sYdXHqszJwcdziGW1a2uwW+guykpoy8Fw5V7LG6YuVC9poPJpIu1UQQCfVaeVG/k3Sz5GkWk0/ayshjiTZSTm77rUlYSTulnQgbndEZ5SFmMrdXV3CkMpoEa6lxdaEHbbqQb47pFamNuqUWO61IIb3afKPX1QOnwCRtnY2d1qRxhjANvdCLVWtobpfqTbwnnu0gj9U7SBmN1Yso/2koKdhwyeLCx/dwsqxSvTH6sYt/K4pspllNVQrlJUJpSFYOIGxI+qpai0AECgArtbwFAFlEbsC5ZtVJD2HyVZjojDVZg1SX2G6XyX24qpE5UKNhlmawcucAvqvToRBgQxtFANC+cfZ7HOR1eFtWAbP8L6fsB6AK2by/2yy94cUHga3fwP7rx73WVpdbzPjOoTTA20upvyGwWWeUVUS1NQt3CXjG6dgaorSCnYKGiypcrRtspaVtc7NQMaQulLBy/07p0Y5kYS52htbkpvFxIYQAxlEjzF25W2HBllN1y8nmcfHdd1MEmqPS6wQK3QvFDX6Ow/lWkdpka4b6vL/wCUrNpa4Vu4b0SufKaruxu5s800KdyewWjjtHhrBjmLZACdqs12Wvh5ALQXd+wSlOw7x9UCYeWgSCdgjlwLQQgTPLWEirKpOmVkFzXEWSdz9UjM1rXFlgurcgpzJe7c91lyi3H1SXopL3PYlLndHmBAI/RK3XKcKwJ96iEJ5oIru5S8pKpnVS7dHxXxtmaZD5QbSgJvdSXaaPa1Wmdr0HTBGQQ14Jb2taC8qyR0bw9hII3BC1IerkACZmr/AHD/AIVXjv4Yzkn5axVHjU0j1FIUOZDOaY/f0OxRjwo1YuXbH6W6ppGHuL/RaSy2/wBLqh7ecj9VqIXyd7VIVSrlUITZqqFJXICGjb5q0p0t0/VWaLd8kF58SSh3WcapHkhLu7khK63JzKfQ0jgLPcbK1xjLKvWfYbGLsmScjYbf5+oXpuv5fwnS5C00+TyN+vP7WkfsbimDpQefx7/3/uEh9rszxMtuO0+WJtn/ALj/AOKTJ5eU+YofdTIbKhgso0cGibun4m01CxcWSTcNOnuTwtfHxmR0XeahZPZXjw5ZsuXyuPhn2/SceNJLuBTfUorxFiAajrkI2Hp80Uy+JqlkNRM7eqzvEOZ1BvNE/suzDx8ce3mZ+bycm9fI0sYue2Fkm7nHW75dk3C/Zzv3/wA9qS+Edc8snFbAIrSBGR7Lax59y1dhOx6w4HP31ea64tIz2I7FeXcFbeO0ZHTmMafPESKuuOP7LIyo3xmRxYQLrm14+c1lX13DlLhLCm7pHUDuePc7JnFyjCCzVxx3SJkLbcfVRrBGpop1hZWOh6PHy9bNypllvYEFYWJlt16TdHc/JGGYOb549k0jzvBb+yz37lFMjnXWwIQXEB5IOyeh7AzbtDSNxaRkYQbpaEnF2k5nAV809FaUfslJSS7nZMSHUdjQ7pYjsN6VRlaqFeraQVwaSpdsCnEVDTbVYG20VQbKWldMcdEa8tIB47FNx52RHxJqH+7dIcivRXjdYop2bLdnRmafxZvF06XbX81tNcHNDgbB7rz43RYcmWA+R23cHhYXD7qOu5/xzKtsqpScfUoyB4jS0+24TLJY5BbHB3yU3GxEylSVVWUJKXcdEZ9TshQjdz/Thdku8waOy5/9OEN7nlKRdpTKfZKBCwyzsjHLnAKZjbk99nsf4jqkYPDdyfTstpPjG36+j4DWYfSmE7NazWflyvA9QndPPJM77z3Fx+q9f1fqOOcZ+MCdBFFwNbLDjZBJ52RAAHbUtMODK/XNyeXhh19YcOJNkSARsNHueFpfBQYQDn/1ZOw4C0JXjGg1u+/Ww9FkCR2RNudl04cOM7cOfl58nXyNV7nHEaTy6hsry+TF0Dl9AfJRC0SMAP3W7lVyJQ1jpD/9R6Lf/wAedbbSHUZwyNuOztzXqh9NbpbJMfwtNfwk53l7ySbWlC3R0w+rih02euOjXS3bOPqUVrqJHpylOnvAawepITMltkB7Hcbcf5/dDny/tpfFy/g8nzmopfKfZ3YpnOhErC8C/YGln5MYmi0n/Cq9J6l4sZxcmxKzaz3Xn+Vx6vtHv/8AO5/bD0vcIywgA7Fxve+CEi86SaseoK38zHZRMf8AnqsaSIgn09fVcb1dlmuomu4pHIIOn0QTGW8EKWlw3tGi2Y8UkEXshueaoFVL3HntwhSvITiapJM8SVe3ogSPLmA7cqz/ADbj7yGQSN0y2GSTsqsbT9V736IgYTzsrkIKhaQOEJ5s0ivNIRG61wx3WXJlqKqQuKkLdyoPK4bOUu7KqAMz7w9CpeNLlEexBRsllaXfRZ35nHTh+7hs/wABVmuINgkEdwh2pBWjlPY+eYxUzDIPUOorSjyumvYHOlew92nt+ywV1qbhKqZ2NiMeLMCfmq5BLnU0EnsAtODp5iH9V259EzFBHDRY0NJ7jlPDx8r2x5vP48fmP1i43R553gzf0mH15P0W5h4cGCx5jZW3mJN37IgLYxqdtfZJ9VyiyBsYNOd5nUuvHjxxeZl5HJzZaK5eU7In0jfdauIwRQN17VvXqsrpWP4sjpn/AHW8e5R83Np5a07hWnP7fSAdSyjNNQOwVcEG77lJ2ZJB7rXwYapOHnrDHTRY0Nx64BNk+yy8+aw43V7UtLJdoYGA8LAy36nlDLhm8gGDVIAtmUaOnMvvusnFFyrXztsSNvo1Nry/2kKYclbehWo8h7L5rf6d1iY7tMhC2IH6mje6Qz5Zq7WabaQatY/VMd0Moyodj+Kux9VrkaXbcKkgDrBHlI3SyxmU1Rw8t4s/aFcLqAnjpxp4G6rkAHegkcrCfjO8bHss7ju1TDl+I2nbFeXycNwr6bh8jHlx3FX1uqtIBruVd4sqGx2eFlpvtG17LjHqFFMsx/VE8BI2c7HANqrmUOAn5IqCUlFIKlSKQnlFfshOGq+wHJVzHbPLLXYLvVDRHmz7KhXTjj6xyZZ+12hS3lQrsCqRFqr1RXeqJU4K3hOSt14gd6UUo3hPY48TGez2IUcs+SurxLu5Yf7GeVFqXilRU5qIOFKq0qyaHvXAPN90B7w11DsiMJ3NoE2z2jsV3R89HWXHW801osrHyZH5eTQ3LjQWlmvLcLbazSX6TG0ufIR5m7BKuni/bLkZme3BwmxN+9X7rEe8udad6i9xeLPZIN3eAUNuKfN05hRFztRW/jRiOMuI4CzsBosBa7toHAIrl5srazsiS7s/NYk79TyVpZezXV2Cx3HdFb8GPzZnB3lWr1MgMDa4AWX07/WWh1c1KAPRBck/kjLa4tlG62MR9t3WJ+ILVxCdP0Th80+H7Dx79lQgEG9qXQne1aQd/XlNxzsB19j5uyz8jCY9zpIv6RHPotKTy0RzygPFQvU5YzKfXVxcmWF3jWcGSM2kaR79k3DGFaQkNr/bakUxw0gC6XFy+Pr7HscHme11lB2sRAzZcxEXFXpSlpYrSE8O5Wq/hIdQeYWW0An3VYY+10jkzmE3WY+LayQ1vdxSkrw7ysFNH7q8sj5X29xJ/hCK7sOOYvPz5bnQyFWrVyoTsKK0iRjZRSNGBoKJCyvwvJyh90WRDUXtc6FYncA1IW/VJtTOJtOEZzeFa+Nl682IWTFpkePQpUhama0eMfcArOkABSn9ZS5Z68mUVbyiAbIQ5RRwnGVf/9k="
                    }, {
                        id: "213487462131841216",
                        name: "Romano Fafardiardo",
                        username: "Romano76",
                        is_current: false,
                        position: 27,
                        score: 86,
                        picture: null
                    }
                ]
            };
        } else if (pUrl == GlobalConstants.BASE_URL + WebServiceUrls.GET_MISSIONS_DATA) {
            response.data = [{
                tag: "mission.complete_profile",
                id: "123456789",
                coins: 20,
                completed: false,
                unlock_timestamp: null,
                tag_description: "mission.desc.complete_profile",
                url: null,
                type: "normal",
                image_url: "https://cdn0.iconfinder.com/data/icons/mobile-development-svg-icons/60/Edit_user-512.png"
            }, {
                tag: "mission.make_first_trip",
                id: "8156321651231",
                coins: 50,
                completed: true,
                unlock_timestamp: null,
                tag_description: "mission.desc.make_first_trip",
                url: null,
                type: "normal",
                image_url: "https://cdn0.iconfinder.com/data/icons/mobile-development-svg-icons/60/Edit_user-512.png"
            }, {
                tag: "mission.go_to_url",
                id: "5489421594",
                coins: 30,
                completed: true,
                unlock_timestamp: null,
                tag_description: "mission.desc.go_to_url",
                url: "http://www.google.ca",
                type: "url",
                image_url: "https://cdn0.iconfinder.com/data/icons/mobile-development-svg-icons/60/Edit_user-512.png"
            }, {
                tag: "mission.redeem_invite",
                id: "8989865656323",
                coins: 1000,
                completed: false,
                unlock_timestamp: null,
                tag_description: "mission.desc.redeem_invite",
                url: null,
                type: "normal",
                image_url: "https://cdn0.iconfinder.com/data/icons/mobile-development-svg-icons/60/Edit_user-512.png"
            }, {
                tag: "mission.invite_friend",
                id: "123456789",
                coins: 10,
                completed: false,
                unlock_timestamp: null,
                tag_description: "mission.desc.invite_friend",
                url: null,
                type: "normal",
                image_url: "https://cdn0.iconfinder.com/data/icons/mobile-development-svg-icons/60/Edit_user-512.png"
            }, {
                tag: "mission.drive_perfect_trip",
                id: "1212145456",
                coins: 100,
                completed: false,
                unlock_timestamp: null,
                tag_description: "mission.desc.drive_perfect_trip",
                url: null,
                type: "normal",
                image_url: "https://cdn0.iconfinder.com/data/icons/mobile-development-svg-icons/60/Edit_user-512.png"
            }, {
                tag: "mission.launch_application",
                id: "123456789",
                coins: 30,
                completed: true,
                unlock_timestamp: "1501909200",
                tag_description: "mission.desc.launch_application",
                url: null,
                type: "normal",
                image_url: "https://cdn0.iconfinder.com/data/icons/mobile-development-svg-icons/60/Edit_user-512.png"
            }, {
                tag: "mission.access_ranking",
                id: "25896321478",
                coins: 20,
                completed: true,
                unlock_timestamp: "1501909900",
                tag_description: "mission.desc.access_ranking",
                url: null,
                type: "normal",
                image_url: "https://cdn0.iconfinder.com/data/icons/mobile-development-svg-icons/60/Edit_user-512.png"
            }, {
                tag: "mission.share_score",
                id: "78798795464545",
                coins: 10,
                completed: false,
                unlock_timestamp: null,
                tag_description: "mission.desc.share_score",
                url: null,
                type: "share",
                image_url: "https://cdn0.iconfinder.com/data/icons/mobile-development-svg-icons/60/Edit_user-512.png"
            }];
        } else if (pUrl == GlobalConstants.BASE_URL + WebServiceUrls.GET_BADGES_DATA) {
            response.data = [{
                tag: "badges.courses1",
                coins: 10,
                tag_description: "badges.courses1.desc",
                levels: 1,
                image_url: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTKORlzsXK_23SUMi1U6-iVgOyTa1WPxlU1QParK4L-R3CcpKSj",
                user_progress: {
                    current_level: 0,
                    progress: 0,
                    image_url: null
                }
            }, {
                tag: "badges.courses2",
                coins: 10,
                tag_description: "badges.courses2.desc",
                levels: 1,
                image_url: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTKORlzsXK_23SUMi1U6-iVgOyTa1WPxlU1QParK4L-R3CcpKSj",
                user_progress: {
                    current_level: 0,
                    progress: 0,
                    image_url: null
                }
            }, {
                tag: "badges.cleanRecord",
                coins: 10,
                tag_description: "badges.cleanRecord.desc",
                levels: 3,
                image_url: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTKORlzsXK_23SUMi1U6-iVgOyTa1WPxlU1QParK4L-R3CcpKSj",
                user_progress: {
                    current_level: 1,
                    progress: 69,
                    image_url: "https://upload.wikimedia.org/wikipedia/commons/thumb/4/4b/Bronze_circle.svg/300px-Bronze_circle.svg.png"
                }
            }, {
                tag: "badges.customerLoyalty",
                coins: 20,
                tag_description: "badges.customerLoyalty.desc",
                levels: 3,
                image_url: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTKORlzsXK_23SUMi1U6-iVgOyTa1WPxlU1QParK4L-R3CcpKSj",
                user_progress: {
                    current_level: 2,
                    progress: 20,
                    image_url: "http://worldartsme.com/images/silver-circle-clipart-1.jpg"
                }
            }, {
                tag: "badges.highScore",
                coins: 20,
                tag_description: "badges.highScore.desc",
                levels: 3,
                image_url: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTKORlzsXK_23SUMi1U6-iVgOyTa1WPxlU1QParK4L-R3CcpKSj",
                user_progress: {
                    current_level: 3,
                    progress: 50,
                    image_url: "http://images.all-free-download.com/images/graphiclarge/gold_circle_clip_art_12860.jpg"
                }
            }, {
                tag: "badges.focused",
                coins: 20,
                tag_description: "badges.focused.desc",
                levels: 3,
                image_url: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTKORlzsXK_23SUMi1U6-iVgOyTa1WPxlU1QParK4L-R3CcpKSj",
                user_progress: {
                    current_level: 0,
                    progress: 20,
                    image_url: null
                }
            }, {
                tag: "badges.speedStar",
                coins: 20,
                tag_description: "badges.speedStar.desc",
                levels: 3,
                image_url: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTKORlzsXK_23SUMi1U6-iVgOyTa1WPxlU1QParK4L-R3CcpKSj",
                user_progress: {
                    current_level: 0,
                    progress: 20,
                    image_url: null
                }
            }, {
                tag: "badges.smoothStopper",
                coins: 20,
                tag_description: "badges.smoothStopper.desc",
                levels: 3,
                image_url: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTKORlzsXK_23SUMi1U6-iVgOyTa1WPxlU1QParK4L-R3CcpKSj",
                user_progress: {
                    current_level: 0,
                    progress: 54,
                    image_url: null
                }
            }, {
                tag: "badges.turningTemple",
                coins: 20,
                tag_description: "badges.turningTemple.desc",
                levels: 3,
                image_url: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTKORlzsXK_23SUMi1U6-iVgOyTa1WPxlU1QParK4L-R3CcpKSj",
                user_progress: {
                    current_level: 0,
                    progress: 0,
                    image_url: null
                }
            }, {
                tag: "badges.fuelSaver",
                coins: 20,
                tag_description: "badges.fuelSaver.desc",
                levels: 3,
                image_url: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTKORlzsXK_23SUMi1U6-iVgOyTa1WPxlU1QParK4L-R3CcpKSj",
                user_progress: {
                    current_level: 0,
                    progress: 0,
                    image_url: null
                }
            }];
        } else if (pUrl == GlobalConstants.BASE_URL + WebServiceUrls.GET_COINS_HISTORY) {
            response.data = {
                earned: [{
                    date: "2017-05-12",
                    coins: 10,
                    tag: "coinsHistory_watchedVideo"
                }, {
                    date: "2017-05-12",
                    coins: 5,
                    tag: "coinsHistory_madeFirstTrip"
                }, {
                    date: "2017-05-12",
                    coins: 20,
                    tag: "coinsHistory_Starbuck"
                }],
                spent: null
            }
        } else if (pUrl == GlobalConstants.BASE_URL + WebServiceUrls.GET_RANKING) {
            response.data = {
                friends: [
                {
                    id: "123456782",
                    picture: "./client/images/porto/default_picture.png",
                    name: "Richard McKinney",
                    coins: 5.5,
                    me: false,
                    position: 1
                },
                {
                    id: "123456783",
                    picture: "./client/images/porto/default_picture.png",
                    name: "Richard McKinney",
                    coins: 6.3,
                    me: false,
                    position: 2
                },
                {
                    id: "123456784",
                    picture: "./client/images/porto/default_picture.png",
                    name: "Jonas Medeiros",
                    coins: 10.3,
                    me: true,
                    position: 3
                },
                {
                    id: "123456785",
                    picture: "./client/images/porto/default_picture.png",
                    name: "Richard McKinney",
                    coins: 11.4,
                    me: false,
                    position: 4
                },
                {
                    id: "123456786",
                    picture: "./client/images/porto/default_picture.png",
                    name: "Richard McKinney",
                    coins: '1k',
                    me: false,
                    position: 5
                },
                {
                    id: "123456787",
                    picture: "./client/images/porto/default_picture.png",
                    name: "Jonas Medeiros",
                    coins: '2.1',
                    me: false,
                    position: 6
                },
                {
                    id: "123456788",
                    picture: "./client/images/porto/default_picture.png",
                    name: "Jonas Medeiros",
                    coins: '2.1',
                    me: false,
                    position: 7
                },
                {
                    id: "123456722",
                    picture: "./client/images/porto/default_picture.png",
                    name: "Jonas Medeiros",
                    coins: '2.1',
                    me: false,
                    position: 8
                },
                {
                    id: "123456711",
                    picture: "./client/images/porto/default_picture.png",
                    name: "Jonas Medeiros",
                    coins: '2.1',
                    me: false,
                    position: 9
                },
                {
                    id: "123456733",
                    picture: "./client/images/porto/default_picture.png",
                    name: "Richard McKinney",
                    coins: 11.4,
                    me: false,
                    position: 10
                }],
                community : [
                {
                    id: "123456782",
                    picture: "./client/images/porto/default_picture.png",
                    name: "Richard McKinney",
                    coins: 5.5,
                    me: false,
                    position: 1
                },
                {
                    id: "123456783",
                    picture: "./client/images/porto/default_picture.png",
                    name: "Richard McKinney",
                    coins: 6.3,
                    me: false,
                    position: 2
                },
                {
                    id: "123456784",
                    picture: "./client/images/porto/default_picture.png",
                    name: "Jonas Medeiros",
                    coins: 10.3,
                    me: false,
                    position: 3
                },
                {
                    id: "123456785",
                    picture: "./client/images/porto/default_picture.png",
                    name: "Richard McKinney",
                    coins: 11.4,
                    me: false,
                    position: 4
                },
                {
                    id: "123456786",
                    picture: "./client/images/porto/default_picture.png",
                    name: "Richard McKinney",
                    coins: '1k',
                    me: false,
                    position: 5
                },
                {
                    id: "123456787",
                    picture: "./client/images/porto/default_picture.png",
                    name: "Jonas Medeiros",
                    coins: '2.1',
                    me: false,
                    position: 6
                },
                {
                    id: "123456788",
                    picture: "./client/images/porto/default_picture.png",
                    name: "Jonas Medeiros",
                    coins: '2.1',
                    me: false,
                    position: 7
                },
                {
                    id: "123456720",
                    picture: "./client/images/porto/default_picture.png",
                    name: "Jonas Medeiros",
                    coins: '2.1',
                    me: false,
                    position: 8
                },
                {
                    id: "123456711",
                    picture: "./client/images/porto/default_picture.png",
                    name: "Jonas Medeiros",
                    coins: '2.1',
                    me: false,
                    position: 9
                },
                {
                    id: "123456334",
                    picture: "./client/images/porto/default_picture.png",
                    name: "Jonas Medeiros",
                    coins: '2.1',
                    me: true,
                    position: 255
                }]
            }
        } else if (pUrl == GlobalConstants.BASE_URL + WebServiceUrls.REMOVE_FRIEND) {
            response.data = { response: true, message: 'user was deleted' };
        } else if (pUrl == GlobalConstants.BASE_URL + WebServiceUrls.ADD_FRIEND) {
            response.data = { response: true, message: 'user was added' };
        } else if (pUrl == GlobalConstants.BASE_URL + WebServiceUrls.SEARCH_FRIEND) {
            response.data = { 
                friends: [
                {
                    id: "123456782",
                    picture: "./client/images/porto/default_picture.png",
                    name: "Richard McKinney",
                    description: "Cras eget convallis tortor.",
                },
                {
                    id: "123456783",
                    picture: "./client/images/porto/default_picture.png",
                    name: "Richard McKinney",
                    description: "Cras eget convallis tortor.",
                },
                {
                    id: "123456784",
                    picture: "./client/images/porto/default_picture.png",
                    name: "Jonas Medeiros",
                    description: "Cras eget convallis tortor.",
                },
                {
                    id: "123456785",
                    picture: "./client/images/porto/default_picture.png",
                    name: "Richard McKinney",
                    description: "Cras eget convallis tortor.",
                },
                {
                    id: "123456786",
                    picture: "./client/images/porto/default_picture.png",
                    name: "Richard McKinney",
                    description: "Cras eget convallis tortor.",
                },
                {
                    id: "123456787",
                    picture: "./client/images/porto/default_picture.png",
                    name: "Jonas Medeiros",
                    description: "Cras eget convallis tortor.",
                },
                {
                    id: "123456788",
                    picture: "./client/images/porto/default_picture.png",
                    name: "Jonas Medeiros",
                    description: "Cras eget convallis tortor.",
                },
                {
                    id: "123456722",
                    picture: "./client/images/porto/default_picture.png",
                    name: "Jonas Medeiros",
                    description: "Cras eget convallis tortor.",
                },
                {
                    id: "123456711",
                    picture: "./client/images/porto/default_picture.png",
                    name: "Jonas Medeiros",
                    description: "Cras eget convallis tortor.",
                },
                {
                    id: "123456733",
                    picture: "./client/images/porto/default_picture.png",
                    name: "Richard McKinney",
                    description: "Cras eget convallis tortor.",
                }]
            };
        }
        q.resolve(response);
        return q.promise;
    }

}
