var mConfigLoaded = false;
angular.module('services')
    .service('AppConfigServices', AppConfigServices);

function AppConfigServices($q, StringUtil, LocalStorage, HttpProxy, WebServiceUrls, LocalStorageKeys, GlobalConstants) {

    this.getConfigValue = getConfigValue;
    this.getThemeColors = getThemeColors;
    this.getAppBehaviorSettings = getAppBehaviorSettings;

    var mConfig = {};

    function getConfigValue(key) {
        var q = $q.defer();
        if (mConfigLoaded) {
            q.resolve(mConfig[key]);
        } else {
            initAppConfig(q, key);
        }

        // mock settings
        initAppConfig(q, key);

        return q.promise;
    }

    function initAppConfig(pQ, pKey) {
        var storedModifiedDate = LocalStorage.get(LocalStorageKeys.APP_SETTINGS_MODIFIED_DATE);
        if (null == storedModifiedDate) {
            loadConfig(pQ, true, pKey);
        } else {
            checkForUpdate(pQ, storedModifiedDate, pKey);
        }
    }

    function getPortoSettings() {
        
        var settings = {"data":{"AppSetting":{"id":"11","name":"1.0","app_version_status_id":"1","created":"2016-09-16 13:01:50","modified":"2017-03-17 14:30:28","modified_by":"4","app_telemetry_option_id":"11","app_login_option_id":"11","app_design_option_id":"11","virtual_device_enabled":true,"native_gps_info_refresh_rate":"1.5","telemetry_refresh_rate":"1.5","live_trip_information_refresh_rate":"1","auto_start_config":{"levels":[{"level":"1","value":"10"},{"level":"2","value":"20"},{"level":"3","value":"30"},{"level":"4","value":"40"},{"level":"5","value":"50"}],"default":{"level":"2"}},"auto_stop_config":{"levels":[{"level":"1","value":"10"},{"level":"2","value":"20"},{"level":"3","value":"30"},{"level":"4","value":"40"},{"level":"5","value":"50"}],"default":{"level":"3"}},"active":true,"created_by":null,"require_display_name":false,"activation_code_validation":false,"failed_login_lock":"5","lock_duration":"10","logo":"https:\/\/s3.ca-central-1.amazonaws.com\/basedrive-static\/app_settings\/666dac79-1136-4ab6-8c7b-731f2acd781d\/1511376160_logo_PortoAppLogo.png","background_image":null,"login_screen":null,"login_background_url":null,"app_background_url":null,"main_background_color":"#01aef0","light_background_color":"#d9f3fd","splash_duration":"5","display_powered_by":true,"text_primary_color":"#ffffff","text_secondary_color":"#70d2f8","secondary_background_color":"#173770","menu_background_color":"#173770","text_main_color":"#000000","notification_duration":"3","ltp_splash":true,"ltp_splash_bypass":false,"ltp_fetch":true,"ltp_block":false,"onboarding":true,"remind_me_later":false,"code_mask":"999.999.999-99","sms_validation":true,"get_a_quote_url":"https:\/\/transitomaisgentil.com.br\/cotacaoapp\/"},"AppBehaviorOptions":{"1":[{"quote":false,"assistance":false}],"2":[{"quote":false,"assistance":false}]},"profile_fields":{"user_avatars.avatar_url":{"writable":true,"visibility":true},"users.name":{"writable":true,"visibility":true},"user_vehicle_informations.vin":{"writable":true,"visibility":true},"user_vehicle_informations.make":{"writable":true,"visibility":true},"user_vehicle_informations.model":{"writable":true,"visibility":true},"user_vehicle_informations.year":{"writable":true,"visibility":true},"users.display_name":{"writable":true,"visibility":true},"users.gender":{"writable":true,"visibility":true},"users.date_of_birth":{"writable":true,"visibility":true},"users.social_security_number":{"writable":false,"visibility":false},"users.driver_licence":{"writable":false,"visibility":false},"users.mobile_phone":{"writable":true,"visibility":true},"users.email":{"writable":false,"visibility":true},"users.password":{"writable":true,"visibility":true},"users.current_insurer":{"writable":true,"visibility":true},"users.current_insurance_price":{"writable":true,"visibility":true},"users.insurance_expiry_month":{"writable":true,"visibility":true}},"MenuItems":[],"LtpOption":{"activation_code_by":false,"code_type":null,"case_sensitive":false,"allow_special_char":false,"code_size":"0"}},"status":200,"config":{"method":"GET","transformRequest":[null],"transformResponse":[null],"url":"http://localhost:8100/baselineConsoleDefault/getSettings","headers":{"Accept":"application/json;","Access-Control-Allow-Origin":"*","User-Token":"t1snqe1pe8bpgln5d9q62peco1","Accept-Language":"en-US","App-Version":"1.0","App-Token":"a692979b-c8a3-11e7-9dec-02370cb022d9","Cache-Control":"Offline"}},"statusText":"OK"};
        settings.data.AppSetting.logo = './client/images/porto_logo.png';

        return settings;
    }

    function loadConfig(q, pUseCache, pKey) {
        if (pUseCache == false) {
            LocalStorage.clear(GlobalConstants.BASE_URL + WebServiceUrls.GET_SETTINGS);
        }

        var response = getPortoSettings();

        mConfig = response.data.AppSetting;
        LocalStorage.set(LocalStorageKeys.APP_SETTINGS_MODIFIED_DATE, mConfig.modified);
        mConfigLoaded = true;

        LocalStorage.setObject(SHA512(GlobalConstants.BASE_URL + "/getSettings"), response);

        q.resolve(mConfig[pKey]);

        // HttpProxy.get(GlobalConstants.BASE_URL + WebServiceUrls.GET_SETTINGS)
        //     .then(function (response) {
        //             mConfig = response.data.AppSetting;
        //             LocalStorage.set(LocalStorageKeys.APP_SETTINGS_MODIFIED_DATE, mConfig.modified);
        //             mConfigLoaded = true;
        //             q.resolve(mConfig[pKey]);
        //         },
        //         function (error) {
        //             q.reject(error);
        //         }
        //     );
    }

    function checkForUpdate(q, pCurrentModifiedDate, pKey) {
        getLatestConfigModifiedDate()
            .then(function (pResponse) {
                var modifiedDate = pResponse.data;
                //format into Date Object
                pCurrentModifiedDate = new Date(StringUtil.getdateinformat(pCurrentModifiedDate));
                modifiedDate = new Date(StringUtil.getdateinformat(modifiedDate));

                if (pCurrentModifiedDate < modifiedDate) {
                    loadConfig(q, false, pKey);
                } else {
                    loadConfig(q, true, pKey);
                }
            }, function (pError) {
                loadConfig(q, true, pKey);
            });
    }

    function getLatestConfigModifiedDate() {
        return HttpProxy.get(GlobalConstants.BASE_URL + WebServiceUrls.GET_LATEST_CONFIG_MODIFIED_DATE);
    }

    function getThemeColors() {
        var q = $q.defer();

        var response = getPortoSettings();

        var config = response.data.AppSetting;
        var data = {};
        data.mainBackground = config['main_background_color'];
        data.lightBackground = config['light_background_color'];
        data.secondaryBackground = config["secondary_background_color"];
        data.menuBackground = config["menu_background_color"];
        data.textMain = config['text_main_color'];
        data.textPrimary = config['text_primary_color'];
        data.textSecondary = config['text_secondary_color'];
        q.resolve(data);
    

        // HttpProxy.get(GlobalConstants.BASE_URL + WebServiceUrls.GET_SETTINGS)
        //     .then(function (response) {
        //             var config = response.data.AppSetting;
        //             var data = {};
        //             data.mainBackground = config['main_background_color'];
        //             data.lightBackground = config['light_background_color'];
        //             data.secondaryBackground = config["secondary_background_color"];
        //             data.menuBackground = config["menu_background_color"];
        //             data.textMain = config['text_main_color'];
        //             data.textPrimary = config['text_primary_color'];
        //             data.textSecondary = config['text_secondary_color'];
        //             q.resolve(data);
        //         },
        //         function (error) {
        //             q.reject(error);
        //         });
        return q.promise;
    }

    function getAppBehaviorSettings() {

        var response = getPortoSettings();
        LocalStorage.setObject(LocalStorageKeys.APP_BEHAVIOR_OPTIONS, response.data.AppBehaviorOptions);


        // HttpProxy.get(GlobalConstants.BASE_URL + WebServiceUrls.GET_SETTINGS).then(function (response) {
        //     // THIS IS USED FOR DYNAMIC MENU.
        //     LocalStorage.setObject(LocalStorageKeys.APP_BEHAVIOR_OPTIONS, response.data.AppBehaviorOptions);
        // });
    }
}
