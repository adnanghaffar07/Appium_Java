angular.module('services')
    .service('AchievementsServices', AchievementsServices);

function AchievementsServices($q, HttpProxy, AchievementsUtil, GlobalConstants, WebServiceUrls, PlaceholderServices) {

    this.getAchievementsList = getAchievementsList;
    this.getAchievements = getAchievements;
    this.getAchievementStatics = getAchievementStatics;
    this.getAchievementDetailProgress = getAchievementDetailProgress;
    this.getCoins = getCoins;

    function getAchievementsList(pCache) {
        var q = $q.defer();
        HttpProxy.get(GlobalConstants.BASE_URL + WebServiceUrls.GET_ACHIEVEMENTS_LIST, null, pCache).then(function (allResponse) {
                q.resolve(allResponse.data);
            },
            function (error) {
                q.reject(error.data);
            });
        return q.promise;
    }

    function getAchievements(pUid) {
        var q = $q.defer();
        if (typeof (pUid) == "undefined") {
            pUid = "";
        }
        var jsonParams = {
            "user_id": pUid
        };

        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.GET_ACHIEVEMENTS, jsonParams)
            .then(function (myResponse) {
                    // var data = [];
                    //data.sort(myResponse.data);
                    //pCallback(data);
                    q.resolve(myResponse.data);
                },
                function (error) {
                    q.reject(error.data);
                });
        return q.promise;
    }

    function getAchievementStatics(pUid) {
        var q = $q.defer();
        if (typeof (pUid) == "undefined") {
            pUid = "";
        }
        var jsonParams = {
            "user_id": pUid
        };

        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.GET_ACHIEVEMENT_STATICS, jsonParams)
            .then(function (myResponse) {
                    q.resolve(myResponse.data);
                },
                function (error) {
                    q.reject(error.data);
                });
        return q.promise;
    }


    function getAchievementDetailProgress(pAchievementId) {
        var q = $q.defer();
        var end_date = Date.today().addDays(-1).toString("yyyy-MM-dd");
        var start_date = Date.today().addDays(-31).toString("yyyy-MM-dd");

        var jsonParams = {
            "achievement_id": pAchievementId,
            "start_date": start_date,
            "end_date": end_date
        };

        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.GET_ACHIEVEMENT_PROGRESS, jsonParams)
            .then(function (response) {
                q.resolve(response);

            }, function (error) {});
        return q.promise;
    }

    function getCoins() {
        var q = $q.defer();
        var coins = {
            data: {
                balance: Math.floor(Math.random() * 9999999)
            }
        }
        q.resolve(coins);
        return q.promise;
    }
}
