angular.module('services')
    .service('CommunicationService', CommunicationService);

function CommunicationService($q, GlobalConstants, WebServiceUrls, StringUtil, HttpProxy, $timeout) {

    this.getCommunicationOptions = getCommunicationOptions;
    this.updateClientCommConfig = updateClientCommConfig;

    function getCommunicationOptions(callback) {
        return HttpProxy.get(GlobalConstants.BASE_URL + WebServiceUrls.GET_CLIENT_COMMUNICATION_CONFIG);
    }

    function updateClientCommConfig(options) {
        var q = $q.defer();
        var jsonParams = options;
        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.UPDATE_CLIENT_COMMUNICATIONCONFIG, jsonParams)
            .then(function (response) {
                    q.resolve(response.data);
                },
                function (error) {
                    q.reject(error.data);
                });
        return q.promise;
    }
}
