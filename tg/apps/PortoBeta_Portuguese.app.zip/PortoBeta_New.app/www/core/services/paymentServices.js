angular.module('services')
    .service('PaymentServices', PaymentServices);

function PaymentServices($q, HttpProxy, GlobalConstants, WebServiceUrls, LocalStorage, LocalStorageKeys) {
    this.addPayment = addPayment;
    this.updatePayment = updatePayment;
    this.getPaymentMethods=getPaymentMethods;
    this.getPaymentMethod = getPaymentMethod;
    this.deletePayment=deletePayment;
    this.getBalanceInfo=getBalanceInfo;
    this.getPackages=getPackages;
    this.buyPackage=buyPackage;
    this.getUserPayments=getUserPayments;
    this.getPayment=getPayment;
        
    function addPayment(paymentdata) {
        var q = $q.defer();
        var UID = LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID);
        HttpProxy.post(GlobalConstants.PAS_URL + WebServiceUrls.APPLICATION_USERS + UID + WebServiceUrls.USER_PAYMENT_METHODS, paymentdata)
            .then(function (response) {
                    q.resolve(response.data);
                },
                function (error) {
                    q.reject(error.data);
                });
        return q.promise;
    }
    function updatePayment(paymentdata) {
        var q = $q.defer();
        var paymentID = '/' + paymentdata.id;
        HttpProxy.put(GlobalConstants.PAS_URL + WebServiceUrls.USER_PAYMENT_METHODS + paymentID, paymentdata)
            .then(function (response) {
                    q.resolve(response.data);
                },
                function (error) {
                    q.reject(error.data);
                });
        return q.promise;
    }
    function getPaymentMethods() {
        var q = $q.defer();
        var UID = LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID);
        HttpProxy.get(GlobalConstants.PAS_URL + WebServiceUrls.APPLICATION_USERS + UID + WebServiceUrls.USER_PAYMENT_METHODS)
            .then(function (response) {
                    q.resolve(response.data);
                },
                function (error) {
                    q.reject(error.data);
                });
        return q.promise;
    }
    function getPaymentMethod(paymentdata) {
        var q = $q.defer();
        var userPaymentMethodId = '/' + paymentdata.id;
        HttpProxy.get(GlobalConstants.PAS_URL + WebServiceUrls.USER_PAYMENT_METHODS + userPaymentMethodId)
            .then(function (response) {
                    q.resolve(response.data);
                },
                function (error) {
                    q.reject(error.data);
                });
        return q.promise;
    }
    function deletePayment(paymentdata) {
        var userPaymentMethodId = '/' + paymentdata.id;
        var q = $q.defer();
        HttpProxy.delete(GlobalConstants.PAS_URL + WebServiceUrls.USER_PAYMENT_METHODS + userPaymentMethodId)
            .then(function (response) {
                    q.resolve(response.data);
                },
                function (error) {
                    q.reject(error.data);
                });
        return q.promise;
    }   
    function getBalanceInfo() {
        var q = $q.defer();
        var UID = LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID);
        HttpProxy.get(GlobalConstants.PAS_URL + WebServiceUrls.APPLICATION_USERS + UID + WebServiceUrls.PAS_CORE+WebServiceUrls.POLICIES)
            .then(function (response) {
                    q.resolve(response.data);
                },
                function (error) {
                    q.reject(error.data);
                });
        return q.promise;
    }
    function getPackages() {
        var q = $q.defer();
        HttpProxy.get(GlobalConstants.PAS_URL + WebServiceUrls.PAS_BILLING + WebServiceUrls.PAYMENT_OPTIONS)
            .then(function (response) {
                    q.resolve(response.data);
                },
                function (error) {
                    q.reject(error.data);
                });
        return q.promise;
    }
    function buyPackage(packageData) {
        var q = $q.defer();
        var PID = LocalStorage.get(LocalStorageKeys.POLICY_ID);
        HttpProxy.post(GlobalConstants.PAS_URL +WebServiceUrls.PAS_CORE+ WebServiceUrls.POLICIES + PID + WebServiceUrls.PAS_BILLING + WebServiceUrls.GET_USER_PAYMENTS, packageData)
            .then(function (response) {
                    q.resolve(response.data);
                },
                function (error) {
                    q.reject(error.data);
                });
        return q.promise;
    }
    function getUserPayments() {
        var q = $q.defer();
        var PID = LocalStorage.get(LocalStorageKeys.POLICY_ID);
        HttpProxy.get(GlobalConstants.PAS_URL + WebServiceUrls.PAS_CORE + WebServiceUrls.POLICIES + PID + WebServiceUrls.PAS_BILLING + WebServiceUrls.GET_USER_PAYMENTS)
            .then(function (response) {
                    q.resolve(response.data);
                },
                function (error) {
                    q.reject(error.data);
                });
        return q.promise;
    }
    function getPayment(paymentData) {
        var q = $q.defer();
        HttpProxy.get(GlobalConstants.PAS_URL + WebServiceUrls.PAS_BILLING + WebServiceUrls.GET_USER_PAYMENTS + paymentData.paymentID)
            .then(function (response) {
                    q.resolve(response.data);
                },
                function (error) {
                    q.reject(error.data);
                });
        return q.promise;
    }
         
};