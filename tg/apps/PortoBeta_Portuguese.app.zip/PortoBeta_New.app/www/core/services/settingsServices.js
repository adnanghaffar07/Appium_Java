angular.module('services')
    .service("SettingsServices", SettingsServices);

function SettingsServices($q, HttpProxy, GlobalConstants, WebServiceUrls, PlaceholderServices) {

    this.getClientCommunicationConfig = getClientCommunicationConfig;
    this.reportProblem = reportProblem;
    this.getUserSettings = getUserSettings;
    this.setUserSettings = setUserSettings;
    this.updateClientCommunicationConfig = updateClientCommunicationConfig;
    this.getEnvironment = getEnvironment;

    function getClientCommunicationConfig() {
        var q = $q.defer();
        HttpProxy.get(GlobalConstants.BASE_URL + WebServiceUrls.GET_CLIENT_COMMUNICATION_CONFIG)
            .then(function (response) {
                    q.resolve(response.data);
                },
                function (error) {
                    q.reject(error.data);
                });
        return q.promise;
    }

    function reportProblem(reportdata) {
        var q = $q.defer();
        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.REPORT_PROBLEM, reportdata)
            .then(function (response) {
                    q.resolve(response.data);
                },
                function (error) {
                    q.reject(error.data);
                });
        return q.promise;
    }

    function getUserSettings() {
        var q = $q.defer();
        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.GET_USER_SETTINGS)
            .then(function (response) {
                    q.resolve(response.data);
                },
                function (error) {
                    q.reject(error.data);
                });
        return q.promise;
    }

    function setUserSettings(data) {
        var q = $q.defer();
        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.SET_USER_SETTINGS, data)
            .then(function (response) {
                    q.resolve(response.data);
                },
                function (error) {
                    q.reject(error.data);
                });
        return q.promise;
    }

    function updateClientCommunicationConfig(data) {
        var q = $q.defer();
        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.UPDATE_CLIENT_COMMUNICATIONCONFIG, data)
            .then(function (response) {
                    q.resolve(response.data);
                },
                function (error) {
                    q.reject(error.data);
                });
        return q.promise;
    }

    function getEnvironment(pCode) {
        var q = $q.defer();
        var jsonParams = {
            activation: pCode
        };

        PlaceholderServices.post(GlobalConstants.BASE_URL + WebServiceUrls.GET_ENVIRONMENT)
            .then(function (response) {
                q.resolve(response);
            }, function (error) {
                q.reject(error);
            });

        return q.promise;
    }
}
