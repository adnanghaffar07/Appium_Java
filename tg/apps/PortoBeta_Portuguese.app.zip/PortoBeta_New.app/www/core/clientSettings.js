angular.module('constants')
    .constant("ClientSettings_Language", {
        DEFAULT_LANGUAGE: "en-US"
    })
    .service("ClientSettings", ClientSettings)


function ClientSettings(LocalStorage, LocalStorageKeys) {


    this.getSupportedViewCodes = getSupportedViewCodes;
    this.getHideForUserLevel1 = getHideForUserLevel1;
    this.getHideForUserLevel2 = getHideForUserLevel2;
    this.hideForIOS = hideForIOS;
    this.TIME_OUT_DELAY = 40000;
    // this.DEFAULT_LANGUAGE = "en-US";
    this.SUPPORTED_LANGUAGES = ["es-ES", "fr-CA", "en-US"];
    this.USER_LEVELS=["TBYB","TBYB_ACTIVE","CLIENT"];
    this.fakeT2Connection = false;
    this.allowNotification=false;
    function getSupportedViewCodes() {
        return ["GET_A_QUOTE",
                "LINK_POLICY",
                "DASHBOARD",
                "ASSISTANCE",
                "TRIP_HISTORY",
                "LEADERBOARD",
                "BADGES",
                "ACHIVEMENTS",
                "PRIZES",
                "ACTIVATE",
                "INVITE_FRIEND",
                "SETTINGS",
                "LOGOUT",
                "EXIT",
                "DEBUG",
                "HELP"];
    }
    function getHideForUserLevel2(){
        return ["ACTIVATE","GET_A_QUOTE","LINK_POLICY","DEBUG"];
    }
      function getHideForUserLevel1(){
        return ["PRIZES","GET_A_QUOTE","LINK_POLICY","DEBUG"];
    }
    function hideForIOS(){
           return ["EXIT"];
    }
}