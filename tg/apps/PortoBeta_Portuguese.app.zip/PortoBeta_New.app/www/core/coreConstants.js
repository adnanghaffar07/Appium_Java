angular.module('constants', [])
    .constant("LocalStorageKeys", {
        AVATAR_CACHE: "AVATAR_CACHE",
        PROFILE_DATA: "PROFILE_DATA",
        OFFLINE_LOGIN_CREDENTIALS: "OFFLINE_LOGIN_CREDENTIALS",
        APP_SETTINGS_MODIFIED_DATE: "APP_SETTINGS_MODIFIED_DATE",
        LOCALE_MODIFIED_DATE: "LOCALE_MODIFIED_DATE",
        CURRENT_LOCALE_KEY: "CURRENT_LOCALE_KEY",
        LOGIN_USERNAME: "LOGIN_USERNAME",
        LOGIN_EMAIL: "LOGIN_EMAIL",
        LOGIN_PASSWORD: "LOGIN_PASSWORD",
        LOGIN_EXTERNAL_ID: "LOGIN_EXTERNAL_ID",
        USER_TOKEN: "USER_TOKEN",
        PAS_USER_TOKEN: "PAS_USER_TOKEN",
        LOGIN_USER_ID: "LOGIN_USER_ID",
        LOGIN_POLICY_OWNER: "LOGIN_POLICY_OWNER",
        LOGIN_POLICY_EFFECTIVE: "LOGIN_POLICY_EFFECTIVE",
        LOGIN_POLICY_EFFECTIVE_TIMESTAMP: "LOGIN_POLICY_EFFECTIVE_TIMESTAMP",
        USER_APP_SETTINGS: "USER_APP_SETTINGS",
        SEND_USER_CREDENTIAL_STATE: "SEND_USER_CREDENTIAL_STATE",
        APP_MODE: "APP_MODE",
        DEBUG_INTENT_ACTION: "DEBUG_INTENT_ACTION",
        DEBUG_INTENT_EXTRAS: "DEBUG_INTENT_EXTRAS",
        LOGIN_TYPE: "LOGIN_TYPE",
        LOGIN_FLAG: "LOGIN_FLAG",
        ACCESS_TOKEN: "ACCESS_TOKEN",
        FB_ACCESS_TOKEN: "FB_ACCESS_TOKEN",
        GPLUS_ACCESS_TOKEN: "GPLUS_ACCESS_TOKEN",
        REFRESH_TOKEN: "REFRESH_TOKEN",
        GPLUS_REFRESH_TOKEN: "GPLUS_REFRESH_TOKEN",
        BASE_URL_OVERRIDE: "BASE_URL_OVERRIDE",
        PAS_URL_OVERRIDE: "PAS_URL_OVERRIDE",
        ZENDESK_API_OVERRIDE: "ZENDESK_API_OVERRIDE",
        COLLECTOR_URL_OVERRIDE: "COLLECTOR_URL_OVERRIDE",
        COLLECTOR_URL_T2_OVERRIDE: "COLLECTOR_URL_T2_OVERRIDE",
        DEBUG_SHOW_LOCALES_TAG: "DEBUG_SHOW_LOCALES_TAG",
        SOCIAL_USER_ID: "SOCIAL_USER_ID",
        DEVICE_TYPE: "DEVICE_TYPE",
        SOCIAL_META: "SOCIAL_META",
        PROFILE_PIC_SRC: "PROFILE_PIC_SRC",
        SET_CLAIM_TYPES: "SET_CLAIM_TYPES",
        SELECTED_CLAIM: 'SELECTED_CLAIM',
        SEEN_ACHIEVEMENTS: "SEEN_ACHIEVEMENTS",
        ACKNOWLEDGED_ACHIEVEMENTS: "ACKNOWLEDGED_ACHIEVEMENTS",
        PERSONAL_PROFILEDATA: "PERSONAL_PROFILEDATA",
        IS_REM_PREPAID: "IS_REM_PREPAID",
        VEHICLE_PROFILEDATA: "VEHICLE_PROFILEDATA",
        USE_WIFI_ONLY_STATE: "USE_WIFI_ONLY_STATE",
        LAST_TRIP: "LAST_TRIP",
        LAST_UPDATE_TIMESTAMP: "LAST_UPDATE_TIMESTAMP",
        IS_IN_BROWSER: "IS_IN_BROWSER",
        BUY_PACKAGE_DETAILS: "BUY_PACKAGE_DETAILS",
        TRIP_AS_PASSENGER: "TRIP_AS_PASSENGER",
        NATIVE_PREFERENCES: "NATIVE_PREFERENCES",
        MILE_CATEGORY_COLOR: "MILE_CATEGORY_COLOR",
        QUOTE_ABOUT: "QUOTE_ABOUT",
        QUOTE_VEHICLE: "QUOTE_VEHICLE",
        QUOTE_DRIVERS: "QUOTE_DRIVERS",
        CLAIMS_DETAILS: "CLAIMS_DETAILS",
        LAST_LOGIN_TIMESTAMP: "LAST_LOGIN_TIMESTAMP",
        TBYB_CREATION_TIMESTAMP: "TBYB_CREATION_TIMESTAMP",
        QUOTE_PROCESS: "QUOTE_PROCESS",
        POLICY_ID: "POLICY_ID",
        QUOTE_ID: "QUOTE_ID",
        SHOW_NOTRIPS_POPUP: "SHOW_NOTRIPS_POPUP",
        LAST_TRIP_ID: "LAST_TRIP_ID",
        USER_SUBSCRIPTION_DATE: "USER_SUBSCRIPTION_DATE",
        LAST_CONTEST_ID: "LAST_CONTEST_ID",
        CARBIT_TUTORIAL_DONE: "CARBIT_TUTORIAL_DONE",
        THEME_COLORS: "THEME_COLORS",
        LOCAL_SETTINGS: "LOCAL_SETTINGS",
        PROFILE_CREATION_DATE: "PROFILE_CREATION_DATE",
        APP_BEHAVIOR_OPTIONS: "APP_BEHAVIOR_OPTIONS",
        IS_FIRST_TIME: "IS_FIRST_TIME",
        MENU_ITEMS: "MENU_ITEMS",
        DEVICE_LOCALE_KEY: "DEVICE_LOCALE_KEY",
        ACCOUNT_TYPE: "ACCOUNT_TYPE",
        APP_TOKEN: "app-token",
        DEFAULT_LOCALE_KEY: "DEFAULT_LOCALE_KEY",
        BUILD_NUMBER: "BUILD_NUMBER",
        GOOGLE_ACCESS_TOKEN: "GOOGLE_ACCESS_TOKEN",
        FACEBOOK_USER_SECRET: "FACEBOOK_USER_SECRET",
        OS_VERSION: "OS_VERSION",
        MANUFACTURER: "MANUFACTURER",
        MODEL: "MODEL"
    }).constant("BooleanConstant", {
        TRUE: "1",
        FALSE: "0",
        BOOL_TRUE: true,
        BOOL_FALSE: false
    })
    .constant("OperateType", {
        PRINT: "print",
        EMAIL: "email"
    })
    .constant("CurrentScreen", {
        INVOICE: "invoice",
        PAYMENT: "payment",
        POLICY: "policy"
    })
    .constant("CameraCapture", {
        IMAGE_SIZE: {
            targetWidth: 100,
            targetHeight: 100
        },
        IMAGE_SIZE_CLAIMS: {
            targetWidth: 200,
            targetHeight: 300
        }
    })
    .constant("UploadImage", {
        TAKE: "take",
        CANCEL: "cancel",
        CHOOSE: "choose",
        DELETE: "delete",
        BASE_64: "data:image/png;base64,"
    })
    .constant("Action", {
        CLOSE: "close",
        DELETE: "delete"
    })
    .constant("PromiseStatus", {
        UNRESOLVED: 0,
        RESOLVED: 1,
        FAILED: 2
    }).constant("DeviceType", {
        T2: "T2",
        VIRTUAL: "VIRTUAL",
        XIRGO_3G: "XIRGO_3G",
        MOBILE_APP: "MOBILE_APP"
    }).constant("DeviceConnectionError", {
        NO_DEVICE_OF_THAT_TYPE_FOUND: "NO_DEVICE_OF_THAT_TYPE_FOUND",
        CONNECTION_TIMEOUT: "CONNECTION_TIMEOUT"
    }).constant("LoginType", {
        TBYB_RB: "1",
        UBI_RB: "2",
        TBYB_PPM: "3",
        UBI_PPM: "4"
    }).constant("AccountType", {
        NORMAL: "NORMAL",
        FACEBOOK: "FACEBOOK",
        GOOGLE: "GOOGLE"
    }).constant("AndroidIntent", {
        ACTION_SEND: "android.intent.action.SEND",
        ACTION_VIEW: "android.intent.action.VIEW",
        EXTRA_TEXT: "android.intent.extra.TEXT",
        EXTRA_SUBJECT: "android.intent.extra.SUBJECT",
        EXTRA_STREAM: "android.intent.extra.STREAM",
        EXTRA_EMAIL: "android.intent.extra.EMAIL",
        ACTION_CALL: "android.intent.action.CALL",
        ACTION_SENDTO: "android.intent.action.SENDTO"
    })
    .constant("ErrorType", {
        PREVENT_INFINITE_LOOP: "PREVENT_INFINITE_LOOP"
    })
    .constant("ProgressValue", {
        COMPLETE: "100.00",
        SEMICOMPLETE: "50.00",
        MAXRANGE: "80.00",
        EMPTY: "0.00"
    })
    .constant("BridgeIntentType", {
        PLATFORM_READY: "PLATFORM_READY",
        INIT_USER_SETTINGS: "INIT_USER_SETTINGS",
        OPEN_EMAIL_EVENT: "OPEN_EMAIL_EVENT",
        COMPOSE_PHONE_NUMBER_EVENT: "COMPOSE_PHONE_NUMBER_EVENT",
        OPEN_WEBSITE_EVENT: "OPEN_WEBSITE_EVENT",
        OPEN_SMS: "OPEN_SMS",
        RUN_DIAGNOSTICS: "RUN_DIAGNOSTICS",
        ACTION_TRIP_STATUS: "ACTION_TRIP_STATUS",
        ACTION_TRIP_START: "ACTION_TRIP_START",
        ACTION_TRIP_STOP: "ACTION_TRIP_STOP",
        ACTION_TRIP_PAUSE: "ACTION_TRIP_PAUSE",
        ACTION_TRIP_RESUME: "ACTION_TRIP_RESUME",
        ACTION_TRIP_TRANSMITTED: "ACTION_TRIP_TRANSMITTED",
        ACTION_TRIP_TRANSMISSION_FAILURE: "ACTION_TRIP_TRANSMISSION_FAILURE",
        ACTION_TRIP_PROCESS_COMPLETE: "ACTION_TRIP_PROCESS_COMPLETE",
        CAPTURE_RAW_EVENTS: "CAPTURE_RAW_EVENTS",
        SEND_TRIP_INFO: "SEND_TRIP_INFO",
        UPDATE_USER_SETTINGS: "UPDATE_USER_SETTINGS",
        UPDATE_USE_WIFI_ONLY: "UPDATE_USE_WIFI_ONLY",
        UPDATE_ANNONYMOUS_DRIVING: "UPDATE_ANNONYMOUS_DRIVING",
        UPDATE_AUTO_START: "UPDATE_AUTO_START",
        UPDATE_TRIP_NOTIFICATION: "UPDATE_TRIP_NOTIFICATION",
        UPDATE_TRIP_SCORE_NOTIFICATION: "UPDATE_TRIP_SCORE_NOTIFICATION",
        UPDATE_CONTEST_NOTIFICATION: "UPDATE_CONTEST_NOTIFICATION",
        UPDATE_HAC_BEEP: "UPDATE_HAC_BEEP",
        UPDATE_HBR_BEEP: "UPDATE_HBR_BEEP",
        LOCALE_KEY_CHANGED: "LOCALE_KEY_CHANGED",
        APP_EXIT: "APP_EXIT",
        SEND_USER_INFORMATION: "SEND_USER_INFORMATION",
        CLEAR_USER_INFORMATION: "CLEAR_USER_INFORMATION",
        START_TRIP: "START_TRIP",
        PAUSE_TRIP: "PAUSE_TRIP",
        RESUME_TRIP: "RESUME_TRIP",
        STOP_TRIP: "STOP_TRIP",
        GET_TRIP_INFO: "GET_TRIP_INFO",
        UPDATE_TRIP_PROCESS_COMPLETE_NOTIFICATION: "UPDATE_TRIP_PROCESS_COMPLETE_NOTIFICATION",
        PING_DEVICE: "PING_DEVICE",
        PING_DEVICE_FAILED: "PING_DEVICE_FAILED",
        DEVICE_READY: "DEVICE_READY",
        BLE_NOT_AVAILABLE: "BLE_NOT_AVAILABLE",
        BLE_START_SCAN: "BLE_START_SCAN",
        BLE_END_SCAN: "BLE_END_SCAN",
        DEVICE_CONNECTED: "DEVICE_CONNECTED",
        DEVICE_FOTA_STARTED: "DEVICE_FOTA_STARTED",
        DEVICE_FOTA_PROGRESS: "DEVICE_FOTA_PROGRESS",
        DEVICE_FOTA_COMPLETED: "DEVICE_FOTA_COMPLETED",
        DEVICE_FOTA_CANCELLED: "DEVICE_FOTA_CANCELLED",
        DEVICE_DATA_RX: "DEVICE_DATA_RX",
        DEVICE_DATA_TX: "DEVICE_DATA_TX",
        DEVICE_DATA_TX_FAILED: "DEVICE_DATA_TX_FAILED",
        DEVICE_DISCOVERED: "DEVICE_DISCOVERED",
        DEVICE_DISAPPEARED: "DEVICE_DISAPPEARED",
        DEVICE_CONNECT_FAILED: "DEVICE_CONNECT_FAILED",
        DEVICE_DISCONNECTED: "DEVICE_DISCONNECTED",
        TELEMETRY_ISSUE_DETECTED: "TELEMETRY_ISSUE_DETECTED",
        UPDATE_AUTO_START_CONFIDENCE: "UPDATE_AUTO_START_CONFIDENCE",
        UPDATE_AUTO_STOP_DURATION: "UPDATE_AUTO_STOP_DURATION",
        NOTIFICATION_LINK: "NOTIFICATION_LINK",
        ACCELERATION: "ACCELERATION",
        DECCELERATION: "DECCELERATION",
        UPDATE_GET_TRIP_STATUS: "UPDATE_GET_TRIP_STATUS",
        GPS_STATE: "GPS_STATE",
        BLUETOOTH_STATE: "BLUETOOTH_STATE",
        WIFI_STATE: "WIFI_STATE",
        CELLULAR_DATA_STATE: "CELLULAR_DATA_STATE",
        AIRPLANE_MODE_STATE: "AIRPLANE_MODE_STATE",
        ACTION_IS_PASSENGER: "ACTION_IS_PASSENGER",
        GOOGLE_PLAY_ISSUE_DETECTED: "GOOGLE_PLAY_ISSUE_DETECTED",
        GET_NOTIFICATION_DATA: "GET_NOTIFICATION_DATA",
        NOTIFICATION_DATA: "NOTIFICATION_DATA",
        CLEAR_NOTIFICATION_DATA: "CLEAR_NOTIFICATION_DATA",
        T2_START_CONFIGURATION: "T2_START_CONFIGURATION",
        T2_PROGRESS_CONFIGURATION: "T2_PROGRESS_CONFIGURATION",
        T2_END_CONFIGURATION: "T2_END_CONFIGURATION",
        T2_LOG_DATA_AVAILABLE: "T2_LOG_DATA_AVAILABLE",
        T2_LOG_DATA_RX: "T2_LOG_DATA_RX",
        T2_LOG_DATA_COMPLETE: "T2_LOG_DATA_COMPLETE",
        START_DEVICE_SCAN: "START_DEVICE_SCAN",
        BLE_DISABLED: "BLE_DISABLED",
        USER_POLICY_ID: "USER_POLICY_ID",
        ACTION_T2_NOTIFICATION: "ACTION_T2_NOTIFICATION",
        SET_TELEMETRY_LOGS: "SET_TELEMETRY_LOGS",
        SET_LANGUAGE: "SET_LANGUAGE",
        ACTION_LOW_BATTERY: "ACTION_LOW_BATTERY",
        ACTION_OKAY_BATTERY: "ACTION_OKAY_BATTERY",
        ACTION_OPEN_SETTINGS_LOCATION: "ACTION_OPEN_SETTINGS_LOCATION"
    }).constant("DeviceFactoryEvent", {
        DEVICE_PING_DEVICE_FAILED_EVENT: "DEVICE_PING_DEVICE_FAILED_EVENT",
        DEVICE_READY_EVENT: "DEVICE_READY_EVENT",
        DEVICE_DISCOVERED_EVENT: "DEVICE_DISCOVERED_EVENT",
        DEVICE_DISAPPEARED_EVENT: "DEVICE_DISAPPEARED_EVENT",
        DEVICE_CONNECT_FAILED_EVENT: "DEVICE_CONNECT_FAILED_EVENT",
        DEVICE_DISCONNECTED_EVENT: "DEVICE_DISCONNECTED_EVENT",
        ACTION_OPEN_SETTINGS_LOCATION: "ACTION_OPEN_SETTINGS_LOCATION"
    }).constant("LoggerUtilType", {
        "LOG": "LOG",
        "WARN": "WARN",
        "ERROR": "ERROR!"
    }).constant("TripEventType", {
        START: "START",
        STOP: "STOP",
        HARD_BRAKING: "HBR",
        OVERSPEED: "OSP",
        HARD_ACCELERATION: "HAC"
    }).constant("PhoneSwitchType", {
        BLUETOOTH: "BLUETOOTH",
        WIFI: "WIFI",
        GPS: "GPS",
        AIRPLANE_MODE: "AIRPLANE_MODE",
        CELLULAR_DATA: "CELLULAR_DATA"
    })
    .constant("WebServiceUrls", {
        LOGIN: "/login",
        PAS_LOGIN: "/drivers/token",
        PAS_CLAIM: "/pas_claim",
        REGISTER: "/register",
        GET_SETTINGS: "/getSettings",
        GET_LATEST_CONFIG_MODIFIED_DATE: "/getLatestConfigModifiedDate",
        FORGOT_PASSWORD: "/forgotPassword",
        GET_LOCALES: "/getLocales",
        GET_TRIPS: "/getTrips",
        GET_TRIP: "/getTrip",
        GET_TRIPS_BY_VEHICLE_ID: "/getTripsByVehicleId",
        GET_GIT_VERSION: "/getGitVersion",
        GET_LOCALE_MODIFIED_DATE: "/getLocaleModifiedDate",
        MODIFY_PASSWORD: "/modifyPassword",
        RECORD_CONSENT: "/recordConsent",
        SET_VEHICLE_PROFILE: "/setVehicleProfile",
        GET_VEHICLE_PROFILE: "/getVehicleProfile",
        SET_GENERAL_PROFILE: "/setGeneralProfile",
        SET_PERSONAL_PROFILE: "/setPersonalProfile",
        GET_PERSONAL_PROFILE: "/getPersonalProfile",
        GET_SCORE: "/getScore",
        GET_ACHIEVEMENTS: "/getAchievements",
        GET_ACHIEVEMENTS_LIST: "/getAchievementList",
        GET_ACHIEVEMENT_STATICS: "/getAchievementStatics",
        GET_CLIENT_COMMUNICATION_CONFIG: "/getClientCommunicationConfig",
        GET_VEHICLE_YEARS: '/getVehicleYears',
        GET_VEHICLE_MAKE: '/getVehicleMakes',
        GET_VEHICLE_MODELS: '/getVehicleModels',
        SET_PROFILE: '/saveProfile',
        GET_USER_SETTINGS: '/getUserSettings',
        SET_USER_SETTINGS: '/setUserSettings',
        GET_DAILY_SCORES: "/getDailyScores",
        GET_OVERALL_SCORES: "/getOverallScores",
        GET_DEVICES: "/getDevices",
        GET_LAST_TRIP: "/getLastTrip",
        GET_ACHIEVEMENT_PROGRESS: "/getAchievementProgress",
        GET_DOCUMENT: "/getDocument",
        GET_ALL_DOCUMENTS: "/getAllDocuments",
        GET_HELP: "/getDocument/htmlHelpScreenText",
        LOGOUT: "/logout",
        GET_ACTIVE_CHALLENGES: "/getActiveChallenges",
        GET_WON_CHALLENGES: "/getWonChallenges",
        GET_LOST_CHALLENGES: "/getLostChallenges",
        HIDE_CHALLENGE: "/hideChallenge",
        GET_CHALLENGE_DETAILS: "/getChallengeDetails",
        GET_GENERAL_RANKINGS: "/getGeneralRankings",
        FACEBOOK_LOGIN: "/loginFacebook",
        GOOGLE_LOGIN: "/loginGoogle",
        GET_IMAGES: "/getImages",
        GET_MODIFIED_CONTESTS: "/getModifiedContests",
        UPDATE_CLIENT_COMMUNICATIONCONFIG: "/updateClientCommunicationConfig",
        GET_AVATAR: "/getAvatar",
        UPDATE_AVATAR: "/updateAvatar",
        SET_AWS_END_POINT: "/setAWSEndpoint",
        GET_VEHICLEINFO_BY_VIN: "/getVehicleInfoByVIN",
        GET_STATES_LIST: "/getStateList",
        ADD_PAYMENT: "/gamify/users/",
        REPORT_PROBLEM: "/reportProblem",
        GET_PACKAGES: "/pas/payment_options",
        GET_REPAIR_SHOPS: "/pas/repair_shops/search",
        GET_INVOICES: '/policy_invoices/',
        GET_INVOICE: "/pas/policy_invoices/",
        GET_USER_PAYMENTS: "/policy_payments/",
        GET_PAYMENT: "/pas/policy_payements/",
        GET_FAQS: "/getFaqs",
        GET_TUTORIALS: "/getTutorials",
        GET_TRIP_HISTORY_COST: "/getTripHistoryCost",
        DELETE_QUOTE: "/deleteQuote",
        GET_QUOTE_ABOUT_YOU: "/getQuoteAboutYou",
        GET_QUOTE_VEHICLE: "/getQuoteVehicle",
        PAS_CORE: "/pas_core",
        PAS_BILLING: "/pas_billing",
        POLICIES: "/policies/",
        APPLICATION_USERS: "/application/users/",
        APPLICATION: "/application",
        REG_USERS: "/users",
        CLAIM_TYPES: "/claim_types",
        CLAIMS: "/pas/claims",
        GET_SET_CLAIMS: "/policy_claims",
        USERS: "/gamify/users/",
        USER_PAYMENT_METHODS: "/pas_billing/user_payment_methods",
        GET_TRIPS_DETAILS_FROM_DATES: "/getTripsDetailsFromDates",
        GET_LAST_TRIP_DETAILS: "/getLastTripDetails",
        GET_TRIPS_DETAILS_FROM_DATES_VEHICLE: "/getTripsDetailsFromDatesByVehicle",
        GET_LAST_TRIP_DETAILS_VEHICLE: "/getLastTripDetailsByVehicle",
        POLICY_PICTURES: "/policy_claim_pictures/",
        CLAIM_VEHICLES: "/vehicles",
        CREATE_QUOTE: "/pas_quote/quotes",
        QUOTE_PURCHASE: "/purchase",
        GET_SEGMENTS_COLORS: "/getSegmentsColors",
        GET_DAILY_DETAILS_FROM_DATES: "/getDailyDetailsFromDates",
        GET_CREATION_DATE: "/getCreationDate",
        GET_NEW_TRIP_NOTIF: "/getNewTripNotif",
        GET_NEW_TRIP_NOTIF2: "/getNewTripNotif2",
        GET_NEW_CONTEST_NOTIF: "/getNewContestNotif",
        GET_PAS_POLICY_INFO: "/pas_core/vehicles",
        GET_CONTEST_DETAILS: "/getContestDetails",
        GET_THEME_COLORS: "/getThemeColors",
        GET_VEHICLE_TYPES: "/getVehicleTypes",
        GET_VEHICLE_MORE_DETAILS: "/getVehicleMoreDetails",
        GET_PRIMARY_VEHICLES: "/getPrimaryVehicles",
        GET_ANNUAL_KMS: "/getAnnualKMs",
        GET_DISTANCE_DRIVEN: "/getDistanceDriven",
        GET_TYPE_OF_ACCIDENTS: "/getTypeOfAccidents",
        GET_ASSISTANCE_OPTIONS: "/getAssistanceOptions",
        DISCONNECT_FACEBOOK: "/disconnectFacebook",
        LINK_FACEBOOK: "/linkFacebookAccount",
        GET_LEADERBOARD_USERS: "/getLeaderboardUsers",
        INVITE_FRIEND: "/inviteFriend",
        GET_INVITES: "/getInvites",
        INVITATION_STATUS: "/invitationStatus",
        GET_PROFILE: "/getProfile",
        MARITAL_STATUSES: "/marital_statuses",
        DRIVER_TYPES: "/driver_types",
        PAYMENT_OPTIONS: "/payment_options",
        PREMIUMS: "/premiums",
        INSURANCES: "/insurances",
        QUOTE_SIMULATIONS: "/quote_simulations",
        GET_TRIPS_TYPES: "/getTripTypes",
        SET_TRANSPORT_TYPE: "/setTransportType",
        GET_ENVIRONMENT: "/getEnvironment",
        ADD_FAVORITE: "/addFavorite",
        REMOVE_FAVORITE: "/removeFavorite",
        GET_FAVORITES: "/getFavorites",
        SEARCH_FAVORITES: "/searchFavorites",
        LINK_TO_POLICY: "/linkToPolicy",
        GET_DASH_GAMING_DATA: "/getDashboardGamingData",
        GET_MISSIONS_DATA: "/getMissionsData",
        GET_BADGES_DATA: "/getBadgesData",
        GET_COINS_HISTORY: "/getCoinsHistory",
        GET_COINS_TOTAL: "/getUserCoins",
        ALERT_COIN_TAG: "/sendActions",
        SMS_VALIDATION: "/smsValidation",
        VALIDATE_CODE: "/validateCode",
        GET_RANKING: "/getRankings",
        REMOVE_FRIEND: "/removeFriend",
        ADD_FRIEND: "/addFriend",
        SEARCH_FRIEND: "/findFriends",
        PAS_LOGIN: "/drivers/token",
        GAQ_LOG: "/logAction",
        SET_PHONE_INFO: "/setPhoneInfo"
    }).constant("ApiStatusCode", {
        INTERNAL_ERROR: 500,
        REQUEST_ERROR: 400,
        UNAUTHORIZED: 401,
        NOT_FOUND: 404,
        METHOD_NOT_ALLOWED: 405,
        TIME_OUT: 408,
        CONFLICT: 409,
        SUCCESS: 200
    }).constant("TripState", {
        UNKNOWN: "UNKNOWN",
        STARTED: "STARTED",
        STOPPED: "STOPPED",
        PAUSED: "PAUSED",
        TRANSMITTED: "TRANSMITTED",
        TRANSMITTED_FAILED: "TRANSMITTED_FAILED"
    }).constant("ScoreType", {
        GLOBAL: "GLOBAL",
        SPEEDING: "SPEEDING",
        BRAKING: "BRAKING",
        CORNERING: "CORNERING",
        ACCELERATION: "ACCELERATION"
    })
    .constant("ApiErrorCode", {
        NO_CALL_MADE: -1, // sent by httpProxy
        TIMED_OUT: 408, // sent by httpProxy
        DISPLAY_NAME_ALREADY_USED: 1001,
        USERNAME_PASSWORD_MISMATCH: 1028,
        CONSENT_REQUIRED: 1022,
        LTP_REQUIRED: 1021,
        ACCOUNT_LOCKED: 1003,
        //CLIENT_NAME_DOESNT_MATCH_EMAIL: 1010,
        //USER_EMAIL_NOT_FOUND: 1000,
        //EMAIL_ALREADY_IN_USE: 1022,
        //ACCOUNT_ALREADY_IN_USE: 1023,
        //INVALID_PHONE_OR_DOB: 1081,
        //INVALID_PIN: 1050,
        EMAIL_ALREADY_USED: 1006,
        //INVALID_PASSWORD: 1055,
        //INVALID_MODE: 1072,
        INACTIVE_STATUS: 1023,
        DEACTIVATED_STATUS: 1024,
        INACTIVE_PROFILE: 1029,
        POLICY_NOT_FOUND: 1030
    }).constant("TetheringStatus", {
        SCANNING: "SCANNING",
        WAITING: "WAITING",
        IDLE: "IDLE"
    }).constant("DeviceStatus", {
        NOT_CONNECTED: "NOT_CONNECTED",
        DISCOVERED: "DISCOVERED",
        READY: "READY",
        DISAPPEARED: "DISAPPEARED",
        CONNECT_FAILED: "CONNECT_FAILED",
        DISCONNECTED: "DISCONNECTED",
        TELEMETRY_ISSUE_DETECTED: "TELEMETRY_ISSUE_DETECTED",
        CONNECTED: "CONNECTED",
        FOTA_STARTED: "FOTA_STARTED",
        FOTA_PROGRESS: "FOTA_PROGRESS",
        FOTA_CANCELLED: "FOTA_CANCELLED",
        FOTA_COMPLETED: "FOTA_COMPLETED",
        CONFIG_STARTED: "CONFIG_STARTED",
        CONFIG_PROGRESS: "CONFIG_PROGRESS",
        CONFIG_ENDED: "CONFIG_ENDED",
        DATA_AVAILABLE: "DATA_AVAILABLE",
        DATA_PROGRESS: "DATA_PROGRESS",
        DATA_COMPLETED: "DATA_COMPLETED"
    })
    .constant("ValidationUtilEnumTest", {
        ENUM1: "ENUM1",
        ENUM2: "ENUM2"
    })
    .constant("AppDocuments", {
        CONTEST_RULE: "contestRules",
        TUTORIALS: "tutorials",
        CONSENT_TEXT: "consentText",
        CLIENT_CONSENT_TEXT: "clientConsentText",
        FAQ: 'faqText',
        PRIVACY_POLICY: 'privacyPolicy'
    }).constant("TimeoutValues", {
        DEVICE_PING: 120000 // 2 minutes
    })
    .constant("DateValues", {
        MONTHS: ["lblMonth_Small_January", "lblMonth_Small_February", "lblMonth_Small_March", "lblMonth_Small_April", "lblMonth_Small_May", "lblMonth_Small_June", "lblMonth_Small_July", "lblMonth_Small_August", "lblMonth_Small_September", "lblMonth_Small_October", "lblMonth_Small_November", "lblMonth_Small_December"],
        DAYS_SUFFIX: ["lblOrdinalnum_First", "lblOrdinalnum_Second", "lblOrdinalnum_Third", "lblOrdinalnum_Fourth"],
        INVALID_DATE: 'Invalid Date'
    })
    .constant("TripDefaultValues", {
        HEADER_WEEKS: ["lblWeek_Small_Sunday", "lblWeek_Small_Monday", "lblWeek_Small_Tuesday", "lblWeek_Small_Wednesday", "lblWeek_Small_Thursday", "lblWeek_Small_Friday", "lblWeek_Small_Saturday"],
        TOTAL_DAYS: 7,
        FIRST_DAY_OF_MONTH: 1,
        MONTHS_HEADERS_DETAIL: ["lblMonth_Full_January", "lblMonth_Full_February", "lblMonth_Full_March", "lblMonth_Full_April", "lblMonth_Full_May", "lblMonth_Full_June", "lblMonth_Full_July", "lblMonth_Full_August", "lblMonth_Full_September", "lblMonth_Full_October", "lblMonth_Full_November", "lblMonth_Full_December"],
        WEEK_HEADERS_DETAIL: ["lblWeek_Full_Sunday", "lblWeek_Full_Monday", "lblWeek_Full_Tuesday", "lblWeek_Full_Wednesday", "lblWeek_Full_Thursday", "lblWeek_Full_Friday", "lblWeek_Full_Saturday"],
        DESCRIPTION: "_desc",
        UNKNOWN: "unknown",
        UNKNONW_EXTRA: "- unknown",
        COMMUNITY_DESCRIPTION: "_community_desc",
        COMMUNITY_TITLE: "_community",
        TOOLTIP_DEFAULT1: 1,
        TOOLTIP_DEFAULT2: 2
    })
    .constant("AchivementsConstants", {
        'ACHIVEMENT_TYPE_ID': '9a7d849d-e820-11e4-9ac1-24b6fd000282'
    })
    .constant("ConnectionConstants", {
        WIFI_CONNECTION: "wifi",
        UNKNOWN_CONNECTION: "UNKNOWN_CONNECTION",
        CELL_CONNECTION: "cellular",
        NO_NETWORK_CONNECTION: "none"
    })
    .constant("StateConstants", {
        'SPLASH_SCREEN': 'splash'
    })
    .constant("NoNetwork", {
        NO_NETWORK_TITLE: "Sin conexión de red",
        NO_NETWORK_CONTENT: "Por favor, compruebe la conexión de red.",
        NO_NETWORK_OK: "OK"
    })
    .constant("SocialConstants", {
        GOOGLE_API: "78170600662-9k4u1qsbslkcoqj4l2jd2u0hjp5vroka.apps.googleusercontent.com",
        GOOGLE_SECRET: 'CqvZCsvgCyZePvVpf4LhK3Ho',
        //         GOOGLE_API: "338345925587-a2j7ri8837ed1rilt7n8cjju312su010.apps.googleusercontent.com",
        // GOOGLE_SECRET: 'w-GijR9EE2FSHnVMDNWJePzK',
        FACEBOOK_APP_ID: "1472261196427780",
        FACEBOOK_SECRET: '',
        FACEBOOK: "facebook",
        GOOGLE: "google",
        NORMAL: "NORMAL",
        FACEBOOK_PROFILE: "https://graph.facebook.com/me?fields=name,gender,email,first_name,last_name&access_token=",
        GOOGLE_PROFILE: "https://www.googleapis.com/plus/v1/people/me?access_token=",
        GOOGLE_REDIRECT_URL: "http://localhost:8100/oauth2callback",
        FACEBOOK_REDIRECT_URL: "http://localhost/oauth2callback",
        GOOGLE_TOKEN_URL: "https://accounts.google.com/o/oauth2/token",
        GOOGLE_VALIDATE_ADDRESS: "https://maps.googleapis.com/maps/api/geocode/json?address=",
        GET_FRIENDS: "https://graph.facebook.com/me?fields=friends&access_token=",
        GOOGLE_CLIENT_END_TEXT: ".apps.googleusercontent.com"
    })
    .constant("DatabaseConstants", {
        DATABASE_NAME: "trips.db",
        TRIP_TABLE: "trip"
    })
    .constant("CacheControlType", {
        PUBLIC: "Public",
        OFFLINE: "Offline",
        NO_CACHE: "No-Cache"
    })
    .constant("ClientType", {
        MUTUEL: "MUTUEL",
        BROKER: "BROKER"
    })
    .constant("ToastTime", {
        DURATION: "2000",
        DEFAULT_REFRESH_DELAY: "500"
    }).constant("AppModeCDF", {
        APP_MODE: "TBYB"
    }).constant("Directions", {
        RIGHT: ["NE", "SE"],
        LEFT: ["NW", "SW"],
        EASTANGLE: 7,
        WESTANGLE: -95,
        NORMALANGLE: -45,
        DirectionKey: "direction_"
    })
    .constant("ESTTimeZone", {
        OffsetHours: 9,
        OffsetMinutes: 30,
        EST_OFFSET: 300
    })
    .constant("NotificationTypes", {
        NEW_CONTEST: 1,
        CONTEST_WON: 2,
        CONTEST_INFO: 3,
        ACHIVEMENT_WON: 4,
        CUSTOM_MESSAGE: 5,
        BADGE_WON: 6
    }).constant("GlobalEvent", {
        INIT_USER_SETTINGS_RECEIVED: "INIT_USER_SETTINGS_RECEIVED",
        ON_CACHE_STATE_CHANGED: "ON_CACHE_STATE_CHANGED"
    }).constant("BannerType", {
        GPS_BANNER: "GPS_BANNER",
        NETWORK_BANNER: "NETWORK_BANNER",
        BLUETOOTH_BANNER: "BLUETOOTH_BANNER",
        BLUETOOTH_NOT_SUPPORTED_BANNER: "BLUETOOTH_NOT_SUPPORTED_BANNER",
        TELEMETRY_DEVICE_BANNER: "TELEMETRY_DEVICE_BANNER",
        AIRPLANE_BANNER: "AIRPLANE_BANNER"
    })
    .constant("SocialShareCategory", {
        TRIP_SHARE: "trip_share",
        BADGE_SHARE: "badge_share",
        ACHIEVEMENT_SHARE: "achievement_share",
        CONTEST_SHARE: "contest_share",
        GENERAL_RANK_SHARE: "rank_share",
        FAVORITE_RANK_SHARE: "favorite_rank_share",
        CONTEST_WON_SHARE: "contest_won_share",
        LAST_TRIP_SHARE: "DASHBOARD_SHARE", //not there.Need to confirm
        BADGE_PAGE_SHARE: "badge_page_share"
    })
    .constant("SocialShareVia", {
        FACEBOOK: "Facebook",
        GOOGLE_PLUS: "Google+",
        TWITTER: "Twitter",
        EMAIL: "Email"
    }).constant("PushConstants", {
        SENDER_ID: '338345925587' // this is baselines project id
            //395720107515
    })
    .constant("ContactRecords", {
        LIMIT_TO: 20
    })
    .constant("VehicleType", {
        TAXI_TYPE: "TAxiType"
    })
    .constant("UserPrefLanguage", {
        English: "en-US",
        French: "fr-CA",
        Spanish: "es-ES",
    })
    .constant("HelpSection", {
        REPLACE_URL: '/gamify/api',
        REPLACE_EXTRA_URL: '/cardif/cardifApi'
    })
    .constant("UserContestState", {
        All: "all",
        Won: "won",
        Lost: "lost"
    })
    .constant("DateSortProp", {
        MODIFIED: "modified"
    })
    .constant("TbybDuration", {
        validTime: 365 // days
    })
    .constant("GaqConstants", {
        AnnualMileage: "12,000" // days
    })
    .constant("TokenConstants", {
        G_ACCESS_TOKEN_CONS: "g_access_token",
        G_REFRESH_TOKEN_CONS: "g_refresh_token",
        FB_ACCESS_TOKEN_CONS: "fb_access_token",
        FB_CONST_EMAIL: "fb_email",
        G_CONST_EMAIL: "g_email"
    })
    .constant("ClearCacheMethods", {
        CASE1: 1,
        CASE2: 2,
        CASE3: 3,
        CASE4: 4,
        CASE5: 5,
        CASE6: 6,
        CASE7: 7
    }).constant("DefaultScreen", {
        DASHBOARD: "app.dashboard",
        FALSE: "0"
    }).constant("LanguageKeys", {
        DEFAULT_LOCALE_KEY: "fr-CA"
    }).constant("MapsProperties", {
        MARKER_OBJ: {
            anchor: [1, 40],
            anchorXUnits: 'fraction',
            anchorYUnits: 'pixels',
            opacity: 0.95,
            icon: 'client/images/insurance/map_black.png'
        },
        MAP_BLUE_IMG: "client/images/insurance/map_blue.png",
        MAP_BLACK_IMG: "client/images/insurance/map_black.png",
    }).constant("QuoteSteps", {
        STEP_1: "1",
        STEP_2: "2",
        STEP_3: "3",
        STEP_4: "4",
        STEP_5: "5",
        LEAVE: "leave",
        SAVE: "save",
    })
    .constant("Profile", {
        GENDER: ["", "Not Specified", "Male", "Female"],
        GENDER_OPTIONS: {
            "N": "notSpecifiedText",
            "M": "Male",
            "F": "Female"
        }
    })
    .constant("ConsentStatus", {
        CONSENT_ACCEPTED: "1"
    })
    .constant("CountryName", {
        USA: 'United States'
    })
    .constant("PaymentTypes", {
        VISA: 1,
        PAYPAL: 2
    }).constant("ClaimTypesIcons", {
        'Collision': 'fa-car',
        'Vandalism': 'fa-car',
        'Stolen Vehicle': 'fa-car',
        'Fire': 'ion-ios-flame',
        'Water Damage': 'ion-waterdrop'
    }).constant("AssistanceType", {
        ASSISTANCE_PHONE: "phone",
        ASSISTANCE_WEBSITE: "webSite",
        ASSISTANCE_EMAIL: "to"
    }).constant("AchievementType", {
        Id: "9a7d849d-e820-11e4-9ac1-24b6fd000282"
    }).constant("ContestStatus", {
        ACTIVE: "active",
        CLOSE: "close"
    }).constant("BackGround", {
        WHITE: "#fff"
    });
