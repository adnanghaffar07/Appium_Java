angular.module('util')
    .service('HttpProxy', HttpProxy);

function HttpProxy($http, $q, $timeout, $ionicHistory, PromiseStatus, WebServiceCache, ListenerUtil, GlobalEvent, NetworkConnectionUtil, LoggerUtil, OfflineLoginFactory, LocalStorage, LocalStorageKeys, GlobalConstants, WebServiceUrls, ApiStatusCode, ApiErrorCode, ErrorType, ConnectionConstants, ApplicationMode, LoginType, AccountType, ValidationUtil, ApplicationStateManager, ClientSettings, $rootScope) {

    this.post = post;
    this.get = get;
    this.put = put;
    this.autoLogin = autoLogin;
    this.isNetworkAvailable = isNetworkAvailable;
    this.setDataLocal = setDataLocal;
    this.clearLocalData = clearLocalData;
    this.checkIfLoggedIn = checkIfLoggedIn;

    this.setUseWifiOnly = setUseWifiOnly;
    this.getUseWifiOnly = getUseWifiOnly;
    this.delete = Delete;

    this.getLastUpdateTimestamp = function () {
        if (lastUpdateTimestamp == -1) {
            loadLastUpdateTimestamp();
        }
        return lastUpdateTimestamp;
    };

    const TAG = "HTTP_PROXY";
    //const TIME_OUT_DELAY = 40000;
    var mWebserviceState = true;
    var lastUpdateTimestamp = -1;


    // *************************  CODE  *************************

    function loadLastUpdateTimestamp() {
        lastUpdateTimestamp = LocalStorage.get(LocalStorageKeys.LAST_UPDATE_TIMESTAMP, -1);
    }

    function setLastUpdatedTimestamp() {
        lastUpdateTimestamp = moment().format("x");
        LocalStorage.set(LocalStorageKeys.LAST_UPDATE_TIMESTAMP, lastUpdateTimestamp);
    }

    function innerRequest(pRequestFunction, pUrl, pJsonParams, pQ, pFromAutoLogin) {
        var q = null;

        if (angular.isDefined(pQ)) {
            q = pQ;
        } else {
            q = $q.defer();
        }


        var publicResponse = WebServiceCache.getPublicResponse(pUrl, pJsonParams);
        if (publicResponse != null) {
            useCache(q, pUrl, publicResponse);
        } else {
            isNetworkAvailable().then(function (isAvailable) {
                if (isAvailable) {
                    $rootScope.networkStatus.isAvailable = true;
                    var timeout = startTimeOut(q, pUrl);
                    callWebservice(pRequestFunction, pUrl, pJsonParams, q, pQ, timeout, pFromAutoLogin);
                    //var offlineResponse = WebServiceCache.getOfflineResponse(pUrl, pJsonParams);
                    //                    if (offlineResponse != null) {
                    //                        var ts = LocalStorage.get(LocalStorageKeys.LAST_UPDATE_TIMESTAMP, 'null');
                    //                        if (ts != 'null' && moment().subtract(1, "minutes").format('x') < ts) {
                    //                            useCache(q, pUrl, offlineResponse);
                    //                            $timeout.cancel(timeout);
                    //                        } else {
                    //                            callWebservice(pRequestFunction, pUrl, pJsonParams, q, pQ, timeout, pFromAutoLogin);
                    //                        }
                    //                    } else {
                    //                        callWebservice(pRequestFunction, pUrl, pJsonParams, q, pQ, timeout, pFromAutoLogin);
                    //                    }
                } else {
                    $rootScope.networkStatus.isAvailable = false;
                    onWebServiceFail();
                    var offlineResponse = WebServiceCache.getOfflineResponse(pUrl, pJsonParams);
                    if (offlineResponse != null) {
                        useCache(q, pUrl, offlineResponse);
                    } else {
                        unableToCall(q, pUrl, pJsonParams);
                    }
                }
            });

        }
        return q.promise;
    }

    function startTimeOut(pQ, pUrl) {
        return $timeout(function () {
            var timedOutResponse = {
                config: {
                    url: pUrl
                },
                data: {
                    lastUpdateTimestamp: lastUpdateTimestamp,
                    message: "Request timeout",
                    api_error_code: ApiErrorCode.TIMED_OUT,
                    'i18n-key': "error_" + ApiStatusCode.TIME_OUT
                },
                status: ApiStatusCode.TIME_OUT,
                statusText: "Request timeout"
            };
            onWebServiceFail();
            LoggerUtil.warn(TAG, "RequestTimeOut (" + pUrl + ")", timedOutResponse);

            pQ.reject(timedOutResponse);
        }, ClientSettings.TIME_OUT_DELAY);
    }

    function useCache(pQ, pUrl, pCachedResponse) {
        logResponse(pUrl, pCachedResponse, true);
        pQ.resolve(pCachedResponse);
    }

    function logResponse(pUrl, pResponse, pIsCached) {
        var response = null;
        var method = pUrl.substr(GlobalConstants.BASE_URL.length);
        var text = (pIsCached) ? "Cached " + pResponse.config.headers["Cache-Control"] + " (" + pUrl + ")" : "Real In (" + pUrl + ")";


        response = angular.copy(pResponse);
        delete response['status'];
        delete response['statusText'];
        delete response['headers'];
        delete response.config['method'];
        delete response.config['headers'];
        delete response.config['transformRequest'];
        delete response.config['transformResponse'];

        if (method == WebServiceUrls.GET_LOCALES ||
            method == WebServiceUrls.GET_ALL_DOCUMENTS ||
            method == WebServiceUrls.GET_AVATAR) {

            //don't log the data in the LoggerUtil
            response.dontLogOnLoggerUtil = true;
        }
        LoggerUtil.log(TAG, text, response);
    }

    function unableToCall(pQ, pUrl, pJsonParams) {
        //NOT ALLOWED OR UNABLE TO REACH OUT
        var noCallResponse = {
            config: {
                url: pUrl,
                data: pJsonParams
            },
            data: {
                lastUpdateTimestamp: lastUpdateTimestamp,
                message: "No call made",
                api_error_code: ApiErrorCode.NO_CALL_MADE,
                'i18n-key': "error_" + ApiStatusCode.METHOD_NOT_ALLOWED
            },
            status: ApiStatusCode.METHOD_NOT_ALLOWED,
            statusText: "No call made"
        };
        LoggerUtil.warn(TAG, "No call made (" + pUrl + ")", noCallResponse);

        pQ.reject(noCallResponse);
    }

    function callWebservice(pRequestFunction, pUrl, pJsonParams, pQ, pPreviousQ, pTimeout, pFromAutoLogin) {
        pFromAutoLogin = ValidationUtil.setDefaultValue(pFromAutoLogin, false);
        setupHeaders();
        LoggerUtil.log(TAG, "Real Out (" + pUrl + ")");
        pRequestFunction(pUrl, pJsonParams)
            .then(function (response) {
                response = WebServiceCache.fakeCacheControl(response);
                if (pQ.promise.$$state.status == PromiseStatus.UNRESOLVED) {
                    logResponse(pUrl, response, false);
                    //cancel the timeout function 
                    $timeout.cancel(pTimeout);
                    WebServiceCache.saveResponse(response);
                    //WebServiceCache.set(pUrl, pJsonParams, response);
                    getTokenFromResultHeader(response);
                    pQ.resolve(response);
                    setLastUpdatedTimestamp();
                    onWebServiceSuccess();

                } else if (pQ.promise.$$state.status == PromiseStatus.FAILED) {
                    LoggerUtil.log(TAG, "TimedOut but came back after all (" + pUrl + ")", response);
                }
            }, function (err) {
                console.log("#### CALL RETURNED ERROR ####");
                console.log('--> URL Called :', pUrl);
                console.log('--> FIND LOGIN', pUrl.indexOf(WebServiceUrls.LOGIN) != -1);
                if (pUrl.indexOf(WebServiceUrls.LOGIN) != -1) {
                    // Means the login was called and it returned an error.
                    getTokenFromResultHeader(err);
                }


                console.log('#############################');
                LoggerUtil.error(TAG, "HTTP_PROXY error", err);
                $timeout.cancel(pTimeout);
                if (0 == err.status) {
                    LoggerUtil.log(TAG, "Probably a CORS error or simply offline");
                    onWebServiceFail();
                    pQ.reject(err);
                } else if (ApiStatusCode.UNAUTHORIZED == err.status) {
                    if (angular.isUndefined(pPreviousQ) && pFromAutoLogin == false) { //is the first Time
                        autoLogin(function (pResult, pUserId) {
                            if (pResult) {
                                innerRequest(pRequestFunction, pUrl, pJsonParams, pQ, false);
                            } else {
                                pQ.reject(err);
                            }
                        });
                    } else {
                        LoggerUtil.log(TAG, "Cannot successfully call the webService")
                        pQ.reject(ErrorType.PREVENT_INFINITE_LOOP);
                    }
                } else {
                    if (ApiStatusCode.CONFLICT != err.status) {
                        onWebServiceFail();
                    }
                    pQ.reject(err);
                }
            });
    }

    function post(pUrl, pJsonParams, pUseCache, pQ, pFromAutoLogin) {
        return innerRequest($http.post, pUrl, pJsonParams, pQ, pFromAutoLogin);
    }

    function get(pUrl, pJsonParams, pUseCache, pQ, pFromAutoLogin) {
        return innerRequest($http.get, pUrl, pJsonParams, pQ, pFromAutoLogin);
    }

    function put(pUrl, pJsonParams, pUseCache, pQ, pFromAutoLogin) {
        return innerRequest($http.put, pUrl, pJsonParams, pQ, pFromAutoLogin);
    }

    function Delete(pUrl, pJsonParams, pUseCache, pQ, pFromAutoLogin) {
        return innerRequest($http.delete, pUrl, pJsonParams, pQ, pFromAutoLogin);
    }

    function setupHeaders() {
        $http.defaults.headers.common['User-Token'] = LocalStorage.get(LocalStorageKeys.USER_TOKEN);
        $http.defaults.headers.common['Accept-Language'] = LocalStorage.get(LocalStorageKeys.CURRENT_LOCALE_KEY, "en-US");
        $http.defaults.headers.common['App-Version'] = GlobalConstants.API_VERSION;
        var authToken = LocalStorage.get(LocalStorageKeys.PAS_USER_TOKEN);
        if (authToken != null && angular.isDefined(authToken)) {
            $http.defaults.headers.common['Authorization'] = "Bearer " + authToken;
        }
        /* 
            SETUP ZENDESK API TOKEN
        */
        var zendeskToken = LocalStorage.get('ZENDESK_TOKEN');
        if (angular.isDefined(zendeskToken) && zendeskToken != null) {
            $http.defaults.headers.common['Authorization'] = 'Basic ' + zendeskToken;
        }

        /*
            SETUP APP TOKEN
        */
        var appToken = LocalStorage.get('app-token');
        if (angular.isDefined(appToken) && appToken != null && appToken != "") {
            $http.defaults.headers.common['App-Token'] = appToken;
        } else {
            $http.defaults.headers.common['App-Token'] = "a692979b-c8a3-11e7-9dec-02370cb022d9"; // prod
            // $http.defaults.headers.common['App-Token'] = "a692979b-c8a3-11e7-9dec-02370cb022d9"; // pre-prod
            // $http.defaults.headers.common['App-Token'] = "44cd7bf7-8f4d-11e7-a4f3-0281b44cd591"; // beta
            // $http.defaults.headers.common['App-Token'] = "5b474e6f-017f-4b1c-9501-d5371fc33dd6"; // integration
            // Smoke Rebate Sandbox : 4cfec064-e0d9-4305-864d-d03ee48e3452
            // Fred1 Sandbox : 52641a79-805d-48d7-8596-c9849f8d671b
            // Porto Integration : 5b474e6f-017f-4b1c-9501-d5371fc33dd6
        }

        $http.defaults.headers.common['Accept'] = "application/json;"
    }

    function getTokenFromResultHeader(response) {
        if (response.headers('Set-Token') != null &&
            response.headers('Set-Token') != LocalStorage.get(LocalStorageKeys.USER_TOKEN)) {
            LocalStorage.set(LocalStorageKeys.USER_TOKEN, response.headers('Set-Token'));
        }
    }

    function isNetworkAvailable() {
        var q = $q.defer();
        NetworkConnectionUtil.getConnectionType().then(function (connectionType) {
            var isAvaiable = true;
            if (connectionType) {
                isAvaiable = true;
            } else {
                isAvaiable = false;
            }
            LoggerUtil.log("DEBUG", "isNetworkAvailable default case connectionType : ", connectionType);
            q.resolve(isAvaiable);

        });
        //return true;
        return q.promise;
    }

    function getUseWifiOnly() {
        return LocalStorage.getBoolean(LocalStorageKeys.USE_WIFI_ONLY_STATE, false);
    }

    function setUseWifiOnly(pValue) {
        LocalStorage.setBoolean(LocalStorageKeys.USE_WIFI_ONLY_STATE, pValue);
    }

    function autoLogin(pResultFunction) {
        var url;
        var application_mode = LocalStorage.get(LocalStorageKeys.APP_MODE);
        var email = LocalStorage.get(LocalStorageKeys.LOGIN_EMAIL);
        var password = LocalStorage.get(LocalStorageKeys.LOGIN_PASSWORD);
        var loginType = LocalStorage.get(LocalStorageKeys.LOGIN_TYPE);
        var accountType = LocalStorage.get(LocalStorageKeys.ACCOUNT_TYPE);
        var userID = LocalStorage.get(LocalStorageKeys.SOCIAL_USER_ID);
        var accessToken = LocalStorage.get(LocalStorageKeys.ACCESS_TOKEN);
        var jsonParams = null;

        if (accountType == AccountType.FACEBOOK) {
            jsonParams = {
                mode: application_mode,
                User: {
                    facebook_id: userID,
                    access_token: accessToken,
                    email: email
                }
            };
            password = "";
            url = GlobalConstants.BASE_URL + WebServiceUrls.FACEBOOK_LOGIN;
        } else if (accountType == AccountType.GOOGLE) {
            jsonParams = {
                mode: application_mode,
                User: {
                    googleplus_id: userID,
                    access_token: accessToken,
                    email: email
                }
            };
            url = GlobalConstants.BASE_URL + WebServiceUrls.GOOGLE_LOGIN;
            password = "";
        } else {
            if (email != null &&
                password != null) {

                jsonParams = {
                    User: {
                        email: email,
                        password: password
                    }
                };
                url = GlobalConstants.BASE_URL + WebServiceUrls.LOGIN;
            } else {
                url == null;
                LoggerUtil.log(TAG, "AutoLogin fail");
                if (angular.isDefined(pResultFunction)) {
                    pResultFunction(false, null);
                }
            }
        }
        if (url) {
            LoggerUtil.log(TAG, "Real Out (" + url + ")");
            $timeout(function () {
                innerRequest($http.post, url, jsonParams, undefined, true).then(function (response) {
                    logResponse(url, response, false);
                    setDataLocal(loginType, response, email, password);
                    LoggerUtil.log(TAG, "AutoLogin successFull", LocalStorage.get(LocalStorageKeys.USER_TOKEN));
                    if (angular.isDefined(pResultFunction)) {
                        pResultFunction(true, response.data.accountId);
                    }
                }, function (err) {
                    if (angular.isDefined(pResultFunction)) {
                        if ((err.status == ApiStatusCode.METHOD_NOT_ALLOWED ||
                                err.status == ApiStatusCode.NOT_FOUND ||
                                err.status == ApiStatusCode.INTERNAL_ERROR ||
                                err.status == ApiStatusCode.TIME_OUT) && OfflineLoginFactory.isValidLogin(loginType, email, password)) {
                            LoggerUtil.log(TAG, "Offline AutoLogin successFull");
                            pResultFunction(true, null);
                        } else {
                            LoggerUtil.log(TAG, "Offline AutoLogin fail", err);
                            pResultFunction(false, null, err);
                        }
                    } else {
                        LoggerUtil.log(TAG, "AutoLogin fail", err);
                    }
                });
            }, 500);
        } else {
            LoggerUtil.log(TAG, "AutoLogin fail", "noCredentialSet");
        }
    }

    function setDataLocal(pMode, pResponse, pEmail, pPass) {
        if (angular.isFunction(pResponse.headers)) {
            LocalStorage.set(LocalStorageKeys.USER_TOKEN, pResponse.headers('Set-Token'));
        } else {
            LocalStorage.set(LocalStorageKeys.USER_TOKEN, pResponse.data.sessionId);
        }
        if (pResponse.status == ApiStatusCode.SUCCESS) {
            LocalStorage.set(LocalStorageKeys.LOGIN_USERNAME, pResponse.data.display_name);
            LocalStorage.set(LocalStorageKeys.LOGIN_USER_ID, pResponse.data.accountId);
            LocalStorage.set(LocalStorageKeys.LOGIN_EMAIL, pEmail);
            LocalStorage.set(LocalStorageKeys.LOGIN_PASSWORD, pPass);
            LocalStorage.set(LocalStorageKeys.LOGIN_USER_LEVEL, pResponse.data.application_mode);
            if (pResponse.data.application_mode == ApplicationMode.TBYB) {
                pResponse.data.policyOwner = true;
                pResponse.data.policyEffective = true;
                pResponse.data.policyEffectiveTimestamp = -1;
                pResponse.data.externalId = -1
            }
            LocalStorage.set(LocalStorageKeys.LOGIN_EXTERNAL_ID, pResponse.data.externalId);
            LocalStorage.setBoolean(LocalStorageKeys.LOGIN_POLICY_OWNER, pResponse.data.policyOwner);
            LocalStorage.setBoolean(LocalStorageKeys.LOGIN_POLICY_EFFECTIVE, pResponse.data.policyEffective);
            LocalStorage.setBoolean(LocalStorageKeys.LOGIN_POLICY_EFFECTIVE_TIMESTAMP, pResponse.data.policyEffectiveTimestamp);
        }
    }

    function clearLocalData() {
        var keepAliveFlags = [
            LocalStorageKeys.BASE_URL_OVERRIDE,
            LocalStorageKeys.COLLECTOR_URL_OVERRIDE,
            LocalStorageKeys.COLLECTOR_URL_T2_OVERRIDE,
            LocalStorageKeys.PAS_URL_OVERRIDE,
            LocalStorageKeys.NATIVE_PREFERENCES,
            LocalStorageKeys.USE_WIFI_ONLY_STATE,
            LocalStorageKeys.TBYB_CREATION_TIMESTAMP,
            LocalStorageKeys.LAST_LOGIN_TIMESTAMP,
            LocalStorageKeys.THEME_COLORS,
            LocalStorageKeys.IS_FIRST_TIME,
            LocalStorageKeys.APP_TOKEN,
            LocalStorageKeys.DEVICE_LOCALE_KEY,
            LocalStorageKeys.DEFAULT_LOCALE_KEY,
            "isFirstLogin", "lastEmailConnected"];

        // Clear cached views
        $ionicHistory.clearCache();

        for (var key in window.localStorage) {
            if (keepAliveFlags.indexOf(key) == -1) {
                LocalStorage.clear(key);
            }
        }
    }

    function checkIfLoggedIn() {
        return (LocalStorage.get(LocalStorageKeys.USER_TOKEN) != null);
    }

    function onWebServiceFail() {
        if (mWebserviceState) {
            NetworkConnectionUtil.getConnectionType().then(function (connectionType) {
                if (!connectionType) {
                    ListenerUtil.playEvent(GlobalEvent.ON_CACHE_STATE_CHANGED, {
                        state: false
                    });
                }
            });
        }
        mWebserviceState = false;
    }

    function onWebServiceSuccess() {
        if (mWebserviceState == false) {
            ListenerUtil.playEvent(GlobalEvent.ON_CACHE_STATE_CHANGED, {
                state: true
            });
        }
        mWebserviceState = true;
    }
}
