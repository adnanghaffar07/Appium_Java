angular.module('util')
    .service('StringUtil', StringUtil);

function StringUtil(TripDefaultValues, $translate, BooleanConstant, SocialConstants) {

    this.testFunctionalities = testFunctionalities;
    this.format = format;
    this.decodeTags = decodeTags;
    this.getdateinformat = getdateinformat;
    this.getNumberFromstring = getNumberFromstring;
    this.replaceAll = replaceAll;
    this.carTypeIcon = carTypeIcon;
    this.checkUnknownText = checkUnknownText;
    this.convertIntToBool = convertIntToBool;
    this.roundOfNumber = roundOfNumber;
    this.checkGoogleClient = checkGoogleClient;
    this.formatNumbers = formatNumbers;

    function testFunctionalities() {
        var className = "StringUtil";
        var func;
        //format

        //with args
        console.assert('111' == this.format('1{0}1', '1'), className + " : " + this.format.name + "('1{0}1','1') should return '111'");
        console.assert('11' == this.format('11', '1'), className + " : " + this.format.name + "('11','1') should return '11'");
        console.assert('11' == this.format('11'), className + " : " + this.format.name + "('11') should return '11'");
        console.assert('1121' == this.format('1{0}{1}1', '1', '2', '3'), className + " : " + this.format.name + "('1{0}{1}1', '1','2','3') should return '1121'");
        console.assert('1131' == this.format('1{0}{2}1', '1', '2', '3'), className + " : " + this.format.name + "('1{0}{2}1', '1','2','3') should return '1131'");
        console.assert('1111' == this.format('1{0}{0}1', '1', '2', '3'), className + " : " + this.format.name + "('1{0}{0}1', '1','2','3') should return '1111'");
        console.assert('1221' == this.format('1{1}{1}1', '1', '2', '3'), className + " : " + this.format.name + "('1{1}{1}1', '1','2','3') should return '1221'");
        console.assert('13{3}1' == this.format('1{2}{3}1', '1', '2', '3'), className + " : " + this.format.name + "('1{2}{3}1', '1', '2', '3') should return '13{3}1'");
        console.assert('13211' == this.format('1{2}{1}{0}1', '1', '2', '3'), className + " : " + this.format.name + "('1{2}{1}{0}1', '1', '2', '3') should return '13211'");
        //with an Array
        console.assert('111' == this.format('1{0}1', ['1']), className + " : " + this.format.name + "('1{0}1',['1']) should return '111'");
        console.assert('11' == this.format('11', ['1']), className + " : " + this.format.name + "('11',['1']) should return '11'");
        console.assert('11' == this.format('11'), className + " : " + this.format.name + "('11') should return '11'");
        console.assert('1121' == this.format('1{0}{1}1', ['1', '2', '3']), className + " : " + this.format.name + "('1{0}{1}1', ['1','2','3']) should return '1121'");
        console.assert('1131' == this.format('1{0}{2}1', ['1', '2', '3']), className + " : " + this.format.name + "('1{0}{2}1', ['1','2','3']) should return '1131'");
        console.assert('1111' == this.format('1{0}{0}1', ['1', '2', '3']), className + " : " + this.format.name + "('1{0}{0}1', ['1','2','3']) should return '1111'");
        console.assert('1221' == this.format('1{1}{1}1', ['1', '2', '3']), className + " : " + this.format.name + "('1{1}{1}1', ['1','2','3']) should return '1221'");
        console.assert('13{3}1' == this.format('1{2}{3}1', ['1', '2', '3']), className + " : " + this.format.name + "('1{2}{3}1', ['1', '2', '3']) should return '13{3}1'");
        console.assert('13211' == this.format('1{2}{1}{0}1', ['1', '2', '3']), className + " : " + this.format.name + "('1{2}{1}{0}1', ['1', '2', '3']) should return '13211'");

    }

    function format(rawString, args) {

        var params = null;
        var startIndex = -1;
        if (!angular.isArray(args)) {
            params = arguments;
            for (var i = 1; i < params.length; i++) {
                rawString = replaceAll(rawString, "{" + (i - 1) + "}", params[i]);
            }
        } else {
            params = args;
            for (var i = 0; i < params.length; i++) {
                rawString = replaceAll(rawString, "{" + i + "}", params[i]);
            }
        }
        return rawString;
    }

    function replaceAll(pString, pFind, pReplace) {
        var t1 = pString.split(pFind);
        var t2 = t1.join(pReplace);

        return pString.split(pFind).join(pReplace);
    }

    //To work dates with both ios and android
    function getdateinformat(vrdate) {
        if (typeof (vrdate) === 'string') {
            return vrdate.replace(/-/g, '/');
        }
        return vrdate;

    }

    function getNumberFromstring(value) {
        value = isNaN(Math.round(value)) ? '0' : Math.round(value);
        return value;
    }

    function decodeTags(pText) {
        return pText
            .replace(new RegExp("&lt;", "g"), '<').replace(new RegExp("&gt;", "g"), '>');
    }

    function carTypeIcon(caricontype) {
        var vrcolor = "_white";
        var vrrescaricontype = caricontype;
        if (caricontype.indexOf(vrcolor) != -1) {
            var vrcaricontypesbustr = caricontype.substr(caricontype.length - vrcolor.length, caricontype.length - 1)
            if (vrcaricontypesbustr == vrcolor) {
                vrrescaricontype = caricontype.substr(0, caricontype.length - vrcolor.length);
            }
        }
        return vrrescaricontype;

    }

    function checkUnknownText(location) {
        if (location.toLowerCase().indexOf(TripDefaultValues.UNKNOWN) != -1) {
            if ($.trim(location.toLowerCase()) == TripDefaultValues.UNKNOWN) {
                return $translate.instant("unknown_location");
            } else {
                var res = location.toLowerCase().replace(TripDefaultValues.UNKNONW_EXTRA, "");
                return res;
            }
        }
        return location;
    }

    function convertIntToBool(value) {
        var returnValue = false;
        if (BooleanConstant.TRUE === value) {
            returnValue = true;
        }
        return returnValue;
    }

    function checkGoogleClient(clientid) {
        //
        if (clientid.indexOf(SocialConstants.GOOGLE_CLIENT_END_TEXT) == -1) {
            return clientid + SocialConstants.GOOGLE_CLIENT_END_TEXT;
        }
        return clientid;
    }

    function roundOfNumber(value, precision) {
        var multiplier = Math.pow(10, precision || 0);
        return Math.round(value * multiplier) / multiplier;
    }

    function formatNumbers(pNumber) {
        return pNumber.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }
}
