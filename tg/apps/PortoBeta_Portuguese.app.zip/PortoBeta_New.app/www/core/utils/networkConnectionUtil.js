angular.module('util')
    .service('NetworkConnectionUtil', NetworkConnectionUtil);

function NetworkConnectionUtil($interval, LoggerUtil, ConnectionConstants, ApplicationStateManager, $q, PhoneSwitchType, $timeout) {
    this.getConnectionType = getConnectionType;
    
    function getConnectionType() {        
        var q = $q.defer();

        if(navigator.onLine){
            q.resolve(true);
        } else{
            q.resolve(false);
        }

        return q.promise;
    }
}
