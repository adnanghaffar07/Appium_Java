angular.module('util')
    .factory('MapsUtil', MapsUtil);

function MapsUtil() {
    function initializeOpenLayerMap(data, TripEventType) {
        var encodedTripPath = data.encoded_path;
        var POIs = [];
        var array = polyline.decode(encodedTripPath, 3);
        for (var i = 0; i < array.length; i++) {
            for (var j = 0; j < array[i].length; j++) {
                var c = array[i][j] / 100;
                array[i][j] = c;
            }
        }
        var tempStart = {
            LN: array[0][1],
            LT: array[0][0],
            type: TripEventType.START
        }

        var tempStop = {
            LN: array[array.length - 1][1],
            LT: array[array.length - 1][0],
            type: TripEventType.STOP
        }

        POIs.push(tempStart);
        POIs.push(tempStop);
        var target = 'trip-map1';
        // Get POI array

        var strokeSettings = {
            color: "#00AEEF",
            width: 4
        }

        var icons = {
            START: {
                iconPath: "./client/images/mapIcons/flag_start.png",
                anchor: [0.5, 15]
            },
            STOP: {
                iconPath: "./client/images/mapIcons/flag_stop.png",
                anchor: [0.5, 15]
            },
            HAC: {
                iconPath: "",
                anchor: [0.5, 15]
            },
            HBR: {
                iconPath: "",
                anchor: [0.5, 15]
            },
            OSP: {
                iconPath: "",
                anchor: [0.5, 15]
            },
            HCO: {
                iconPath: "",
                anchor: [0.5, 15]
            }
        };
        init_mapFromPointsArrayBASEDRIVE(array, POIs, target, icons, strokeSettings);
    }

    function mapSettings(tripdid, tripdata) {
        var encodedTripPath = tripdata.encoded_path;
        var POIs = tripdata.map_poi;
        var array = polyline.decode(encodedTripPath, 3);
        for (var i = 0; i < array.length; i++) {
            for (var j = 0; j < array[i].length; j++) {

                var c = array[i][j] / 100;
                array[i][j] = c;
            }
        }

        var target = 'trip-map' + tripdid;
        // Get POI array

        var strokeSettings = {
            color: "#00AEEF",
            width: 4
        }

        var icons = {
            START: {
                iconPath: "./client/img/mapIcons/flag_start.png",
                anchor: [0.5, 15]
            },
            STOP: {
                iconPath: "./client/img/mapIcons/flag_stop.png",
                anchor: [0.5, 15]
            },
            HAC: {
                iconPath: "./client/img/mapIcons/hac-icon.png",
                anchor: [0.5, 15]
            },
            HBR: {
                iconPath: "./client/img/mapIcons/hbr-icon.png",
                anchor: [0.5, 15]
            },
            OSP: {
                iconPath: "./client/img/mapIcons/osp-icon.png",
                anchor: [0.5, 15]
            },
            HCO: {
                iconPath: "./client/img/mapIcons/hco-icon.png",
                anchor: [0.5, 15]
            }
        };


        init_mapFromPointsArrayBASEDRIVE(array, POIs, target, icons, strokeSettings);
    }

    function singlePointMap_init(pId, pLon, pLat, pMarkerObj) {
        /*
            @PARAMS : 
            -- pId : id of the element to add the map
            -- pLon, pLat : Longitude and Latitude of the point.
            -- pMarkerObj : Object containing needed informations to create the marker.
        */

        var iconFeature = new ol.Feature({
            geometry: new ol.geom.Point(ol.proj.fromLonLat([pLon, pLat], 'EPSG:3857'))
        });

        var iconStyle = new ol.style.Style({
            image: new ol.style.Icon((pMarkerObj))

            /*
                pMarkerObject must have the following structure in your controller :
                
                var markerObj = {
                    anchor: [0.5, 40],
                    anchorXUnits: 'fraction',
                    anchorYUnits: 'pixels',
                    opacity: 0.95,
                    src: '/client/img/marker_img_path.png'
                };
            */
        });

        iconFeature.setStyle(iconStyle);

        var vectorSource = new ol.source.Vector({
            features: [iconFeature]
        });

        var vectorLayer = new ol.layer.Vector({
            source: vectorSource
        });

        var rasterLayer = new ol.layer.Tile({
            source: new ol.source.TileJSON({
                url: 'http://api.tiles.mapbox.com/v3/mapbox.geography-class.jsonp',
                crossOrigin: ''
            })
        });

        var map = new ol.Map({
            view: new ol.View({
                center: ol.proj.fromLonLat([pLon, pLat], 'EPSG:3857'),
                zoom: 15
            }),
            controls: [],
            interactions: ol.interaction.defaults({
                dragPan: false,
                mouseWheelZoom: false,
                doubleClickZoom: false
            }),
            layers: [
        new ol.layer.Tile({
                    source: new ol.source.OSM()
                })
        , vectorLayer],
            target: pId
        });
    }

    function plotPath(id, pLat, pLon) {
        var vectorLines = new ol.layer.Vector({
            source: new ol.source.Vector({
                url: 'client/jsons/line-samples.geojson',
                format: new ol.format.GeoJSON()
            }),
            style: [
        new ol.style.Style({
                    stroke: new ol.style.Stroke({
                        color: 'black',
                        width: 4
                    })
                })
      ]
        });

        var map = new ol.Map({
            layers: [
        new ol.layer.Tile({
                    source: new ol.source.OSM()
                }),
        vectorLines],
            target: id,
            view: new ol.View({
                center: [pLat, pLon],
                zoom: 10
            }),
            controls: []
        });
    }

    function init_mapFromPointsArrayBASEDRIVE(pArray, pInferredArray, pPoi, targetID, pIcons, pStrokeSettings, pInferredStrokeSettings) {
        
        // Tile Layer
        var layerMQ = new ol.layer.Tile({
            source: new ol.source.OSM()
        });

        // Trip Line Layer
        var points = [];
        var vectorSource = new ol.source.Vector({});
        var layerPoints = addPoints(pArray, points, vectorSource);

        var layerLines = new ol.layer.Vector({
            source: new ol.source.Vector({
                features: [new ol.Feature({
                    geometry: new ol.geom.LineString(points, 'XY'),
                    name: 'Line'
                })]
            }),
            style: [
                new ol.style.Style({
                    stroke: new ol.style.Stroke({
                        color: pStrokeSettings.color,
                        width: pStrokeSettings.width
                    })
                })
              ]
        });
        ///////////////////

        // Inferred Line Layer
//        if(pInferredArray.length > 0){
            var points_inferred = [];
            var vectorSource_inferred = new ol.source.Vector({});
            var layerInferredPoints = addPoints(pInferredArray, points_inferred, vectorSource_inferred);

            var layerLines_inferred = new ol.layer.Vector({
                source: new ol.source.Vector({
                    features: [new ol.Feature({
                        geometry: new ol.geom.LineString(points_inferred, 'XY'),
                        name: 'Line'
                    })]
                }),
                style: [
                    new ol.style.Style({
                        stroke: new ol.style.Stroke({
                            color: pInferredStrokeSettings.color,
                            width: pInferredStrokeSettings.width
                        })
                    })
                  ]
            });
//        }
        ///////////////////

        // Markers Layer
        var mrkr;
        var startArr = [];
        var endArr = [];
        var accelArr = [];
        var brakeArr = [];
        var speedArr = [];
        var cornerArr = [];
        var distractedArr = [];
        if (pPoi) {
            for (var i = 0; i < pPoi.length; i++) {
                switch (pPoi[i].type) {
                    case "START":
                        startArr.push([parseFloat(pPoi[i].LN), parseFloat(pPoi[i].LT)]);
                        break;
                    case "STOP":
                        endArr.push([parseFloat(pPoi[i].LN), parseFloat(pPoi[i].LT)]);
                        break;
                    case "HAC":
                    case "HAC_STRONG":
                    case "ac":
                        accelArr.push([parseFloat(pPoi[i].LN), parseFloat(pPoi[i].LT)]);
                        break;
                    case "HBR":
                    case "HBR_STRONG":
                    case "dc":
                        brakeArr.push([parseFloat(pPoi[i].LN), parseFloat(pPoi[i].LT)]);
                        break;
                    case "OSP":
                    case "OSP_STRONG":
                    case "osp":
                        speedArr.push([parseFloat(pPoi[i].LN), parseFloat(pPoi[i].LT)]);
                        break;
                    case "HCO":
                    case "HCO_STRONG":
                    case "ht":
                        cornerArr.push([parseFloat(pPoi[i].LN), parseFloat(pPoi[i].LT)]);
                        break;
                    case "dd":
                        distractedArr.push(polyline.decode(pPoi[i].encoded_path, 3));
                        break;
                }
            }
        }

        for (var i = 0; i < distractedArr.length; i++) {
            for (var j = 0; j < distractedArr[i].length; j++) {
                for (var k = 0; k < distractedArr[i][j].length; k++) {
                    var c = distractedArr[i][j][k] / 100;
                    distractedArr[i][j][k] = c;
                }
            }
        }

        var startLayer = createMarkerLayer(startArr, pIcons["START"].iconPath, pIcons["START"].anchor, 'start');
        var endLayer = createMarkerLayer(endArr, pIcons["STOP"].iconPath, pIcons["STOP"].anchor, 'end');
        var accelLayer = createMarkerLayer(accelArr, pIcons["HAC"].iconPath, pIcons["HAC"].anchor, 'event');
        var brakeLayer = createMarkerLayer(brakeArr, pIcons["HBR"].iconPath, pIcons["HBR"].anchor, 'event');
        var speedLayer = createMarkerLayer(speedArr, pIcons["OSP"].iconPath, pIcons["OSP"].anchor, 'event');
        var cornerLayer = createMarkerLayer(cornerArr, pIcons["HCO"].iconPath, pIcons["HCO"].anchor, 'event');

        // Map Init
        var map = new ol.Map({
            target: targetID,
            layers: [],
            view: new ol.View({
                center: ol.proj.fromLonLat([pArray[0][1], pArray[0][0]], 'EPSG:3857'),
                maxZoom: 15
            }),
            controls: []
        });

        map.addLayer(layerMQ);
        map.addLayer(layerLines);
        map.addLayer(layerLines_inferred);

        // Add Distracted Driving Layers
        if (distractedArr.length > 0) {
            for (var i = 0; i < distractedArr.length; i++) {
                var points_dd = [];
                var vectorSource_dd = new ol.source.Vector({});
                var layerPoints_dd = addPoints(distractedArr[i], points_dd, vectorSource_dd);

                var layerLines_dd = new ol.layer.Vector({
                    source: new ol.source.Vector({
                        features: [new ol.Feature({
                            geometry: new ol.geom.LineString(points_dd, 'XY'),
                            name: 'Line'
                        })]
                    }),
                    style: [
                new ol.style.Style({
                            stroke: new ol.style.Stroke({
                                color: "#FFD200",
                                width: pStrokeSettings.width,
                                lineCap: "square"
                            })
                        })
              ]
                });
                map.addLayer(layerLines_dd);
            }
        }

        map.addLayer(startLayer);
        map.addLayer(endLayer);
        map.addLayer(accelLayer);
        map.addLayer(brakeLayer);
        map.addLayer(speedLayer);
        map.addLayer(cornerLayer);

        var extent = layerLines.getSource().getExtent();
        map.getView().fit(extent, map.getSize());

        function addPoints(pA, pPoints, pVs) {
            //create a bunch of icons and add to source vector
            if (pA) {
                for (var i = 0; i < pA.length; i++) {
                    var x = pA[i][1];
                    var y = pA[i][0];

                    var iconFeature = new ol.Feature({
                        geometry: new ol.geom.Point(ol.proj.fromLonLat([x, y], 'EPSG:3857')),
                        name: 'Marker ' + i
                    });
                    pPoints[i] = ol.proj.fromLonLat([x, y], 'EPSG:3857');
                    pVs.addFeature(iconFeature);
                }

                //add the feature vector to the layer vector
                var vectorLayer = new ol.layer.Vector({
                    source: pVs
                });
                return vectorLayer;
            }
        }

        // Create Layers Markers
        function createMarkerLayer(pA, pMrkr, pAnchor, pType) {
            var features = [];

            var markerObj = {
                anchor: pAnchor,
                anchorXUnits: 'fraction',
                anchorYUnits: 'pixels',
                opacity: 0.95,
                scale: 0.6,
                src: pMrkr
            };
            //
            //            if (pType == 'event') {
            //                markerObj.scale = 1
            //            }


            var iconStyle = new ol.style.Style({
                image: new ol.style.Icon((markerObj))
            });

            for (var i = 0; i < pA.length; i++) {
                var iconFeature = new ol.Feature({
                    geometry: new ol.geom.Point(ol.proj.fromLonLat([pA[i][0], pA[i][1]], 'EPSG:3857'))
                });

                iconFeature.setStyle(iconStyle);
                features[i] = iconFeature;
            }

            var vectorSource = new ol.source.Vector({
                features: features
            });

            var vectorLayer = new ol.layer.Vector({
                source: vectorSource
            });

            return vectorLayer;
        }
    }

    // IMPORTANT FUNCTION
    // DO NOT EDIT THIS FUNCTION
    // IF YOU NEED IT TO DO SOMETHING ELSE, CREATE A NEW ONE.
    function init_mapFromPointsArray(pArray, pPoi, pStartMrkr, pEndMrkr, pAccelMrkr, pBrakeMrkr, pSpeedMrkr, pElement) {
        // Tile Layer
        var layerMQ = new ol.layer.Tile({
            source: new ol.source.OSM()
        });

        // Line Layer
        var points = [];
        var vectorSource = new ol.source.Vector({});
        var layerPoints = addPoints(pArray);

        var layerLines = new ol.layer.Vector({
            source: new ol.source.Vector({
                features: [new ol.Feature({
                    geometry: new ol.geom.LineString(points, 'XY'),
                    name: 'Line'
                })]
            }),
            style: [
                new ol.style.Style({
                    stroke: new ol.style.Stroke({
                        color: '#454545',
                        width: 8
                    })
                })
              ]
        });

        // Markers Layer
        var mrkr;
        var startArr = [];
        var endArr = [];
        var accelArr = [];
        var brakeArr = [];
        var speedArr = [];
        var s = 0;
        var e = 0;
        var acc = 0;
        var brk = 0;
        var spd = 0;
        if (pPoi) {
            for (var i = 0; i < pPoi.length; i++) {
                switch (pPoi[i].Type) {
                    case "START":
                    case "start":
                        startArr[s] = [parseFloat(pPoi[i].LN), parseFloat(pPoi[i].LT)];
                        s++;
                        break;

                    case "STOP":
                    case "stop":
                        endArr[e] = [parseFloat(pPoi[i].LN), parseFloat(pPoi[i].LT)];
                        e++;
                        break;

                    case "HAC":
                    case "HAC_STRONG":
                    case "hac":
                    case "hac_strong":
                    case "ac":
                        accelArr[acc] = [parseFloat(pPoi[i].LN), parseFloat(pPoi[i].LT)];
                        acc++;
                        break;

                    case "HBR":
                    case "HBR_STRONG":
                    case "hbr":
                    case "hbr_strong":
                    case "dc":
                        brakeArr[brk] = [parseFloat(pPoi[i].LN), parseFloat(pPoi[i].LT)];
                        brk++;
                        break;

                    case "OSP":
                    case "osp":
                    case "OSP_STRONG":
                        speedArr[spd] = [parseFloat(pPoi[i].LN), parseFloat(pPoi[i].LT)];
                        spd++;
                        break;
                }
            }
        }
        // start layer
        var startLayer = createMarkerLayer(startArr, pStartMrkr, 'startend');

        // end layer
        var endLayer = createMarkerLayer(endArr, pEndMrkr, 'startend');

        // accel layer
        var accelLayer = createMarkerLayer(accelArr, pAccelMrkr, 'fault');

        // brake layer
        var brakeLayer = createMarkerLayer(brakeArr, pBrakeMrkr, 'fault');

        // brake layer
        var speedLayer = createMarkerLayer(speedArr, pSpeedMrkr, 'fault');

        // Map Init

        var element = 'trip-map';
        if (typeof pElement != 'undefined') {
            element = pElement;
        }
        var map = new ol.Map({
            target: element,
            layers: [],
            view: new ol.View({
                center: ol.proj.fromLonLat([pArray[0][1], pArray[0][0]], 'EPSG:3857')
            }),
            controls: []
        });

        map.addLayer(layerMQ);
        map.addLayer(layerLines);
        map.addLayer(startLayer);
        map.addLayer(endLayer);
        map.addLayer(accelLayer);
        map.addLayer(brakeLayer);
        map.addLayer(speedLayer);

        var extent = layerLines.getSource().getExtent();
        map.getView().fit(extent, map.getSize());


        // functions
        function addPoints(pA) {
            //create a bunch of icons and add to source vector
            for (var i = 0; i < pA.length; i++) {
                var x = pA[i][1];
                var y = pA[i][0];

                var iconFeature = new ol.Feature({
                    geometry: new ol.geom.Point(ol.proj.fromLonLat([x, y], 'EPSG:3857')),
                    name: 'Marker ' + i
                });
                points[i] = ol.proj.fromLonLat([x, y], 'EPSG:3857');
                vectorSource.addFeature(iconFeature);
            }

            //add the feature vector to the layer vector
            var vectorLayer = new ol.layer.Vector({
                source: vectorSource
            });
            return vectorLayer;
        }

        // Create Layers Markers
        function createMarkerLayer(pA, pMrkr, pType) {
            var features = [];
            var anchor;
            var scale;
            switch (pType) {
                case "startend":
                    anchor = [0.5, 12];
                    scale = 1;
                    break;

                case "fault":
                    anchor = [0.5, 105];
                    scale = 0.4;
                    break;
            }

            var markerObj = {
                anchor: anchor,
                scale: scale,
                anchorXUnits: 'fraction',
                anchorYUnits: 'pixels',
                opacity: 0.95,
                src: pMrkr
            };


            var iconStyle = new ol.style.Style({
                image: new ol.style.Icon((markerObj))
            });

            for (var i = 0; i < pA.length; i++) {
                var iconFeature = new ol.Feature({
                    geometry: new ol.geom.Point(ol.proj.fromLonLat([pA[i][0], pA[i][1]], 'EPSG:3857'))
                });

                iconFeature.setStyle(iconStyle);
                features[i] = iconFeature;
            }

            var vectorSource = new ol.source.Vector({
                features: features
            });

            var vectorLayer = new ol.layer.Vector({
                source: vectorSource
            });

            return vectorLayer;
        }
    }

    // IMPORTANT FUNCTION
    // THIS IS FOR ERIE APPLICATION
    // THIS MAP FUNCTION HANDLES LINE WITH MULTIPLE COLORS
    function init_mapFromPointsArray_multipleColors(pArray, pStartMrkr, pEndMrkr, pElement, pSegColors, pMileColors) {
        console.log(999, pArray);
        // Tile Layer
        var layerMQ = new ol.layer.Tile({
            source: new ol.source.OSM()
        });

        var layerLinesArr = [];
        for (var a = 0; a < pArray.length; a++) {
            // Line Layer
            var points = [];
            var vectorSource = new ol.source.Vector({});
            addPoints(pArray[a]);
            var color = defineSegColor(pMileColors[a]);

            var layerLines = new ol.layer.Vector({
                source: new ol.source.Vector({
                    features: [new ol.Feature({
                        geometry: new ol.geom.LineString(points, 'XY'),
                        name: 'Line'
                    })]
                }),
                style: [
                new ol.style.Style({
                        stroke: new ol.style.Stroke({
                            color: color,
                            width: 5
                        })
                    })
              ]
            });
            layerLinesArr.push(layerLines);
        }

        // One line to define the length of the trip.
        var lengthPoints = [];
        addStartAndLastPoints(pArray);
        var layerLengthLine = new ol.layer.Vector({
            source: new ol.source.Vector({
                features: [new ol.Feature({
                    geometry: new ol.geom.LineString(lengthPoints, 'XY'),
                    name: 'Line'
                })]
            }),
            style: [
            new ol.style.Style({
                    stroke: new ol.style.Stroke({
                        color: 'rgba(0,0,0,0)',
                        width: 8
                    })
                })
          ]
        });

        // Markers Layer
        var mrkr;
        var startArr = [];
        var endArr = [];
        var s = 0;
        var e = 0;
        if (pStartMrkr) {
            startArr[s] = [parseFloat(pArray[0][0].x1), parseFloat(pArray[0][0].y1)];
        }

        if (pStartMrkr) {
            var arrLen = pArray.length - 1;
            var inArrLen = pArray[arrLen].length - 1;
            endArr[s] = [parseFloat(pArray[arrLen][inArrLen].x2), parseFloat(pArray[arrLen][inArrLen].y2)];
        }

        // start layer
        var startLayer = createMarkerLayer(startArr, pStartMrkr, 'startend');

        // end layer
        var endLayer = createMarkerLayer(endArr, pEndMrkr, 'startend');

        // Map Init

        var element = 'trip-map';
        if (typeof pElement != 'undefined') {
            element = pElement;
        }

        var map = new ol.Map({
            target: element,
            layers: [],
            view: new ol.View({
                center: ol.proj.fromLonLat([pArray[0][1], pArray[0][0]], 'EPSG:3857')
            }),
            controls: []
        });

        map.addLayer(layerMQ);
        map.addLayer(layerLengthLine);

        for (var i = 0; i < layerLinesArr.length; i++) {
            map.addLayer(layerLinesArr[i]);
        }

        map.addLayer(startLayer);
        map.addLayer(endLayer);

        var extent = layerLengthLine.getSource().getExtent();
        map.getView().fit(extent, map.getSize());


        // functions
        function addPoints(pA) {
            //create a bunch of icons and add to source vector
            for (var i = 0; i < pA.length; i++) {
                var x1 = pA[i].x1;
                var y1 = pA[i].y1;

                var x2 = pA[i].x2;
                var y2 = pA[i].y2;

                points[i] = ol.proj.fromLonLat([x1, y1], 'EPSG:3857');
                points[i + 1] = ol.proj.fromLonLat([x2, y2], 'EPSG:3857');
            }
        }

        function addStartAndLastPoints(pA) {
            var al = pA.length - 1;
            var il = pA[al].length - 1;

            var x1 = pA[0][0].x1;
            var y1 = pA[0][0].y1;

            var x2 = pA[al][il].x1;
            var y2 = pA[al][il].y1;

            lengthPoints[0] = ol.proj.fromLonLat([x1, y1], 'EPSG:3857');
            lengthPoints[1] = ol.proj.fromLonLat([x2, y2], 'EPSG:3857');
        }

        // Define the color for each segment
        function defineSegColor(pType) {
            var c = "#000000";
            switch (pType) {
                case pSegColors[0].type:
                    c = pSegColors[0].dark;
                    break;
                case pSegColors[1].type:
                    c = pSegColors[1].dark;
                    break;
                case pSegColors[2].type:
                    c = pSegColors[2].dark;
                    break;
                case pSegColors[3].type:
                    c = pSegColors[3].dark;
                    break;
                case pSegColors[4].type:
                    c = pSegColors[4].dark;
                    break;
            }
            return c;
        }

        // Create Layers Markers
        function createMarkerLayer(pA, pMrkr) {
            var features = [];
            var anchor = [0.5, 110];
            var scale = 0.28;

            var markerObj = {
                anchor: anchor,
                scale: scale,
                anchorXUnits: 'fraction',
                anchorYUnits: 'pixels',
                opacity: 0.8,
                src: pMrkr
            };


            var iconStyle = new ol.style.Style({
                image: new ol.style.Icon((markerObj))
            });

            for (var i = 0; i < pA.length; i++) {
                var iconFeature = new ol.Feature({
                    geometry: new ol.geom.Point(ol.proj.fromLonLat([pA[i][0], pA[i][1]], 'EPSG:3857'))
                });

                iconFeature.setStyle(iconStyle);
                features[i] = iconFeature;
            }

            var vectorSource = new ol.source.Vector({
                features: features
            });

            var vectorLayer = new ol.layer.Vector({
                source: vectorSource
            });

            return vectorLayer;
        }
    }

    function multiPointMap_init(targetID, pArray, pPoi, pIcons) {

        var map = new ol.Map({
            target: targetID,
            layers: [
                new ol.layer.Tile({
                    source: new ol.source.OSM()
                })
            ],
            view: new ol.View({
                center: ol.proj.transform([pPoi[0], pPoi[1]], 'EPSG:4326', 'EPSG:3857'),
                zoom: 12
            })
        });
        for (var pos = 0; pos < pArray.length; pos++) {
            map.addOverlay(new ol.Overlay({
                position: ol.proj.transform(
                    [pArray[pos].lon, pArray[pos].lat],
                    'EPSG:4326',
                    'EPSG:3857'
                ),
                element: $("<img src=" + pIcons.icon + ">")
            }));
        }
        return map;
    }

    function dragEnabledMap_init(targetID, pArray, pPoi, pIcons, getDragCord) {
        var app = {};
        app.Drag = function () {
            ol.interaction.Pointer.call(this, {
                handleDownEvent: app.Drag.prototype.handleDownEvent,
                handleDragEvent: app.Drag.prototype.handleDragEvent,
                handleMoveEvent: app.Drag.prototype.handleMoveEvent,
                handleUpEvent: app.Drag.prototype.handleUpEvent
            });
            this.coordinate_ = null;
            this.cursor_ = 'pointer';
            this.feature_ = null;
            this.previousCursor_ = undefined;
        };

        ol.inherits(app.Drag, ol.interaction.Pointer);

        app.Drag.prototype.handleDownEvent = function (evt) {
            var map = evt.map;
            var feature = map.forEachFeatureAtPixel(evt.pixel,
                function (feature) {
                    return feature;
                });

            if (feature) {
                this.coordinate_ = evt.coordinate;
                this.feature_ = feature;
            }

            return !!feature;
        };

        app.Drag.prototype.handleDragEvent = function (evt) {
            var deltaX = evt.coordinate[0] - this.coordinate_[0];
            var deltaY = evt.coordinate[1] - this.coordinate_[1];

            var geometry = /** @type {ol.geom.SimpleGeometry} */
                (this.feature_.getGeometry());
            geometry.translate(deltaX, deltaY);

            this.coordinate_[0] = evt.coordinate[0];
            this.coordinate_[1] = evt.coordinate[1];
        };

        app.Drag.prototype.handleMoveEvent = function (evt) {
            if (this.cursor_) {
                var map = evt.map;
                var feature = map.forEachFeatureAtPixel(evt.pixel,
                    function (feature) {
                        return feature;
                    });
                var element = evt.map.getTargetElement();
                if (feature) {
                    if (element.style.cursor != this.cursor_) {
                        this.previousCursor_ = element.style.cursor;
                        element.style.cursor = this.cursor_;
                    }
                } else if (this.previousCursor_ !== undefined) {
                    element.style.cursor = this.previousCursor_;
                    this.previousCursor_ = undefined;
                }
            }
        };

        app.Drag.prototype.handleUpEvent = function (evt) {
            this.coordinate_ = null;
            this.feature_ = null;
            return getDragCord(ol.proj.transform(evt.coordinate, 'EPSG:3857', 'EPSG:4326'));
        };

        var pointFeature = new ol.Feature(new ol.geom.Point(ol.proj.transform([pPoi[1], pPoi[0]], 'EPSG:4326', 'EPSG:3857')));

        var map = new ol.Map({
            target: targetID,
            interactions: ol.interaction.defaults().extend([new app.Drag()]),
            layers: [
                new ol.layer.Tile({
                    source: new ol.source.OSM()
                }),
                new ol.layer.Vector({
                    source: new ol.source.Vector({
                        features: [pointFeature]
                    }),
                    style: new ol.style.Style({
                        image: new ol.style.Icon( /** @type {olx.style.IconOptions} */ ({
                            anchor: [0.5, 46],
                            anchorXUnits: 'fraction',
                            anchorYUnits: 'pixels',
                            opacity: 1,
                            src: pIcons.icon
                        }))
                    })
                })
            ],
            view: new ol.View({
                center: ol.proj.transform([pPoi[1], pPoi[0]], 'EPSG:4326', 'EPSG:3857'),
                zoom: 15
            })
        });
    }
    return {
        init_mapFromPointsArray: init_mapFromPointsArray,
        init_mapFromPointsArrayBASEDRIVE: init_mapFromPointsArrayBASEDRIVE,
        multiPointMap_init: multiPointMap_init,
        dragEnabledMap_init: dragEnabledMap_init,
        init_mapFromPointsArray_multipleColors: init_mapFromPointsArray_multipleColors,
        initializeOpenLayerMap: initializeOpenLayerMap
    }
}