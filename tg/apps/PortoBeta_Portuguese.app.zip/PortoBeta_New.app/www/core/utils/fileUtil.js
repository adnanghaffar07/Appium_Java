angular.module('util')
    .factory('FileUtil', FileUtil);

function FileUtil($q, $cordovaFileTransfer, $cordovaFile) {

    function checkIfFileExist(dir, fileName) {
        var q = $q.defer();
        $cordovaFile.checkFile(dir, fileName)
            .then(function (success) {
                q.resolve(success);
            }, function (error) {
                q.reject(error);
            });
        return q.promise;
    }

    function readFile(dir,fileName){
        var q = $q.defer();
        $cordovaFile.readAsText(dir,fileName).then(function(response){
          q.resolve(response);  
        },function(error){
            q.reject(error);
        });
        return q.promise;
    }
    
    function getApplicationDirectory(){
       return  cordova.file.applicationDirectory;
    }
    
    return {
        checkIfFileExist: checkIfFileExist,
        readFile : readFile,
        getApplicationDirectory : getApplicationDirectory
    };
}
