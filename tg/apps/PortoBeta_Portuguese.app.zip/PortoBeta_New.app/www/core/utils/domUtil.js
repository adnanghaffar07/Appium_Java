angular.module('util')
    .service('DOMUtil', DOMUtil)

function DOMUtil($q, $interval, ValidationUtil) {

    var DEFAULT_REFRESH_DELAY = 500;

    this.onElementReady = onElementReady;

    function onElementReady(pDomElementString, pDelay) {
        var q = $q.defer();
        pDelay = ValidationUtil.setDefaultValue(pDelay, DEFAULT_REFRESH_DELAY);
        var stopPromise = $interval(function () {

            if (angular.isDefined($(pDomElementString)[0])) {
                $interval.cancel(stopPromise);
                q.resolve();
            }
        }, pDelay);
        return q.promise;
    }
}