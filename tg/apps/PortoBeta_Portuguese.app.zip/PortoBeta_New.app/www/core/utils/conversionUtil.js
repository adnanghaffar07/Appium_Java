angular.module('util')
    .factory('ConversionUtil', ConversionUtil);

function ConversionUtil(ValidationUtil, AppConfigServices, BooleanConstant, StringUtil) {

    //TODO HGC change the factory to a service
    var mMetric = true;
    var mConfigurationLoaded = false;

    function initConversionSetting() {
        AppConfigServices.getConfigValue("use_metric_system")
            .then(function (pValue) {
                mMetric = (BooleanConstant.TRUE == pValue);
                mConfigurationLoaded = true;
            }, function (pError) {
                mMetric = true; //default true
                mConfigurationLoaded = true;
            });
    }

    /*
        Name : formatPhoneNumber
        Desc : FOrmat phone number to a readable format (999 999-9999)
        @Param : pValue (string)
    */
    function formatPhoneNumber(pValue) {
        if (pValue != null && pValue.indexOf('-') == -1)
            pValue = pValue.toString().replace(/(.{3})/, "$1 ").replace(/(.{7})/, "$1-");
        if (pValue != null && pValue.indexOf('-') != -1 && pValue.indexOf('-') == 3)
            pValue = pValue.toString().replace('-', ' ');
        return pValue;
    }

    return {
        initConversionSetting: initConversionSetting,
        formatPhoneNumber: formatPhoneNumber
    }
}
