angular.module('util')
    .service('ContactsUtil', ContactsUtil);

function ContactsUtil($q, HttpProxy, LoggerUtil, MockFactory, GlobalConstants, WebServiceUrls) {

    this.getAllContacts = getAllContacts;

    var fallbackToMock = false;

    function getAllContacts() {
        var q = $q.defer();

        try {
            var options = new ContactFindOptions();
            options.multiple = true;
            navigator.contacts.find(["id", "name", "emails", "phoneNumbers"], function (response) {
                q.resolve(formatRawContacts(response));
            }, function (error) {
                q.resolve(error);
            }, options);
        } catch (e) {
            LoggerUtil.log("ContactsUtil", e);

            fallbackToMock = true;
            if (fallbackToMock) {
                q.resolve(formatRawContacts(MockFactory.getContacts()));
            } else {
                q.reject(e);
            }
        }
        return q.promise;
    }

    function formatRawContacts(pRawContacts) {
        // Add useful contacts only to returned Data
        var data = [];
        for (var i = 0; i < pRawContacts.length; i++) {
            if (pRawContacts[i].name && pRawContacts[i].name.formatted != '') {
                var mobileFound = false;
                var emailsFound = false;
                if (pRawContacts[i].phoneNumbers != null) {
                    // THERE'S AT LEAST ONE PHONE NUMBER.
                    // FIND IF THERE IS ONE THAT IS 'MOBILE' TYPE
                    for (var j = 0; j < pRawContacts[i].phoneNumbers.length; j++) {
                        if (pRawContacts[i].phoneNumbers[j].type == 'mobile') {
                            mobileFound = true;
                        }
                    }
                }

                if (pRawContacts[i].emails != null) {
                    // THERE IS AT LEAST OPNE EMAIL.
                    emailsFound = true;
                }

                if (mobileFound || emailsFound) {
                    // THERE IS AT LEAST ONE MOBILE PHONE OR ONE EMAIL SO WE ADD THIS CONTACT TO DATA
                    data.push(pRawContacts[i]);
                }
            }
        }
        return data;
    }
}
