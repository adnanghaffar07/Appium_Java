angular.module('util')
    .service('LoadingUtil', LoadingUtil);

function LoadingUtil($rootScope, $state, $ionicLoading, ValidationUtil, ToastTime) {

    this.showLoader = showLoader;
    this.hideLoader = hideLoader;
    this.showToast = showToast;
    this.showDebugLoading = false;

    function showLoader() {

        if (this.showDebugLoading) {
            $rootScope.goToDebug = function () {
                $state.go("debug");
                $ionicLoading.hide();
            }
            $ionicLoading.show({
                /*content: 'Loading',*/
                templateUrl: "./core/templates/debugLoading.html",
                animation: 'fade-in',
                showBackdrop: true,
                maxWidth: 200,
                showDelay: 0
            });
        } else {
            $ionicLoading.show({
                content: 'Loading',
                animation: 'fade-in',
                showBackdrop: true,
                maxWidth: 200,
                showDelay: 0,
                templateUrl: "./client/templates/spinner-loader.html"
            });
        }
    }

    function hideLoader() {
        $ionicLoading.hide();
    }

    function showToast(pText, pDuration) {
        //var DEFAULT_REFRESH_DELAY = 500;
        pDuration = ValidationUtil.setDefaultValue(pDuration, ToastTime.DEFAULT_REFRESH_DELAY);

        $ionicLoading.show({
            template: pText,
            noBackdrop: true,
            duration: pDuration
        });
    }
}
