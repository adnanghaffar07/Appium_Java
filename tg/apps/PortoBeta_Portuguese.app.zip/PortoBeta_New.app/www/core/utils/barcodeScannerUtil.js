angular.module('util')
    .factory('BarcodeScannerUtil', barcodeScannerUtil);

function barcodeScannerUtil($q,$http,$cordovaBarcodeScanner) {
	this.sacnBarCode = sacnBarCode;
	function sacnBarCode(options) {
		var q = $q.defer();
		// if(!options){
		// 	options = {};
		// }
		 cordova.plugins.barcodeScanner.scan(function(barcodeData) {
			q.resolve(barcodeData);
		},function(error){
			q.reject(error);
		});
		return q.promise;
	};
	
	
	return {
		sacnBarCode : sacnBarCode
	};


}