angular.module('util')
    .factory('SocialLoginUtil', SocialLoginUtil);

function SocialLoginUtil(ProfileServices) {

    function processGooglePlusData(data) {
        var birthday;
        var location;
        var gender;
        var language;
        var hasData = false;
        if (angular.isDefined(data.birthday)) {
            birthday = data.birthday;
        }
        if (angular.isDefined(data.placesLived)) {
            var places = data.placesLived;
            for (var i = 0; i < places.length; i++) {
                var place = places[i];
                if (place.primary) {
                    location = place.value;
                }
            }
        }
        if (angular.isDefined(data.gender)) {
            gender = data.gender;
        }

        if (angular.isDefined(data.language)) {
            language = data.language;
        }
        var personalProfile = {

        };
        if (location) {
            hasData = true;
            personalProfile['city_name'] = location;
        }
        if (gender) {
            hasData = true;
            if (gender === 'male') {
                gender = 'M';
            } else if (gender === 'female') {
                gender = 'F';
            }
            personalProfile['gender'] = gender;
        }
        if (hasData) {
            ProfileServices.setPersonalProfile(personalProfile);
        }


    }

    function processFacebookMeta(data) {
        var gender;
        var hasData = false;
        var personalProfile = {};
        var userprofile = {};
        if (data) {
            if (angular.isDefined(data.gender)) {
                gender = data.gender;
            }
            if (gender) {
                hasData = true;
                if (gender === 'male') {
                    gender = 'M';
                } else if (gender === 'female') {
                    gender = 'F';
                }
                personalProfile['gender'] = gender;
            }
            if (data.first_name) {
                hasData = true;
                userprofile['first_name'] = data.first_name;
            }
            if (data.last_name) {
                hasData = true;
                userprofile['last_name'] = data.last_name;
            }
            if (hasData) {
                ProfileServices.setPersonalProfile(personalProfile, userprofile);
            }
        }
    }

    return {
        processGooglePlusData: processGooglePlusData,
        processFacebookMeta: processFacebookMeta
    };

}
