angular.module('util')
    .factory('ScoresUtil', function (PopupUtil, $http, $rootScope, LocalStorage, $timeout) {
        
        var validateServerStatus = function (status, throwPopUp) { // return true if no errors are trap

            if (465 == status) {
                if (throwPopUp) {
                    PopupUtil.showSimpleAlert("~Server Error", "~Password security is not met");
                }
                return false;
            } else if (463 == status) {
                if (throwPopUp) {
                    PopupUtil.showSimpleAlert("~Server Error", "~Display name is already taken");
                }
                return false;
            } else if (464 == status) {
                if (throwPopUp) {
                    PopupUtil.showSimpleAlert("~Server Error", "~Email is already taken");
                }
                return false;
            } else if (200 == status) {
                return true;
            }
            if (throwPopUp) {
                PopupUtil.showSimpleAlert("~Server Error", "~Unknown error");
            }
            return false;
        };

        return {
			validateServerStatus: validateServerStatus
        }

    });