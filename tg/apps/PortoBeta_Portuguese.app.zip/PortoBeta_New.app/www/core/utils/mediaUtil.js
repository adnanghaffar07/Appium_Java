angular.module('util')
    .factory('MediaUtil', MediaUtil);


function MediaUtil($q,$cordovaMedia) {

	function playSound(url) {
		var q = $q.defer();
		var mediaObj = $cordovaMedia.newMedia(url);
        mediaObj.play();
		q.resolve(mediaObj);
	}
	
	return {
		playSound : playSound
	};


}