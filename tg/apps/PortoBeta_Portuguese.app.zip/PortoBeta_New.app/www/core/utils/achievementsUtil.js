angular.module('util')
    .service('AchievementsUtil', AchievementsUtil);

function AchievementsUtil(ProgressValue, LocalStorage, LocalStorageKeys) {

    this.formatAchievementProgress = formatAchievementProgress;
	this.mergeSeenAchievements = mergeSeenAchievements;
    
    var mSeenAchievements = null;
    var mAcknowledgedAchievements = null;
    var mAcknowledgedAchievementsDirty = true;

    function formatAchievementProgress(pData) {

        pData.sort(reverseSort);
        var result = {
            days: [],
            score: []
        };

        var chartDuration = 30;
        var step = 4;
        var d = Date.today().addDays(-chartDuration);
        var labelDay = "";
        var score = -1;
        var item = null;
        var itemIndex = -1;
        for (var i = 0; i < chartDuration; i++) {

            if (i % step == 0) {
                labelDay = d.getDate();
            } else {
                labelDay = "";
            }

            result.days.push(labelDay);
            d.addDays(1);

            score = null;
            itemIndex = pData.length - chartDuration + i;
            item = pData[itemIndex];
            if (item != null) {
                score = item.score;
            }
            result.score.push(score);
        }
        return result;
    }

   
    function mergeSeenAchievements() {
        var changeMade = false;
        mSeenAchievements = LocalStorage.getObject(LocalStorageKeys.SEEN_ACHIEVEMENTS);
        mAcknowledgedAchievements = LocalStorage.getObject(LocalStorageKeys.ACKNOWLEDGED_ACHIEVEMENTS);
        if (mSeenAchievements != null) {
            if (mAcknowledgedAchievements == null) {
                mAcknowledgedAchievements = [];
            }

            var code = null;
            for (var i = 0; i < mSeenAchievements.length; i++) {
                code = mSeenAchievements[i];
                if (mAcknowledgedAchievements.indexOf(code) == -1) {
                    mAcknowledgedAchievements.push(code);
                    changeMade = true;
                }
            }

            mSeenAchievements = null;
            LocalStorage.setObject(LocalStorageKeys.SEEN_ACHIEVEMENTS, null);
            if (changeMade) {
                LocalStorage.setObject(LocalStorageKeys.ACKNOWLEDGED_ACHIEVEMENTS, mAcknowledgedAchievements);
                mAcknowledgedAchievementsDirty = true;
            }
        }
    }
}
   