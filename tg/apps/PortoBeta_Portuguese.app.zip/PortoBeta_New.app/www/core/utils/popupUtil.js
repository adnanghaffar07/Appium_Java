angular.module('util')
    .service('PopupUtil', PopupUtil);

function PopupUtil($ionicPopup, $q, $rootScope, $state, NoNetwork, $translate, $ionicModal, LoadingUtil, ValidationUtil, $timeout, NetworkConnectionUtil, ConnectionConstants) {

    this.showCustomPopup = showCustomPopup;
    this.showCustomPopupLocal = showCustomPopupLocal;
    this.showSimpleAlert = showSimpleAlert;
    this.confirmPopup = confirmPopup;

    function showCustomPopup(pTitle, pTemplateUrl, pButtons, pScope) {
        //Root scope is added to close the pop up on route change and close the pop up on backdrop
        $rootScope.popUp = $ionicPopup.show({
            title: pTitle,
            templateUrl: pTemplateUrl,
            buttons: pButtons,
            scope: pScope
        });
        disableBackDrop();
        return $rootScope.popUp;
    }

    function showCustomPopupLocal(pTitle, pTemplate, pButtons, pScope, pDisableBackDrop) {
        if ($rootScope.networkStatus.isAvailable) {
            pDisableBackDrop = ValidationUtil.setDefaultValue(pDisableBackDrop, true);
            //Root scope is added to close the pop up on route change and close the pop up on backdrop
            $rootScope.popUp = $ionicPopup.show({
                title: pTitle,
                template: pTemplate,
                buttons: pButtons,
                scope: pScope
            });
            if (pDisableBackDrop) {
                disableBackDrop();
            }
            return $rootScope.popUp;
        }
    }


    function showSimpleAlert(pTitle, pText, pButtons, pScope, pDisableBackDrop) {
        if ($rootScope.networkStatus.isAvailable) {
            pDisableBackDrop = ValidationUtil.setDefaultValue(pDisableBackDrop, true);
            var defaultButtons = [{
                text: "<span>" + $translate.instant("common_OK") + "</span>"
            }];
            pButtons = ValidationUtil.setDefaultValue(pButtons, defaultButtons);
            if (pButtons == NoNetwork.NO_NETWORK_OK) {
                defaultButtons = [{
                    text: "<span>" + NoNetwork.NO_NETWORK_OK + "</span>"
                }];
                pButtons = defaultButtons;
            }


            //Root scope is added to close the pop up on route change and close the pop up on backdrop
            $rootScope.popUp = $ionicPopup.show({
                title: pTitle,
                template: pText,
                buttons: pButtons,
                scope: pScope
            });
            if (pDisableBackDrop) {
                disableBackDrop();
            }
            return $rootScope.popUp;
        }
    }

    function disableBackDrop() {
        $('body').removeClass('popup-open');
    }

    function confirmPopup(title, subtitle, callBack, pScope) {
        $ionicPopup.show({
            title: title,
            subTitle: subtitle,
            scope: pScope,
            buttons: [
                {
                    text: '<span>' + $translate.instant('common_CANCEL') + '</span>',
                    onTap: function (e) {
                        return false;
                    }
                },
                {
                    text: '<span>' + $translate.instant('common_OK') + '</span>',
                    onTap: function (e) {
                        return true;
                    }
                },
            ]
        }).then(callBack, function (err) {
            console.log('Err:', err);
        });

    }

}
