angular.module('util')
    .service('ProfileDataUtil', ProfileDataUtil);

function ProfileDataUtil($q, LocalStorage, LocalStorageKeys, ProfileServices, ApplicationMode, StringUtil) {
    this.createProfileData = createProfileData;

    // FOR BASEDRIVE / ERIE AND OTHER BASEDRIVE BASED PROJECTS
    function createProfileData(pRawData) {

        if (!pRawData.User) {
            console.log('some went wrong on User node at ProfileDataUtil');
            return false;
        }

        var profileData = {
            user: {
                id: pRawData.User.id,
                external_id: pRawData.User.external_id,
                first_name: pRawData.User.first_name,
                last_name: pRawData.User.last_name,
                date_of_birth: pRawData.User.date_of_birth,
                email: pRawData.User.email,
                display_name: pRawData.User.display_name,
                facebook_id: pRawData.User.facebook_id,
                address_id: pRawData.User.address_id,
                gender: pRawData.User.gender,
                driver_licence: pRawData.User.driver_licence,
                created_on: pRawData.User.created,
                mobile_phone: pRawData.User.mobile_phone,
                full_name: pRawData.User.name,
                company_id: pRawData.User.company_id,
            },
            cars: pRawData.VehicleProfile,
            Address: pRawData.Address,
            Insurance: pRawData.Insurance
        };

        if(angular.isUndefined(profileData.cars)){
           profileData.cars=[];
        }
        if (angular.isArray(profileData.cars) && angular.isDefined(profileData.cars) && angular.isUndefined(profileData.cars[0])) {
           profileData.cars[0] = { vin: "", year: "", make: "", model: "" };
        }
        if (angular.isObject(profileData.cars) && !angular.isArray(profileData.cars)){
           var vrCars = profileData.cars;
           profileData.cars = [];
           profileData.cars.push(vrCars);
        }
        if (!angular.isObject(profileData.Address) || angular.isUndefined(profileData.Address)) {
           profileData.Address = { street_name: "", appartement: "", city: "", state: "", zip_code: "" };
        }

        LocalStorage.setObject(LocalStorageKeys.PROFILE_DATA, profileData);
    }
}
