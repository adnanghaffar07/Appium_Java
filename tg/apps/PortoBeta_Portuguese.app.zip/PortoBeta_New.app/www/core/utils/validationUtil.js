angular.module('util')
    .service('ValidationUtil', ValidationUtil);

function ValidationUtil(StringUtil, ValidationUtilEnumTest) {
    this.testFunctionalities = testFunctionalities;
    this.validateEmail = validateEmail;
    this.checkPasswordStrength = checkPasswordStrength;
    this.isEmpty = isEmpty;
    this.setDefaultValue = setDefaultValue;
    this.validateEnum = validateEnum;
    this.validatePhoneNumber = validatePhoneNumber;
    this.isValidDate = isValidDate;
    this.validaCPF = validaCPF;
    this.isNormalValidDate = isNormalValidDate;
    
    function testFunctionalities() {
        var className = "ValidationUtil";
        var func;

        //isEmpty
        func = this.isEmpty;
        console.assert(true == func(""), className + " : " + func.name + "('') should return true ");
        console.assert(true == func(0), className + " : " + func.name + "(0) should return true ");
        console.assert(false == func(-1), className + " : " + func.name + "(-1) should return false ");
        console.assert(true == func(null), className + " : " + func.name + "(null) should return true");
        console.assert(true == func('___-___-____'), className + " : " + func.name + "('___-___-____') should return true");
        console.assert(true == func(undefined), className + " : " + func.name + "(undefined) should return empty");
        console.assert(false == func("NOT_EMPTY"), className + " : " + func.name + "('NOT_EMPTY') should return false NOT_EMPTY");
        console.assert(true == func("", "not_empty"), className + " : " + func.name + "('','NOT_EMPTY') should return true ");
        console.assert(true == func("NOT_EMPTY", undefined), className + " : " + func.name + "(NOT_EMPTY',undefined) should return true");
        console.assert(true == func({}), className + " : " + func.name + "({}) should return true");
        console.assert(false == func({
            key: "value"
        }), className + " : " + func.name + "({key:'value'}) should return true");


        //validateEmail
        console.assert(true == this.validateEmail("test@test.ca"), "this.validateEmail('test@test.ca') should return true");
        console.assert(false == this.validateEmail(), "this.validateEmail() should return false");
        console.assert(false == this.validateEmail(""), "this.validateEmail('') should return false");
        console.assert(false == this.validateEmail(null), "this.validateEmail(null) should return false");
        console.assert(false == this.validateEmail(123), "this.validateEmail(123) should return false");
        console.assert(false == this.validateEmail('123'), "this.validateEmail('123') should return false");
        console.assert(false == this.validateEmail('123@'), "this.validateEmail('123@') should return false");
        console.assert(false == this.validateEmail('123@123'), "this.validateEmail('123@123') should return false");
        console.assert(false == this.validateEmail('123@123.'), "this.validateEmail('123@123.') should return false");
        console.assert(false == this.validateEmail('123@123.c'), "this.validateEmail('123@123.c') should return false");
        console.assert(true == this.validateEmail('123@123.ca'), "this.validateEmail('123@123.ca') should return true");
        console.assert(true == this.validateEmail('123+456@123.ca'), "this.validateEmail('123+456@123.ca') should return true");
        console.assert(true == this.validateEmail('123.789@123.ca'), "this.validateEmail('123.789@123.ca') should return true");


        //validateEnum
        console.assert(true == this.validateEnum(ValidationUtilEnumTest, ValidationUtilEnumTest.ENUM1), "This.validateEnum(ValidationUtilEnumTest,ValidationUtilEnumTest.ENUM1) should return true")
        console.assert(false == this.validateEnum(ValidationUtilEnumTest, ValidationUtilEnumTest.ENUM3), "This.validateEnum(ValidationUtilEnumTest,ValidationUtilEnumTest.ENUM3) should return false")
        console.assert(false == this.validateEnum(ValidationUtilEnumTest, undefined), "This.validateEnum(ValidationUtilEnumTest,undefined) should return false");
        console.assert(false == this.validateEnum(ValidationUtilEnumTest, null), "This.validateEnum(ValidationUtilEnumTest,null) should return false");
        console.assert(false == this.validateEnum(ValidationUtilEnumTest, ''), "This.validateEnum(ValidationUtilEnumTest,'') should return false");
        console.assert(true == this.validateEnum(ValidationUtilEnumTest, ValidationUtilEnumTest.ENUM2), "This.validateEnum(ValidationUtilEnumTest,ValidationUtilEnumTest.ENUM2) should return true")

    }

    function validateEmail(pEmail) {
        if (!pEmail) {
            return false;
        }
        var re = /^[a-zA-Z0-9_\!#$%^&*()+-]+(\.[a-zA-Z0-9_\!#$%^&*()+-]+)*@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.([a-zA-Z]{2,4})$/;
        return (re.test(pEmail));
    }

    function validateEnum(pConstantObj, pKey) {
        for (var key in pConstantObj) {
            if (pConstantObj[key] == pKey) {
                return true;
            }
        }
        console.error("Unable to find a match for the contant ", pConstantObj, " with the key ", pKey);
        return false;
    }

    function checkPasswordStrength(pPassword) {
        if (!pPassword) {
            return false;
        }
        //  var re = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$/;
        var re = /^((?=.*\d)(?=.*[A-Z])(?=.*[a-z]).{8,})$/;
        //var re = /^[a-zA-Z0-9_\!#$%^&*()+-]+(\.[a-zA-Z0-9_\!#$%^&*()+-]+)*@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.([a-zA-Z]{2,4})$/;
        return (re.test(pPassword));
    }

    function isEmpty() {
        var field;
        for (var i = 0; i < arguments.length; ++i) {
            field = arguments[i];
            if (field == "" ||
                field == 0 ||
                field == null ||
                field == '___-___-____' ||
                (angular.isObject(field) && isEmptyObject(field))) {
                return true;
            }
        }
        return false;
    }

    function isEmptyObject(ob) {
        for (var i in ob) {
            return false;
        }
        return true;
    }

    function setDefaultValue(pField, pDefaultValue) {
        if (angular.isUndefined(pField) || pField === 'undefined') {
            pField = pDefaultValue;
        }
        return pField;
    }

    /*
        Name : validatePhoneNumber
        Desc : Validate a string to make sure it fits the requirements for a phone number
        @Params : pPhone
        @Requirements : length of 10. Only digits.
    */
    function validatePhoneNumber(pPhone) {
        var isValid = true;
        // Validate it is only digits        
        console.log(111, /^[\d+]+$/.test(pPhone), pPhone);
        if (!/^[\d+]+$/.test(pPhone)) {
            console.log("test");
            isValid = false;
        } else {
            console.log(pPhone.length);
            if (pPhone.length > 12) {
                isValid = false;
            }
        }

        return isValid;
    }

    function isValidDate(dateString, mask) {

        // validate if is valid date
        if (!moment(dateString, mask, true).isValid()) {
          return false;
        }

        var date = new Date(dateString);

        var age = - (moment(date).diff(moment(), 'years'));

        // too old
        if (age > 140) {
          return false;
        }

        // too young
        if (age < 15) {
          return false;
        }

        return true;
    }

    function isNormalValidDate(dateString, mask) {

        // validate if is valid date
        if (!moment(dateString, mask, true).isValid()) {
          return false;
        }

        return true;
    }

    function validaCPF(_cpf) {

        if(_cpf === undefined) {
            return false;
        }

        var cpf = _cpf.replace(/[^\d]+/g,'');

        var numbers, digits, sum, i, result, iguals_digits;

        iguals_digits = 1;

        if (cpf.length < 11){
          return false;
        }

        for (i = 0; i < cpf.length - 1; i++) {
          if (cpf.charAt(i) != cpf.charAt(i + 1)) {
              iguals_digits = 0;
              break;
          }
        }

        if (!iguals_digits) {
            numbers = cpf.substring(0,9);
            digits = cpf.substring(9);
            sum = 0;
            for (i = 10; i > 1; i--) {
                  sum += numbers.charAt(10 - i) * i;
            }
            result = sum % 11 < 2 ? 0 : 11 - sum % 11;
            if (result != digits.charAt(0)) {
              return false;
            }
            numbers = cpf.substring(0,10);
            sum = 0;
            for (i = 11; i > 1; i--) {
                  sum += numbers.charAt(11 - i) * i;
            }
            result = sum % 11 < 2 ? 0 : 11 - sum % 11;
            if (result != digits.charAt(1)) {
              return false;
            }
            return true;
        } else {
          return false;
        }
    }
}
