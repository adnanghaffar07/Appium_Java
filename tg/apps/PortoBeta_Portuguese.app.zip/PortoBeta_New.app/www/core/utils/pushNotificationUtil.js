angular.module('util')
    .service('PushNotificationUtil', PushNotificationUtil);

function PushNotificationUtil($cordovaPush,$state, $rootScope, LocalStorage,ListenerUtil, PopupUtil, LocalStorageKeys, ClientSettings, $q, $translate, NotificationTypes, PushConstants, $timeout) {


    function register() {
        var q = $q.defer();
        try {
            document.addEventListener("deviceready", function () {
                $rootScope.push = PushNotification.init({
                    "android": {
                        "senderID": PushConstants.SENDER_ID,
                        "forceShow": true,
                        "payload":{
                            "content-available": "1"
                        }
                    },
                    "IOS": {
                        "badge": true,
                        "sound": true,
                        "alert": false
                    }
                });

                $rootScope.push.on('registration', function (data) {
                    var id = data.registrationId;
                    q.resolve(id);
                });

                $rootScope.push.on('notification', function (data) {
                    $rootScope.contestNotificationActive = true;
                    $rootScope.contest = data;
                    $rootScope.$apply();
                    // $timeout(function () {
                    //     $rootScope.contestNotificationActive = false;
                    // },5000);
                    //redirectToScreen(data);
                   if (isForground && ionic.Platform.isIOS()) {
                       redirectToScreen(data);
                    }
                });


                $rootScope.push.on('error', function (e) {
                    console.log(e);
                });

            }, false); 
           
            //q.resolve(push);

          
        } catch (e) {
            q.reject(e);
        }
        return q.promise;
    }

    function unregister() {
        var q = $q.defer();
        if ($rootScope.push) {
            $rootScope.push.unregister(function (success) {
                q.resolve(success);
            }, function (error) {
                q.reject(error);
            });
        } else {
            q.reject("NULL REFERENCE");
        }
        return q.promise;
    }
    
    function redirectToScreen(data){
        var message = data.message;
                    var title = data.title;
                    //alert('Notification on click');
                    var icon = "file://client/img/tracking_blue.png";
                    var additionalData = data.additionalData;
                    //var notificationType = 1;
                    console.log(JSON.stringify(data));
                    var isForground = additionalData.foreground;
                    var contestID=additionalData.contestId;
                    if (additionalData) {
						//     if(isForground &&ionic.Platform.isIOS()){
                        //  PopupUtil.showSimpleAlert(title, message);
                        // } else{
                         notificationType = parseInt(additionalData.notificationType);
                        if (notificationType && !isNaN(notificationType)) {
                            switch (notificationType) {
                                case NotificationTypes.NEW_CONTEST:
                                    ListenerUtil.playEvent('CONTEST_NOTIFICATION', {
                                        contestID: contestID
                                    });
                                  //  $state.go();
                                    break;
                                case NotificationTypes.CONTEST_WON:
                                    ListenerUtil.playEvent('CONTEST_WON', {
                                        contestID: contestID
                                    });
                                    break;
                                case NotificationTypes.CONTEST_INFO:
                                    ListenerUtil.playEvent('CONTEST_NOTIFICATION', {
                                        contestID: contestID
                                    });
                                    break;
                                case NotificationTypes.ACHIVEMENT_WON:
                                    ListenerUtil.playEvent('ACHIVEMENT_WON', {

                                    });
                                    break;
                                case NotificationTypes.BADGE_WON:
                                 var achievement ={"id":additionalData.ids[0]};
                                    ListenerUtil.playEvent('BADGE_WON',{'achievement': achievement
                                        
                                    });
                                   // ListenerUtil.playEvent('BADGES_RELOAD',{});
                                    break;
                                case NotificationTypes.CUSTOM_MESSAGE:
                                    title = $translate.instant('Notification');
                                    // "achievements":{"badges":2,"achievements":0,"others":0}
                                    message = $translate.instant('Notification');
                                    if (data.title) {
                                        message = data.title;
                                    }
                                    break;
                            }
                        }
						//}
                    }
    }

    return {
        register: register,
        unregister: unregister,
        redirectToScreen:redirectToScreen
    };

}
