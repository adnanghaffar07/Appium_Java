angular.module('util')
    .service('ExternalInteractionUtil', ExternalInteractionUtil);

function ExternalInteractionUtil(CordovaBroadcaster) {

    this.openMail = openMail;
    this.composePhoneNumber = composePhoneNumber;
    this.openWebSite = openWebSite;
    function openMail(pTo, pSubject, pBody) {
        CordovaBroadcaster.openMail(pTo, pSubject, pBody);
    }

    function composePhoneNumber(pPhoneNumber) {
        //TODO CATCH different format and send it back as a int
        CordovaBroadcaster.composePhoneNumber(pPhoneNumber);
    }
    
    function openWebSite(pUrl) {
        CordovaBroadcaster.openWebSite(pUrl);
    }
}
