angular.module('util')
    .factory('CircleProgressUtil', CircleProgressUtil);

function CircleProgressUtil() {
    function init_DefaultCircle(pE, pV, pS, pC, pT) {
        $(pE).circleProgress({
            value: pV / 100,
            size: pS,
            startAngle: Math.PI * 1.499,
            fill: {
                color: pC
            },
            thickness: pT
        });
    }

    var _originalInitFill = $.circleProgress.defaults.initFill;
    $.circleProgress.defaults.initFill = function () {
        _originalInitFill.apply(this, arguments);
        if (this.fill.sectors) {
            var s = this.size,
                r = s / 2,
                sa = this.startAngle;
            var bg = $('<canvas>')[0];
            bg.width = s;
            bg.height = s;
            var lastValue = 0,
                ctx = bg.getContext('2d');
            for (var i = 0; i < this.fill.sectors.length; i++) {
                var sector = this.fill.sectors[i],
                    currentColor = sector[0],
                    currentValue = sector[1];
                ctx.beginPath();
                ctx.moveTo(r, r);
                ctx.arc(r, r, r, sa + 2 * lastValue * Math.PI, sa + 2 * currentValue * Math.PI);
                ctx.moveTo(r, r);
                ctx.fillStyle = currentColor;
                ctx.fill();
                lastValue = currentValue;
            }
            this.arcFill = this.ctx.createPattern(bg, 'no-repeat');
        }
    };


    function init_MultiColoredCircle(pE, pV, pS, pC, pT) {
        $(pE).circleProgress({
            value: 1,
            size: pS,
            startAngle: Math.PI * 1.499,
            fill: {
                sectors: [
                    [pC[0].color, 0.2],
                    [pC[1].color, 0.4],
                    [pC[2].color, 0.5],
                    [pC[3].color, 0.8],
                    [pC[4].color, 1.0]
                ]
                    //                sectors: [
                    //                    [pC[0].color, pC[0].value],
                    //                    [pC[1].color, pC[1].value],
                    //                    [pC[2].color, pC[2].value],
                    //                    [pC[3].color, pC[3].value],
                    //                    [pC[4].color, pC[4].value]
                    //                ]
            },
            animation: {
                duration: 1000
            },
            thickness: pT
        });
    }

    return {
        init_DefaultCircle: init_DefaultCircle
    }
}
