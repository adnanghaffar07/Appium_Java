angular.module('util')
    .factory('CameraUtil', cameraUtil);

function cameraUtil($q) {
    if (typeof Camera != "undefined") {
        var defaultOptions = {
            quality: 50,
            destinationType: Camera.DestinationType.DATA_URL,
            allowEdit: false,
            correctOrientation: true,
            targetWidth: 300,
            targetHeight: 300
        };
    }

    function takePicture(options) {
        var q = $q.defer();
        if (angular.isUndefined(options)) {
            options = {};
        }
        options['sourceType'] = navigator.camera.PictureSourceType.CAMERA;
        corePicture(options).then(function (url) {
            q.resolve(url);
        }, function (error) {
            q.reject(error);
        });
        return q.promise;
    };

    function getPicture(options) {
        var q = $q.defer();
        if (angular.isUndefined(options)) {
            options = {};
        }
        options['sourceType'] = navigator.camera.PictureSourceType.PHOTOLIBRARY;
        corePicture(options).then(function (url) {
            q.resolve(url);
        }, function (error) {
            q.reject(error);
        });
        return q.promise;
    };

    function corePicture(options) {
        var q = $q.defer();
        angular.extend(options, defaultOptions);
        if (navigator.camera) {
            navigator.camera.getPicture(function (url) {
                q.resolve(url);
            }, function (message) {
                q.reject(message);
            }, options);
        } else {
            q.reject("Camera plugin not installed or Runinng in browser");
        }
        return q.promise;
    }

    return {
        takePicture: takePicture,
        getPicture: getPicture
    };


}
