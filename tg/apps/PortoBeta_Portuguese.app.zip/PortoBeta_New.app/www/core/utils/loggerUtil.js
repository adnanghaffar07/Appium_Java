angular.module('util')
    .service('LoggerUtil', LoggerUtil);

function LoggerUtil(LoggerUtilType, StringUtil) {

    this.testFunctionalities = testFunctionalities;
    this.log = log;
    this.logSilent = logSilent;
    this.warn = warn;
    this.error = error;
    this.getLogs = getLogs;
    this.clearLogs = clearLogs;

    var mLogs = [{
        type: "META-DATA",
        data: "LOG_START",
        tag: null
    }];

    function testFunctionalities() {
        var className = "LoggerUtil";
        var func;

        //log
        func = this.log;
        func("TAG", "log1");
        console.assert(this.getLogs(LoggerUtilType.LOG).indexOf("log1") != -1,
            StringUtil.format("{0} : {1}('log1') should return 'log1'", className, func.name));

        func("TAG", "log2", "log3");
        console.assert(this.getLogs(LoggerUtilType.LOG).indexOf('log2 log3') != -1, StringUtil.format("{0} : {1}('log2','log3') should return 'log2 log3'", className, func.name));

        //warn
        func = this.warn;
        func("TAG", "warn1");
        console.assert(this.getLogs(LoggerUtilType.WARN).indexOf("warn1") != -1, StringUtil.format("{0} : {1}('warn1') should return 'warn1'", className, func.name));

        func("TAG", "warn2", "warn3");
        console.assert(this.getLogs(LoggerUtilType.WARN).indexOf('warn2 warn3') != -1, StringUtil.format("{0} : {1}('warn2','warn3') should return 'warn2 warn3'", className, func.name));

        //error
        func = this.error;
        func("TAG", "error1");
        console.assert(this.getLogs(LoggerUtilType.ERROR).indexOf("error1") != -1, StringUtil.format("{0} : {1}('error1') should return 'error1'", className, func.name));

        func("TAG", "error2", "error3");
        console.assert(this.getLogs(LoggerUtilType.ERROR).indexOf('error2 error3') != -1, StringUtil.format("{0} : {1}('error2','error3') should return 'error2 error3'", className, func.name));

        //clearLogs
        func = clearLogs;
        log("TAG", "log1");
        console.assert(this.getLogs(LoggerUtilType.LOG).indexOf("log1") != -1, StringUtil.format("{0} : {1}('log1') should return 'log1'", className, func.name));
        func();
        console.assert(this.getLogs(LoggerUtilType.LOG).indexOf("log1") == -1, StringUtil.format("{0} : {1}() : 'log1' should not be found after a clearLogs", className, func.name));
    }

    function displayLogWithArguments(pTag, pArguments) {
        if (pArguments.length == 2) {
            console.log(pTag, pArguments[1]);
        } else if (pArguments.length == 3) {
            console.log(pTag, pArguments[1], pArguments[2]);
        } else if (pArguments.length == 4) {
            console.log(pTag, pArguments[1], pArguments[2], pArguments[3]);
        } else if (pArguments.length == 5) {
            console.log(pTag, pArguments[1], pArguments[2], pArguments[3], pArguments[4]);
        }
    }

    function displayWarnWithArguments(pTag, pArguments) {
        if (pArguments.length == 2) {
            console.warn(pTag, pArguments[1]);
        } else if (pArguments.length == 3) {
            console.warn(pTag, pArguments[1], pArguments[2]);
        } else if (pArguments.length == 4) {
            console.warn(pTag, pArguments[1], pArguments[2], pArguments[3]);
        } else if (pArguments.length == 5) {
            console.warn(pTag, pArguments[1], pArguments[2], pArguments[3], pArguments[4]);
        }
    }

    function displayErrorWithArguments(pTag, pArguments) {
        if (pArguments.length == 2) {
            console.error(pTag, pArguments[1]);
        } else if (pArguments.length == 3) {
            console.error(pTag, pArguments[1], pArguments[2]);
        } else if (pArguments.length == 4) {
            console.error(pTag, pArguments[1], pArguments[2], pArguments[3]);
        } else if (pArguments.length == 5) {
            console.error(pTag, pArguments[1], pArguments[2], pArguments[3], pArguments[4]);
        }
    }

    function log(pTag, etc) {
        var text = getArgumentText(arguments);
        innerLog(LoggerUtilType.LOG, pTag, text);
        displayLogWithArguments(pTag, arguments);
    }

    function logSilent(pTag, etc) {
        var text = getArgumentText(arguments);
        innerLog(LoggerUtilType.LOG, pTag, text);
    }

    function warn(pTag, etc) {
        var text = getArgumentText(arguments);
        innerLog(LoggerUtilType.WARN, pTag, text);
        displayWarnWithArguments(pTag, arguments);
    }

    function error(pTag, etc) {
        var text = getArgumentText(arguments);
        innerLog(LoggerUtilType.ERROR, pTag, text);
        displayErrorWithArguments(pTag, arguments);
    }

    function getArgumentText(pArguments) {
        var text = "";
        var args = (pArguments.length === 1 ? [pArguments[0]] : Array.apply(null, pArguments));
        for (var i = 1; i < args.length; ++i) {
            if (i != 1) {
                text += " ";
            }
            if (args[i] instanceof(Error)) {
                text += args[i].message;
            } else if (angular.isObject(args[i])) {
                if (args[i].dontLogOnLoggerUtil) {
                    args[i].data = "HIDE DATA BECAUSE IT'S TOO LARGE";
                }
                text += JSON.stringify(args[i]);
            } else {
                text += args[i];
            }
        }
        return text;
    }

    function innerLog(pType, pTag, pText) {
        mLogs.push({
            type: pType,
            data: pText,
            tag: pTag
        });
    }

    function clearLogs() {
        mLogs = [];
    }

    function getLogs(pType, pTag) {
        var result = "";
        var item = "";
        for (var i = 0; i < mLogs.length; i++) {
            item = mLogs[i];
            if ((angular.isUndefined(pType) && angular.isUndefined(pTag)) || (pType == item.type && angular.isUndefined(pTag)) || (angular.isUndefined(pType) && pTag == item.tag) || (pType == item.type && pTag == item.tag)) {
                if (i != 0) {
                    result += "\n"
                }
                result += item.tag + " " + item.data;
            }
        }
        return result;
    }
}
