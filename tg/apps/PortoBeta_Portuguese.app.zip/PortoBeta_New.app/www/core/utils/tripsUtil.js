angular.module('util')
    .service('TripsUtil', TripsUtil);

function TripsUtil($rootScope, LocalStorage, TripDefaultValues, DateUtil, StringUtil, $translate, ValidationUtil) {

    this.getDateFormatDailyScores = getDateFormatDailyScores;
    this.getMonthStartEndDates = getMonthStartEndDates;

    function getDateFormatDailyScores(year, month, date) {
        var vrMonth = month > 9 ? month : "0" + month;
        var vrDate = date > 9 ? date : "0" + date;
        return year + "-" + vrMonth + "-" + vrDate;
    }
    function getMonthStartEndDates() {
        var vrCurDate = new Date();
        var vrCurYear = vrCurDate.getFullYear();
        var vrCurMonth = vrCurDate.getMonth();
        var vrCurMonthFirstDay = new Date(vrCurYear, vrCurMonth, 1);

        var vrMonthFirstDay = vrCurMonthFirstDay.getDate();
        var vrCurDay = vrCurDate.getDate();
        vrCurMonth = vrCurMonth + 1;
        vrCurMonth = vrCurMonth > 9 ? vrCurMonth : "0" + vrCurMonth;
        vrMonthFirstDay = vrMonthFirstDay > 9 ? vrMonthFirstDay : "0" + vrMonthFirstDay;
        vrCurDay = vrCurDay > 9 ? vrCurDay : "0" + vrCurDay;
        var vrStartDate = vrCurYear + "-" + vrCurMonth + "-" + vrMonthFirstDay;
        var vrEndDate = vrCurYear + "-" + vrCurMonth + "-" + vrCurDay;
        return {
            StartDate: vrStartDate,
            EndDate: vrEndDate
        };
    }
}
