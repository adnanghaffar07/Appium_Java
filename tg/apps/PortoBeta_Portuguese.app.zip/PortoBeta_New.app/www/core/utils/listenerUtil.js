angular.module('util')
    .service('ListenerUtil', ListenerUtil);

function ListenerUtil(LoggerUtil, StringUtil, ValidationUtil) {

    this.testFunctionalities = testFunctionalities;
    this.registerListener = registerListener;
    this.removeListener = removeListener;
    this.removeAllListener = removeAllListener;
    this.playEvent = playEvent;

    const TAG = "ListenerUtil";
    var mListeners = {};

    //    var template = {
    //        "EVENT_A": {
    //            "a": "function()",
    //            "b": "function()",
    //            "unnamedListeners":[]  
    //        },
    //        "EVENT_B": {
    //            "c": "function()",
    //            "d": "function()",
    //            "e": "function()",
    //            "unnamedListeners":[]
    //        }
    //    };


    function testFunctionalities() {
        //TODO HGC create unit Test
    }

    function registerListener(pEventName, pListenerName, pCallbackFunction) {
        if (ValidationUtil.isEmpty(pEventName)) {
            console.warn("pEventName is empty");
        } else if (ValidationUtil.isEmpty(pCallbackFunction)) {
            console.warn("pCallbackFunction is empty");
        } else {

            var eventContainer = mListeners[pEventName];
            if (eventContainer == null) {
                eventContainer = {};
                eventContainer.unnamedListeners = [];
                mListeners[pEventName] = eventContainer;
            }
            var listener = eventContainer[pListenerName];
            if (listener == null) {
                listener = pCallbackFunction;
                if (ValidationUtil.isEmpty(pListenerName)) {
                    eventContainer.unnamedListeners.push(listener);
                } else {
                    eventContainer[pListenerName] = listener;
                }
            } else {
                console.warn("already defined event listener");
            }
            LoggerUtil.log(TAG, StringUtil.format("{0} event registered for the {1} method", pEventName, pCallbackFunction.name));
        }
    }

    function removeListener(pEventName, pListenerName) {
        if (ValidationUtil.isEmpty(pEventName)) {
            console.warn("pEventName is empty");
        } else if (ValidationUtil.isEmpty(pListenerName)) {
            console.warn("pListenerName is empty");
        } else {
            var eventListenerContainer = mListeners[pEventName];
            if (ValidationUtil.isEmpty(eventListenerContainer)) {
                console.warn("Unknown event name");
            } else {
                var listener = eventListenerContainer[pListenerName];
                if (ValidationUtil.isEmpty(listener)) {
                    console.warn("Unknown listener ", pListenerName, " for the event ", pEventName);
                } else {
                    delete mListeners[pEventName][pListenerName];
                    return true;
                }
            }
        }
        return false;
    }

    function removeAllListener(pEventName) {
        if (ValidationUtil.isEmpty(pEventName)) {
            console.warn("pEventName is empty");
        } else {
            delete mListeners[pEventName];
        }
    }

    function playEvent(pEventName, pExtras, pSilent) {
        pSilent = ValidationUtil.setDefaultValue(pSilent, false);
        var count = 0;
        var v = mListeners[pEventName];
        if (!ValidationUtil.isEmpty(v)) {
            Object.keys(v).forEach(function (key) {
                var callback = v[key];
                if (key != "unnamedListeners") {
                    if (ValidationUtil.isEmpty(callback)) {
                        console.warn("Unknown listener for event", pEventName);
                    } else {
                        if (!pSilent) {
                            LoggerUtil.log(TAG, StringUtil.format("Dispatch event :{0} extras : {1} to {2}", pEventName, JSON.stringify(pExtras), callback.name));
                        }
                        callback(pExtras);
                    }
                } else {
                    var f = null;
                    for (var i = 0; i < v.unnamedListeners.length; i++) {
                        f = v.unnamedListeners[i];
                        if (!ValidationUtil.isEmpty(f)) {
                            if (!pSilent) {
                                LoggerUtil.log(TAG, StringUtil.format("Dispatch event :{0} extras : {1} to {2}", pEventName, JSON.stringify(pExtras), f.name));
                            }
                            f(pExtras);
                            count++;
                        }
                    }
                }
            });
        }
        if (count == 0 && !pSilent) {
            LoggerUtil.log(TAG, StringUtil.format("Dispatch event :{0} extras : {1} to 0 listener(s)", pEventName, JSON.stringify(pExtras)));
        }
    }


}
