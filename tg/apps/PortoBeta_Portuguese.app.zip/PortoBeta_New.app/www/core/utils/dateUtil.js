angular.module('util')
    .service('DateUtil', DateUtil);

function DateUtil($translate, $q, ValidationUtil, StringUtil, PopupUtil, ESTTimeZone, TripDefaultValues, DateValues) {
    this.getOneMonth_small = getOneMonth_small;
    this.convertRecentDate = convertRecentDate;
    this.formatDateAsUTC = formatDateAsUTC;
    this.getDateFromNewDate = getDateFromNewDate;
    this.getDateDiff = getDateDiff;
    this.convertToEST = convertToEST;
    this.eriedateformat = eriedateformat;
    this.ertripdateformat = ertripdateformat;
    this.erieInsurancedateformat = erieInsurancedateformat;
    this.convertDateTimeToTime = convertDateTimeToTime;
    this.getUtcDate = getUtcDate;
    this.getNoOfDaysInMonth = getNoOfDaysInMonth;
    this.getFormDateFmt = getFormDateFmt;
    this.getLocalTimeFromUtc = getLocalTimeFromUtc;
    var monthsSmall = DateValues.MONTHS;

    var initialize = false;
    var initializing = false;

    function formatDateAsUTC(pDate) {
        if (!ValidationUtil.isEmpty(pDate) && pDate.indexOf("UTC") == -1) { // not empty and doesn't have a UTC
            pDate = pDate.replace("T", " ");
            pDate = pDate.replace("Z", " ");

            pDate = pDate + " UTC";
        }
        return pDate;

    }


    function getOneMonth_small(pI) {
        return $translate.instant(monthsSmall[pI]);
    }

    function convertRecentDate(pDate) {
        var today = Date.today();
        var yesterday = Date.today().add(-1).days();
        var current = Date.parse(pDate);
        var vrcurrdate = new Date();
        var firstdayweek = vrcurrdate.getDate() - vrcurrdate.getDay();
        var firstdayweekdate = new Date(vrcurrdate.setDate(firstdayweek));
        if (Date.parse(current).toString("yyyy-MM-dd") === Date.parse(today).toString("yyyy-MM-dd")) {
            current = $translate.instant('lblDay_Today');
        } else if (Date.parse(current).toString("yyyy-MM-dd") === Date.parse(yesterday).toString("yyyy-MM-dd")) {
            current = $translate.instant('lblDay_Yesterday');
        } else if (Date.parse(firstdayweekdate).toString("yyyy-MM-dd") > Date.parse(current).toString("yyyy-MM-dd")) {
            var months = [$translate.instant("lblMonth_Small_January"),
                             $translate.instant("lblMonth_Small_February"),
                             $translate.instant("lblMonth_Small_March"),
                             $translate.instant("lblMonth_Small_April"),
                             $translate.instant("lblMonth_Small_May"),
                             $translate.instant("lblMonth_Small_June"),
                             $translate.instant("lblMonth_Small_July"),
                             $translate.instant("lblMonth_Small_August"),
                             $translate.instant("lblMonth_Small_September"),
                             $translate.instant("lblMonth_Small_October"),
                             $translate.instant("lblMonth_Small_November"),
                             $translate.instant("lblMonth_Small_December")];

            current = moment(current).format('D') + ' ' + months[current.getMonth()] + ' ' + Date.parse(current).toString("yyyy");

            //current = Date.parse(current).toString("dd MMM");
        } else {
            var days = [$translate.instant("lblWeekFull_Sunday"),
                         $translate.instant("lblWeekFull_Monday"),
                         $translate.instant("lblWeekFull_Tuesday"),
                         $translate.instant("lblWeekFull_Wednesday"),
                         $translate.instant("lblWeekFull_Thursday"),
                         $translate.instant("lblWeekFull_Friday"),
                         $translate.instant("lblWeekFull_Saturday")];

            current = days[current.getDay()];
        }
        return current;
    }

    function getDaySuffix(daysuffix) {
        var vrDaySuffix = "";
        if (daysuffix <= 3) {
            vrDaySuffix = DateValues.DAYS_SUFFIX[daysuffix - 1];
        } else {
            vrDaySuffix = DateValues.DAYS_SUFFIX[3];
        }

        return $translate.instant(vrDaySuffix);

    }

    function getDateFromNewDate(vrDate) {
        //To return date in particular format by considering date after converting to new date
        var vrYear = vrDate.getFullYear();
        var vrMonth = vrDate.getMonth();
        var vrDay = vrDate.getDate();
        var dateArr = [vrMonth + 1, vrDay];
        for (var i = 0; i < dateArr.length; i++) {
            if (dateArr[i] < 10) {
                dateArr[i] = '0' + dateArr[i];
            }
        }
        // var vrHours = vrDate.getHours();
        //var vrMinutes=vrDate.getMinutes();
        //var vrSeconds=vrDate.getMinutes();

        return vrYear + '-' + dateArr[0] + '-' + dateArr[1];

    }

    function getDateDiff(pThen) {
        var now = moment();
        var diff = moment.duration(now.diff(pThen)).asDays();
        return Math.round(diff) + 1;
    }

    function returnValidDate() {
        var template = '<p>' + $translate.instant('error_bellow_16') + '</p>';

        PopupUtil.showSimpleAlert('', template);
    }

    function convertToEST(date) {
        if (date) {

            date = StringUtil.getdateinformat(date);
            date = formatDateAsUTC(date);


            var giveTimeInLocalMiliSec = new Date(date).getTime();
            var estOffSetMiliSec = 300 * 60 * 1000;
            var localoffsetMiliSec = new Date().getTimezoneOffset() * 60 * 1000;
            var convertEstMiliSec = giveTimeInLocalMiliSec - estOffSetMiliSec + (localoffsetMiliSec);
            var newEstFormatDate = new Date(convertEstMiliSec);
            return newEstFormatDate;
        }
    }

    //    function convertToEST(date) {
    //        date = StringUtil.getdateinformat(date);
    //        var offsetHours = ESTTimeZone.OffsetHours;
    //        var offsetMinutes = ESTTimeZone.OffsetMinutes;
    //        var d = new Date(date);
    //        var d2 = new Date(date);
    //        d2.setHours(d.getHours() - offsetHours);
    //        d2.setMinutes(d.getMinutes() - offsetMinutes);
    //        var res = new Date(d2);
    //        return res.toString("yyyy-MM-dd HH:mm:ss");
    //    }

    function eriedateformat() {
        var todaydate = new Date();

        var vrgetday = todaydate.getDate();
        if (vrgetday < 10) {
            vrgetday = "0" + vrgetday;
        }
        var vrgetweekday = todaydate.getDay();
        vrgetweekday = $translate.instant(TripDefaultValues.WEEK_HEADERS_DETAIL[vrgetweekday]);
        var vrgetmonth = todaydate.getMonth();
        vrgetmonth = TripDefaultValues.MONTHS_HEADERS_DETAIL[vrgetmonth];
        vrgetmonth = $translate.instant(vrgetmonth);
        var vrgetyear = todaydate.getFullYear();
        return vrgetweekday + " " + vrgetmonth + " " + vrgetday + ", " + vrgetyear;
    }

    function erieInsurancedateformat(t, s) {
        var s = s.split(' ')[0];
        var dn = s.split('-')[2];
        var mn = s.split('-')[1];
        var y = s.split('-')[0];
        var m;
        var months = [];
        var month;

        if (t == 'full') {
            months = ['lblMonth_Full_January', 'lblMonth_Full_February', 'lblMonth_Full_March', 'lblMonth_Full_April', 'lblMonth_Full_May', 'lblMonth_Full_June', 'lblMonth_Full_July', 'lblMonth_Full_August', 'lblMonth_Full_September', 'lblMonth_Full_October', 'lblMonth_Full_November', 'lblMonth_Full_December'];
        } else {
            months = ['lblMonth_Small_January', 'lblMonth_Small_February', 'lblMonth_Small_March', 'lblMonth_Small_April', 'lblMonth_Small_May', 'lblMonth_Small_June', 'lblMonth_Small_July', 'lblMonth_Small_August', 'lblMonth_Small_September', 'lblMonth_Small_October', 'lblMonth_Small_November', 'lblMonth_Small_December'];
        }

        m = months[mn - 1];

        month = $translate.instant(m);

        if (dn < 10) {
            dn = dn[1];
        }

        return month + ' ' + dn + ', ' + y;
    }

    function ertripdateformat(t, s, d) {
        s = StringUtil.getdateinformat(s);

        var s = s.split(' ')[0];
        var dn = s.split('/')[2];
        var mn = s.split('/')[1];
        var y = s.split('/')[0];
        var dt = new Date(s);
        var we = dt.getDay();
        var m, w;
        var months = [];
        var weeks = [];
        var month, week;

        if (t == 'full') {
            months = ['lblMonth_Full_January', 'lblMonth_Full_February', 'lblMonth_Full_March', 'lblMonth_Full_April', 'lblMonth_Full_May', 'lblMonth_Full_June', 'lblMonth_Full_July', 'lblMonth_Full_August', 'lblMonth_Full_September', 'lblMonth_Full_October', 'lblMonth_Full_November', 'lblMonth_Full_December'];

        } else {
            months = ['lblMonth_Small_January', 'lblMonth_Small_February', 'lblMonth_Small_March', 'lblMonth_Small_April', 'lblMonth_Small_May', 'lblMonth_Small_June', 'lblMonth_Small_July', 'lblMonth_Small_August', 'lblMonth_Small_September', 'lblMonth_Small_October', 'lblMonth_Small_November', 'lblMonth_Small_December'];
        }
        weeks = TripDefaultValues.WEEK_HEADERS_DETAIL;
        m = months[mn - 1];
        w = weeks[we];
        month = $translate.instant(m);
        week = $translate.instant(w);
        // if (dn < 10) {
        //     dn = dn[1];
        // }
        if (d == "end") {
            return month + ' ' + dn + ', ' + y;
        } else if (d == "start") {
            return month + ' ' + dn;
        } else if (d == "month") {
            return month + ' ' + y;
        } else {
            return week + ', ' + ' ' + month + '. ' + dn + ', ' + y;
        }
    }

    function getFormDateFmt(dt) {
        var date = dt;
        var weekday = date.getDay();
        var month = date.getMonth();
        var day = date.getDate();
        var year = date.getFullYear();
        var we = TripDefaultValues.WEEK_HEADERS_DETAIL;
        var mn = DateValues.MONTHS;
        var m = $translate.instant(mn[month]);
        var w = $translate.instant(we[weekday]);
        return w + " " + m + " " + day + ", " + year;
    }

    function convertDateTimeToTime(date) {
        var today = new Date(date);
        var h = today.getHours();
        var m = today.getMinutes();
        var s = today.getSeconds();
        h = h % 12;
        h = h ? h : 12; // the hour '0' should be '12'
        var ampm = h >= 12 ? 'PM' : 'AM';
        return h + ':' + m + ' ' + ampm;
    }

    function getUtcDate(date) {
        console.log(10, date);
        var now = new Date(date);
        console.log(11, now);
        var month = parseInt(now.getUTCMonth() + 1);
        console.log(12, month);
        return now.getUTCFullYear() + "-" + month + "-" + now.getUTCDate() + " " + now.getUTCHours() + ":" + now.getUTCMinutes() + ":" + now.getUTCSeconds();
    }

    function getNoOfDaysInMonth(y, m) {
        return /8|3|5|10/.test(--m) ? 30 : m == 1 ? (!(y % 4) && y % 100) || !(y % 400) ? 29 : 28 : 31;
    }

    /*
        Name : getLocalTimeFromUtc
        Desc : Convert a UTC date object to a Local date object
        Params : pUtc - UTC date object
    */
    function getLocalTimeFromUtc(pUtc) {
        return moment(moment.utc(pUtc).toDate()).format('YYYY-MM-DD HH:mm:ss');
    }
}
