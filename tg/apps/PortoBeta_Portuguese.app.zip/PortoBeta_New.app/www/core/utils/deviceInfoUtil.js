angular.module('util')
    .service('DeviceInfoUtil', DeviceInfoUtil);

function DeviceInfoUtil(GlobalConstants, $cordovaDevice) {
    this.getDeviceInfo = getDeviceInfo;
    this.isdeviceandroid = isdeviceandroid;
    this.getiosversion = getiosversion;
    function getDeviceInfo() {
        var version = null;
        var model = null;
        var applicationVersion = GlobalConstants.API_VERSION;
        try {
            var version = $cordovaDevice.getVersion();
            var model = $cordovaDevice.getModel();
        } catch (e) {
        }

        return {
            version: version,
            model: model,
            applicationVersion: applicationVersion
        };
    }
    
    function isdeviceandroid(){
        if(navigator.userAgent.match(/Android/i)){
            return true;            
        }else{
            return false;
        }
        
    }
    function getiosversion(){
  function iOSversion() {
  if (/iP(hone|od|ad)/.test(navigator.platform)) {
    var v = (navigator.appVersion).match(/OS (\d+)_(\d+)_?(\d+)?/);
    return [parseInt(v[1], 10), parseInt(v[2], 10), parseInt(v[3] || 0, 10)];
  }
}

ver = iOSversion();

if (ver[0] >= 5) {
  return ver[0]
}
    }
}
