/**
CLASS TripInformation
used to store the information of a running trip

*/

function TripInformation() {
    this.tripId = "";
    this.state = "";
    this.duration = -1;
    this.distance = -1;
    this.speed = -1;
    this.heading = -1;
    this.cardinalHeading = "";
}