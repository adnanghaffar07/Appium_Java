/**
CLASS CarInfo
used to store the Car information

*/

function CarInfo() {
    this.year = "";
    this.make = ""
    this.model = "";
    this.icon = "";
    this.vin = "";
}