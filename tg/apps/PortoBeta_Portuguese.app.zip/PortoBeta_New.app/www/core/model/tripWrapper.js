/**
CLASS TripWrapper
used to store the information  trip

*/

function TripWrapper() {
    this.tripData = null;
    this.score = -1;
    this.accelerationScore = -1;
    this.corneringScore = -1;
    this.brakingScore = -1;
    this.speedScore = -1;
    this.driver = "";
    this.isMyTrip = false;
    this.distance = -1;
    this.startTime = null;
    this.endTime = null;
    this.startLocation = null;
    this.endLocation = null;
    this.isLastTrip = false;
    this.iconType = null;
    this.avatar = null;
    this.avatarLetter = null;


    this.extractInfoFromTripData = function (pPreviewTrip, pIdIconsArr) {

        this.score = Math.round(this.tripData.scoreAverage);
        this.accelerationScore = Math.round(this.tripData.scoreAcceleration);
        this.corneringScore = Math.round(this.tripData.scoreTurn);
        this.brakingScore = Math.round(this.tripData.scoreBraking);
        this.speedScore = Math.round(this.tripData.scoreSpeed);

        this.distance = Math.round(this.tripData.distance);
        this.endTime = Date.parse(this.tripData.endTime).getTime();

        var item = null;
        for (var i = 0; i < pIdIconsArr.length; i++) {
            item = pIdIconsArr[i];
            if (item.hasOwnProperty("avatar")) {
                //avatars
                this.avatar = 'iVBORw0KGgoAAAANSUhEUgAAAFIAAABTCAYAAAAMcFA+AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyZpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMDE0IDc5LjE1Njc5NywgMjAxNC8wOC8yMC0wOTo1MzowMiAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTQgKFdpbmRvd3MpIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOkRDQ0IzRkY2QzA4MjExRTU4NENFQ0UzRDNCN0VDM0Y4IiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOkRDQ0IzRkY3QzA4MjExRTU4NENFQ0UzRDNCN0VDM0Y4Ij4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6RENDQjNGRjRDMDgyMTFFNTg0Q0VDRTNEM0I3RUMzRjgiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6RENDQjNGRjVDMDgyMTFFNTg0Q0VDRTNEM0I3RUMzRjgiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz5bH+4UAAAJHUlEQVR42uydS0xb2RnHj6+v8RMbAgT8wDEDwZhno1ImL4YQlOmMJp3tqKvu2k07y5Fm0S66qVSpUqXuuohmkS6qLjNTVU1IMkmUaVKNFB4BA2HCgLFDMBC/sK9t7Pn+7kBhwOD3vWD/pSvA3HPvOb/7nXO+87ifZRcuX2FiSqvRsNraGlZTY2AGg54Z9PrUZ0qVkuflcl6hUCi3trbipCgpHo3Fk5FIhPn8fubz+dmbNz62sfGGhTY3RS0HX+obKpVK1mwx02FiTY2NMp1Oqz8qjZyA4kDabZlNxj3nBIMh/6uVleSSy82WXMtMEISSlktWCoskCKzFZmVtrW8BgI7jOHkx75dIJLaW3Z7gi/lv2MuFRUYWfbxBaqiKdnd2sA77WQVZk0aMKkeWuemcmYtNTjnZZhGrf1FAoo37UV8PABbd+rKxUgIafDY2UZT2VN5stRWuwaUqDIAjV4e0jacbNDKZjGMSEfLS0FCvcjjsPCeTxVZXvSyRTEoPJBr/9386IrPZzhjICiUD8IdC3kzGJlVba0t0w+djgUBQGiBhhRfOD7CLFwYMyt3dqsSFvJ5ta1Wp1SrB436Vt3XmBRJ+3wfvvcuszRYDO6ZqqK9X2c5YhWWPJy+XKWeQ8AXff++aSqfVatkxF1ml6uzZVtn6+kbc7w+UDiT1xmx4aFBHQw8FOyGCw/9WS4siHA5HvWvrxQfZ19PFLp4fMEipRy5kz37G2qyi4aiw8nq1eCB7CeLbP/mxgZ1wWcymrGFmbFWdHfaygLgtlBVlLihI6pXh3uhZmQlltlothQGJaa3hoctKaj9k5QYSZR5+57ISbl5eIHmeZ9dGrrCqqioVK1Oh7NeuXkmxyBnk+YF+TLoaWJkLDC683Z8bSLPZyBwd7WUP8f++c7sBTLICCTMevHheVsG3V2CSroofCLK3u5NVV1frK+j2CkzgS2cEUqNRs77ebnUFW9qRnRqMjgTZ292Fql1VQZbWk6kCo32f7/5DpVKiURXV1VGr1fWtra2/t1gsH+hJ5H7IotFo0k9yuVxfzM/P/y4cDntF7nhUz8YnIpGIcPBY+1xfL2a6RZkWw4RBV1fXn4eGhm6YTKYejUajksvlsu9nZmT4u6mpqcdut3+cTCaNXq/33/SvpBh5lcs5PrGVENyeV/urNpZMOzraFWJBvHTp0lfnzp37BfJxeCHkDOfhfDFnoBwOu2J3XncygnVnlUhLpgTmHzabzZ5NGpyPdGKBBCsw2wcSi/fijBpqHZ2dnSO5pEU6pBcL5m5mKZBYs8IOCDEyQ+3iZ2Kmz0dgtr3elwKJfThiLOTTPXmz2dyeV2EoPa4jBkgwA7tdIM2iPFGdTmdRKBR5DUWRHtcRyyq32aVAYleYSD7jGSldJxdts+O0Wg3LZGtdMRSPx31Suk5utUqrB0Ouvq5OtBFCKBRalNJ1chUYctgtK5ZojLW+sbGR1+YbpMd1xAQJhhzWZMQUjZ3/Jmb6QggMuWqduDtO5ubmfhsIBKK5pEU6pBcbJLWTjFNrxJ163Nraij58+HAkFotlNQGB85EO6cUGiflJjsaMvNgZWV9fn7hz585wOBzOaLM3zsP5SMckIBrd8Bw2D0khM2tra89u3bplczqdj8idSefmMPwf5+F8JhHhNRbZjRs3JLdSSA+3qrGx8Zper3+HnrZREASP3+9/sLKyclsKVflAmFLMFGC53e4vcLBjIo4abYFVlJfAkMPraRUUeQ5RiSEfEYS4SiW9rT08z6sUCoWO2ks1PewwPfUgdTYRKYKkNjzOhzfDrMYgXn+DdZfa2tquhoaGj+rr669SB9NMh+6g6TX4jtTpBOlY8nq9d1dXV/9OQ8TnyWQyISbITWLIB4IhZix1w8xxvNFovG6z2T6xWCyOTOckcV5dXV01HZ0tLS2d9NGvAdflck0vLCz80ePxfJ5IJEreVAWJIY/XdUvouBo6Ojr+0t7efp1+L8gKIOACKh2fURVLzM7Ofk6+5m/o95JNrYEhj3edS1F97Xb7H/r6+n6Z74z4EQ+K6+np+ZAe1s/Gxsb+OjMz82kpqj0Y8t61taLehMBpBwcHn5pMppKtZ+Bh9ff3/4rueZ3G4wNU/UPFvB8YcqHQZuql8WK1hcPDwxOlhLhbuC/uX8zFMbADw1Q7hTfvi3ETh8Pxp9OnT58Ss0fF/ZGPYl1/m10KJEIXFENtbW0/l4KfV8x8bLP7HqQ79WJ4oW9SXV0tie2BxcoHmIHdDki8FYoYEJXBXnYCs+03and8OQTSqCg77Wa2AxLRSBBIo4InM0WIFZjtA4mQLtPO2VgFUWZyEqvdYXD2+FcTz6dYd5cjWqg95Ddv3qw5iRARFQus9vjMe8w1IrDpmdlwxd4OFxjt3j++DyQ0PvE8RbyCK701jk9M7R/F/fADzK0RzIpVptH45FT4oIhWB05ljZFVBgIBfwXbXgUCQf/Y+OTB8wppzJc9fPyfZAXdXj0iJunW3NNOri4ve9iUc8ZXwfc/gYVr2Z32/4fOUj95+jXbeOMre5hgABaHiTuih2K3R++xaDQaKVeIKDsYpKvSGYGEEH713oNHQjKZLLs2E2VG2cHgKGW0ALW46GKPv3padr04yoyyZ6KMAyitetdg3gKCC5UDxCf//do3OTWd8flZRaJCZKYtgmk+4TCfEkSM8LJR1rHRAJNGP4K12XziYgGhTXz0+In/+ZQz67Q5RevD8iNVdcFqbZZJZaNq3r1zLCbcGb0f+ublQk7pc44fiTiLC98uxk3GJgHxF4+1n0iO4j//dTv+ejX3wAR5RTTFesXsi3mmVFYJiAx6XEcso/ceYF96XtfJO8ZuIpFgS0vL1Ha+FpoaG6ME9VjE2cUExOj9LyNoD1GGfFWwqM+InuycmUWQCaGhoZ6XauRnbAodG58M3L3/gGXiaJccZMo6afDj8bxic3PzMTkvF+pOnVJIJfIp1qCnZ2YDo3e/jH27uFTQGORQ5SsGjgPIHbMvgy+9KIkPiIK8mH+ZOsgyg9l+DUsmKouvYTlMCGN+qrYmFRwee9nxU6NWIyoWT1JsLw1j0YmOWCQixDfJVUl9KZDPl/q5ji8GCoVELYesDGfHiqLvBBgA1kIkYJ0nYKEAAAAASUVORK5CYII=';
                this.avatarLetter = 'U';

                if (item.driver_id == this.tripData.driver_id) {
                    this.avatar = item.avatar;
                    this.avatarLetter = item.avatarLetter;
                    break;
                }
            } else {
                //car icons
                if (item.id == null || item.id == this.tripData.carId) {
                    this.iconType = item.icon_type;
                    break;
                } else {
                    this.iconType = "default";
                }
            }
        }

        console.log(555, this);

        if (!pPreviewTrip) {
            this.startTime = Date.parse(this.tripData.startTime).getTime();
            this.startLocation = this.tripData.start_location;
            this.endLocation = this.tripData.end_location;
        }
    }
}
