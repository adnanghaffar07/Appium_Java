/*
    SCORE OBJECT FOR REBATE BASE MODE
*/

function OverallDrivingScores() {
    this.global = {
        "score": -1,
        "hbr": -1,
        "hac": -1,
        "spd": -1,
        "hco": -1,
        "distance": -1
    };
    this.lastTrip = {
        "score": -1,
        "hbr": -1,
        "hac": -1,
        "spd": -1,
        "hco": -1,
        "distance": -1
    };
    this.lastWeek = {
        "score": -1,
        "hbr": -1,
        "hac": -1,
        "spd": -1,
        "hco": -1,
        "distance": -1
    };
    this.lastMonth = {
        "score": -1,
        "hbr": -1,
        "hac": -1,
        "spd": -1,
        "hco": -1,
        "distance": -1
    };
}

/*
    SCORE OBJECT FOR PAY PER MILE MODE
*/
function OverallDrivingInfo() {
    this.global = {
        "cost": -1,
        "distance": -1,
        "trip_date": -1,
        "free_miles_earned": -1,
        "free_miles_consumed": -1,
        "safe_miles_driven": -1,
        "price_per_category": {
            "safe_interstate": -1,
            "safe_other": -1,
            "aggressive": -1,
            "risky": -1,
            "dangerous": -1
        },
        "price_per_mile_current": {
            "safe_interstate": -1,
            "safe_other": -1,
            "aggressive": -1,
            "risky": -1,
            "dangerous": -1
        },
        "distance_per_category": {
            "safe_interstate": -1,
            "safe_other": -1,
            "aggressive": -1,
            "risky": -1,
            "dangerous": -1
        },
        break_points: [],
        date_from: -1
    };
    this.lastTrip = {
        "cost": -1,
        "distance": -1,
        "trip_date": -1,
        "free_miles_earned": -1,
        "free_miles_consumed": -1,
        "safe_miles_driven": -1,
        "price_per_category": {
            "safe_interstate": -1,
            "safe_other": -1,
            "aggressive": -1,
            "risky": -1,
            "dangerous": -1
        },
        "distance_per_category": {
            "safe_interstate": -1,
            "safe_other": -1,
            "aggressive": -1,
            "risky": -1,
            "dangerous": -1
        },
        "price_per_mile_current": {
            "safe_interstate": -1,
            "safe_other": -1,
            "aggressive": -1,
            "risky": -1,
            "dangerous": -1
        },
        break_points: [],
        date_from: -1
    };
    this.lastWeek = {
        "cost": -1,
        "distance": -1,
        "trip_date": -1,
        "free_miles_earned": -1,
        "free_miles_consumed": -1,
        "safe_miles_driven": -1,
        "price_per_category": {
            "safe_interstate": -1,
            "safe_other": -1,
            "aggressive": -1,
            "risky": -1,
            "dangerous": -1
        },
        "distance_per_category": {
            "safe_interstate": -1,
            "safe_other": -1,
            "aggressive": -1,
            "risky": -1,
            "dangerous": -1
        },
        "price_per_mile_current": {
            "safe_interstate": -1,
            "safe_other": -1,
            "aggressive": -1,
            "risky": -1,
            "dangerous": -1
        },
        break_points: [],
        date_from: -1
    };
    this.lastMonth = {
        "cost": -1,
        "distance": -1,
        "trip_date": -1,
        "free_miles_earned": -1,
        "free_miles_consumed": -1,
        "safe_miles_driven": -1,
        "price_per_category": {
            "safe_interstate": -1,
            "safe_other": -1,
            "aggressive": -1,
            "risky": -1,
            "dangerous": -1
        },
        "distance_per_category": {
            "safe_interstate": -1,
            "safe_other": -1,
            "aggressive": -1,
            "risky": -1,
            "dangerous": -1
        },
        "price_per_mile_current": {
            "safe_interstate": -1,
            "safe_other": -1,
            "aggressive": -1,
            "risky": -1,
            "dangerous": -1
        },
        break_points: [],
        date_from: -1
    };
}
