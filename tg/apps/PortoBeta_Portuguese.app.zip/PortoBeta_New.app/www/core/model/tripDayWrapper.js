/**
CLASS TripDayWrapper
used to store the TripWrappers

*/

function TripDayWrapper() {
    var mDailyScore = -1;
    var mDailyAccelationScore = -1;
    var mDailyBrakingScore = -1;
    var mDailySpeedingScore = -1;
    var mDailyCorneringScore = -1;

    this.tripWrappers = [];
    this.date = "1901-01-01";
    this.displayDate = "";

    this.innerGetScore = function (pScoreName) {
        var score = 0;
        for (var i = 0; i < this.tripWrappers.length; i++) {
            score += this.tripWrappers[i][pScoreName];
        }

        return score / this.tripWrappers.length;
    }

    this.getDailyScore = function () {
        if (mDailyScore == -1) {
            mDailyScore = this.innerGetScore("score");
        }
        return mDailyScore;
    };
    this.getDailyAccelerationScore = function () {
        if (mDailyAccelationScore == -1) {
            mDailyAccelationScore = this.innerGetScore("accelerationScore");
        }
        return mDailyAccelationScore;
    };
    this.getDailyBrakingScore = function () {
        if (mDailyBrakingScore == -1) {
            mDailyBrakingScore = this.innerGetScore("brakingScore");
        }
        return mDailyBrakingScore;
    };
    this.getDailySpeedingScore = function () {
        if (mDailySpeedingScore == -1) {
            mDailySpeedingScore = this.innerGetScore("speedScore");
        }
        return mDailySpeedingScore;
    };
    this.getDailyCorneringScore = function () {
        if (mDailyCorneringScore == -1) {
            mDailyCorneringScore = this.innerGetScore("corneringScore");
        }
        return mDailyCorneringScore;
    };
}