# basedrive-ionic-core
Stores the common codebase for all of our ionic projects
