angular.module('factories')
    .service("CordovaBroadcaster", CordovaBroadcaster);

function CordovaBroadcaster($rootScope, LoggerUtil, GlobalConstants, BridgeIntentType, LocalStorage, LocalStorageKeys, ClientSettings) {

    var TAG = "INTENT";

    this.sendPlatformReady = sendPlatformReady;
    this.changeUseOnlyWifi = changeUseOnlyWifi;
    this.changeAnonymousDriving = changeAnonymousDriving;
    this.openMail = openMail;
    this.composePhoneNumber = composePhoneNumber;
    this.openWebSite = openWebSite;
    this.setAutoStartValue = setAutoStartValue;
    this.setTripScoreNotification = setTripScoreNotification;
    this.setContestNotification = setContestNotification;
    this.setHardAccelerationBeep = setHardAccelerationBeep;
    this.setHardBreakingBeep = setHardBreakingBeep;
    this.setLocaleKey = setLocaleKey;
    this.startTrip = startTrip;
    this.pauseTrip = pauseTrip;
    this.resumeTrip = resumeTrip;
    this.sendUserInformation = sendUserInformation;
    this.sendPolicyInformation = sendPolicyInformation;
    this.stopTrip = stopTrip;
    this.exitApp = exitApp;
    this.requestTripInformation = requestTripInformation;
    this.updateTripProcessNotification = updateTripProcessNotification;
    this.clearUserInformation = clearUserInformation;
    this.pingDevice = pingDevice;
    this.updateAutoStartConfidence = updateAutoStartConfidence;
    this.updateAutoStopDuration = updateAutoStopDuration;
    this.updateTripNotification = updateTripNotification;
    this.openSMS = openSMS;
    this.updateGetTripStatus = updateGetTripStatus;
    this.sendBroadcast = sendBroadcast;
    this.setCaptureRawEvents = setCaptureRawEvents;
    this.sendRunDiagnotics = sendRunDiagnotics;
    this.getNotificationData = getNotificationData;
    this.clearNotificationData = clearNotificationData;
    this.startDeviceScan = startDeviceScan;
    this.reloadWebView = reloadWebView;
    this.actionT2Notification = actionT2Notification;
    this.setTelemetryLogs = setTelemetryLogs;
    this.setLanguage = setLanguage;
    this.openLocationSettings = openLocationSettings;

    function sendPlatformReady() {
        innerBroadcast({
            action: BridgeIntentType.PLATFORM_READY,
            extras: {
                baseURL: GlobalConstants.BASE_URL,
                collectorURL: GlobalConstants.COLLECTOR_URL,
                collectorURLT2: GlobalConstants.COLLECTOR_URL_T2,
                enable_end_trip_notification: ClientSettings.allowNotification
            }
        });
    }

    function changeUseOnlyWifi(pValue) {
        innerBroadcast({
            action: BridgeIntentType.UPDATE_USE_WIFI_ONLY,
            extras: {
                "useWifiOnly": pValue
            }
        });
    }

    function actionT2Notification(pValue) {
        innerBroadcast({
            action: BridgeIntentType.ACTION_T2_NOTIFICATION,
            extras: {
                "t2Notification": pValue
            }
        });
    }

    function changeAnonymousDriving(pValue) {
        innerBroadcast({
            action: BridgeIntentType.UPDATE_ANNONYMOUS_DRIVING,
            extras: {
                anonymousDriving: pValue
            }
        });
    }

    function openMail(pTo, pSubject, pBody, pAttachPath, pFilename) {
        innerBroadcast({
            action: BridgeIntentType.OPEN_EMAIL_EVENT,
            extras: {
                "to": pTo,
                "subject": pSubject,
                "body": pBody,
                "directory": pAttachPath,
                "filename": pFilename
            }
        });
    }

    function composePhoneNumber(pPhoneNumber) {
        innerBroadcast({
            action: BridgeIntentType.COMPOSE_PHONE_NUMBER_EVENT,
            extras: {
                "phoneNumber": pPhoneNumber
            }
        });
    }

    function openWebSite(pUrl) {
        innerBroadcast({
            action: BridgeIntentType.OPEN_WEBSITE_EVENT,
            extras: {
                "URL": pUrl
            }
        });
    }

    function setAutoStartValue(pAutoStart, pAutoStartValue) {
        innerBroadcast({
            action: BridgeIntentType.UPDATE_AUTO_START,
            extras: {
                "autoStart": pAutoStart,
                "autoStartValue": pAutoStartValue
            }
        });
    }

    function setTripScoreNotification(pValue) {
        innerBroadcast({
            action: BridgeIntentType.UPDATE_TRIP_SCORE_NOTIFICATION,
            extras: {
                "tripNotification": pValue
            }
        });
    }

    function updateTripNotification(pValue) {
        innerBroadcast({
            action: BridgeIntentType.UPDATE_TRIP_NOTIFICATION,
            extras: {
                "tripNotification": pValue
            }
        });
    }

    function setContestNotification(pValue) {
        innerBroadcast({
            action: BridgeIntentType.UPDATE_CONTEST_NOTIFICATION,
            extras: {
                "contestNotification": pValue
            }
        });
    }

    function setHardAccelerationBeep(pValue) {
        innerBroadcast({
            action: BridgeIntentType.UPDATE_HAC_BEEP,
            extras: {
                "HACBeep": pValue
            }
        });
    }

    function setHardBreakingBeep(pValue) {
        innerBroadcast({
            action: BridgeIntentType.UPDATE_HBR_BEEP,
            extras: {
                "HBRBeep": pValue
            }
        });
    }

    function setLocaleKey(pLocaleKey) {
        innerBroadcast({
            action: BridgeIntentType.LOCALE_KEY_CHANGED,
            extras: {
                "key": pLocaleKey.substring(0, 2)
            }
        });
    }

    function startTrip(e) {
        innerBroadcast({
            action: BridgeIntentType.START_TRIP,
            extras: {}
        });
    }

    function stopTrip() {
        innerBroadcast({
            action: BridgeIntentType.STOP_TRIP,
            extras: {}
        });
    }

    function pauseTrip(e) {
        innerBroadcast({
            action: BridgeIntentType.PAUSE_TRIP,
            extras: {}
        });
    }

    function resumeTrip(e) {
        innerBroadcast({
            action: BridgeIntentType.RESUME_TRIP,
            extras: {}
        });
    }

    function openLocationSettings(e) {
        innerBroadcast({
            action: BridgeIntentType.ACTION_OPEN_SETTINGS_LOCATION,
            extras: {}
        });
    }

    function sendUserInformation(pUserId, pUserToken, pDevices) {
        console.log("##########\nSENDING USER INFORMATIONS - DEVICES" + JSON.stringify(pDevices) + "\n##########");
        var mode = LocalStorage.get(LocalStorageKeys.LOGIN_TYPE);
        var email = LocalStorage.get(LocalStorageKeys.LOGIN_EMAIL);

        var pCompanyId = "";

        if (typeof (pUserId) == "undefined") {
            pUserId = "";
        }

        if (pDevices && pDevices.length > 0 && pDevices[0].Device && pDevices[0].Device.company_id) {
            pCompanyId = pDevices[0].Device.company_id;
        }

        var _extras = {
            user: pUserId,
            userToken: pUserToken,
            devices: pDevices,
            mode: mode,
            email: email,
            company_id: pCompanyId
        };

        innerBroadcast({
                action: BridgeIntentType.SEND_USER_INFORMATION,
                extras: _extras
            },
            function () {
                console.log("##########\nSENDING USER INFORMATIONS - SUCCESS\n##########");
                LocalStorage.set(LocalStorageKeys.SEND_USER_CREDENTIAL_STATE, "SENT");
                console.log("send credentials success");
            }
        );

        console.log(_extras, "### Extras for send user info");

    }

    function clearUserInformation() {
        innerBroadcast({
            action: BridgeIntentType.CLEAR_USER_INFORMATION,
            extras: {}
        });
    }



    function exitApp() {
        innerBroadcast({
            action: BridgeIntentType.APP_EXIT,
            extras: {}
        });
    }

    function openSMS(pTo, pBody) {
        innerBroadcast({
            action: BridgeIntentType.OPEN_SMS,
            extras: {
                to: pTo,
                body: pBody
            }
        });
    }

    function setCaptureRawEvents(pValue) {
        innerBroadcast({
            action: BridgeIntentType.CAPTURE_RAW_EVENTS,
            extras: {
                captureRawEvents: pValue
            }
        });
    }

    function sendRunDiagnotics(pUID) {
        innerBroadcast({
            action: BridgeIntentType.RUN_DIAGNOSTICS,
            extras: {
                UID: pUID
            }
        });
    }




    function requestTripInformation() {
        innerBroadcast({
            action: BridgeIntentType.GET_TRIP_INFO,
            extras: {}
        });
    }

    function updateTripProcessNotification(score, accleration, speeding, braking) {
        innerBroadcast({
            action: BridgeIntentType.UPDATE_TRIP_PROCESS_COMPLETE_NOTIFICATION,
            extras: {
                "score": score,
                "hardAcceleration": accleration,
                "extremeSpeeding": speeding,
                "hardBraking": braking
            }
        });
    }

    function updateGetTripStatus(pGetTripStatus) {
        innerBroadcast({
            action: BridgeIntentType.UPDATE_GET_TRIP_STATUS,
            extras: {
                update_gettripStatus: pGetTripStatus
            }
        });
    }

    function getNotificationData() {
        innerBroadcast({
            action: BridgeIntentType.GET_NOTIFICATION_DATA,
            extras: {}
        });
    }

    function clearNotificationData() {
        innerBroadcast({
            action: BridgeIntentType.CLEAR_NOTIFICATION_DATA,
            extras: {}
        });
    }

    /********************** T2  *********************/

    function pingDevice(pUID) {
        innerBroadcast({
            action: BridgeIntentType.PING_DEVICE,
            extras: {
                UID: pUID
            }
        });
    }

    function startDeviceScan() {
        innerBroadcast({
            action: BridgeIntentType.START_DEVICE_SCAN,
            extras: {}
        });
    }

    /********************** T2  *********************/
    function updateAutoStartConfidence(pValue) {
        innerBroadcast({
            action: BridgeIntentType.UPDATE_AUTO_START_CONFIDENCE,
            extras: {
                confidence: pValue
            }
        });
    }

    function updateAutoStopDuration(pDuration) {
        innerBroadcast({
            action: BridgeIntentType.UPDATE_AUTO_STOP_DURATION,
            extras: {
                duration: pDuration
            }
        });
    }

    function sendBroadcast(pIntentName, pExtras) {
        innerBroadcast({
            action: pIntentName,
            extras: pExtras
        });
    }

    /** inner sendBroadcast *********************/
    function innerBroadcast(pJson, pResultFunction, pFailFunction) {
        if (pResultFunction == undefined) {
            pResultFunction = function () {
                console.log("success");
            };
        }

        if (pFailFunction == undefined) {
            pFailFunction = function (args) {
                //console.log(args);
            };
        }

        LoggerUtil.log(TAG, JSON.stringify(pJson));
        window.webintent.sendBroadcast(pJson, pResultFunction, pFailFunction);
    }

    function sendPolicyInformation() {
        var pPolicyId = LocalStorage.get(LocalStorageKeys.POLICY_ID);
        if (typeof (pPolicyId) == "undefined") {
            pPolicyId = "";
        }
        innerBroadcast({
                action: BridgeIntentType.USER_POLICY_ID,
                extras: {
                    policyId: pPolicyId
                }
            },
            function () {
                console.log("##########\nSENDING Policy INFORMATIONS - SUCCESS\n##########");
            }
        );
    }

    function reloadWebView() {
        innerBroadcast({
            action: "RELOAD_WEB_VIEW",
            extras: {
                "webview": true
            }
        });
    }

    function setTelemetryLogs(pValue) {
        innerBroadcast({
            action: BridgeIntentType.SET_TELEMETRY_LOGS,
            extras: {
                enableLogs: pValue
            }
        });
    }

    function setLanguage(pValue) {
        innerBroadcast({
            action: BridgeIntentType.SET_LANGUAGE,
            extras: {
                lang: pValue
            }
        });
    }

}
