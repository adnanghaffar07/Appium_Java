angular.module("factories")
    .service("AvatarCache", AvatarCache);

function AvatarCache($q, HttpProxy, ValidationUtil, LocalStorage, LocalStorageKeys, GlobalConstants, WebServiceUrls) {

    var mCache;
    this.getAvatar = getAvatar;
    this.unsetmCache = unsetmCache;

    function unsetmCache() {
        mCache = {};

    }

    /*DEPRECATED use getAvatarByUserId */
    function getAvatar(pUsername) {
        var q = $q.defer();

        if (mCache == null) {
            mCache = LocalStorage.getObject(LocalStorageKeys.AVATAR_CACHE, {});
        }
        var avatar;
        if (pUsername) {
            avatar = mCache[pUsername];
        }
        if (avatar != null) {
            q.resolve(avatar);
        } else {

            var jsonParams = {
                username: pUsername
            };

            HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.GET_AVATAR, jsonParams).then(function (pResponse) {
                pResponse.data['useLetter'] = false;
                if (pResponse.data.avatar == null) {
                    pResponse.data['useLetter'] = true;
                }
                pResponse.data['isMyself'] = false;
                if (pResponse.data.username == LocalStorage.get(LocalStorageKeys.LOGIN_USERNAME)) {
                    pResponse.data['isMyself'] = true;
                }

                if (pUsername) {
                    mCache[pUsername] = pResponse.data;
                    LocalStorage.setObject(LocalStorageKeys.AVATAR_CACHE, mCache);
                }
                q.resolve(pResponse.data);
            }, function (pError) {
                q.reject(pError);
            });
        }
        return q.promise;
    }
}
