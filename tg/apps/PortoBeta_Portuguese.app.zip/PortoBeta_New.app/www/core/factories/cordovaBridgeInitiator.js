angular.module('factories')
    .run(CordovaBridgeInitiator);

function CordovaBridgeInitiator(CordovaReceiver, CordovaBroadcaster, ConversionUtil, GlobalConstants) {

    ionic.Platform.ready(onPlatformReady);

    function onPlatformReady() {

        //Receiver
        window.webintent.onNewIntent(onNewIntent);
        
        //Initialising Globalconstants
        GlobalConstants.init();

        //Broadcaster
        CordovaBroadcaster.sendPlatformReady();

    }

    function onNewIntent(json) {
        //alert("onNewIntent:" + JSON.stringify(json));
        //console.log("[cordovaBridgeInitiator] raw json received : " + JSON.stringify(json));

        CordovaReceiver.onNewIntent(json["Action"], json["extras"]);
    }

}