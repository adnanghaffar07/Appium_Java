angular.module('factories')
    .service('UnitTestManager', UnitTestManager);

function UnitTestManager(LocalStorage, ValidationUtil, StringUtil, LoggerUtil, OfflineLoginFactory, WebServiceCache, ListenerUtil, ApplicationStateManager) {

    this.startTests = startTests;

    function startTests() {
        LocalStorage.testFunctionalities();
        ValidationUtil.testFunctionalities();
        LoggerUtil.testFunctionalities();
        OfflineLoginFactory.testFunctionalities();
        WebServiceCache.testFunctionalities();
        StringUtil.testFunctionalities();
        ListenerUtil.testFunctionalities();
       // ApplicationStateManager.testFunctionalities();
    }
}
