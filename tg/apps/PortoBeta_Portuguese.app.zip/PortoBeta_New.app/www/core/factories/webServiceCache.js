angular.module("factories")
    .service("WebServiceCache", WebServiceCache);

function WebServiceCache(LocalStorage, LocalStorageKeys, ValidationUtil, LoggerUtil, GlobalConstants, WebServiceUrls, StringUtil, CacheControlType) {

    this.testFunctionalities = testFunctionalities;
    this.saveResponse = saveResponse;
    this.getPublicResponse = getPublicResponse;
    this.getOfflineResponse = getOfflineResponse;
    this.clearCache = clearCache;
    this.fakeCacheControl = fakeCacheControl;
    this.cleanseCache = cleanseCache;

    const TAG = "HTTP_PROXY";

    function testFunctionalities() {

        var prefix = "[TEST]";
        var className = "WebServiceCache";

        var baseUrl = "";
        var params = "";


        baseUrl = prefix + GlobalConstants.BASE_URL + 'ABC';
        //EMPTY_CACHE
        this.clearCache();
        console.assert(null == getPublicResponse(baseUrl),
            StringUtil.format("{0} : getPublicResponse({1}) should return null because the cache just got emptied", className, baseUrl));

        var item = {
            config: {
                url: baseUrl,
                headers: {
                    "Cache-Control": "Public"
                }
            },
            data: [1, 2, 3, 4]
        };
        //NOT_EMPTY_CACHE
        this.saveResponse(item);
        console.assert(null != getPublicResponse(baseUrl),
            StringUtil.format("{0} : getPublicResponse({1}) should not return null", className, baseUrl));


        //WRONG_KEY
        console.assert(null == getPublicResponse(baseUrl + 'D'),
            StringUtil.format("{0} : getPublicResponse({1}D') should return null because we did not add something in the cache with the key 'ABCD'", className, baseUrl));

        //GOOD_KEY
        console.assert(angular.equals(item, getPublicResponse(baseUrl)),
            StringUtil.format("{0} : getPublicResponse({1}) should return the value of the key 'ABC'", className, baseUrl));

        //NOT_CACHABLE_RESPONSE
        baseUrl = prefix + GlobalConstants.BASE_URL + 'EFG';
        var noneCachableResponse = {
            config: {
                url: baseUrl,
                headers: {
                    "Cache-Control": "No-Cache"
                }
            },
            data: [4, 5, 6]
        };
        this.saveResponse(noneCachableResponse);

        console.assert(null == getPublicResponse(baseUrl),
            StringUtil.format("{0} : getPublicResponse({1}) should return null because the value inserted 'EFG' is not cachable", className, baseUrl));

        console.assert(null == getOfflineResponse(baseUrl),
            StringUtil.format("{0} : getOfflineResponse({1}) should return null because the value inserted 'EFG' is not cachable", className, baseUrl));



        //OFFLINE_RESPONSE
        baseUrl = prefix + GlobalConstants.BASE_URL + 'OFFLINE';
        var offlineResponse = {
            config: {
                url: baseUrl,
                headers: {
                    "Cache-Control": "Offline"
                }
            },
            data: [4, 5, 6]
        };
        this.saveResponse(offlineResponse);

        console.assert(null == getPublicResponse(baseUrl),
            StringUtil.format("{0} : getPublicResponse({1}) should return null", className, baseUrl));

        console.assert(null != getOfflineResponse(baseUrl),
            StringUtil.format("{0} : getPublicResponse({1}) should be != null", className, baseUrl));

        console.assert(angular.equals(offlineResponse, getOfflineResponse(baseUrl)),
            StringUtil.format("{0} : getOfflineResponse({1}) should return the offlineResponse", className, baseUrl));


        //REQUEST  GET with 1 Param
        baseUrl = prefix + GlobalConstants.BASE_URL + '/GET';
        params = '/param1';
        var getResponseOneParam = {
            config: {
                url: baseUrl + params,
                headers: {
                    "Cache-Control": "Offline"
                }
            },
            data: [7, 8, 9]
        };
        this.saveResponse(getResponseOneParam);
        console.assert(null == getOfflineResponse(baseUrl),
            StringUtil.format("{0} : getOfflineResponse({1}) should return null", className, baseUrl));
        console.assert(null != getOfflineResponse(baseUrl + params),
            StringUtil.format("{0} : getOfflineResponse({1}) should be != null", className, baseUrl + params));
        console.assert(angular.equals(getResponseOneParam, getOfflineResponse(baseUrl + params)),
            StringUtil.format("{0} : getOfflineResponse({1}) should return the getResponseOneParam", className, baseUrl + params));



        //REQUEST  GET with 2 Params
        baseUrl = prefix + GlobalConstants.BASE_URL + '/GET';
        params = '/param1/param2';

        var getResponseTwoParam = {
            config: {
                url: baseUrl + params,
                headers: {
                    "Cache-Control": "Offline"
                }
            },
            data: [7, 8, 9]
        };

        this.saveResponse(getResponseTwoParam);

        console.assert(null == getOfflineResponse(baseUrl),
            StringUtil.format("{0} : getOfflineResponse({1}) should return null", className, baseUrl));

        console.assert(null != getOfflineResponse(baseUrl + params),
            StringUtil.format("{0} : getOfflineResponse({1}) should be != null", className, baseUrl + params));

        console.assert(angular.equals(getResponseTwoParam, getOfflineResponse(baseUrl + params)),
            StringUtil.format("{0} : getOfflineResponse({1}) should return the getResponseTwoParam", className, baseUrl + params));

        //request post with params

        baseUrl = prefix + GlobalConstants.BASE_URL + "/POST_METHOD";
        params = {
            key: "value"
        };
        var postResponseWithParam = {
            config: {
                url: baseUrl,
                headers: {
                    "Cache-Control": "Offline"
                },
                data: params
            },
            data: [10, 11, 12]
        };

        this.saveResponse(postResponseWithParam);

        console.assert(null == getOfflineResponse(baseUrl),
            StringUtil.format("{0} : getOfflineResponse({1}) should return null", className, baseUrl));

        console.assert(null != getOfflineResponse(baseUrl, params),
            StringUtil.format("{0} : getOfflineResponse({1}) should be != null", className, baseUrl + "," + JSON.stringify(params)));

        console.assert(angular.equals(postResponseWithParam, getOfflineResponse(baseUrl, params)),
            StringUtil.format("{0} : getOfflineResponse({1}) should return the postResponseWithParam", className, baseUrl + "," + JSON.stringify(params)));


        var params2 = {
            key: "value2"
        };
        var postResponse2WithParam = {
            config: {
                url: baseUrl,
                headers: {
                    "Cache-Control": "Offline"
                },
                data: params2
            },
            data: [10, 11, 12]
        };
        this.saveResponse(postResponse2WithParam);

        console.assert(null == getOfflineResponse(baseUrl),
            StringUtil.format("{0} : getOfflineResponse({1}) should return null", className, baseUrl));

        console.assert(null != getOfflineResponse(baseUrl, params2),
            StringUtil.format("{0} : getOfflineResponse({1}) should be != null", className, baseUrl + "," + JSON.stringify(params2)));

        console.assert(angular.equals(postResponse2WithParam, getOfflineResponse(baseUrl, params2)),
            StringUtil.format("{0} : getOfflineResponse({1}) should return the postResponse2WithParam", className, baseUrl + "," + JSON.stringify(params2)));

        //back to 1
        console.assert(angular.equals(postResponseWithParam, getOfflineResponse(baseUrl, params)),
            StringUtil.format("{0} : getOfflineResponse({1}) should return the postResponseWithParam", className, baseUrl + "," + JSON.stringify(params)));








        //resquest post




        //EXPIRED_RESPONSE
        /*TODO HGC SET EXPIRED
        var expiredData = { //TODO HGC set cacheControl
            config: {
                url: GlobalConstants.BASE_URL + "GHI",
                headers: {
                    "Cache-Control": "No-Cache"
                }
            },
            data: [7, 8, 9]
        };
        this.saveResponse(expiredData);

        console.assert(null == getPublicResponse(GlobalConstants.BASE_URL + "GHI"),
            StringUtil.format("{0} : getPublicResponse('GHI') should return null because the value inserted in 'GHI' should be expired", className));
*/


        LocalStorage.clearAllPrefixedEntries(prefix);

    }

    function saveResponse(pResponse) {
        var cacheType = pResponse.config['headers']['Cache-Control'];

        if (cacheType == CacheControlType.PUBLIC ||
            cacheType == CacheControlType.OFFLINE) {
            var key = pResponse.config.url;
            if (!ValidationUtil.isEmpty(pResponse.config.data)) {
                key += "/" + JSON.stringify(pResponse.config.data);
            }


            key = SHA512(key);

            var response = angular.copy(pResponse);
            delete response['status'];
            delete response['statusText'];
            delete response['headers'];
            delete response.config['method'];

            delete response.config['headers']['Accept'];
            delete response.config['headers']['Accept-Language'];
            delete response.config['headers']['Access-Control-Allow-Origin'];
            delete response.config['headers']['App-Version'];
            delete response.config['headers']['Content-Type'];
            delete response.config['headers']['User-Token'];

            delete response.config['transformRequest'];
            delete response.config['transformResponse'];

            LocalStorage.setObject(key, response);
        }
    }

    function getPublicResponse(pUrl, pJSONParams) {
        var key = pUrl;
        if (!ValidationUtil.isEmpty(pJSONParams)) {
            key += "/" + JSON.stringify(pJSONParams);
        }

        key = SHA512(key);

        var response = LocalStorage.getObject(key);

        //        if (response != null && response.config['headers']['Cache-Control'] == CacheControlType.PUBLIC) {
        //            return response;
        //        }
        //        return null;
    }

    function getOfflineResponse(pUrl, pJSONParams) {
        var key = pUrl;
        if (!ValidationUtil.isEmpty(pJSONParams)) {
            key += "/" + JSON.stringify(pJSONParams);
        }

        key = SHA512(key);

        var response = LocalStorage.getObject(key);;
        if (response != null && response.config['headers']['Cache-Control'] == CacheControlType.OFFLINE) {
            return response;
        }
        return null;
    }

    function clearCache() {
        for (var key in window.localStorage) {
            if (key.indexOf(GlobalConstants.BASE_URL) != -1) //found a httpRequest
            {
                LocalStorage.clear(key);
            }
        }
    }

    function cleanseCache(pCacheType) {
        // Based on a cache type, we will clear only some cached web services.
        /*
            TYPES :
            -> 0 : Trips related services
            -> 1 : Profile related services
            -> 2 : ...
        */
        var keysArray = [];
        switch (pCacheType) {
            case 1:
                // 1 = TRIP / SCORES
                console.log("CLEARING TRIP / SCORE RELATED CACHE");
                keysArray = [
                    GlobalConstants.BASE_URL + WebServiceUrls.GET_TRIPS,
                    GlobalConstants.BASE_URL + WebServiceUrls.GET_DAILY_SCORES,
                    GlobalConstants.BASE_URL + WebServiceUrls.GET_TRIP,
                    GlobalConstants.BASE_URL + WebServiceUrls.GET_LAST_TRIP,
                    GlobalConstants.BASE_URL + WebServiceUrls.GET_SCORE,
                    GlobalConstants.BASE_URL + WebServiceUrls.GET_TRIPS_DETAILS_FROM_DATES,
                    GlobalConstants.BASE_URL + WebServiceUrls.GET_LAST_TRIP_DETAILS_VEHICLE,
                    GlobalConstants.BASE_URL + WebServiceUrls.GET_TRIPS_DETAILS_FROM_DATES_VEHICLE,
                    GlobalConstants.BASE_URL + WebServiceUrls.GET_TRIPS_BY_VEHICLE_ID,
                    GlobalConstants.BASE_URL + WebServiceUrls.GET_LAST_TRIP_DETAILS,
                    GlobalConstants.BASE_URL + WebServiceUrls.GET_ACHIEVEMENT_PROGRESS,
                    GlobalConstants.BASE_URL + WebServiceUrls.GET_ACHIEVEMENTS
                ];
                break;
            case 2:
                // 2 = PROFILE
                console.log("CLEARING PROFILE RELATED CACHE");
                keysArray = [
                    GlobalConstants.BASE_URL + WebServiceUrls.GET_PROFILE,
                    GlobalConstants.BASE_URL + WebServiceUrls.GET_VEHICLE_PROFILE,
                    GlobalConstants.BASE_URL + WebServiceUrls.GET_AVATAR,
                    GlobalConstants.BASE_URL + WebServiceUrls.GET_PERSONAL_PROFILE
                ];
                break;
            case 3:
                // 3 = FAVORITES
                keysArray = [
                    GlobalConstants.BASE_URL + WebServiceUrls.GET_GENERAL_RANKINGS,
                    GlobalConstants.BASE_URL + WebServiceUrls.GET_ACHIEVEMENTS,
                    GlobalConstants.BASE_URL + WebServiceUrls.GET_ACHIEVEMENT_PROGRESS,
                    GlobalConstants.BASE_URL + WebServiceUrls.GET_ACHIEVEMENTS_LIST,
                    GlobalConstants.BASE_URL + WebServiceUrls.GET_CONTEST_LIST
                ];
                break;
            case 4:
                // 4 = ACHIEVEMENTS
                keysArray = [
                 GlobalConstants.BASE_URL + WebServiceUrls.GET_ACHIEVEMENTS,
                 GlobalConstants.BASE_URL + WebServiceUrls.GET_ACHIEVEMENT_PROGRESS
                ];
                break;
            case 5:
                // 5 = RANKING
                keysArray = [
                 GlobalConstants.BASE_URL + WebServiceUrls.GET_GENERAL_RANKINGS
                ];
                break;
            case 6:
                // 6 = SETTINGS
                keysArray = [
                 GlobalConstants.BASE_URL + WebServiceUrls.GET_CLIENT_COMMUNICATION_CONFIG,
                 GlobalConstants.BASE_URL + WebServiceUrls.GET_USER_SETTINGS
                ];
                break;
            case 7:
                // INSURANCE - PAYMENTS
                var UID = LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID);
                keysArray = [
                    GlobalConstants.PAS_URL + WebServiceUrls.APPLICATION_USERS + UID + WebServiceUrls.USER_PAYMENT_METHODS
                ];
                break;
            case 8:
                // Quotes
                var UID = LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID);
                keysArray = [
                    GlobalConstants.PAS_URL + WebServiceUrls.APPLICATION_USERS + UID + WebServiceUrls.CREATE_QUOTE
                ];
                break;
            case 9:
                // All Methods
                keysArray = [
                    GlobalConstants.PAS_URL + WebServiceUrls.APPLICATION_USERS + UID + WebServiceUrls.CREATE_QUOTE,
                    GlobalConstants.BASE_URL + WebServiceUrls.GET_TRIPS,
                    GlobalConstants.BASE_URL + WebServiceUrls.GET_DAILY_SCORES,
                    GlobalConstants.BASE_URL + WebServiceUrls.GET_TRIP,
                    GlobalConstants.BASE_URL + WebServiceUrls.GET_LAST_TRIP,
                    GlobalConstants.BASE_URL + WebServiceUrls.GET_SCORE,
                    GlobalConstants.BASE_URL + WebServiceUrls.GET_TRIPS_DETAILS_FROM_DATES,
                    GlobalConstants.BASE_URL + WebServiceUrls.GET_LAST_TRIP_DETAILS,
                    GlobalConstants.BASE_URL + WebServiceUrls.GET_LAST_TRIP_DETAILS_VEHICLE,
                    GlobalConstants.BASE_URL + WebServiceUrls.GET_TRIPS_DETAILS_FROM_DATES_VEHICLE,
                    GlobalConstants.BASE_URL + WebServiceUrls.GET_TRIPS_BY_VEHICLE_ID,
                    GlobalConstants.BASE_URL + WebServiceUrls.GET_ACHIEVEMENT_PROGRESS,
                    GlobalConstants.BASE_URL + WebServiceUrls.GET_ACHIEVEMENTS,
                    GlobalConstants.BASE_URL + WebServiceUrls.GET_PROFILE,
                    GlobalConstants.BASE_URL + WebServiceUrls.GET_VEHICLE_PROFILE,
                    GlobalConstants.BASE_URL + WebServiceUrls.GET_AVATAR,
                    GlobalConstants.BASE_URL + WebServiceUrls.GET_PERSONAL_PROFILE,
                    GlobalConstants.BASE_URL + WebServiceUrls.GET_GENERAL_RANKINGS,
                    GlobalConstants.BASE_URL + WebServiceUrls.GET_ACHIEVEMENTS,
                    GlobalConstants.BASE_URL + WebServiceUrls.GET_ACHIEVEMENT_PROGRESS,
                    GlobalConstants.BASE_URL + WebServiceUrls.GET_ACHIEVEMENTS_LIST,
                    GlobalConstants.BASE_URL + WebServiceUrls.GET_CONTEST_LIST,
                    GlobalConstants.BASE_URL + WebServiceUrls.GET_ACHIEVEMENTS,
                 GlobalConstants.BASE_URL + WebServiceUrls.GET_ACHIEVEMENT_PROGRESS,
                 GlobalConstants.BASE_URL + WebServiceUrls.GET_CLIENT_COMMUNICATION_CONFIG,
                 GlobalConstants.BASE_URL + WebServiceUrls.GET_USER_SETTINGS,
                 GlobalConstants.PAS_URL + WebServiceUrls.APPLICATION_USERS + UID + WebServiceUrls.USER_PAYMENT_METHODS
                ];
                break;
            case 10:
                // User balance Info.
                var UID = LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID);
                keysArray = [
                    GlobalConstants.PAS_URL + WebServiceUrls.APPLICATION_USERS + UID + WebServiceUrls.PAS_CORE + WebServiceUrls.POLICIES
                ];
                break;
        }

        for (var i = 0; i < keysArray.length; i++) {
            for (var key in window.localStorage) {
                if (key.indexOf(keysArray[i]) != -1) {
                    LocalStorage.clear(key);
                }
            }
        }
    }


    function fakeCacheControl(pResponse) {
        var publicServices = [
            WebServiceUrls.GET_SETTINGS,
            WebServiceUrls.GET_LOCALES,
            WebServiceUrls.GET_ACHIEVEMENTS_LIST
        ];
        var userId = LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID);
        var offlineServices = [
            WebServiceUrls.GET_PROFILE,
            WebServiceUrls.GET_TRIPS,
            WebServiceUrls.GET_TRIP,
            WebServiceUrls.GET_GIT_VERSION,
            WebServiceUrls.GET_VEHICLE_PROFILE,
            WebServiceUrls.GET_PERSONAL_PROFILE,
            WebServiceUrls.GET_SCORE,
            WebServiceUrls.GET_ACHIEVEMENTS,
            WebServiceUrls.GET_CLIENT_COMMUNICATION_CONFIG,
            WebServiceUrls.GET_VEHICLE_YEARS,
            WebServiceUrls.GET_VEHICLE_MAKE,
            WebServiceUrls.GET_VEHICLE_MODELS,
            WebServiceUrls.GET_USER_SETTINGS,
            WebServiceUrls.GET_DAILY_SCORES,
            WebServiceUrls.GET_DEVICES,
            WebServiceUrls.GET_LAST_TRIP,
            WebServiceUrls.GET_ACHIEVEMENT_PROGRESS,
            WebServiceUrls.GET_DOCUMENT,
            WebServiceUrls.GET_ALL_DOCUMENTS,
            WebServiceUrls.GET_HELP,
            WebServiceUrls.GET_CONTEST_LIST,
            //WebServiceUrls.GET_GENERAL_RANKINGS,
            WebServiceUrls.GET_IMAGES,
            WebServiceUrls.GET_MODIFIED_CONTESTS,
            WebServiceUrls.GET_AVATAR,
            WebServiceUrls.GET_VEHICLEINFO_BY_VIN,
            WebServiceUrls.GET_STATES_LIST,
            WebServiceUrls.GET_CREATION_DATE,
            WebServiceUrls.GET_DAILY_DETAILS_FROM_DATES,
            WebServiceUrls.GET_SEGMENTS_COLORS,
            WebServiceUrls.POLICY_PICTURES,
            WebServiceUrls.GET_LAST_TRIP_DETAILS,
            WebServiceUrls.GET_TRIPS_DETAILS_FROM_DATES,
            WebServiceUrls.GET_LAST_TRIP_DETAILS_VEHICLE,
            WebServiceUrls.GET_TRIPS_DETAILS_FROM_DATES_VEHICLE,
            WebServiceUrls.GET_TRIPS_BY_VEHICLE_ID,
            WebServiceUrls.GET_FRIEND_RECORDS,
            WebServiceUrls.GET_TRIP_HISTORY_COST,
            WebServiceUrls.GET_PACKAGES,
            WebServiceUrls.GET_REPAIR_SHOPS,
            WebServiceUrls.GET_INVOICE,
            WebServiceUrls.GET_INVOICES,
            WebServiceUrls.GET_USER_PAYMENTS,
            WebServiceUrls.GET_FAQS,
            WebServiceUrls.GET_TUTORIALS,
            WebServiceUrls.GET_QUOTES,
            WebServiceUrls.GET_QUOTE_ABOUT_YOU,
            WebServiceUrls.GET_QUOTE_VEHICLE,
            WebServiceUrls.REG_USERS,
            WebServiceUrls.APPLICATION_USERS + userId + WebServiceUrls.GET_PAS_POLICY_INFO
        ];

        // STRIP the parameters
        if (pResponse.config.url.indexOf(GlobalConstants.BASE_URL) > -1) {
            var methodPlusParams = pResponse.config.url.substr(GlobalConstants.BASE_URL.length);
            var methodName = "/" + methodPlusParams.split('/')[1];
        }

        pResponse.config['headers']['Cache-Control'] = CacheControlType.OFFLINE;
        return pResponse;
    }
}
