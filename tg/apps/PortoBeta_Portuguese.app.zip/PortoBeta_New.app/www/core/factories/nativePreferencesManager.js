angular.module('factories')
    .service('NativePreferencesManager', NativePreferencesManager);

function NativePreferencesManager(LocalStorage, LocalStorageKeys) {

    var mConfig = {};

    this.savePreferences = savePreferences;
    this.getPreference = getPreference;
    this.setPreference = setPreference;

    function savePreferences(pExtras) {
        mConfig = pExtras;
        LocalStorage.setObject(LocalStorageKeys.NATIVE_PREFERENCES, mConfig);
        LocalStorage.setBoolean(LocalStorageKeys.USE_WIFI_ONLY_STATE, mConfig['useWifiOnly']);
    }

    function getPreference(pKey) {
       // if (Object.keys(mConfig).length == 0) {
         //   mConfig = LocalStorage.getObject(LocalStorageKeys.NATIVE_PREFERENCES);
        //}
        return mConfig[pKey];
    }

    function setPreference(pKey, pValue) {
        mConfig[pKey] = pValue;
    }
}
