angular.module('factories')
    .service("CordovaReceiver", CordovaReceiver);

function CordovaReceiver($rootScope, LoggerUtil, TripStateFactory, NativePreferencesManager, FileUtil, ListenerUtil, DeviceFactory, TripState, MediaUtil, BridgeIntentType, ApplicationStateManager, GlobalEvent, PushNotificationUtil) {

    var TAG = "INTENT";
    var intentNotFoundCount = 0;
    var interval;
    var tempPextras;

    this.onNewIntent = onNewIntent;

    function onNewIntent(pAction, pExtras) {

        LoggerUtil.log(TAG, pAction + " " + ((pExtras) ? JSON.stringify(pExtras) : ''));
        intentNotFoundCount = 0;

        onNewIntent_trips(pAction, pExtras);
        onNewIntent_telemetryDevice(pAction, pExtras);
        onNewIntent_phoneState(pAction, pExtras);
        onNewIntent_misc(pAction, pExtras);
    }

    function updateGPS(pExtras) {
        clearInterval(interval);
        $rootScope.$broadcast(BridgeIntentType.GPS_STATE, tempPextras);
    }

    function onNewIntent_trips(pAction, pExtras) {
        switch (pAction) {
            case BridgeIntentType.ACTION_TRIP_STATUS:
                TripStateFactory.onTripStatus(pExtras);
                break;
            case BridgeIntentType.ACTION_TRIP_START:
                TripStateFactory.startTrip(pExtras.tripId);
                break;
            case BridgeIntentType.ACTION_TRIP_PAUSE:
                TripStateFactory.onActionTripPause();
                break;
            case BridgeIntentType.ACTION_TRIP_RESUME:
                TripStateFactory.onActionTripResume();
                break;
            case BridgeIntentType.ACTION_TRIP_STOP:
                TripStateFactory.stopTrip();
                break;
            case BridgeIntentType.ACTION_TRIP_TRANSMITTED:
                TripStateFactory.onTripTransmitted();
                break;
            case BridgeIntentType.ACTION_TRIP_TRANSMISSION_FAILURE:
                TripStateFactory.onActionTripTransmissionFailure();
                break;
            case BridgeIntentType.ACTION_TRIP_PROCESS_COMPLETE:
                TripStateFactory.onActionTripProcessComplete();
                break;
            case BridgeIntentType.SEND_TRIP_INFO:
                TripStateFactory.setTripInfo(pExtras);
                break;
            case BridgeIntentType.ACTION_IS_PASSENGER:
                TripStateFactory.actionIsPassenger(pExtras);
                break;
            default:
                intentNotFoundCount++;
        }
    }

    function onNewIntent_telemetryDevice(pAction, pExtras) {
        LoggerUtil.log("T2_INTENT", pAction + JSON.stringify(pExtras));

        switch (pAction) {
            case BridgeIntentType.PING_DEVICE_FAILED:
                DeviceFactory.onPingDeviceFailed(pExtras);
                break;
            case BridgeIntentType.DEVICE_READY:
                DeviceFactory.onDeviceReady(pExtras);
                break;
            case BridgeIntentType.DEVICE_DISCOVERED:
                DeviceFactory.onDeviceDiscovered(pExtras);
                break;
            case BridgeIntentType.DEVICE_DISAPPEARED:
                DeviceFactory.onDeviceDisappeared(pExtras);
                break;
            case BridgeIntentType.DEVICE_CONNECT_FAILED:
                DeviceFactory.onDeviceConnectFailed(pExtras);
                break;
            case BridgeIntentType.TELEMETRY_ISSUE_DETECTED:
                DeviceFactory.onTelemetryIssueDetected(pExtras);
                break;
            case BridgeIntentType.DEVICE_DISCONNECTED:
                DeviceFactory.onDeviceDisconnected(pExtras);
                break;
            case BridgeIntentType.BLE_NOT_AVAILABLE:
                DeviceFactory.onBluetoothNotSupported(pExtras);
                break;
            case BridgeIntentType.BLE_START_SCAN:
                DeviceFactory.onBLEScanStarted(pExtras);
                break;
            case BridgeIntentType.BLE_END_SCAN:
                DeviceFactory.onBLEScanEnded(pExtras);
                break;
            case BridgeIntentType.DEVICE_CONNECTED:
                DeviceFactory.onDeviceConnected(pExtras);
                break;
            case BridgeIntentType.DEVICE_FOTA_STARTED:
                DeviceFactory.onDeviceFotaStarted(pExtras);
                break;
            case BridgeIntentType.DEVICE_FOTA_PROGRESS:
                DeviceFactory.onDeviceFotaProgress(pExtras);
                break;
            case BridgeIntentType.DEVICE_FOTA_COMPLETED:
                DeviceFactory.onDeviceFotaCompleted(pExtras);
                break;
            case BridgeIntentType.DEVICE_FOTA_CANCELLED:
                DeviceFactory.onDeviceFotaCancelled(pExtras);
                break;
            case BridgeIntentType.DEVICE_DATA_RX:
                DeviceFactory.onDeviceDataRx(pExtras);
                break;
            case BridgeIntentType.DEVICE_DATA_TX:
                DeviceFactory.onDeviceDataTx(pExtras);
                break;
            case BridgeIntentType.DEVICE_DATA_TX_FAILED:
                DeviceFactory.onDeviceDataTxFailed(pExtras);
                break;
            case BridgeIntentType.GOOGLE_PLAY_ISSUE_DETECTED:
                DeviceFactory.googlePlayIssueDetected(pExtras);
                break;
            case BridgeIntentType.T2_START_CONFIGURATION:
                DeviceFactory.onDeviceStartConfiguration(pExtras);
                break;
            case BridgeIntentType.T2_PROGRESS_CONFIGURATION:
                DeviceFactory.onDeviceProgressConfiguration(pExtras);
                break;
            case BridgeIntentType.T2_END_CONFIGURATION:
                DeviceFactory.onDeviceEndConfiguration(pExtras);
                break;
            case BridgeIntentType.T2_LOG_DATA_AVAILABLE:
                DeviceFactory.onDeviceLogDataAvailable(pExtras);
                break;
            case BridgeIntentType.T2_LOG_DATA_RX:
                DeviceFactory.onDeviceLogDataRx(pExtras);
                break;
            case BridgeIntentType.T2_LOG_DATA_COMPLETE:
                DeviceFactory.onDeviceLogDataComplete(pExtras);
                break;
            default:
                intentNotFoundCount++;
        }
    }

    function onNewIntent_phoneState(pAction, pExtras) {
        switch (pAction) {

            //     case BridgeIntentType.WIFI_STATE:
            //     ApplicationStateManager.onWifiStateChangedIntentRecieved(pExtras);
            //     break;
            //     case BridgeIntentType.BLUETOOTH_STATE:
            //     ApplicationStateManager.onBluetoothStateChangedIntentRecieved(pExtras);
            //     break;
            case BridgeIntentType.GPS_STATE:
                console.log("INTENT_RECEIVED -> GPS_STATE :", pExtras);
                //ApplicationStateManager.onGPSStateChangedIntentRecieved(pExtras);
                $rootScope.$broadcast(BridgeIntentType.GPS_STATE, pExtras);
                break;
                //     case BridgeIntentType.AIRPLANE_MODE_STATE:
                //     ApplicationStateManager.onAirplaneModeChangedIntentRecieved(pExtras);
                //     break;
                //     case BridgeIntentType.CELLULAR_DATA_STATE:
                //     ApplicationStateManager.onCellularDataStateIntentRecieved(pExtras);
                //     break;
            default:
                intentNotFoundCount++;
        }
    }

    function onNewIntent_misc(pAction, pExtras) {
        switch (pAction) {
            case BridgeIntentType.INIT_USER_SETTINGS:

                NativePreferencesManager.savePreferences(pExtras);
                ListenerUtil.playEvent(GlobalEvent.INIT_USER_SETTINGS_RECEIVED);

                tempPextras = pExtras;
                if (pExtras && pExtras.gps_state !== undefined && pExtras.gps_state !== null && pExtras.gps_state === false) {
                    interval = setInterval(updateGPS, 5000);
                }
                
                break;
            case BridgeIntentType.NOTIFICATION_LINK:
                ListenerUtil.playEvent(BridgeIntentType.NOTIFICATION_LINK, pExtras.tripId);
                break;
            case BridgeIntentType.ACCELERATION:
                var applicationDir = FileUtil.getApplicationDirectory();
                var url = applicationDir + 'www/client/sounds/hac.mp3';
                MediaUtil.playSound(url);
                break;
            case BridgeIntentType.DECCELERATION:
                var applicationDir = FileUtil.getApplicationDirectory();
                var url = applicationDir + 'www/client/sounds/hbr.mp3';
                MediaUtil.playSound(url);
                break;
            case BridgeIntentType.LOW_BATTERY:
                console.log("########## RECEIVED INTENT - LOW_BATTERY ############", pExtras);
                ListenerUtil.playEvent(BridgeIntentType.LOW_BATTERY, pExtras);
                break;
            case BridgeIntentType.OKAY_BATTERY:
                console.log("########## RECEIVED INTENT - OKAY_BATTERY ############", pExtras);
                ListenerUtil.playEvent(BridgeIntentType.ACTION_OKAY_BATTERY, pExtras);
                break;
            case BridgeIntentType.NOTIFICATION_DATA:
                pExtras = pExtras.aps;
                var vrextrasdata = {
                    alert: pExtras.alert,
                    endDate: "",
                    startDate: "",
                    title: pExtras.title,
                    additionalData: {
                        foreground: false,
                        notificationType: pExtras.notificationType,
                        contestId: pExtras.contestId
                    }
                }
                PushNotificationUtil.redirectToScreen(vrextrasdata);
                //
            default:
                intentNotFoundCount++
                if (intentNotFoundCount == 4) {
                    LoggerUtil.log(TAG, "Default Case in CordovaReceiver.onNewIntent Action : " + pAction + " extras : " + JSON.stringify(pExtras));
                }
        }
    }
}
