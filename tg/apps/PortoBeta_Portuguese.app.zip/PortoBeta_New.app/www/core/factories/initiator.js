angular.module('factories')
    .run(Initiator);

function Initiator(ConversionUtil, UnitTestManager, ListenerUtil, LoggerUtil, CordovaBroadcaster, ClientSettings_Language, AchievementsUtil, GlobalConstants, LocalStorage, LocalStorageKeys, HttpProxy, ClientSettings, GlobalEvent, MockFactory,ApplicationStateManager) {

    ListenerUtil.registerListener(GlobalEvent.INIT_USER_SETTINGS_RECEIVED, null, initClientApp);

    ionic.Platform._checkPlatforms();
    if (ionic.Platform.platforms[0] == 'browser') {
        LocalStorage.setBoolean(LocalStorageKeys.IS_IN_BROWSER, true);
        //fake the INIT_User
        MockFactory.fakeInitUserSettingsIntent();
        LoggerUtil.log("DEBUG", "IN BROWSER");
    } else {
        LocalStorage.setBoolean(LocalStorageKeys.IS_IN_BROWSER, false);
        LoggerUtil.log("DEBUG", "NOT IN BROWSER");
    }

    function initClientApp() {
        GlobalConstants.init();
		ApplicationStateManager.init();
        sendLocaleKey();
        if (HttpProxy.checkIfLoggedIn()) {
            ConversionUtil.initConversionSetting();
            if (LocalStorage.get(LocalStorageKeys.SEND_USER_CREDENTIAL_STATE) == null) {
                LocalStorage.set(LocalStorageKeys.SEND_USER_CREDENTIAL_STATE, "NOT_SENT");
            }
        }


        function sendLocaleKey() {
            ionic.Platform.ready(function () {
                var localLanguageKey = navigator.language;
                var currentkey = LocalStorage.get(LocalStorageKeys.CURRENT_LOCALE_KEY);
                if (currentkey != null) {
                    localLanguageKey = currentkey;
                }
                CordovaBroadcaster.setLocaleKey(localLanguageKey);

            });
        }
    }
}
