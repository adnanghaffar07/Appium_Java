angular.module('factories')
    .service('OfflineLoginFactory', OfflineLoginFactory);

function OfflineLoginFactory(ValidationUtil, StringUtil, LocalStorage, LocalStorageKeys, LoginType) {
    var mCredentials = null;


    this.testFunctionalities = testFunctionalities;
    this.saveLoginCredentials = saveLoginCredentials;
    this.isValidLogin = isValidLogin;
    this.clearCredentials = clearCredentials;

    function testFunctionalities() {
        var className = "OfflineLoginFactory";

        //save the already present credentials
        oldCredentials = LocalStorage.getObject(LocalStorageKeys.OFFLINE_LOGIN_CREDENTIALS);

        //empty Credentials bank
        this.clearCredentials();
        console.assert(false == this.isValidLogin(LoginType.TBYB, "email", "password"),
            StringUtil.format("{0} : isValidLogin(LoginType.TBYB,'email','password') should return false because the factory is empty", className));

        //empty request
        console.assert(false == this.isValidLogin(),
            StringUtil.format("{0} : isValidLogin() should return false because it received an empty request", className));


        //partial request
        console.assert(false == this.isValidLogin(LoginType.TBYB, "email"),
            StringUtil.format("{0} : isValidLogin(LoginType.TBYB,'email') should return false because it received a partial request", className));


        //rightCombinaison
        this.saveLoginCredentials(LoginType.TBYB, "email", "password");
        console.assert(true == this.isValidLogin(LoginType.TBYB, "email", "password"),
            StringUtil.format("{0} : isValidLogin(LoginType.TBYB,'email','password') should return true because we just called the saveLoginCredentials(LoginType.TBYB,'email','password')", className));

        //wrongCombinaison1
        console.assert(false == this.isValidLogin(LoginType.TBYB, "email1", "password"),
            StringUtil.format("{0} : isValidLogin(LoginType.TBYB,'email1','password') should return false because we just called the saveLoginCredentials(LoginType.TBYB,'email','password')", className));

        //wrongCombinaison2
        console.assert(false == this.isValidLogin(LoginType.TBYB, "email", "password1"),
            StringUtil.format("{0} : isValidLogin(LoginType.TBYB,'email','password1') should return false because we just called the saveLoginCredentials(LoginType.TBYB,'email','password')", className));
        //cleared Credentials
        this.clearCredentials();
        console.assert(false == this.isValidLogin(LoginType.TBYB, "email", "password"),
            StringUtil.format("{0} : isValidLogin(LoginType.TBYB,'email','password') should return false because we just cleared the CredentialsBank", className));


        //empty Credentials bank
        console.assert(false == this.isValidLogin(LoginType.CLIENT, "email", "password"),
            StringUtil.format("{0} : isValidLogin(LoginType.CLIENT,'email','password') should return false because the factory is empty", className));

        //empty request
        console.assert(false == this.isValidLogin(),
            StringUtil.format("{0} : isValidLogin() should return false because it received an empty request", className));


        //partial request
        console.assert(false == this.isValidLogin(LoginType.CLIENT, "email"),
            StringUtil.format("{0} : isValidLogin(LoginType.CLIENT,'email') should return false because it received a partial request", className));


        //rightCombinaison
        this.saveLoginCredentials(LoginType.CLIENT, "email", "password");
        console.assert(true == this.isValidLogin(LoginType.CLIENT, "email", "password"),
            StringUtil.format("{0} : isValidLogin(LoginType.CLIENT,'email','password') should return true because we just called the saveLoginCredentials(LoginType.CLIENT,'email','password')", className));

        //wrongCombinaison1
        console.assert(false == this.isValidLogin(LoginType.CLIENT, "email1", "password"),
            StringUtil.format("{0} : isValidLogin(LoginType.CLIENT,'email1','password') should return false because we just called the saveLoginCredentials(LoginType.CLIENT,'email','password')", className));

        //wrongCombinaison2
        console.assert(false == this.isValidLogin(LoginType.CLIENT, "email", "password1"),
            StringUtil.format("{0} : isValidLogin(LoginType.CLIENT,'email','password1') should return false because we just called the saveLoginCredentials(LoginType.CLIENT,'email','password')", className));

        //save in tbyb read in client
        this.saveLoginCredentials(LoginType.TBYB, "email23", "password23");
        console.assert(false == this.isValidLogin(LoginType.CLIENT, "email23", "password23"),
            StringUtil.format("{0} : isValidLogin(LoginType.CLIENT,'email23','password23') should return false because we just called the saveLoginCredentials(LoginType.CLIENT,'email23','password23')", className));


        //save in client read in tbyb
        this.saveLoginCredentials(LoginType.CLIENT, "email24", "password24");
        console.assert(false == this.isValidLogin(LoginType.TBYB, "email24", "password24"),
            StringUtil.format("{0} : isValidLogin(LoginType.CLIENT,'email24','password24') should return false because we just called the saveLoginCredentials(LoginType.CLIENT,'email24','password24')", className));


        //cleared Credentials
        this.clearCredentials();
        console.assert(false == this.isValidLogin(LoginType.CLIENT, "email", "password"),
            StringUtil.format("{0} : isValidLogin(LoginType.CLIENT,'email','password') should return false because we just cleared the CredentialsBank", className));





        //FACEBOOK
        console.assert(false == this.isValidLogin(LoginType.FACEBOOK, "facebookEmail"), StringUtil.format("{0} : isValidLogin(LoginType.FACEBOOK,'facebookEmail') should return false because we just cleared the CredentialsBank", className));


        this.saveLoginCredentials(LoginType.FACEBOOK, "facebookEmail");

        console.assert(false == this.isValidLogin(LoginType.FACEBOOK, "facebookEmail2"), StringUtil.format("{0} : isValidLogin(LoginType.FACEBOOK,'facebookEmail2') should return false", className));
        console.assert(true == this.isValidLogin(LoginType.FACEBOOK, "facebookEmail"), StringUtil.format("{0} : isValidLogin(LoginType.FACEBOOK,'facebookEmail') should return true", className));

        console.assert(false == this.isValidLogin(LoginType.TBYB, "facebookEmail"), StringUtil.format("{0} : isValidLogin(LoginType.TBYB,'facebookEmail') should return false", className));

        console.assert(false == this.isValidLogin(LoginType.GOOGLE, "facebookEmail"), StringUtil.format("{0} : isValidLogin(LoginType.GOOGLE,'facebookEmail') should return false", className));

        this.clearCredentials();
        console.assert(false == this.isValidLogin(LoginType.FACEBOOK, "facebookEmail"), StringUtil.format("{0} : isValidLogin(LoginType.FACEBOOK,'facebookEmail') should return false", className));


        //GOOGLE PLUS
        console.assert(false == this.isValidLogin(LoginType.GOOGLE, "googleEmail"), StringUtil.format("{0} : isValidLogin(LoginType.FACEGOOGLEBOOK,'googleEmail') should return false because we just cleared the CredentialsBank", className));

        this.saveLoginCredentials(LoginType.GOOGLE, "googleEmail");
        console.assert(false == this.isValidLogin(LoginType.GOOGLE, "googleEmail2"), StringUtil.format("{0} : isValidLogin(LoginType.GOOGLE,'googleEmail2') should return false", className));
        console.assert(true == this.isValidLogin(LoginType.GOOGLE, "googleEmail"), StringUtil.format("{0} : isValidLogin(LoginType.GOOGLE,'googleEmail') should return true", className));

        console.assert(false == this.isValidLogin(LoginType.TBYB, "googleEmail"), StringUtil.format("{0} : isValidLogin(LoginType.TBYB,'googleEmail') should return false", className));

        console.assert(false == this.isValidLogin(LoginType.FACEBOOK, "googleEmail"), StringUtil.format("{0} : isValidLogin(LoginType.FACEBOOK,'googleEmail') should return false", className));

        this.clearCredentials();
        console.assert(false == this.isValidLogin(LoginType.GOOGLE, "googleEmail"), StringUtil.format("{0} : isValidLogin(LoginType.GOOGLE,'googleEmail') should return false", className));


        //restore the already present credentials
        if (oldCredentials != null) {
            saveLoginCredentials(oldCredentials.loginType, oldCredentials.user, oldCredentials.password);
        }

    }

    function saveLoginCredentials(pLoginType, pEmail, pPassword) {
        mCredentials = {
            loginType: pLoginType,
            email: pEmail,
            password: pPassword
        };
        LocalStorage.setObject(LocalStorageKeys.OFFLINE_LOGIN_CREDENTIALS, mCredentials);
    }

    function isValidLogin(pLoginType, pEmail, pPassword) {

        if (ValidationUtil.isEmpty(pLoginType, pEmail) ||
            ((pLoginType == LoginType.TBYB_RB || pLoginType == LoginType.UBI_RB || pLoginType == LoginType.TBYB_PPM || pLoginType == LoginType.UBI_PPM) && ValidationUtil.isEmpty(pPassword))) {
            return false;
        }

        if (mCredentials == null) {
            mCredentials = LocalStorage.getObject(LocalStorageKeys.OFFLINE_LOGIN_CREDENTIALS, {});
        }
        if (!ValidationUtil.isEmpty(pLoginType) && mCredentials.email == pEmail && mCredentials.password == pPassword) {
            return true;
        }
        return false;
    }

    function clearCredentials() {
        mCredentials = null;
        LocalStorage.clear(LocalStorageKeys.OFFLINE_LOGIN_CREDENTIALS);
    }
}
