angular.module('factories')
    .service('ApplicationStateManager', ApplicationStateManager);

function ApplicationStateManager(ListenerUtil, NativePreferencesManager, ValidationUtil, PhoneSwitchType, StringUtil, BridgeIntentType) {

    var mStates = {};
    this.init = init;
    this.getState = getState;

    this.onGPSStateChangedIntentRecieved = onGPSStateChangedIntentRecieved;

    function init() {
        mStates[PhoneSwitchType.WIFI] = NativePreferencesManager.getPreference('wifi_state');
        mStates[PhoneSwitchType.BLUETOOTH] = NativePreferencesManager.getPreference('bluetooth_state');
        mStates[PhoneSwitchType.AIRPLANE_MODE] = NativePreferencesManager.getPreference('airplane_mode_state');
        mStates[PhoneSwitchType.GPS] = NativePreferencesManager.getPreference('gps_state');
        mStates[PhoneSwitchType.CELLULAR_DATA] = NativePreferencesManager.getPreference('cellular_data_state');
    }

    /**
    @param pEventType : value from PhoneSwitchType constant
    */
    function getState(pPhoneSwitchType) {
        //if(Object.keys(mStates).length == 0){
        //	init();
        //}
        ValidationUtil.validateEnum(PhoneSwitchType, pPhoneSwitchType);
        return mStates[pPhoneSwitchType];
    }

    function onGPSStateChangedIntentRecieved(pState) {
        //mStates[PhoneSwitchType.GPS] = pState.gps_state;
        ListenerUtil.playEvent(BridgeIntentType.GPS_STATE, pState);

    }

}
