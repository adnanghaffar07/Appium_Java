angular.module("factories")
    .service("DeviceFactory", DeviceFactory);

function DeviceFactory(ListenerUtil, DeviceFactoryEvent, TelemetryServices, GlobalConstants, WebServiceUrls, $q, $timeout, $interval, LoggerUtil, CordovaBroadcaster, DeviceType, TimeoutValues, DeviceConnectionError, ClientSettings, BridgeIntentType, TetheringStatus, DeviceStatus, PopupUtil, $translate) {

    this.init = init;
    this.initByDevice = initByDevice;
    this.getDevices = TelemetryServices.getDevices;
    this.registerEvent = registerEvent;
    this.checkDeviceConnection = checkDeviceConnection;
    this.onPingDeviceFailed = onPingDeviceFailed;
    this.startDeviceScan = startDeviceScan;

    this.onDeviceReady = onDeviceReady;
    this.onDeviceDiscovered = onDeviceDiscovered;
    this.onDeviceDisappeared = onDeviceDisappeared;
    this.onDeviceConnectFailed = onDeviceConnectFailed;
    this.onDeviceDisconnected = onDeviceDisconnected;
    this.onTelemetryIssueDetected = onTelemetryIssueDetected;
    this.onBluetoothNotSupported = onBluetoothNotSupported;
    this.onBLEScanStarted = onBLEScanStarted;
    this.onBLEScanEnded = onBLEScanEnded;
    this.onBLEDisabled = onBLEDisabled;
    this.onDeviceConnected = onDeviceConnected;
    this.onDeviceFotaStarted = onDeviceFotaStarted;
    this.onDeviceFotaProgress = onDeviceFotaProgress;
    this.onDeviceFotaCancelled = onDeviceFotaCancelled;
    this.onDeviceFotaCompleted = onDeviceFotaCompleted;
    this.onDeviceDataRx = onDeviceDataRx;
    this.onDeviceDataTx = onDeviceDataTx;
    this.onDeviceDataTxFailed = onDeviceDataTxFailed;
    this.onDeviceStartConfiguration = onDeviceStartConfiguration;
    this.onDeviceProgressConfiguration = onDeviceProgressConfiguration;
    this.onDeviceEndConfiguration = onDeviceEndConfiguration;
    this.onDeviceLogDataAvailable = onDeviceLogDataAvailable;
    this.onDeviceLogDataRx = onDeviceLogDataRx;
    this.onDeviceLogDataComplete = onDeviceLogDataComplete;
    this.googlePlayIssueDetected = googlePlayIssueDetected;

    const TAG = "T2_INTENT";

    var mQ = null;
    var mDevices = null;

    this.tetheringStatus = {
        bleStatus: TetheringStatus.IDLE,
        bleScanCount: 0,
        bleLastScanTimeStamp: -1,
        UID: null,
        deviceStatus: DeviceStatus.NOT_CONNECTED,
        deviceRxCount: 0,
        deviceTxCount: 0,
        deviceTxFailCount: 0,
        deviceTxSeq: null,
        deviceTimestamp: -1,
        deviceFotaProgress: -1,
        deviceConfigProgress: -1,
        deviceLogDataProgress: -1,
        deviceProgress: 0,
        deviceData: [],
        devices: [] // --> This wil be to delete once everything work without devices...
    };

    function init() {
        this.getDevices().then(function (pDevices) {
            for (var i = 0; i < pDevices.length; i++) {
                var item = {
                    UID: null,
                    type: null,
                    status: null,
                    RxCount: 0,
                    TxCount: 0,
                    TxFailCount: 0,
                    TxSeq: null,
                    timeStamp: -1,
                    fotaProgress: -1,
                    data: []
                };
                item.type = pDevices[i].Device.DeviceModel.type;
                item.UID = pDevices[i].Device.uid;

                this.tetheringStatus.devices.push(item);
            }
        });
        //load initialValue from the init_userSetting INTENT TODO HGC 
    }

    function initByDevice(uid) {
        var item = {
            UID: uid,
            type: "T2",
            status: null,
            RxCount: 0,
            TxCount: 0,
            TxFailCount: 0,
            TxSeq: null,
            timeStamp: -1,
            fotaProgress: -1,
            data: []
        };

        this.tetheringStatus.devices = [item];
    }


    function onBLEScanStarted(pExtras) {
        console.log("BLE SCAN STARTED\n##########\n");
        this.tetheringStatus.bleLastScanTimeStamp = moment().format('x');
        this.tetheringStatus.bleStatus = TetheringStatus.SCANNING;
        this.tetheringStatus.bleScanCount++;
        this.tetheringStatus.deviceStatus = DeviceStatus.SCANNING;
    }

    function onBLEScanEnded(pExtras) {
        console.log("BLE SCAN ENDED\n##########\n");
        this.tetheringStatus.bleStatus = TetheringStatus.WAITING;
        this.tetheringStatus.deviceStatus = DeviceStatus.END_SCANNING;
    }

    function onBLEDisabled(pExtras){
        console.log("BLE DISABLED\n##########\n");
        this.tetheringStatus.bleStatus = TetheringStatus.WAITING;
        this.tetheringStatus.deviceStatus = DeviceStatus.BLE_DISABLED;
    }
    
    function onDeviceConnected(pExtras) {
        console.log("DEVICE CONNECTED" + JSON.stringify(pExtras) + "\n##########\n");
        this.tetheringStatus.deviceStatus = DeviceStatus.CONNECTED;
        this.tetheringStatus.UID = pExtras.UID;
        this.tetheringStatus.deviceTimestamp = moment().format('x');
        this.tetheringStatus.deviceData.push("<span>---- DEVICE CONNECTED ----</span><br />" + JSON.stringify(pExtras) + "<br /><br />");

        // Below to be deleted once working without devices.
        var device = getDeviceByUID(this.tetheringStatus.devices, pExtras.UID);
        if (device) {
            device.status = DeviceStatus.CONNECTED;
            device.timeStamp = moment().format('x');
        }
    }

    function onDeviceFotaStarted(pExtras) {
        console.log("DEVICE FOTA STARTED" + JSON.stringify(pExtras) + "\n##########\n");
        this.tetheringStatus.deviceStatus = DeviceStatus.FOTA_STARTED;
        this.tetheringStatus.deviceTimestamp = moment().format('x');
        this.tetheringStatus.deviceData.push("<span>---- FOTA STARTED ----</span> <br />" + JSON.stringify(pExtras) + "<br /><br />");

        // to be deleted
        var device = getDeviceByUID(this.tetheringStatus.devices, pExtras.UID);
        if (device) {
            device.status = DeviceStatus.FOTA_STARTED;
            device.timeStamp = moment().format('x');
        }
    }

    function onDeviceFotaProgress(pExtras) {
        console.log("DEVICE FOTA PROGRESS" + JSON.stringify(pExtras) + "\n##########\n");
        this.tetheringStatus.deviceStatus = DeviceStatus.FOTA_PROGRESS;
        this.tetheringStatus.deviceFotaProgress = pExtras.progress;
        this.tetheringStatus.deviceProgress = pExtras.progress;
        this.tetheringStatus.deviceTimestamp = moment().format('x');
        this.tetheringStatus.deviceData.push("<span>---- FOTA PROGRESS ----</span> <br />" + JSON.stringify(pExtras) + "<br /><br />");

        // To be deleted
        var device = getDeviceByUID(this.tetheringStatus.devices, pExtras.UID);
        if (device) {
            device.status = DeviceStatus.FOTA_PROGRESS;
            device.fotaProgress = pExtras.progress;
            device.timeStamp = moment().format('x');
        }
    }

    function onDeviceFotaCancelled(pExtras) {
        console.log("DEVICE FOTA CANCELLED" + JSON.stringify(pExtras) + "\n##########\n");
        this.tetheringStatus.deviceStatus = DeviceStatus.FOTA_CANCELLED;
        this.tetheringStatus.UID = pExtras.UID;
        this.tetheringStatus.deviceTimestamp = moment().format('x');
        this.tetheringStatus.deviceData.push("<span>---- FOTA CANCELLED ----</span><br />" + JSON.stringify(pExtras) + "<br /><br />");

        setStatusToConnected();

        // to delete
        var device = getDeviceByUID(this.tetheringStatus.devices, pExtras.UID);
        if (device) {
            device.status = DeviceStatus.FOTA_CANCELLED;
            device.timeStamp = moment().format('x');
        }
    }

    function onDeviceFotaCompleted(pExtras) {
        console.log("DEVICE FOTA COMPLETED" + JSON.stringify(pExtras) + "\n##########\n");
        this.tetheringStatus.deviceStatus = DeviceStatus.FOTA_COMPLETED;
        this.tetheringStatus.deviceTimestamp = moment().format('x');
        this.tetheringStatus.deviceData.push("<span>---- FOTA COMPLETED ----</span> <br />" + JSON.stringify(pExtras) + "<br /><br />");

        setStatusToConnected();

        // to delete        
        var device = getDeviceByUID(this.tetheringStatus.devices, pExtras.UID);
        if (device) {
            device.status = DeviceStatus.FOTA_COMPLETED;
            device.timeStamp = moment().format('x');
        }
    }

    function onDeviceDataRx(pExtras) {
        console.log("DEVICE DATA RX" + JSON.stringify(pExtras) + "\n##########\n");
        this.tetheringStatus.deviceRxCount++;
        this.tetheringStatus.UID = pExtras.UID;
        this.tetheringStatus.deviceTimestamp = moment().format('x');
        this.tetheringStatus.deviceData.push("<span>---- DATA RECEIVED ----</span> <br />" + JSON.stringify(pExtras) + "<br /><br />");

        // to delete
        var device = getDeviceByUID(this.tetheringStatus.devices, pExtras.UID);
        if (device) {
            device.RxCount++;
            device.timeStamp = moment().format('x');
            device.data.push("\n\n ---------- \n\n" + pExtras.data);
        }
    }

    function onDeviceDataTx(pExtras) {
        console.log("DEVICE DATA TX" + JSON.stringify(pExtras) + "\n##########\n");
        this.tetheringStatus.deviceTxCount++;
        this.tetheringStatus.deviceTxSeq = pExtras.seq;
        this.tetheringStatus.deviceTimestamp = moment().format('x');
        this.tetheringStatus.deviceData.push("<span>---- DATA TRANSMITTED ----</span> <br />" + JSON.stringify(pExtras) + "<br /><br />");

        // to delete
        var device = getDeviceByUID(this.tetheringStatus.devices, pExtras.UID);
        if (device) {
            device.TxCount++;
            device.timeStamp = moment().format('x');
            device.TxSeq = pExtras.seq;
        }
    }

    function onDeviceDataTxFailed(pExtras) {
        console.log("DEVICE DATA TX FAILED" + JSON.stringify(pExtras) + "\n##########\n");
        this.tetheringStatus.deviceTxFailCount++;
        this.tetheringStatus.UID = pExtras.UID;
        this.tetheringStatus.deviceTimestamp = moment().format('x');
        this.tetheringStatus.deviceData.push("<span>---- DATA TRANSMITION FAILED ----</span> <br />" + JSON.stringify(pExtras) + "<br /><br />");

        // to delete
        var device = getDeviceByUID(this.tetheringStatus.devices, pExtras.UID);
        if (device) {
            device.timeStamp = moment().format('x');
            device.TxFailCount++;
        }
    }

    function onDeviceStartConfiguration(pExtras) {
        console.log("DEVICE CONFIG START" + JSON.stringify(pExtras) + "\n##########\n");
        this.tetheringStatus.deviceStatus = DeviceStatus.CONFIG_STARTED;
        this.tetheringStatus.deviceConfigProgress = pExtras.progress;
        this.tetheringStatus.deviceProgress = pExtras.progress;
        this.tetheringStatus.deviceData.push("<span>---- DEVICE CONFIG START ----</span> <br />" + JSON.stringify(pExtras) + "<br /><br />");
        this.tetheringStatus.UID = pExtras.UID;
        this.tetheringStatus.deviceTimestamp = moment().format('x');
    }

    function onDeviceProgressConfiguration(pExtras) {
        console.log("DEVICE CONFIG PROGRESS" + JSON.stringify(pExtras) + "\n##########\n");
        this.tetheringStatus.deviceStatus = DeviceStatus.CONFIG_PROGRESS;
        this.tetheringStatus.deviceConfigProgress = pExtras.progress;
        this.tetheringStatus.deviceProgress = pExtras.progress;
        this.tetheringStatus.deviceData.push("<span>---- DEVICE CONFIG PROGRESS ----</span> <br />" + JSON.stringify(pExtras) + "<br /><br />");
        this.tetheringStatus.UID = pExtras.UID;
        this.tetheringStatus.deviceTimestamp = moment().format('x');
    }

    function onDeviceEndConfiguration(pExtras) {
        console.log("DEVICE CONGIF END" + JSON.stringify(pExtras) + "\n##########\n");
        this.tetheringStatus.deviceStatus = DeviceStatus.CONNECTED;
        this.tetheringStatus.deviceConfigProgress = pExtras.progress;
        this.tetheringStatus.deviceProgress = pExtras.progress;
        this.tetheringStatus.UID = pExtras.UID;
        this.tetheringStatus.deviceData.push("<span>---- DEVICE CONFIG END ----</span> <br />" + JSON.stringify(pExtras) + "<br /><br />");
        this.tetheringStatus.deviceTimestamp = moment().format('x');
        //setStatusToConnected();
    }

    function onDeviceLogDataAvailable(pExtras) {
        console.log("DEVICE LOG DATA AVAILABLE" + JSON.stringify(pExtras) + "\n##########\n");
        this.tetheringStatus.deviceStatus = DeviceStatus.DATA_AVAILABLE;
        this.tetheringStatus.deviceLogDataProgress = pExtras.progress;
        this.tetheringStatus.deviceProgress = pExtras.progress;
        this.tetheringStatus.UID = pExtras.UID;
        this.tetheringStatus.deviceData.push("<span>---- LOG DATA AVAILABLE ----</span> <br />" + JSON.stringify(pExtras) + "<br /><br />");
        this.tetheringStatus.deviceTimestamp = moment().format('x');
    }

    function onDeviceLogDataRx(pExtras) {
        console.log("DEVICE LOG DATA PROGRESS" + JSON.stringify(pExtras) + "\n##########\n");
        this.tetheringStatus.deviceStatus = DeviceStatus.DATA_PROGRESS;
        this.tetheringStatus.deviceLogDataProgress = pExtras.progress;
        this.tetheringStatus.deviceProgress = pExtras.progress;
        this.tetheringStatus.UID = pExtras.UID;
        this.tetheringStatus.deviceData.push("<span>---- LOG DATA PROGRESS ----</span> <br />" + JSON.stringify(pExtras) + "<br /><br />");
        this.tetheringStatus.deviceTimestamp = moment().format('x');
    }

    function onDeviceLogDataComplete(pExtras) {
        console.log("DEVICE LOG DATA COMPLETED" + JSON.stringify(pExtras) + "\n##########\n");
        this.tetheringStatus.deviceStatus = DeviceStatus.DATA_COMPLETED;
        this.tetheringStatus.deviceLogDataProgress = pExtras.progress;
        this.tetheringStatus.deviceProgress = pExtras.progress;
        this.tetheringStatus.UID = pExtras.UID;
        this.tetheringStatus.deviceData.push("<span>---- LOG DATA COMPLETED ----</span> <br />" + JSON.stringify(pExtras) + "<br /><br />");
        this.tetheringStatus.deviceTimestamp = moment().format('x');
        setStatusToConnected();
    }

    function setStatusToConnected() {
        $timeout(function () {
            this.tetheringStatus.deviceStatus = DeviceStatus.CONNECTED;
        }, 500);
    }

    /**
    @param pEventType : value from DeviceFactoryEvent constant
    @param pCallback : function to be called on specificEvent triggered
    */
    function registerEvent(pEventType, pCallback) {
        ListenerUtil.registerListener(pEventType, null, pCallback);
    }

    //***************** PUBLIC ***************************//

    function checkDeviceConnection(pDeviceType) {
        switch (pDeviceType) {
            case DeviceType.T2:
                return initT2Connection();
            default:
                console.warn("Default case in initDeviceConnection");
        }
    }

    function onDeviceReady(pExtras) {
        if (mQ) {
            mQ.resolve(pExtras.UID);
        }
        this.tetheringStatus.UID = pExtras.UID;
        this.tetheringStatus.deviceStatus = DeviceStatus.READY;
        this.tetheringStatus.deviceTimestamp = moment().format('x');
        this.tetheringStatus.deviceData.push("<span>---- DEVICE READY ----</span> <br />" + JSON.stringify(pExtras) + "<br /><br />");
        ListenerUtil.playEvent(BridgeIntentType.DEVICE_READY, pExtras);

        // to delete
        var device = getDeviceByUID(this.tetheringStatus.devices, pExtras.UID);
        if (device) {
            device.status = DeviceStatus.READY;
            device.timeStamp = moment().format('x');
        }
    }

    function onPingDeviceFailed(pExtras) {
        if (mQ) {
            mQ.reject(pExtras.reason);
        }
        ListenerUtil.playEvent(BridgeIntentType.PING_DEVICE_FAILED, pExtras);
    }

    function onDeviceDiscovered(pExtras) {
        console.log("DEVICE DISCOVERED" + JSON.stringify(pExtras) + "\n##########");
        ListenerUtil.playEvent(BridgeIntentType.DEVICE_DISCOVERED, pExtras);
        this.tetheringStatus.UID = pExtras.UID;
        this.tetheringStatus.deviceStatus = DeviceStatus.DISCOVERED;
        this.tetheringStatus.deviceTimestamp = moment().format('x');
        this.tetheringStatus.deviceData.push("<span>---- DEVICE DISCOVERED ----</span> <br />" + JSON.stringify(pExtras) + "<br /><br />");

        // to delete
        var device = getDeviceByUID(this.tetheringStatus.devices, pExtras.UID);
        if (device) {
            device.status = DeviceStatus.DISCOVERED;
            device.timeStamp = moment().format('x');
        }
    }

    function onDeviceDisappeared(pExtras) {
        console.log("DEVICE DISAPPEARED" + JSON.stringify(pExtras) + "\n##########");
        ListenerUtil.playEvent(BridgeIntentType.DEVICE_DISAPPEARED, pExtras);
        this.tetheringStatus.deviceStatus = DeviceStatus.DISAPPEARED;
        this.tetheringStatus.deviceTimestamp = moment().format('x');
        this.tetheringStatus.deviceData.push("<span>---- DEVICE DISAPPEARED ----</span> <br />" + JSON.stringify(pExtras) + "<br /><br />");

        // to delete
        var device = getDeviceByUID(this.tetheringStatus.devices, pExtras.UID);
        if (device) {
            device.status = DeviceStatus.DISAPPEARED;
            device.timeStamp = moment().format('x');
        }
    }

    function onDeviceConnectFailed(pExtras) {
        console.log("DEVICE CONNECTION FAILED" + JSON.stringify(pExtras) + "\n##########");
        ListenerUtil.playEvent(BridgeIntentType.DEVICE_CONNECT_FAILED, pExtras);
        this.tetheringStatus.deviceStatus = DeviceStatus.CONNECT_FAILED;
        this.tetheringStatus.deviceTimestamp = moment().format('x');
        this.tetheringStatus.deviceData.push("<span>---- DEVICE CONNECTION FAILED ----</span> <br />" + JSON.stringify(pExtras) + "<br /><br />");

        // to delete
        var device = getDeviceByUID(this.tetheringStatus.devices, pExtras.UID);
        if (device) {
            device.status = DeviceStatus.CONNECT_FAILED;
            device.timeStamp = moment().format('x');
        }
    }

    function onDeviceDisconnected(pExtras) {
        console.log("DEVICE DISCONNECTED" + JSON.stringify(pExtras) + "\n##########");
        ListenerUtil.playEvent(BridgeIntentType.DEVICE_DISCONNECTED, pExtras);
        this.tetheringStatus.UID = pExtras.UID;
        this.tetheringStatus.deviceStatus = DeviceStatus.DISCONNECTED;
        this.tetheringStatus.deviceTimestamp = moment().format('x');
        this.tetheringStatus.deviceData.push("<span>---- DEVICE DISCONNECTED ----</span> <br />" + JSON.stringify(pExtras) + "<br /><br />");

        // to delete
        var device = getDeviceByUID(this.tetheringStatus.devices, pExtras.UID);
        if (device) {
            device.status = DeviceStatus.DISCONNECTED;
            device.timeStamp = moment().format('x');
            device.data.push("\n\n ---------- \n\n" + "DEVICE DISCONNECTED");
        }
    }

    function onTelemetryIssueDetected(pExtras) {
        ListenerUtil.playEvent(BridgeIntentType.TELEMETRY_ISSUE_DETECTED, pExtras);
        this.tetheringStatus.UID = pExtras.UID;
        this.tetheringStatus.deviceStatus = DeviceStatus.TELEMETRY_ISSUE_DETECTED;
        this.tetheringStatus.deviceTimestamp = moment().format('x');
        this.tetheringStatus.deviceData.push("<span>---- TELEMETRY ISSUE DETECTED ----</span> <br />" + JSON.stringify(pExtras) + "<br /><br />");

        // to delete
        var device = getDeviceByUID(this.tetheringStatus.devices, pExtras.UID);
        if (device) {
            device.status = DeviceStatus.TELEMETRY_ISSUE_DETECTED;
            device.timeStamp = moment().format('x');
        }
        var button = [{
            text: '<span>' + $translate.instant('common_OK') + '</span>'
                }];
        PopupUtil.showSimpleAlert($translate.instant("deviceConnection_connectionErrorTitle"),
            "<p translate>" + pExtras.key + "</p>", button);
    }

    function onBluetoothNotSupported(pExtras) {
        ListenerUtil.playEvent(BridgeIntentType.BLE_NOT_AVAILABLE, pExtras);
    }

    function googlePlayIssueDetected(pExtras) {
        var button = [{
            text: '<span>' + $translate.instant('common_OK') + '</span>'
                }];
        PopupUtil.showSimpleAlert($translate.instant("deviceConnection_connectionErrorTitle"),
            "<p translate>" + pExtras.key + "</p>", button);
    }

    //**************** PRIVATE *********************//


    function getDeviceByUID(pDevices, pUID) {
        for (var i = 0; i < pDevices.length; i++) {
            if (pDevices[i].UID == pUID) {
                return pDevices[i];
            }
        }
        return null;
    }

    function initT2Connection() {
        mQ = $q.defer();
        var deviceUID = null;
        if (mDevices) {
            for (var i = 0; i < mDevices.length; i++) {
                if (mDevices[i].Device.DeviceModel.type == DeviceType.T2) {
                    deviceUID = mDevices[i].UserDevice.UID;
                }
            }
        }
        if (deviceUID == null) {
            mQ.reject(DeviceConnectionError.NO_DEVICE_OF_THAT_TYPE_FOUND);
        } else {
            CordovaBroadcaster.pingDevice(deviceUID);
            $timeout(pingDeviceTimeout, TimeoutValues.DEVICE_PING);
            if (ClientSettings.fakeT2Connection) {
                fakeReceivedCallForNative(); //TODO HGC Remove this
            }
        }
        return mQ.promise;
    }

    function pingDeviceTimeout() {
        mQ.reject(DeviceConnectionError.CONNECTION_TIMEOUT);
    }

    function startDeviceScan() {
        // Will trigger the SCAN_START
        CordovaBroadcaster.startDeviceScan();
    }

    function fakeReceivedCallForNative() { //TODO HGC Remove this
        this.onDeviceReady({
            UID: "FAKE_UID"
        });
    }
}
