angular.module('factories', [])
    .service('TripStateFactory', TripStateFactory);

function TripStateFactory($timeout, TripState, ListenerUtil,
    CordovaBroadcaster, LocalStorage, LocalStorageKeys, WebServiceCache) {

    const TRIP_STATE_CHANGED = "TRIP_STATE_CHANGED";
    const TRIP_INFO_CHANGED = "TRIP_INFO_CHANGED";
    const TRIP_PROCESS_COMPLETE = "TRIP_PROCESS_COMPLETE";
    const RELOAD_RATE = 1000; //TODO HGC use live_trip_infomation_refresh_rate
    var mTripInfo = null;

    this.getTripId = getTripId;
    this.startTrip = startTrip;
    this.stopTrip = stopTrip;
    this.is = is;
    this.getTripState = getTripState;
    this.registerTripStatusChanged = registerTripStatusChanged;
    this.registerTripInfoChanged = registerTripInfoChanged;
    this.registerTripProcessComplete = registerTripProcessComplete;
    this.setTripInfo = setTripInfo;
    this.onTripStatus = onTripStatus;
    this.onTripTransmitted = onTripTransmitted;
    this.onActionTripTransmissionFailure = onActionTripTransmissionFailure;
    this.onActionTripProcessComplete = onActionTripProcessComplete;
    this.onActionTripPause = onActionTripPause;
    this.onActionTripResume = onActionTripResume;
    this.actionIsPassenger = actionIsPassenger;

    //***************** PUBLIC *****************
    function getTripId() {
        if (mTripInfo) {
            return mTripInfo.tripId;
        }
        return null;
    }

    function startTrip(pTripId) {
        mTripInfo = new TripInformation();
        mTripInfo.tripId = pTripId;
        mTripInfo.state = TripState.STARTED;

        startGetTripInfoLiveReload();
        ListenerUtil.playEvent(TRIP_STATE_CHANGED, mTripInfo);
    }

    function stopTrip() {
        if (mTripInfo) {
            mTripInfo.state = TripState.STOPPED;
        }
        stopGetTripInfoLiveReload();
        ListenerUtil.playEvent(TRIP_STATE_CHANGED, mTripInfo);
    }

    function is(pTripState) {
        var tripState = null;
        if (mTripInfo == null) {
            tripState = TripState.STOPPED;
        } else {
            tripState = mTripInfo.state;
        }
        return (tripState == pTripState);
    }

    function getTripState() {
        var tripState = null;
        if (mTripInfo == null) {
            tripState = TripState.STOPPED;
        } else {
            tripState = mTripInfo.state;
        }
        return tripState;
    }

    function registerTripStatusChanged(pCallback) {
        ListenerUtil.registerListener(TRIP_STATE_CHANGED, null, pCallback);
    }

    function registerTripInfoChanged(pCallback) {
        ListenerUtil.registerListener(TRIP_INFO_CHANGED, null, pCallback);
    }

    function registerTripProcessComplete(pCallback) {
        ListenerUtil.registerListener(TRIP_PROCESS_COMPLETE, null, pCallback);
    }

    function setTripInfo(pExtras) {
        if (mTripInfo != null) {
            mTripInfo.duration = pExtras.duration;
            mTripInfo.distance = pExtras.distance;
            mTripInfo.speed = pExtras.speed;
            mTripInfo.heading = pExtras.heading;
            mTripInfo.cardinalHeading = pExtras.cardinalHeading;
        }
        ListenerUtil.playEvent(TRIP_INFO_CHANGED, pExtras);
    }

    function onTripStatus(pExtras) {

        if (pExtras.status == TripState.STARTED) {
            startTrip(pExtras.tripId);
        } else if (pExtras.status == TripState.PAUSED) {
            startTrip(pExtras.tripId);
            setTripState(TripState.PAUSED);
        } else if (pExtras.status == TripState.STOPPED) {
            stopTrip();
        }
    }

    function onTripTransmitted() {
        setTripState(TripState.TRANSMITTED);
        WebServiceCache.cleanseCache(1);

        $timeout(function () {
          //  setTripState(TripState.STOPPED);
            ListenerUtil.playEvent(TRIP_PROCESS_COMPLETE);
        }, 15000);
    }

    function onActionTripTransmissionFailure() {
        setTripState(TripState.TRANSMITTED_FAILED);
        $timeout(function () {
         //   setTripState(TripState.STOPPED);
            ListenerUtil.playEvent(TRIP_PROCESS_COMPLETE);
        }, 15000);
    }

    function onActionTripProcessComplete() {
        stopTrip();
        ListenerUtil.playEvent(TRIP_PROCESS_COMPLETE);
    }

    function onActionTripPause() {
        setTripState(TripState.PAUSED);
    }

    function onActionTripResume() {
        setTripState(TripState.STARTED);
    }

    function actionIsPassenger(pExtras) {
        LocalStorage.set(LocalStorageKeys.TRIP_AS_PASSENGER, pExtras.isPassenger);
    }

    //***************** PUBLIC *****************
    //***************** PRIVATE *****************

    function setTripState(pTripState) {
        if (mTripInfo == null) {
            mTripInfo = new TripInformation();
        }
        mTripInfo.state = pTripState;
        ListenerUtil.playEvent(TRIP_STATE_CHANGED, mTripInfo);
    }

    //***************** PRIVATE *****************

    //***************** liveReload *****************
    var liveReloadRunning = false;

    function startGetTripInfoLiveReload() {
        liveReloadRunning = true;
        callRequestTripInformation();
    }

    function scheduleNextReload() {
        $timeout(callRequestTripInformation, RELOAD_RATE);
    }

    function callRequestTripInformation() {
        CordovaBroadcaster.requestTripInformation();
        if (liveReloadRunning) {
            scheduleNextReload();
        }
    }

    function stopGetTripInfoLiveReload() {
        liveReloadRunning = false;
    }

    //***************** liveReload *****************


}
