/**
 * cordova Web Intent plugin
 * Copyright (c) Boris Smus 2010
 *
 */
(function (cordova) {
    var WebIntent = function () {

    };

    var mTestCallback = null;
    var mLogs = [];

    WebIntent.prototype.ACTION_SEND = "android.intent.action.SEND";
    WebIntent.prototype.ACTION_VIEW = "android.intent.action.VIEW";
    WebIntent.prototype.EXTRA_TEXT = "android.intent.extra.TEXT";
    WebIntent.prototype.EXTRA_SUBJECT = "android.intent.extra.SUBJECT";
    WebIntent.prototype.EXTRA_STREAM = "android.intent.extra.STREAM";
    WebIntent.prototype.EXTRA_EMAIL = "android.intent.extra.EMAIL";
    WebIntent.prototype.ACTION_CALL = "android.intent.action.CALL";
    WebIntent.prototype.ACTION_SENDTO = "android.intent.action.SENDTO";

    WebIntent.prototype.startActivity = function (params, success, fail) {
        if (cordova != null) {
            return cordova.exec(function (args) {
                success(args);
            }, function (args) {
                fail(args);
            }, 'WebIntent', 'startActivity', [params]);
        }
    };

    WebIntent.prototype.hasExtra = function (params, success, fail) {
        return cordova.exec(function (args) {
            success(args);
        }, function (args) {
            fail(args);
        }, 'WebIntent', 'hasExtra', [params]);
    };

    WebIntent.prototype.getUri = function (success, fail) {
        return cordova.exec(function (args) {
            success(args);
        }, function (args) {
            fail(args);
        }, 'WebIntent', 'getUri', []);
    };

    WebIntent.prototype.getExtra = function (params, success, fail) {
        return cordova.exec(function (args) {
            success(args);
        }, function (args) {
            fail(args);
        }, 'WebIntent', 'getExtra', [params]);
    };


    WebIntent.prototype.onNewIntent = function (callback) {
        mTestCallback = callback;
        if (cordova != null) {
            return cordova.exec(function (args) {
                mLogs.push(JSON.stringify(args));
                callback(args);
            }, function (args) {}, 'WebIntent', 'onNewIntent', []);
        }
    };

    WebIntent.prototype.sendBroadcast = function (params, success, fail) {
        mLogs.push(JSON.stringify(params));
        if (cordova != null) {
            return cordova.exec(function (args) {
                success(args);
            }, function (args) {
                fail(args);
            }, 'WebIntent', 'sendBroadcast', [params]);
        } else {
            if (angular.isDefined(fail))
                fail("[WebIntent] unavailable " + JSON.stringify(params));
        }
    };

    WebIntent.prototype.testOnNewIntent = function (json) {
        if (mTestCallback) {
            mLogs.push(JSON.stringify(json));
            mTestCallback(json);
        }
    }
    WebIntent.prototype.getLogs = function () {

        var logs = JSON.stringify(mLogs);
        var finalData = logs.replace(/\\/g, '');

        return finalData;
    }

    window.webintent = new WebIntent();

    // backwards compatibility
    window.plugins = window.plugins || {};
    window.plugins.webintent = window.webintent;
})(window.PhoneGap || window.Cordova || window.cordova);