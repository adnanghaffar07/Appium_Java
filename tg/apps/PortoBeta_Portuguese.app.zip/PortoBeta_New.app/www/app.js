// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
// 'starter.controllers' is found in controllers.js
angular.module('starter', ['ionic', 'controllers', 'factories', 'googlechart', 'services', 'constants', 'util', 'localStorage', 'pascalprecht.translate', 'ngCordova', 'ngSanitize', 'ionic-pullup', 'ngIOS9UIWebViewPatch', 'ngImgCrop'])
    .run(function ($ionicPlatform, $cordovaSplashscreen, $rootScope) {
        $ionicPlatform.ready(function () {
            $rootScope.networkStatus = {};
            if (window.StatusBar) {
                StatusBar.styleDefault();
            }
            if (window.cordova && window.cordova.plugins.Keyboard) {
                cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
            }
            /*setTimeout(function ()  {
                $cordovaSplashscreen.hide();
            }, 2000);*/
        });
    })

.run(function ($rootScope, $cordovaSplashscreen, PopupUtil, PushNotificationUtil, ListenerUtil, $state, $timeout, NetworkConnectionUtil, ConnectionConstants, AppConfigServices, LocalStorage, LocalStorageKeys) {

        var data = LocalStorage.getObject(LocalStorageKeys.THEME_COLORS, null);
        if (data == null) {
            AppConfigServices.getThemeColors().then(function (data) {
                setThemeColors(data);
            }, function (error) {
                setTimeout(function () {
                    $cordovaSplashscreen.hide();
                }, 40000);
            });
        } else {
            setThemeColors(data);
        }

        function setThemeColors(data) {
            data.mainBackground = "#203252";
            data.secondaryBackground = "#FFF";
            data.menuBackground = "#203252";
            data.textMain = "#7f7f7f";
            data.textPrimary = "#FFF";
            data.textSecondary = "#289fd8";
            data.lightBackground = "#289fd8";
            $rootScope.themeColors = data;
            LocalStorage.setObject(LocalStorageKeys.THEME_COLORS, data);
        }

        $rootScope.networkStatus = {};
        $rootScope.$on('$stateChangeStart', function () {
            if ($rootScope.popUp) {
                $rootScope.popUp.close();
            }
            NetworkConnectionUtil.getConnectionType().then(function (connectionType) {
                if (!connectionType) {
                    $timeout(function () {
                        $rootScope.networkStatus.isAvailable = false;
                        $('.has-header').addClass('has-nonetwork-banner');
                    }, 250);
                } else {
                    $rootScope.networkStatus.isAvailable = true;
                    $('.has-header').removeClass('has-nonetwork-banner');
                }
            });
        });
        ListenerUtil.registerListener('CONTEST_NOTIFICATION', null, function (extra) {
            var contest = {};
            contest.contestId = extra;
            $state.go("app.prizesDetail", {
                "specificContest": contest
            });
        });
    })
    .config(function ($ionicConfigProvider) {

        // Here we use $ionicConfigProvider to override some platform specific behaviors to keep the same behavior on every device.
        // ie. On Android, tabs are by default at the top of the screen and on IOS they are at the bottom.
        // We want tabs to be at the bottom on both ios and android.
        // If you need it, here is the link to go : http://ionicframework.com/docs/nightly/api/provider/%24ionicConfigProvider/
        $ionicConfigProvider.tabs.position("bottom");
        $ionicConfigProvider.backButton.previousTitleText(false);
        $ionicConfigProvider.backButton.text('');
        $ionicConfigProvider.backButton.icon('ion-ios-arrow-back');
        $ionicConfigProvider.navBar.alignTitle("center");
        $ionicConfigProvider.tabs.style("standard");
        $ionicConfigProvider.views.swipeBackEnabled(false);
    })
    .config(function ($httpProvider) {
        $httpProvider.defaults.headers.common['Access-Control-Allow-Origin'] = '*';
        $httpProvider.defaults.headers.post['Content-Type'] = 'application/json';
        $httpProvider.defaults.headers.post['App-Version'] = '1.0';
        $httpProvider.defaults.headers.post['Accept'] = 'application/json';
    })
    .config(function ($translateProvider, LocalStorageKeys, $compileProvider) {
        $translateProvider.useLoader('CustomTranslateLoader', {});
        $compileProvider.imgSrcSanitizationWhitelist(/^\s*(https?|local|data|content|file):/);
        $translateProvider.determinePreferredLanguage(function () {
            var key = window.localStorage[LocalStorageKeys.CURRENT_LOCALE_KEY];
            return key;
            // define a function to determine the language
            // and return a language key
        });
    })
    .config(function ($stateProvider, $urlRouterProvider) {

        $stateProvider
            .state('debug', {
                url: "/debug",
                templateUrl: "core/templates/debug.html",
                controller: 'DebugCtrl'
            })
            .state('debugScreen', {
                url: "/debug-screen",
                templateUrl: "core/templates/debug-screen.html",
                controller: 'DebugScreenCtrl'
            })
            .state('noLocationService', {
                url: "/no-location-service",
                templateUrl: "client/templates/no-location-service.html",
                controller: 'NoLocationServiceCtrl'
            })
            .state('activation', {
                url: '/activation',
                cache: false,
                templateUrl: 'client/templates/testdrive-activation.html',
                controller: 'TestdriveActivationCtrl'
            })
            .state('login', {
                url: '/login',
                cache: false,
                templateUrl: 'client/templates/login.html',
                controller: 'LoginCtrl'
            })
            .state('register', {
                url: '/register',
                templateUrl: 'client/templates/register.html',
                controller: 'RegisterCtrl'
            })
            .state('app.smsValidation', {
                url: "/profile/smsValidation",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/sms-validation.html",
                        controller: "SmsValidationCtrl"
                    }
                }
            })
            .state('requestCode', {
                url: '/request-code',
                cache: false,
                templateUrl: 'client/templates/request-activation-code.html',
                controller: 'RequestActivationCodeCtrl'
            })
            .state('consent', {
                url: '/consent',
                templateUrl: 'client/templates/consent.html',
                controller: 'ConsentCtrl'
            })
            .state('forgotPassword', {
                url: '/forgot-password',
                templateUrl: 'client/templates/forgot-password.html',
                controller: 'ForgotPasswordCtrl'
            })
            .state('newUserTutorial', {
                url: "/new-user-tutorial",
                templateUrl: "client/templates/new-user-tutorial.html",
                controller: "NewUserTutorialCtrl"
            })
            .state('app', {
                url: "/app",
                abstract: true,
                templateUrl: "client/templates/menu.html",
                controller: 'MenuCtrl'
            })
            .state('app.gaq', {
                url: "/get-a-quote",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/gaq.html",
                        controller: "GaqCtrl"
                    }
                }
            })
            .state('ltpSplash', {
                url: '/ltp-splash',
                templateUrl: 'client/templates/ltp-splash.html',
                controller: 'LtpSplashCtrl'
            })
            .state('ltpContentBlocked', {
                url: '/ltp-content-blocked',
                templateUrl: 'client/templates/ltp-content-blocked.html',
                controller: 'LtpContentBlockedCtrl'
            })
            .state('app.dashboard', {
                url: "/dashboard",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/dashboard.html",
                        controller: "DashboardCtrl"
                    }
                }
            })
            .state('app.dashboardPorto', {
                url: "/porto/dashboard",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/porto/dashboard.html",
                        controller: "DashboardPortoCtrl"
                    }
                }
            })
            .state('app.dashboardPpm', {
                url: "/dashboard-ppm",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/dashboard-ppm.html",
                        controller: "DashboardPpmCtrl"
                    }
                }
            })
            .state('app.dashboardHelp', {
                url: "/dashboard-help",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/dashboard-help.html",
                        controller: "DashboardHelpCtrl"
                    }
                }
            })
            .state('app.tripHistory', {
                url: "/trip-history",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/trip-history.html",
                        controller: "TripHistoryCtrl"
                    }
                }
            })
            .state('app.tripHistoryDetails', {
                url: "/trip-history-details",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/trip-history-details.html",
                        controller: "TripHistoryDetailsCtrl"
                    }
                },
                params: {
                    trip_id: null,
                    tripTypes: null,
                    tripTypesData: null
                }
            })
            .state('app.tripHistoryDetailsLegends', {
                url: "/trip-history-details-legends",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/trip-history-legends.html",
                        controller: "TripHistoryLegendsCtrl"
                    }
                },
                params: {
                    trip_id: null,
                    tripTypes: null,
                    tripTypesData: null
                }
            })
            .state('app.tripHistoryDetailsPpm', {
                url: "/trip-history-details-ppm",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/trip-history-details-ppm.html",
                        controller: "TripHistoryDetailsPpmCtrl"
                    }
                },
                params: {
                    trip_id: null,
                    tripTypes: null,
                    tripTypesData: null
                }
            })
            .state('app.tripHistoryCalendar', {
                url: "/trip-history-calendar",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/trip-history-calendar.html",
                        controller: "TripHistoryCalendarCtrl"
                    }
                }
            })
            .state('app.tripHistoryCalendarPpm', {
                url: "/trip-history-calendar-ppm",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/trip-history-calendar-ppm.html",
                        controller: "TripHistoryCalendarPpmCtrl"
                    }
                }
            })
            .state('app.profile', {
                url: "/profile",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/profile.html",
                        controller: "ProfileCtrl"
                    }
                }
            })
            .state('app.profileName', {
                url: "/profile/name",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/profile-name.html",
                        controller: "ProfileNameCtrl"
                    }
                }
            })
            .state('app.profileUsername', {
                url: "/profile/username",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/profile-username.html",
                        controller: "ProfileUsernameCtrl"
                    }
                }
            })
            .state('app.profileGender', {
                url: "/profile/gender",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/profile-gender.html",
                        controller: "ProfileGenderCtrl"
                    }
                }
            })
            .state('app.profilePayment', {
                url: "/profile/payment",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/profile-payment.html",
                        controller: "ProfilePaymentCtrl"
                    }
                }
            })
            .state('app.profileAddPayment', {
                url: "/profile/add-payment",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/profile-add-payment.html",
                        controller: "ProfileAddPaymentCtrl"
                    }
                }
            })
            .state('app.profileAddPaymentScan', {
                url: "/profile/add-payment/scan",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/profile-add-payment-scan.html",
                        controller: "ProfileAddPaymentScanCtrl"
                    }
                }
            })
            .state('app.profileAddPaymentPaypal', {
                url: "/profile/add-payment/paypal",
                cache: false,
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/profile-add-payment-paypal.html",
                        controller: "ProfileAddPaymentPaypalCtrl"
                    }
                },
                params: {
                    specificPayment: {}
                }
            })
            .state('app.profileAddPaymentCardDetails', {
                url: "/profile/add-payment/card-details",
                cache: false,
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/profile-add-payment-Carddetails.html",
                        controller: "ProfileAddPaymentCardDetailsCtrl"
                    }
                },
                params: {
                    specificPayment: {},
                    isCardScanned: false
                }
            })
            .state('app.profileDriversLicense', {
                url: "/profile/driverslicense",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/profile-driverlicense.html",
                        controller: "ProfileDriversLicenseCtrl"
                    }
                }
            })
            .state('app.profileDateOfBirth', {
                url: "/profile/dateOfBirth",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/profile-dateOfBirth.html",
                        controller: "ProfileDateOfBirthCtrl"
                    }
                }
            })
            .state('app.profilePassword', {
                url: "/profile/password",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/profile-password.html",
                        controller: "ProfilePasswordCtrl"
                    }
                }
            })
            .state('app.profileResetPassword', {
                url: "/profile/reset-password",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/profile-resetPassword.html",
                        controller: "ProfileResetPasswordCtrl"
                    }
                }
            })
            .state('app.profileEmail', {
                url: "/profile/email",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/profile-email.html",
                        controller: "ProfileEmailCtrl"
                    }
                }
            })
            .state('app.profileAddress', {
                url: "/profile/address",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/profile-address.html",
                        controller: "ProfileAddressCtrl"
                    }
                }
            })
            .state('app.profileMobileNumber', {
                url: "/profile/mobile-number",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/profile-mobilenumber.html",
                        controller: "ProfileMobileNumberCtrl"
                    }
                }
            })
            .state('app.profileFacebook', {
                url: "/profile/facebook",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/profile-facebook.html",
                        controller: "ProfileFacebookCtrl"
                    }
                }
            })
            .state('app.profileVehicleInfo', {
                url: "/profile/vehicleInfo",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/profile-vehicle-info.html",
                        controller: "ProfileVehicleInfoCtrl"
                    }
                }
            })
            .state('app.profilePictures', {
                url: "/profile/pictures",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/profile-pictures.html",
                        controller: "ProfilePicturesCtrl"
                    }
                }
            })
            .state('app.profilePictureZoom', {
                url: "/profile/picture-zoom",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/profile-picture-zoom.html",
                        controller: "ProfilePictureZoomCtrl"
                    }
                },
                params: {
                    specificPicture: {}
                }
            })
            .state('app.profileInsuranceName', {
                url: "/profile/insurance-name",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/profile-insurance-name.html",
                        controller: "ProfileInsuranceNameCtrl"
                    }
                },
                params: {
                    specificPicture: {}
                }
            })
            .state('app.profileInsurancePremium', {
                url: "/profile/insurance-premium",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/profile-insurance-premium.html",
                        controller: "ProfileInsurancePremiumCtrl"
                    }
                },
                params: {
                    specificPicture: {}
                }
            })
            .state('app.profileInsuranceExpirancy', {
                url: "/profile/insurance-expire",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/profile-insurance-expirancy.html",
                        controller: "ProfileInsuranceExpirancyCtrl"
                    }
                },
                params: {
                    specificPicture: {}
                }
            })
            .state('app.settings', {
                url: "/settings",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/settings.html",
                        controller: "SettingsCtrl"
                    }
                }
            })
            .state('app.settingsAutoStart', {
                url: "/settings/auto-start",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/settings-autostart.html",
                        controller: "AutoStartCtrl"
                    }
                }
            })
            .state('app.settingsCarbit', {
                url: "/settings/carbit",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/settings-carbit.html",
                        controller: "CarbitCtrl"
                    }
                }
            })
            .state('app.settingsLanguages', {
                url: "/settings/languages",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/settings-languages.html",
                        controller: "LanguagesCtrl"
                    }
                }
            })
            .state('app.settingsCarbitShippingStatus', {
                url: "/settings/carbit-shipping-status",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/settings-carbit-shipping-status.html",
                        controller: "CarbitShippingStatusCtrl"
                    }
                }
            })
            .state('app.settingsCarbitUpdate', {
                url: "/settings/carbit-update",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/settings-carbit-update.html",
                        controller: "CarbitUpdateCtrl"
                    }
                }
            })
            .state('app.settingsCarbitReleaseNotes', {
                url: "/settings/carbit-release-notes",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/settings-carbit-release-notes.html",
                        controller: "CarbitReleaseNotesCtrl"
                    }
                }
            })
            .state('app.settingsCarbitUpdateText', {
                url: "/settings/carbit-update-text",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/settings-carbit-update-text.html",
                        controller: "CarbitUpdateTextCtrl"
                    }
                }
            })
            .state('app.settingsCarbitConnection', {
                url: "/settings/carbit-connection",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/settings-carbit-connection.html",
                        controller: "CarbitConnectionCtrl"
                    }
                }
            })
            .state('app.settingsGeneralConditions', {
                url: "/settings/general-conditions",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/settings-generalconditions.html",
                        controller: "GeneralConditionsCtrl"
                    }
                }
            })
            .state('app.settingsContestRules', {
                url: "/settings/contest-rules",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/settings-contestrules.html",
                        controller: "ContestRulesCtrl"
                    }
                }
            })
            .state('app.faq', {
                url: "/faq",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/settings-faq.html",
                        controller: "FaqCtrl"
                    }
                }
            })
            .state('app.faqCategory', {
                url: "/faq-category",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/settings-faq-category.html",
                        controller: "FaqCategoryCtrl"
                    }
                },
                params: {
                    "category": []
                }
            })
            .state('app.faqCategoryArticle', {
                url: "/faq-category-article",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/settings-faq-category-article.html",
                        controller: "FaqCategoryArticleCtrl"
                    }
                },
                params: {
                    "article": []
                }
            })
            .state('app.settingsTutorials', {
                url: "/settings/tutorials",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/settings-tutorials.html",
                        controller: "TutorialsCtrl"
                    }
                }
            })
            .state('app.settingsPrivacyPolicy', {
                url: "/settings/privacy-policy",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/settings-privacypolicy.html",
                        controller: "PrivacyPolicyCtrl"
                    }
                }
            })
            .state('app.settingsReportProblem', {
                url: "/settings/report-problem",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/settings-reportaproblem.html",
                        controller: "ReportProblemCtrl"
                    }
                }
            })
            .state('app.achievements', {
                url: "/achievements",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/achievements.html",
                        controller: "AchievementsCtrl"
                    }
                }
            })
            .state('app.achievementsDetails', {
                url: "/achievements/details",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/achievements-details.html",
                        controller: "AchievementsDetailsCtrl"
                    }
                },
                params: {
                    "achievement": ''
                }
            })
            .state('app.badges', {
                url: "/badges",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/badges.html",
                        controller: "BadgesCtrl"
                    }
                }
            })
            .state('app.missions', {
                url: "/missions",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/missions.html",
                        controller: "MissionsCtrl"
                    }
                }
            })
            .state('app.missions_score', {
                url: "/missionsScore",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/mission-score.html",
                        controller: "MissionScoreCtrl"
                    }
                }
            })
            .state('app.coins', {
                url: "/coins",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/coins.html",
                        controller: "CoinsCtrl"
                    }
                }
            })
            .state('app.leaderboard', {
                url: "/leaderboard",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/leaderboard.html",
                        controller: "LeaderboardCtrl"
                    }
                }
            })
            .state('app.leaderboardAdd', {
                url: "/leaderboard-add",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/leaderboard-add.html",
                        controller: "LeaderboardAddCtrl"
                    }
                }
            })
            .state('app.leaderboardAddSearch', {
                url: "/leaderboard-add-search",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/leaderboard-add-search.html",
                        controller: "LeaderboardAddSearchCtrl"
                    }
                }
            })
            .state('app.leaderboardAddContacts', {
                url: "/leaderboard-add-contacts",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/leaderboard-add-contacts.html",
                        controller: "LeaderboardAddContactsCtrl"
                    }
                }
            })
            .state('app.leaderboardConnectFacebook', {
                url: "/leaderboard/connect/facebook",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/leaderboard-connect-facebook.html",
                        controller: 'LeaderboardConnectFacebookCtrl'
                    }
                }
            })
            .state('app.leaderboardAddFacebookFriends', {
                url: "/leaderboard/add/facebookfriends",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/leaderboard-add-facebookfriends.html",
                        controller: 'LeaderboardAddFacebookFriendsCtrl'
                    }
                }
            })
            .state('app.leaderboardInvites', {
                url: "/leaderboard/invites",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/leaderboard-invites.html",
                        controller: 'LeaderboardInvitesCtrl'
                    }
                }
            })
            .state('app.leaderboardConnectContacts', {
                url: "/leaderboard/connectcontacts",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/leaderboard-connect-contacts.html",
                        controller: 'LeaderboardConnectContactsCtrl'
                    }
                }
            })
            .state('app.prizes', {
                url: "/prizes",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/prizes.html",
                        controller: "PrizesCtrl"
                    }
                }
            })
            .state('app.prizesDetail', {
                url: "/prizes/detail",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/prizes-detail.html",
                        controller: "PrizesDetailCtrl"
                    }
                },
                params: {
                    specificContest: {}
                }
            })
            .state('app.quote', {
                url: "/quote",
                abstract: true,
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/quote.html",
                        controller: "QuoteCtrl"
                    }
                }
            })
            .state('app.quoteGet', {
                url: "/quote/get",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/quote-get.html",
                        controller: "QuoteGetCtrl"
                    }
                }
            })
            .state('app.quoteSimulation', {
                url: "/quote/simulation",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/quote-simulation.html",
                        controller: "QuoteSimulationCtrl"
                    }
                },
                params: {
                    quoteId: ''
                }
            })
            .state('app.quote.quoteAbout', {
                url: "/quote/about",
                views: {
                    'quoteContent': {
                        templateUrl: "client/templates/quote-about.html",
                        controller: "QuoteAboutCtrl"
                    }
                }
            })
            .state('app.quote.quoteVehicles', {
                url: "/quote/vehicles",
                views: {
                    'quoteContent': {
                        templateUrl: "client/templates/quote-vehicles.html",
                        controller: "QuoteVehiclesCtrl"
                    }
                }
            })
            .state('app.quoteVehiclesAdd', {
                url: "/quote/vehicles-add",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/quote-vehicles-add.html",
                        controller: "QuoteVehiclesAddCtrl"
                    }
                },
                params: {
                    pIndex: null
                }
            })
            .state('app.quote.quoteDrivers', {
                url: "/quote/drivers",
                views: {
                    'quoteContent': {
                        templateUrl: "client/templates/quote-drivers.html",
                        controller: "QuoteDriversCtrl"
                    }
                }
            })
            .state('app.quoteDriversAdd', {
                url: "/quote/drivers-add",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/quote-drivers-add.html",
                        controller: "QuoteDriversAddCtrl"
                    }
                },
                params: {
                    pIndex: null
                }
            })
            .state('app.quote.quoteFinalDetails', {
                url: "/quote/final-details",
                views: {
                    'quoteContent': {
                        templateUrl: "client/templates/quote-final-details.html",
                        controller: "QuoteFinalDetailsCtrl"
                    }
                }
            })
            .state('app.quote.quoteYourQuote', {
                url: "/quote/your-quote",
                views: {
                    'quoteContent': {
                        templateUrl: "client/templates/quote-your-quote.html",
                        controller: "QuoteYourQuoteCtrl"
                    }
                },
                params: {
                    "createdQuote": false
                }
            })
            .state('app.quotePurchase', {
                url: "/quote/purchase",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/quote-purchase.html",
                        controller: "QuotePurchaseCtrl"
                    }
                }
            })
            .state('app.quoteReceipt', {
                url: "/quote/receipt",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/quote-receipt.html",
                        controller: "QuoteReceiptCtrl"
                    }
                },
                params: {
                    'receipt': null
                }
            })
            .state('app.assistance', {
                url: "/assistance",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/assistance.html",
                        controller: "AssistanceCtrl"
                    }
                }
            })
            .state('app.assistanceLiveChat', {
                url: "/assistance/livechat",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/assistance-livechat.html",
                        controller: "LiveChatCtrl"
                    }
                }
            })
            .state('app.completeMyEnrolment', {
                url: "/completeMyEnrolment",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/complete-my-enrolment.html",
                        controller: "CompleteEnrolmentCtrl"
                    }
                }
            })
            .state('app.selectInfo', {
                url: "/select-info",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/select-info.html",
                        controller: 'SelectInfoCtrl'
                    }
                },
                params: {
                    list: [],
                    from: -1,
                    selectedValue: ""
                }
            })
            .state('app.selectTripType', {
                url: "/select-trip-type",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/trip-history-select-type.html",
                        controller: 'TripHistorySelectTypeCtrl'
                    }
                },
                params: {
                    list: [],
                    tripId: ""
                }
            })
            .state('app.insurance', {
                url: "/insurance",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/insurance.html",
                        controller: 'InsuranceCtrl'
                    }
                }
            })
            .state('app.insurancePolicy', {
                url: "/insurance/policy",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/insurance-policy.html",
                        controller: 'InsurancePolicyCtrl'
                    }
                }
            }).state('app.insuranceInvoices', {
                url: "/insurance/invoices",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/insurance-invoices.html",
                        controller: 'InsuranceInvoicesCtrl'
                    }
                }
            }).state('app.insuranceInvoiceDetails', {
                url: "/insurance/invoice-details",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/insurance-invoice-details.html",
                        controller: 'InsuranceInvoiceDetailsCtrl'
                    }
                },
                params: {
                    invoiceId: ''
                }
            }).state('app.insurancePayments', {
                url: "/insurance/payments",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/insurance-payments.html",
                        controller: 'InsurancePaymentsCtrl'
                    }
                }
            }).state('app.insurancePaymentDetails', {
                url: "/insurance/payment-details",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/insurance-payment-details.html",
                        controller: 'InsurancePaymentDetailsCtrl'
                    }
                },
                params: {
                    paymentId: ''
                }
            }).state('app.insuranceRepairShops', {
                url: "/insurance/repair-shops",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/insurance-repair-shops.html",
                        controller: 'InsuranceRepairShopsCtrl'
                    }
                }
            })
            .state('app.insuranceClaims', {
                url: "/insurance/claims",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/insurance-claims.html",
                        controller: 'InsuranceClaimsCtrl'
                    }
                }
            })
            .state('app.insuranceNewClaim', {
                url: "/insurance/new-claim",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/insurance-new-claim.html",
                        controller: 'InsuranceNewClaimCtrl'
                    }
                }
            })
            .state('app.insuranceClaimsCollision', {
                url: "/insurance/claims/collision",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/insurance-claims-collision.html",
                        controller: 'InsuranceClaimsCollisionCtrl'
                    }
                },
                params: {
                    'claimType': '',
                    'location': ''
                }
            })
            .state('app.insuranceClaimsCollisionPictures', {
                url: "/insurance/claims/collision/pictures",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/insurance-claims-collision-pictures.html",
                        controller: 'InsuranceClaimsCollisionPicturesCtrl'
                    }
                }
            })
            .state('app.insuranceClaimsCollisionLocation', {
                url: "/insurance/claims/collision/location",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/insurance-claims-collision-location.html",
                        controller: 'InsuranceClaimsCollisionLocationCtrl'
                    }
                }
            })
            .state('app.insuranceClaimsCollisionPosition', {
                url: "/insurance/claims/collision/position",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/insurance-claims-collision-position.html",
                        controller: 'InsuranceClaimsCollisionPositionCtrl'
                    }
                }
            })
            .state('app.insuranceClaimsCollisionForm', {
                url: "/insurance/claims/collision/form",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/insurance-claims-collision-form.html",
                        controller: 'InsuranceClaimsCollisionFormCtrl'
                    }
                }
            })
            .state('app.insuranceClaimsCollisionFormPeople', {
                url: "/insurance/claims/collision/form/people",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/insurance-claims-collision-form-people.html",
                        controller: 'InsuranceClaimsCollisionFormPeopleCtrl'
                    }
                }
            })
            .state('app.insuranceClaimsCollisionFormDetails', {
                url: "/insurance/claims/collision/form/details",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/insurance-claims-collision-form-details.html",
                        controller: 'InsuranceClaimsCollisionFormDetailsCtrl'
                    }
                },
                params: {
                    'details': ''
                }
            })
            .state('app.insuranceClaimsCollisionFormSignature', {
                url: "/insurance/claims/collision/form/signature",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/insurance-claims-collision-form-signature.html",
                        controller: 'InsuranceClaimsCollisionFormSignatureCtrl'
                    }
                }
            })

        .state('app.insuranceClaimsLocationSelection', {
                url: "/insurance/claims/location/selection",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/insurance-claims-location-selection.html",
                        controller: 'InsuranceClaimsLocationSelectionCtrl'
                    }
                },
                params: {
                    'tripid': ''
                }
            })
            .state('app.insuranceClaimsCollisionFormPeopleEdit', {
                url: "/insurance/claims/collision/form/people/edit",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/insurance-claims-collision-form-people-edit.html",
                        controller: 'InsuranceClaimsCollisionFormPeopleEditCtrl'
                    }
                },
                params: {
                    pIndex: {}
                }
            })
            .state('app.insuranceClaimsStolen', {
                url: "/insurance/claims/stolen",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/insurance-claims-stolen.html",
                        controller: 'InsuranceClaimsStolenCtrl'
                    }
                }
            })
            .state('app.profileRemainingPrepaidBalance', {
                url: "/profile/remaining-prepaid-balance",
                views: {
                    'menuContent': {
                        templateUrl: "client/templates/profile-remainingPrepaidBalance.html",
                        controller: 'ProfileRemainingPrepaidBalanceCtrl'
                    }
                }
            })
            .state('onboarding', {
                url: '/onboarding',
                cache: false,
                templateUrl: 'client/templates/onboarding.html',
                controller: 'OnboardingCtrl'
            })

        // if none of the above states are matched, use this as the fallback
        $urlRouterProvider.otherwise('/login');
    });
