$.fn.progressBar = function(options){
    $(this).children('div').animate({
        width: options.value + '%'
    }, 200);
}