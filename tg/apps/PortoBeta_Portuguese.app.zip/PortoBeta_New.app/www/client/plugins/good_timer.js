var GoodTimer = function()
{
  
  this.time_ended = false;
  this.callBack = null;
  this.end = null;
  this.time = 0;
  this.time_interval = null;
  this.go = false;
  this.time_fix = 0;
  this.initial = new Date();

  this.str_pad_left = function(string,pad,length) {
    return (new Array(length+1).join(pad)+string).slice(-length);
  };

  this.reset = function(){
    this.time = 0;
  };

  this.setInitialTime = function(total_seconds){

    //must make now - initial_time to get the inicial time
    var now = new Date();
    now.setSeconds(now.getSeconds() - total_seconds);

    this.initial = new Date(now);
  };

  this.init = function(initial_time, end_time, call_back){

    if(initial_time){

      this.setInitialTime(initial_time);

      this.time = initial_time;
    }

    if(end_time){
      this.end = end_time;
    }

    if(call_back){
      this.callBack = call_back;
    }

    this.callBack();
  };

  this.runTimer = function(){
    this.clear();

    var self = this;

    this.time_interval = setInterval(function(){

      if(self.end && self.time >= self.end){

        self.time_ended = true;
        self.callBack();

      }else{

        if(self.go){

          var now = new Date();
          var elapsedTime = parseInt((now.getTime() - self.initial.getTime())  / 1000);

          self.time = elapsedTime;

          self.callBack();
        }

      };
      
    }, 1000);
  };

  this.setFinishTime = function(t){
    this.end = t;
  };

  this.setTime = function(t){

    //recalc timmer

    this.setInitialTime(t);

    this.time = t;
  };

  this.start = function(t){

    this.go = true;

    this.runTimer();
  },

  this.stop = function(){

    this.go = false;

    this.clear();
  };

  this.clear = function(){
    try{
      clearInterval(this.time_interval);
    }catch(e){
      console.log("error at clear interval", e);
    }
  };

  this.getTimeStatus = function(){
    return this.time_ended;
  };

  this.getSeconds = function(){
    return this.time;
  };

  this.getTimeFormated = function(){

    var temp_time = this.time;

    var hours = Math.floor(temp_time / 3600);

    temp_time = temp_time - hours * 3600;

    var minutes = Math.floor(temp_time / 60);
    var seconds = temp_time - minutes * 60;

    return this.str_pad_left(hours,'0',2)+':'+this.str_pad_left(minutes,'0',2)+':'+this.str_pad_left(seconds,'0',2);
  };

  this.getFromMaxTimeFormated = function(total){

    var temp_time = total - this.time;

    var hours = Math.floor(temp_time / 3600);

    temp_time = temp_time - hours * 3600;

    var minutes = Math.floor(temp_time / 60);
    var seconds = temp_time - minutes * 60;

    return this.str_pad_left(hours,'0',2)+':'+this.str_pad_left(minutes,'0',2)+':'+this.str_pad_left(seconds,'0',2);
  };
};