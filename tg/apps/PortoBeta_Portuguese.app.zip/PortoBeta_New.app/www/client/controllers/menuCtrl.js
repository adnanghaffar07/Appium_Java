angular.module('controllers')
    .controller('MenuCtrl', MenuCtrl);

function MenuCtrl(CordovaReceiver, $translate, $state, $scope, $timeout, $ionicSideMenuDelegate, $ionicHistory, LoginServices, LocalStorage, LocalStorageKeys, $rootScope, DateUtil, $q, ListenerUtil, CordovaBroadcaster, BridgeIntentType, $cordovaPrinter, OperateType, CurrentScreen, BooleanConstant, AvatarServices, LoginType, DeviceFactory, $interval, NetworkConnectionUtil, ConnectionConstants, PaymentServices, PushNotificationUtil, AppConfigServices, TripStateFactory, TripState, FirebaseService, QuoteServices) {
    // Scope Functions
    $scope.toggleMenu = toggleMenu;
    $scope.goToSettings = goToSettings;
    $scope.goToEditProfile = goToEditProfile;
    $scope.navigateTo = navigateTo;
    $scope.closeNetworkBanner = closeNetworkBanner;
    $scope.removeContestNotification = removeContestNotification;
    $scope.goToPrizeDetail = goToPrizeDetail;
    $scope.closeSideMenu = closeSideMenu;
    $scope.closeLocationBanner = closeLocationBanner;
    $scope.menuItemClicked = menuItemClicked;

    $scope.goBack = goBack;
    $scope.formatDate = formatDate;
    $scope.showExportOptions = showExportOptions;
    $scope.exportFooter = BooleanConstant.BOOL_FALSE;
    $rootScope.updateMenuHeader = BooleanConstant.BOOL_FALSE;
    $rootScope.updateProfilePic = BooleanConstant.BOOL_FALSE;
    $rootScope.contestNotificationActive = BooleanConstant.BOOL_FALSE;
    $scope.operate = operate;
    $rootScope.locationStatus = {};
    $rootScope.quoteData = {
        vehicles: {},
        drivers: []
    };
    $rootScope.quoteData.drivers[0] = {};

    $scope.settings = LocalStorage.getObject(LocalStorageKeys.USER_APP_SETTINGS);

    // setting date translation
    moment.locale('pt-BR', {
        months : [
            "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho",
            "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"
        ],
        monthsShort : [
            "Jan", "Fev", "Mar", "Abr", "Ma", "Jun",
            "Jul", "Ago", "Set", "Out", "Nov", "Dez"
        ],
        weekdays : [
            "Domingo", "Segunda-feira", "Terça-feira", "Quarta-feira", "Quinta-feira", "Sexta-feira", "Sabado"
        ]
    });

    moment.lang('pt-BR');
    // moment.locale('en', {
    //     months : [
    //         "January", "February", "March", "April", "May", "June", "July",
    //         "August", "September", "October", "November", "December"
    //     ],
    //     monthsShort : [
    //         "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    //         "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
    //     ],
    //     weekdays : [
    //         "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"
    //     ]
    // });

    // Scope Variables
    $scope.themeColors = LocalStorage.getObject(LocalStorageKeys.THEME_COLORS);

    // Get Avatar, here to prevent calling this everytime we load a screen.
    getAvatar();

    // Scope Life Cycle    
    $scope.$on('$ionicView.loaded', ionicViewLoaded);
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    // Custom Events
    // // GPS_STATE Changed, either it is ON or OFF
    $rootScope.$on(BridgeIntentType.GPS_STATE, onLocationChanged);

    $rootScope.$on(BridgeIntentType.SEND_TRIP_INFO, function(pEvent, pExtras) {

        console.log('call SEND_TRIP_INFO');

        $scope.currentlyDriving = true;
    });

    // On Update of balance info, it will get called and updates balance.
    $rootScope.$on('CallGetBalanceInfo', function (event, args) {
        var pMode = LocalStorage.get(LocalStorageKeys.LOGIN_TYPE);
        if (pMode == LoginType.UBI_PPM || pMode == LoginType.UBI_RB) {
            getBalanceInfo();
        }
    });
    // Scope Event

    function setDateLang(key) {
        // if (key === 'en-US') {
        //     moment.lang('pt-BR');
        // } else if (key === 'pt-BR') {
        //     moment.lang('pt-BR');
        // } else {
        //     moment.lang('pt-BR');
        // }

        moment.lang('pt-BR');
    }

    // INIT CARBIT
    $scope.tetheringStatus = DeviceFactory.tetheringStatus;
    normalizeStatus(DeviceFactory.tetheringStatus.deviceStatus);

    // Function
    function ionicViewLoaded() {
        document.addEventListener("offline", onOffline, false);
        document.addEventListener("online", onOnline, false);

        var pMode = LocalStorage.get(LocalStorageKeys.LOGIN_TYPE);
        if (pMode == LoginType.UBI_PPM || pMode == LoginType.UBI_RB) {
            getBalanceInfo();
        } else {
            setNotificationTimeout();
        }
        $("ion-content ion-list .item-radio i, .item-radio .radio-content i").css('color', $rootScope.themeColors.mainBackground);

        // SET DYNAMIC MENU ITEMS
        var behaviorConfig = LocalStorage.getObject(LocalStorageKeys.APP_BEHAVIOR_OPTIONS);
        
        try {
            switch (LocalStorage.get(LocalStorageKeys.LOGIN_TYPE)) {
                case "1":
                    $scope.behaviorConfig = behaviorConfig ? behaviorConfig["1"] : null;
                    break;
                case "2":
                    $scope.behaviorConfig = behaviorConfig ? behaviorConfig["2"] : null;
                    break;
                case "3":
                    $scope.behaviorConfig = behaviorConfig ? behaviorConfig["3"] : null;
                    break;
                case "4":
                    $scope.behaviorConfig = behaviorConfig ? behaviorConfig["4"] : null;
                    break;
            }
        } catch (e) {
            console.log(e);
        }
    }

    function ionicViewBeforeEnter() {
        // CHECK LOCATION SERVICE
        setupLocationAvailable();

        $scope.profileData = LocalStorage.getObject(LocalStorageKeys.PROFILE_DATA);
        if (LocalStorage.get(LocalStorageKeys.LOGIN_TYPE) == LoginType.TBYB_PPM || LocalStorage.get(LocalStorageKeys.LOGIN_TYPE) == LoginType.TBYB_RB) {
            $scope.isTBYB = true;
        } else {
            $scope.isTBYB = false;
        }
        if (LocalStorage.get(LocalStorageKeys.LOGIN_TYPE) == LoginType.TBYB_PPM || LocalStorage.get(LocalStorageKeys.LOGIN_TYPE) == LoginType.UBI_PPM) {
            $scope.isPPM = true;
        } else {
            $scope.isPPM = false;
        }

        var menuItems = LocalStorage.getObject(LocalStorageKeys.MENU_ITEMS);

        $scope.menuItems = menuItems;

        var languageLocal = LocalStorage.get(LocalStorageKeys.CURRENT_LOCALE_KEY);
        var languageDevice = LocalStorage.get(LocalStorageKeys.DEVICE_LOCALE_KEY);

        if (languageDevice) {
            setDateLang(languageDevice);
        } else {
            setDateLang(languageLocal);
        }
    }

    function toggleMenu() {
        if ($rootScope.updateMenuHeader) {
            $rootScope.updateMenuHeader = false;
            $scope.profileData = LocalStorage.getObject(LocalStorageKeys.PROFILE_DATA);
        }
        if ($rootScope.updateProfilePic) {
            $rootScope.updateProfilePic = false;
            $scope.profileImage = LocalStorage.get(LocalStorageKeys.PROFILE_PIC_SRC);
        }
        $ionicSideMenuDelegate.toggleLeft();
    }

    function closeSideMenu() {
        $ionicSideMenuDelegate.toggleLeft(false);
    }

    function goToSettings() {
        $state.go('app.settings');
    }

    function goToEditProfile() {
        $state.go('app.profile');
    }

    function navigateTo(pRoute, pEvent) {
        closeSideMenu();
        $state.go(pRoute);
    }

    function goBack() {
        $ionicHistory.goBack();
    }

    function formatDate(date) {
        date = DateUtil.erieInsurancedateformat("full", date.substring(0, 10));
        return date;
    }

    function showExportOptions() {
        $scope.exportFooter = BooleanConstant.BOOL_TRUE;
    }

    function getAvatar() {
        AvatarServices.getAvatar().then(function (response) {
            if (angular.isDefined(response.avatar) && response.avatar != null) {
                var avatar = "data:image/png;base64," + response.avatar;
                $scope.profileImage = avatar;
                LocalStorage.set(LocalStorageKeys.PROFILE_PIC_SRC, avatar);
            } else {
                $scope.profileImage = false;
            }
        }, function (error) {
            $scope.profileImage = false;
        });
    }

    function getBalanceInfo() {
        PaymentServices.getBalanceInfo().then(function (response) {
            //LoadingUtil.hideLoader();
            if (response.data.length > 0) {
                var balance = 0;
                var freemiles = 0;
                for (var i = 0; i < response.data.length; i++) {
                    balance += parseFloat(response.data[i].balance);
                    freemiles += response.data[i].free_miles;
                }
                var policy_id = response.data[0].id;
                LocalStorage.set(LocalStorageKeys.POLICY_ID, policy_id);
                $scope.balanceAccount = balance;
                $scope.freemiles = freemiles;
            }
            //$scope.balanceAccount = parseFloat(response.data[0].balance+response.data[0].miles_balance);

        }, function (error) {

        });
    }

    /*
        name : operate
        params : It takes option (email/print), type (invoice/payment/policy), event(element id)
        description : It performs email,print operations based on parameters passed.
        return : It opens native email app with attaching file (policy,invoice or payment).
    */
    function operate(option, type, event) {
        switch (option) {
            case OperateType.EMAIL:
                switch (type) {
                    case CurrentScreen.INVOICE:
                        composeMail(type, event);
                        break;
                    case CurrentScreen.PAYMENT:
                        composeMail(type, event);
                        break;
                    case CurrentScreen.POLICY:
                        composeMailPolicy(type, event);
                        break;
                }
                break;
            case OperateType.PRINT:
                printpage(type, event)
                break;
        }
        $scope.exportFooter = BooleanConstant.BOOL_FALSE;
    }

    /*
        name : composeMailPolicy
        params : It takes (invoice/payment/policy) and image url of policy
        description : It converts image to pdf, and attaches pdf to native email app
    */
    function composeMailPolicy(type, imageURI) {
        var image = new Image();
        image.src = imageURI;
        image.onload = function () {
            var canvas = document.createElement('canvas');
            canvas.width = this.naturalWidth; // or 'width' if you want a special/scaled size
            canvas.height = this.naturalHeight; // or 'height' if you want a special/scaled size
            canvas.getContext('2d').drawImage(this, 0, 0);
            $scope.imgData = canvas.toDataURL('image/jpeg');
            var doc = new jsPDF();
            doc.setFontSize(40);
            //doc.text(40, 30, "Octocat loves jsPDF", 4);
            doc.addImage($scope.imgData, 10, 40, 180, 180);
            var pdfOutput = doc.output('blob');
            saveFile = function (pdfOutput) {
                console.log("file system...");
                window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, function (fileSystem) {
                        var vrSubject = type + LocalStorage.get(LocalStorageKeys.LOGIN_EMAIL);
                        fileSystem.root.getFile(vrSubject + '.pdf', {
                            create: BooleanConstant.BOOL_TRUE
                        }, function (entry) {
                            var fileEntry = entry;
                            $scope.nativeURL = entry.nativeURL;
                            entry.createWriter(function (writer) {
                                writer.onwrite = function (evt) {
                                    CordovaBroadcaster.openMail('', vrSubject, '', fileSystem.root.nativeURL, entry.name);
                                };
                                writer.write(pdfOutput);
                            }, function (error) {
                                console.log(error);
                                alert(error);
                            });

                        }, function (error) {
                            console.log(error);
                            alert(error);
                        });
                    },
                    function (event) {
                        console.log(evt.target.error.code);
                    });
            }
            saveFile(pdfOutput);
        };
    }

    /*
        name : printpage
        params : It takes type(invoice/payment/policy) and element id as a parameter
        description : It gets near by airprinters and prints the content of DOM element passed.
    */
    function printpage(type, elementId) {
        if ($cordovaPrinter.isAvailable()) {
            var printImage = document.getElementById(elementId);
            $cordovaPrinter.print(printImage, 'print', {
                name: 'basedrive-print.com',
                landscape: BooleanConstant.BOOL_TRUE
            }, function () {
                alert('printing finished or canceled');
            });
            e.stopImmediatePropagation();
        } else {
            alert("Printing is not available on device");
        }
    }

    /*
        name : composeMail
        params : It takes type(invoice/payment/policy) and element id as a parameter
        description : It converts html content to image and then to pdf and attaches to native email app.
    */
    function composeMail(type, elementId) {
        getDataURI(type, elementId).then(function (imgData) {
            var vrSubject = type;
            var doc = new jsPDF();
            doc.addImage(imgData, 'png', 10, 10, 190, 280);
            var pdfOutput = doc.output('blob');
            window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, function (fileSystem) {
                    fileSystem.root.getFile(vrSubject + '.pdf', {
                        create: BooleanConstant.BOOL_TRUE
                    }, function (entry) {
                        $scope.nativeURL = entry.nativeURL;
                        entry.createWriter(function (writer) {
                            writer.onwrite = function (evt) {
                                CordovaBroadcaster.openMail('', vrSubject, '', fileSystem.root.nativeURL, entry.name);
                            };
                            writer.write(pdfOutput);
                        }, function (error) {
                            console.log(error);
                            alert(error);
                        });
                    }, function (error) {
                        console.log(error);
                        alert(error);
                    });
                },
                function (event) {
                    console.log(event.target.error.code);
                });
        })

    }

    /*
        name : getDataURI
        params : It takes type(invoice/payment/policy) and element id as a parameter
        description : It converts html content to image.
        return : data url (base64) of dom content.
    */
    function getDataURI(type, elementId) {
        var q = $q.defer();
        html2canvas(document.getElementById(elementId), {
            onrendered: function (canvas) {
                $scope.imgData = canvas.toDataURL('image/png');
                q.resolve($scope.imgData);
            },
            useCORS: BooleanConstant.BOOL_TRUE,
            width: 360,
            height: 600
        });
        return q.promise;
    }

    /*
        Watch changes in T2 device status
    */
    $scope.$watch(function () {
        return $scope.tetheringStatus.deviceStatus;
    }, function (newStatus) {
        normalizeStatus(newStatus);
    });

    /*
        Watch changes in T2 BLE status
    */
    $scope.$watch(function () {
        return $scope.tetheringStatus.bleStatus;
    }, function (newStatus) {
        normalizeBleStatus(newStatus);
    });

    /*
        Watch changes in T2 device progress
    */

    $scope.$watch(function () {
        return $scope.tetheringStatus.deviceProgress;
    }, function (newProgress) {
        $scope.deviceProgress = newProgress;
    });

    /*
        Name: normalizeStatus
        @Param: pStatus -> T2 Device Status
        Desc: Takes raw status and normalize into 3 global status.
        Not Connected
        Connected
        Downloading
    */
    function normalizeStatus(pStatus) {
        console.log(777, pStatus);

        switch (pStatus) {
            case 'NOT_CONNECTED':
            case 'DISCONNECTED':
            case 'DISAPPEARED':
            case 'CONNECT_FAILED':
                $scope.deviceStatus = 'Not connected';
                break;
            case 'CONNECTED':
            case 'FOTA_COMPLETED':
            case 'FOTA_CANCELLED':
            case 'CONFIG_ENDED':
            case 'DATA_COMPLETED':
                $scope.deviceStatus = 'Connected';
                break;
            case 'FOTA_STARTED':
            case 'FOTA_PROGRESS':
            case 'CONFIG_STARTED':
            case 'CONFIG_PROGRES':
            case 'DATA_AVAILABLE':
            case 'DATA_PROGRESS':
                $scope.deviceStatus = 'Downloading';
                break;
        }

        console.log(999, $scope.deviceStatus);
    }

    /*
        Name: normalizeBleStatus
        @Param: pStatus -> T2 BLE Status
        Desc: Takes raw status and normalize into 1 global status.
        Scanning
    */
    function normalizeBleStatus(pStatus) {
        switch (pStatus) {
            case 'SCANNING':
                $scope.bleStatus = 'Scanning';
                break;
            default:
                $scope.bleStatus = null;
                break;
        }
    }

    /*
        name : closeNetworkBanner
        desc : Close the network banner when click on close icon
    */
    function closeNetworkBanner() {
        $rootScope.networkStatus.isAvailable = true;
        //        $('.has-header').removeClass('has-nonetwork-banner');
    }

    /*
        name : onOffline
        desc : Trigger when the internet is lost
    */

    function onOffline() {
        $rootScope.networkStatus.isAvailable = false;
        //$('.has-header').addClass('has-nonetwork-banner');
    }

    /*
        name : onOffline
        desc : Trigger when the there is internet connection established
    */
    function onOnline() {
        $rootScope.networkStatus.isAvailable = true;
        //$('.has-header').removeClass('has-nonetwork-banner');
    }


    //    $scope.$watch(function () {
    //        return $rootScope.networkStatus.isAvailable
    //    }, function (newStatus) {
    //        if (newStatus) {
    //            $('.has-header').removeClass('has-banner');
    //        } else {
    //            $('.has-header').addClass('has-nonetwork-banner');
    //        }
    //    });

    /*
        name : goToPrizeDetail
        desc : Redirect to prize details screen 
    */
    function goToPrizeDetail(pData) {
        PushNotificationUtil.redirectToScreen(pData);
        $rootScope.contestNotificationActive = false;
    }

    /*
        name : removeContestNotification
        desc : Hiding the contest notification
    */
    function removeContestNotification() {
        $rootScope.contestNotificationActive = false;
    }

    /*
        name : setNotificationTimeout
        desc : Set the notificaiton timeout vaue to close the notification
    */
    function setNotificationTimeout() {
        AppConfigServices.getConfigValue("notification_duration").then(function (result) {
            $rootScope.notificationTimeout = parseInt(result) * 1000;
        }, function (error) {
            //q.reject(error);
        });
    }

    /*
        name : setupLocationAvailable
        desc : WIll check if location is turned ON or OFF and show banner accordingly.
    */
    function setupLocationAvailable() {
        var options = {
            timeout: 5000
        };
        navigator.geolocation.getCurrentPosition(onLocationSuccess, onLocationFailed, options);
        //        onLocationFailed();
    }

    function onLocationSuccess() {
        //$rootScope.locationStatus.isAvailable = true;
    }

    function onLocationFailed() {
        //$rootScope.locationStatus.isAvailable = false;
        //$state.go('noLocationService');
    }

    function onLocationChanged(pEvent, pExtras) {

        console.log(pExtras, "pEvent");
        console.log(pExtras, "pExtras");

        if (!pExtras.gps_state) {
            //onLocationFailed();
            $state.go('noLocationService');
        }
    }
    
    function closeLocationBanner() {
        //$rootScope.locationStatus.isAvailable = true;
    }

    /*
        
    */
    if (TripStateFactory.is(TripState.STARTED)) {
        $state.currentlyDriving = true;
    }

    if (TripStateFactory.is(TripState.STOPPED)) {
        $state.currentlyDriving = false;
    }

    TripStateFactory.registerTripStatusChanged(function (pTrip) {
        $scope.tripId = pTrip.tripId;
        if (TripStateFactory.is(TripState.STARTED)) {
            $scope.currentlyDriving = true;
        }
        if (TripStateFactory.is(TripState.STOPPED)) {
            $scope.currentlyDriving = false;
        }
    });

    ListenerUtil.registerListener(BridgeIntentType.ACTION_LOW_BATTERY, function (pExtras) {
        console.log("####### REGISTERED EVENT - LOW BATTERY #########", pExtras);
        $scope.lowBatteryAlert = true;
    })

    ListenerUtil.registerListener(BridgeIntentType.ACTION_OKAY_BATTERY, function (pExtras) {
        console.log("####### REGISTERED EVENT - OKAY BATTERY #########", pExtras);
        $scope.lowBatteryAlert = false;
    })

    function menuItemClicked(pMi) {

        var url = '';

        FirebaseService.logEvent("select_content", {
            content_type: "menu",
            item_name: "Menu", 
            custom_dimension1: LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID), 
            custom_dimension2: "Menu",
            custom_dimension5: LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID) !== null ? "logged in" : "logged out",
            custom_dimension7: $translate.instant(pMi.tag)
        });

        if (pMi.url) {
            
            url = pMi.url + "?internal_id=" + $scope.profileData.user.id;

            if (pMi.tag === "menu_courses") {

                FirebaseService.logEvent("generate_lead", {
                    content_type: "courses",
                    item_name: "Cursos", 
                    custom_dimension2: "Cursos",
                    custom_dimension5: LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID) !== null ? "logged in" : "logged out"
                });

                openNormal(url);
                return true;
            }

            if (pMi.tag === "menu_gaq") {
                logGAQ();
            } 

            openNormal(url);

        } else {
            navigateTo(pMi.state, null);
        }
    }

    function logGAQ() {

        try {
            navigator.geolocation.getCurrentPosition(function(position) {

                var date = new Date();

                var now = moment(date).format('YYYY-M-D h:m:s');

                var data = {
                    action_id: "1", 
                    lat: position.coords.latitude, 
                    lon: position.coords.longitude, 
                    datetime: now
                };

                QuoteServices.logQuote(data).then(function (res) {
                    console.log(res)
                });

            }, function(error) {
                console.log(error, 'position error');
            });

        } catch (e) {
            console.log(e);
        }
    }

    function openNormal(pUrl) {

        console.log(pUrl);

        try {

            if (cordova) {
                cordova.InAppBrowser.open(pUrl, '_blank', 'location=yes');
            }
            
            // window.open(pUrl, "_system");
        } catch(e) {
            console.log(e);
        }
    }

    function startInAppBrowser(pUrl) {
        try {
            if (!angular.isUndefined(cordova)) {
                var ref = cordova.InAppBrowser.open(pUrl, "_blank", "location=yes");
                // Exit event listener
                //ref.addEventListener('exit', onInAppBrowserExit);
            }
        } catch(e) {
            console.log(e);
        }
    }
}
