angular.module('controllers')
    .controller('DashboardCtrl', DashboardCtrl);

function DashboardCtrl($rootScope, $scope, $state, $ionicSlideBoxDelegate, $timeout, GlobalConstants, AppSetupServices, AchievementsServices, ScoresServices, PopupUtil, LoadingUtil, CircleProgressUtil, LocalStorage, LocalStorageKeys, LoggerUtilType, $translate, TripsServices, WebServiceCache, DateUtil, StringUtil, AchievementType, $ionicHistory, TripStateFactory, TripState) {
    // Scope functions
    $scope.changeTab = changeTab;
    $scope.slideHasChanged = slideHasChanged;
    $scope.goToBadges = goToBadges;
    $scope.goToGaq = goToGaq;

    // Scope Variables
    $rootScope.activeMenuItem = "dashboard";
    $scope.selectedTab = 'lastTrip';
    $scope.achievementsAvailable = false;
    $scope.circle_size = Math.round($(window).width() / 1.75);
    console.log("CIRCLE SIZE", $scope.circle_size);
    $scope.circle_fontsize = Math.round($scope.circle_size / 2);
    $scope.hac = 0;
    $scope.hbr = 0;
    $scope.hco = 0;
    $scope.spd = 0;
    $scope.txt = 0;
    $scope.scoreDetails = 0;
    $scope.user_achievements = 0;
    $scope.user_badges = 0;
    $scope.community_badges = 0;
    $scope.community_achievments = 0;
    $scope.lastWeekDatesRange = moment().subtract(7, "days").format("MMM D") + ' - ' + moment().subtract(1, "days").format("MMM D, YYYY");
    $scope.lastMonthDatesRange = moment().subtract(1, "month").format("MMM D") + ' - ' + moment().subtract(1, "days").format("MMM D, YYYY");
    $scope.settingsObj = LocalStorage.getObject(SHA512(GlobalConstants.BASE_URL + "/getSettings"));

    $ionicHistory.clearHistory();
    $ionicHistory.clearCache();

    // Scope Life Cycle
    $scope.$on('$ionicView.loaded', ionicViewLoaded);
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    // Functions

    /*
        Name: ionicViewLoaded
        Desc: Fetch data from database
    */
    function ionicViewLoaded() {
        // loadDashboard();
        TripStateFactory.registerTripStatusChanged(refreshDashboard);
        ScoresServices.getOverallDrivingScores(getScoresCallback);
        AchievementsServices.getAchievements().then(getAchievementsCallBack);
        AchievementsServices.getCoins().then(getCoinsCallBack);

        $scope.$watch('currentlyDriving', function (n) {
            if (n) {
                startRecAnimation();
            }
        });

        // Depricated -> to delete
        //AchievementsServices.getAchievementStatics(LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID)).then(getAchievementStaticsCallback);
        ///////////////////////////
    }

    function startRecAnimation() {
        var vrSetIntervalOnEnter;
        var vrSetIntervalTripChanged;

        var i = 0;
        $(".rec-led").fadeIn(500);
        //// Anvesh P PROM-3008 //////
        clearInterval(vrSetIntervalOnEnter);
        clearInterval(vrSetIntervalTripChanged);
        //// Anvesh P PROM-3008 //////
        vrSetIntervalTripChanged = setInterval(function () {
            $(".rec-led").animate({
                opacity: 0.25
            }, 500, function () {
                $(".rec-led").animate({
                    opacity: 1
                }, 500)
            });
        }, 1500);
    }

    /*
        Name: ionicViewBeforeEnter
        Desc: Prepare screen before loading
    */
    function ionicViewBeforeEnter() {
        LoadingUtil.showLoader();

        validateGeolocalisationService();

        var lastTripId = LocalStorage.get(LocalStorageKeys.LAST_TRIP_ID, "null");
        TripsServices.getNewTripNotif(lastTripId).then(function (data) {
            if (lastTripId != "null") {
                if (lastTripId != data.trip_id) {
                    LocalStorage.set(LocalStorageKeys.LAST_TRIP_ID, data.trip_id);
                    WebServiceCache.cleanseCache(1);
                }
            } else if (data.trip_id != "" && data.trip_id != null) {
                LocalStorage.set(LocalStorageKeys.LAST_TRIP_ID, data.trip_id);
                WebServiceCache.cleanseCache(1);
            }
        });
    }

    /*
        NAME : validateGeolocalisationService
    */
    function validateGeolocalisationService() {
        var options = {
            timeout: 5000
        };
        navigator.geolocation.getCurrentPosition(onLocationSuccess, onLocationFailed, options);
    }

    function onLocationSuccess() {
        $rootScope.locationStatus.isAvailable = true;
    }

    function onLocationFailed() {
        $rootScope.locationStatus.isAvailable = false;
        //$state.go('noLocationService');
    }

    /*
        Name: getScoresCallback
        Desc: Prepare score object to show on screen
        Param: pScoresData
    */
    function getScoresCallback(pScoresData) {
        $scope.scoresData = pScoresData;
        $scope.hac = pScoresData.lastTrip.hac;
        $scope.hbr = pScoresData.lastTrip.hbr;
        $scope.hco = pScoresData.lastTrip.hco;
        $scope.spd = pScoresData.lastTrip.spd;
        var container = '#last-trip .show-score .score';
        var score = pScoresData.lastTrip.score;
        $scope.lastTripDate = moment(DateUtil.formatDateAsUTC(StringUtil.getdateinformat(pScoresData.lastTrip.endTime))).format("dddd, MMMM D, YYYY");
        $scope.scoreDetails = score;

        var creationDate = moment(LocalStorage.get(LocalStorageKeys.PROFILE_CREATION_DATE));

        if (creationDate.diff(moment(), 'days') > 365) {
            $scope.thisYearDatesRange = moment().subtract(365, 'days').format('MMMM YYYY') + ' - ' + $translate.instant('presentText');
        } else {
            $scope.thisYearDatesRange = creationDate.format('MMM D, YYYY') + ' - ' + $translate.instant('presentText');
        }

        $timeout(function () {
            LoadingUtil.hideLoader();
            $(container).addClass('loaded');
            initCircle(container, score);
            $('.page-hider').fadeOut('fast');
        }, 500);
    }

    function loadDashboard() {
        ScoresServices.getOverallDrivingScores(getScoresCallback);
    }
    /*
        Name: refreshDashboard
        Desc: Reloads the dashboard when a trip is transmitted 
    */
    function refreshDashboard(pExtras) {
        var tripState = TripStateFactory.getTripState();
        if (typeof (pExtras) != 'undefined') {
            $scope.currentlydriventrip = pExtras.tripId;
        }
        $scope.drivingState = tripState;
        if (tripState != TripState.STOPPED && tripState != TripState.STARTED) {
            WebServiceCache.cleanseCache(1);
            WebServiceCache.cleanseCache(3);
            if ($state.current.url == "/dashboard") {
                $timeout(function () {
                    $scope.drivingState = TripState.STOPPED;
                    ScoresServices.getOverallDrivingScores(getScoresCallback);
                }, 5000);
            }
        }
    }

    /*
        Name: getAchievementsCallback
        Desc: Prepare Achievements object to be shown on screen
        Param: pAchievements
    */
    function getAchievementsCallBack(achievements) {
        var latests = [];

        // Sort achievement to have last progressed in first place.
        achievements.sort(function (a, b) {
            return moment(b.UserAchievement.last_progressed_on) - moment(a.UserAchievement.last_progressed_on);
        });

        // Loop through all badges and add only the 3 latest to the array. They must be at least level 1.
        for (var j = 0; j < achievements.length; j++) {
            if (achievements[j].UserAchievement.level > 0 && achievements[j].Achievement.AchievementType.name == "Badges") {
                switch (achievements[j].UserAchievement.level) {
                    case "1":
                        achievements[j].UserAchievement.level_name = "bronze";
                        break;
                    case "2":
                        achievements[j].UserAchievement.level_name = "silver";
                        break;
                    case "3":
                        achievements[j].UserAchievement.level_name = "gold";
                        break;
                }
                latests.push(achievements[j]);
            }

            if (latests.length == 3) {
                break;
            }
        }

        $scope.latestsAchievements = latests;

        // Start progress animation
        $timeout(function () {
            var badges = $('ion-content section#rewards div.one-badge');
            console.log(41111, badges);
            for (var i = 0; i < badges.length; i++) {
                CircleProgressUtil.init_DefaultCircle(badges[i], latests[i].UserAchievement.progress, 60, $scope.themeColors.textPrimary, 2);
            }
        }, 500);
    }

    /*
        NAME : getCoinsCallback
        DESC : Prepare coins to show on Dashboard
        @Param : pCoins
    */
    function getCoinsCallBack(pCoins) {
        $scope.coins = StringUtil.formatNumbers(pCoins.data.balance);
    }


    /*
        TO DELETE
    */

    //    function getAchievementStaticsCallback(pAchievements) {
    //        $scope.community_achievments = pAchievements.total_achievements; // pList[1].Achievement.length;
    //        $scope.community_badges = pAchievements.total_badges; //pList[0].Achievement.length;
    //        $scope.user_achievements = pAchievements.user_count_achievements;
    //        $scope.user_badges = pAchievements.user_count_badges;
    //        $scope.badge_progress = ($scope.user_badges / $scope.community_badges) * 100;
    //        $scope.achievements_progress = ($scope.user_achievements / $scope.community_achievments) * 100;
    //
    //
    //
    //
    //        AchievementsServices.getAchievementsList().then(function (pList) {
    //            console.log(555, pList);
    //            var vrAchievementsCount = 0,
    //                vrUserAchivements = 0;
    //            var vrBadgesCount = 0,
    //                vrUserBadges = 0;
    //            for (var i = 0; i < pList.length; i++) {
    //                if (pList[i].Achievement.AchievementType.id != AchievementType.Id) {
    //                    vrBadgesCount += 1;
    //                } else {
    //                    vrAchievementsCount += 1;
    //                }
    //            }
    //            for (var j = 0; j < pAchievements.length; j++) {
    //                if (pAchievements[j].Achievement.achievement_type_id != AchievementType.Id) {
    //                    if (pAchievements[j].UserAchievement.progress == 100) {
    //                        vrUserBadges += 1;
    //                    }
    //                } else {
    //                    if (pAchievements[j].UserAchievement.progress == 100) {
    //                        vrUserAchivements += 1;
    //                    }
    //                }
    //            }
    //            $scope.community_achievments = vrAchievementsCount; // pList[1].Achievement.length;
    //            $scope.community_badges = vrBadgesCount; //pList[0].Achievement.length;
    //            $scope.user_achievements = vrUserAchivements;
    //            $scope.user_badges = vrUserBadges;
    //            $scope.badge_progress = ($scope.user_badges / $scope.community_badges) * 100;
    //            $scope.achievements_progress = ($scope.user_achievements / $scope.community_achievments) * 100;
    //        }, function (error) {
    //            PopupUtil.showSimpleAlert($translate.instant('error'), $translate.instant(error['i18n-key']));
    //        });
    //
    //
    //        console.log(pAchievements);
    //        if (pAchievements.length > 0) {
    //            $scope.achievementsAvailable = true;
    //            var achievementsCount = 0;
    //            for (var i = 0; i < pAchievements.length; i++) {
    //                if (pAchievements[i].UserAchievement.progress == 100) {
    //                    achievementsCount += 1;
    //                }
    //            }
    //            $scope.user_achievements = achievementsCount;
    //            // INSERT ACHIEVEMENTS LOGIC HERE
    //        }
    //    }

    /*
        Name: slideHasChanged
        Desc: Handles sliding event. Updates the view after slide.
        Param: pI, pScoreData
    */
    function slideHasChanged(pI, pScoreData) {
        var container = null;
        var score = null;
        switch (pI) {
            case 0:
                $scope.selectedTab = 'lastTrip';
                $scope.hac = pScoreData.lastTrip.hac;
                $scope.hbr = pScoreData.lastTrip.hbr;
                $scope.hco = pScoreData.lastTrip.hco;
                $scope.spd = pScoreData.lastTrip.spd;
                container = '#last-trip .show-score .score';
                score = pScoreData.lastTrip.score;
                $scope.scoreDetails = score;
                break;
            case 1:
                $scope.selectedTab = 'lastWeek';
                $scope.hac = pScoreData.lastWeek.hac;
                $scope.hbr = pScoreData.lastWeek.hbr;
                $scope.hco = pScoreData.lastWeek.hco;
                $scope.spd = pScoreData.lastWeek.spd;
                container = '#last-week .show-score .score';
                score = pScoreData.lastWeek.score;
                $scope.scoreDetails = score;
                break;
            case 2:
                $scope.selectedTab = 'lastMonth';
                $scope.hac = pScoreData.lastMonth.hac;
                $scope.hbr = pScoreData.lastMonth.hbr;
                $scope.hco = pScoreData.lastMonth.hco;
                $scope.spd = pScoreData.lastMonth.spd;
                container = '#last-month .show-score .score';
                score = pScoreData.lastMonth.score;
                $scope.scoreDetails = score;
                break;
            case 3:
                $scope.selectedTab = 'thisYear';
                $scope.hac = pScoreData.global.hac;
                $scope.hbr = pScoreData.global.hbr;
                $scope.hco = pScoreData.global.hco;
                $scope.spd = pScoreData.global.spd;
                container = '#this-year .show-score .score';
                score = pScoreData.global.score;
                $scope.scoreDetails = score;
                break;
        }

        if (!$(container).hasClass('loaded')) {
            $(container).addClass('loaded');
            initCircle(container, score);
        }
    }

    /*
        Name: changeTab
        Desc: Use de slidebox delegate to force sliding to a given index.
        Param: pI
    */
    function changeTab(pI) {
        $ionicSlideBoxDelegate.$getByHandle('scoresSlider').slide(pI);
    }

    /*
        Name: initCircle
        Desc: Initialize te progress circle animation
        Param: pE (Element), pV (Value)
    */
    function initCircle(pE, pV) {
        CircleProgressUtil.init_DefaultCircle(pE, pV, $scope.circle_size, $scope.themeColors.textPrimary, 12);
    }

    /*
        Name : goToBadges
        Desc : Redirect to Badges screen
    */
    function goToBadges() {
        $state.go('app.badges');
    }

    /*
        Name : goToGaq
        Desc : Redirect to the GAQ Process
    */
    function goToGaq() {
        /*
            GET INFORMATION FOR USER ID AND USER EXTERNAL ID AND BUILD THE URL FOR THE GAQ PROCESS
        */

        var pd = LocalStorage.getObject(LocalStorageKeys.PROFILE_DATA);
        var gaq_url = $scope.settingsObj.data.AppSetting.get_a_quote_url + "?internal_id=" + pd.user.id + "&external_id=" + pd.user.external_id;

        if (!angular.isUndefined(cordova)) {
            var ref = cordova.InAppBrowser.open(gaq_url, "_blank", "location=yes");

            // Exit event listener
            ref.addEventListener('exit', onInAppBrowserExit);
        }
    }

    function onInAppBrowserExit() {
        console.log("#### IN APP BROWSER EXIT EVENT ####");
        $state.go($state.current, {}, {
            reload: true
        });
    }
}
