angular.module('controllers')
    .controller('LtpSplashCtrl', LtpSplashCtrl)

function LtpSplashCtrl($rootScope, $state, $scope, $timeout, $ionicPlatform, LocalStorage, LocalStorageKeys, GlobalConstants, LtpServices, PopupUtil, $translate, ApiErrorCode, LoadingUtil, ValidationUtil, HttpProxy) {
    $scope.$on('$ionicView.loaded', ionicViewLoaded);
    
    $scope.submitClicked = submitClicked;
    $scope.settingsObj = LocalStorage.getObject(SHA512(GlobalConstants.BASE_URL + "/getSettings"));

    $scope.goBack = function() {
        HttpProxy.clearLocalData();
        $state.go("login");
    }
    

    $scope.focusActivationCode = function ($event) {

        if ($('#textActivationInsurer').val().length === 0) {
            setTimeout(function() {
                $('#textActivationInsurer')[0].setSelectionRange(0, 0);
            }, 200);
        }
    }

    $scope.focusActivationdateOfBirth = function ($event) {
        if ($('#textDateOfBirth').val().length === 0) {
            setTimeout(function() {
                $('#textDateOfBirth')[0].setSelectionRange(0, 0);    
            }, 200);
        }
    }

    function ionicViewLoaded() {
        // Set mask for Date Of Birth
        $('#textDateOfBirth').mask('99-99-9999');
        $('#textActivationInsurer').mask('999.999.999-99');

        // $('#textActivationInsurer')[0].setSelectionRange(0, 0);
        // $('#textDateOfBirth')[0].setSelectionRange(0, 0);
    }

    /*
        Name : submitClicked
        Desc : Validate information before calling service
    */
    function submitClicked() {
        // Check if we have all information before calling web service
        var externalId = null;
        var externalValid = false;
        var dobValid = false;
        var dateOfBirth = textDateOfBirth.value ? textDateOfBirth.value.split("-").reverse().join("-") : null;

        if (textActivationInsurer.value === null || textActivationInsurer.value === "") {
            PopupUtil.showSimpleAlert($translate.instant('Error'), '<p>' + $translate.instant('activation_code_empty')+ '</p>');
            return false;
        } else if (!ValidationUtil.validaCPF(textActivationInsurer.value)) {
            PopupUtil.showSimpleAlert($translate.instant('Error'), '<p>' + $translate.instant('activation_code_invalid')+ '</p>');
            return false;
        } else {
            var formated = textActivationInsurer.value.replace(new RegExp(/[-.,_!@#$%?&*()+=¤{}'"<>:/ ]/g), '');
            externalId = formated;
            externalValid = true;
        }

        // Means it is an Insurer code
        if (dateOfBirth === null || dateOfBirth === "") {
            PopupUtil.showSimpleAlert($translate.instant('Error'), '<p>' + $translate.instant('date_of_birth_empty') + '</p>');
            return false;
        } else if (!ValidationUtil.isValidDate(dateOfBirth, 'YYYY-MM-DD')) {
            PopupUtil.showSimpleAlert($translate.instant('Error'), '<p>' + $translate.instant('date_of_birth_invalid')+ '</p>');
            return false;
        } else {
            dateOfBirth = dateOfBirth;
            dobValid = true;
        }

        if (externalValid && dobValid) {
            callLinkToPolicy(externalId, dateOfBirth);
        }
    }

    /*
        Name : callLinkToPolicy
        Desc : Prepare jsonParams and call linkToPolicy service
    */
    function callLinkToPolicy(pExternalId, pDateOfBirth) {
        LoadingUtil.showLoader();

        var jsonParams = {
            "findClient": {
                "external_id": pExternalId,
                "date_of_birth": pDateOfBirth
            }
        }
        LtpServices.linkToPolicy(jsonParams).then(function (response) {
            LoadingUtil.hideLoader();
            
            $scope.success();
        }, function (error) {
            LoadingUtil.hideLoader();
            
            // Test if error is : NO POLICY FOUND
            if (error.data.api_error_code == ApiErrorCode.POLICY_NOT_FOUND) {
                if ($scope.settingsObj.data.AppSetting.ltp_block) {
                    // LTP_BLOCK is turned ON, so we redirect to LTP BLOCK screen
                    $state.go('ltpContentBlocked');
                } else {
                    // LTP_BLOCK is turned OFF, so we redirect to Dashboard
                    var menuObj = LocalStorage.getObject(LocalStorageKeys.MENU_ITEMS);
                    //$state.go(menuObj[0].state);
                    $scope.success();
                }

                
            } else {
                PopupUtil.showSimpleAlert($translate.instant('Error'), '<p>' + $translate.instant(error.data['i18n-key']) + '</p>');
            }
        });
    }

    $scope.success = function() {
        var btn = [{
            text: '<span> ' + $translate.instant("common_OK") + ' </span>',
            onTap: function (e) {
                $state.go("login");
            }
        }];
        PopupUtil.showSimpleAlert($translate.instant('general_congratulations'), '<p>' + $translate.instant('ltp_accountLinkedMessage') + '</p>', btn);
    }

    $ionicPlatform.registerBackButtonAction(function (event) {
        event.preventDefault();
    }, 100);
}
