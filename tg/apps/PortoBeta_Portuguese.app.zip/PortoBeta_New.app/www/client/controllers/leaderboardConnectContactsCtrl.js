angular.module('controllers')
    .controller('LeaderboardConnectContactsCtrl', LeaderboardConnectContactsCtrl);

function LeaderboardConnectContactsCtrl($state, $rootScope, $scope, $ionicHistory) {
    // SCOPE VARIABLES


    // SCOPE FUNCTIONS
    $scope.connectContacts = connectContacts;
    
    // SCOPE LIFE CYCLE EVENTS

    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    // FUNCTIONS
    
     /*
        name : ionicViewBeforeEnter
        desc : Can write functions or data to be binded before entering screen.. 
    */
    function ionicViewBeforeEnter() {
  
    }
    
    /*
        name : connectContacts
        desc : Redirects to screen displaying list of user contacts. 
    */
    function connectContacts() {
        $state.go("app.leaderboardAddContacts");
    }
}
