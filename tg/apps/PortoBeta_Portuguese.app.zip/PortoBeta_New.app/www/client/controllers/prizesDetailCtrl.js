angular.module('controllers')
    .controller('PrizesDetailCtrl', PrizesDetailCtrl);

function PrizesDetailCtrl($rootScope, $scope, $state, $stateParams, StringUtil, TripDefaultValues, $translate, DateUtil, WebServiceCache, CordovaBroadcaster, PrizesServices, $ionicSlideBoxDelegate, $timeout, LoadingUtil) {
    // SCOPE FUNCTIONS


    // SCOPE VARIABLES
    // $scope.contest = $stateParams.specificContest;
    // $scope.contestDesc = $translate.instant($scope.contest.description);
    // $scope.conteststatus = $scope.contest.user_status_in_contest;

    $scope.contest = {};
    $scope.contest.sponsor_logo = true;
    $scope.contest.challenge_images = true;
    $scope.contentLoaded = false;


    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    $scope.$on('$ionicView.enter', ionicViewEnter);

    // FUNCTIONS
    ////// Functionality when before entering into the view
    /*
        name : ionicViewBeforeEnter
        desc : will do the data binding to the scope before entering into the view
    */
    function ionicViewBeforeEnter() {
        if (angular.isDefined($stateParams.specificContest.contestId)) {
            WebServiceCache.cleanseCache(3);
            CordovaBroadcaster.clearNotificationData();
            LoadingUtil.showLoader();
            PrizesServices.getChallengeDetails($stateParams.specificContest.contestId).then(function (response) {
                LoadingUtil.hideLoader();
                $scope.contest = response;
                $scope.contestDesc = $translate.instant($scope.contest.description);
                $scope.conteststatus = $scope.contest.status;
                $timeout(function(){
                   $ionicSlideBoxDelegate.update(); 
                });
                bindContestDate();
                $scope.contentLoaded = true;
            }, function (error) {
                LoadingUtil.hideLoader();
                console.log(error);
            });
        } else {
            LoadingUtil.showLoader();
            PrizesServices.getChallengeDetails($stateParams.specificContest.id).then(function (response) {
                LoadingUtil.hideLoader();
                $scope.contest = response;
                $scope.contestDesc = $translate.instant($scope.contest.description);
                $scope.conteststatus = $scope.contest.status;
                $timeout(function(){
                   $ionicSlideBoxDelegate.update(); 
                });
                bindContestDate();
                $scope.contentLoaded = true;
            }, function (error) {
                LoadingUtil.hideLoader();
                console.log(error);
            });
        }
    }

    /* 
       name : ionicViewEnter
       desc : This method will be triggerred afte entering in to page.
   */
    function ionicViewEnter() {

    }

    ////// Function to bind contest date.
    /*
        name : bindContestDate
        desc : Binds start and end date of contests.
    */
    function bindContestDate() {
        if ($scope.conteststatus == 'active') {
            $scope.userQualifiedPercentage = $scope.contest.percentage_qualified;
            if ($scope.contest.start_date !="0000-00-00 00:00:00" && $scope.contest.end_date !="0000-00-00 00:00:00" ){
            var startDate = $scope.contest.start_date;
            var endDate = $scope.contest.end_date;
            startDate = moment(DateUtil.formatDateAsUTC(StringUtil.getdateinformat(startDate))).format("MMMM DD, YYYY");
            endDate = moment(DateUtil.formatDateAsUTC(StringUtil.getdateinformat(endDate))).format("MMMM DD, YYYY");
            if (startDate.substr(startDate.length - 4) != endDate.substr(endDate.length - 4)) {
                $scope.contestdate = startDate + ' - ' + endDate;
            } else {
                $scope.contestdate = startDate.substr(0, startDate.length - 6) + ' - ' + endDate;
            }
            }

        }
    }


    ////// Function to show date in specific format.
    /*
        name : formatDate
        desc : To show date in specific format of Month Day, Year.
    */
    /*function formatDate(date) {
        var formatDate;
        if (date) {
            //date = StringUtil.getdateinformat(date);
            var newDate = new Date(date);
            var monthKey = TripDefaultValues.MONTHS_HEADERS_DETAIL[newDate.getMonth()];
            var month = $translate.instant(monthKey);
            formatDate = month + ' ' + newDate.getDate() + ',' + newDate.getFullYear();
        }
        return formatDate;
    }*/
}
