angular.module('controllers')
    .controller('ProfileAddPaymentCardDetailsCtrl', ProfileAddPaymentCardDetailsCtrl);

function ProfileAddPaymentCardDetailsCtrl($rootScope, $scope, $state, $ionicHistory, $stateParams, Action, BooleanConstant, PaymentServices, LoadingUtil, PopupUtil, LocalStorage, LocalStorageKeys,LoggerUtilType, PaymentTypes, WebServiceCache,$translate) {
    // SCOPE FUNCTIONS
    $scope.saveCardDetails = saveCardDetails;
    $scope.optionSeletected = optionSeletected;
    $scope.deletePayment = deletePayment;
    $scope.deleteCurrentPayment = deleteCurrentPayment; 
    //SCOPE VARIABLES
    $scope.showDeleteOverLay = BooleanConstant.BOOL_FALSE;
    $scope.editForm = BooleanConstant.BOOL_FALSE;
    $scope.paymentData = $stateParams.specificPayment;
    //$scope.paymentData.expiration_date = $scope.paymentData.expiration_month + '/' + $scope.paymentData.expiration_year;
    $scope.isCardScanned = $stateParams.isCardScanned;
    
    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    $scope.$on('$ionicView.enter', ionicViewEnter);
    // FUNCTIONS
    /* 
      name : ionicViewBeforeEnter
      desc : Make a call to webservice to fetch data and bind object.
  */
    function ionicViewBeforeEnter() {
        isEditForm();
    }
    
    /* 
       name : ionicViewEnter
       desc : This method will be triggerred afte entering in to page.
   */
    function ionicViewEnter() {
        
    }
    
    /* 
       name : saveCardDetails
       desc : Saves card details and navigates to payment screen.
   */
    function saveCardDetails() {
        var paydata = {};
        var address = {};
        var profileData = LocalStorage.getObject(LocalStorageKeys.PROFILE_DATA);
        paydata = $scope.paymentData;
        //paydata.email = profileData.user.email;
        address.postal_code = profileData.user.postal_code;
        var id = paydata.id;
        address.city = profileData.user.city_name;
        address.state = profileData.user.state;
        address.country = profileData.user.country;
        address.street = profileData.user.street_name;
        address.app = profileData.user.app_name;
        paydata.address = address;
        paydata.payment_method_id=PaymentTypes.VISA;
        paydata.type = "visa";
        //As saving payment is out of scope, hard coding data.
        paydata={"expiration_date":"01/05","cc_number":"8527419","cvs_number":"999","postal_code":"8527419635","nickname":"5678903456","address":{},"payment_method_id":1,"type":"visa", "id" : id};
        if ($scope.isCardScanned) {
            LoadingUtil.showLoader();
            PaymentServices.addPayment(paydata).then(function (response) {
                LoadingUtil.hideLoader();
                WebServiceCache.cleanseCache(7);
                if ($rootScope.createPaymentMethodsGAQ) {
                    $rootScope.createPaymentMethodsGAQ = null;
                    $state.go('app.quotePurchase');
                    return false;
                }
                $scope.navigateTo("app.profilePayment");
            }, function (error) {
                LoadingUtil.hideLoader();
                PopupUtil.showSimpleAlert($translate.instant('error'),$translate.instant(error.data['i18n-key']));
               //$scope.navigateTo("app.profilePayment");
                return false;
            });
        } else {
            LoadingUtil.showLoader();
            PaymentServices.updatePayment(paydata).then(function (response) {
                LoadingUtil.hideLoader();
                WebServiceCache.cleanseCache(7);
                $scope.navigateTo("app.profilePayment");
            }, function (error) {
                LoadingUtil.hideLoader();
               PopupUtil.showSimpleAlert($translate.instant('error'),$translate.instant(error.data['i18n-key']));
               //$scope.navigateTo("app.profilePayment");
                return false;
            });
        }
    }
    
    /* 
        name : optionSeletected
        parameter:selected action delete / cancel
        desc : Performs selected action of delete record / stay on page.
    */
    function optionSeletected(option) {
        if (option == Action.DELETE) {
            deleteCurrentPayment();
            $scope.navigateTo("app.profilePayment");
            
        } else if (option == Action.CLOSE) {
            $scope.showDeleteOverLay = BooleanConstant.BOOL_FALSE;
        }
    }
    
    /* 
       name : deletePayment
       desc : Displays delete / cancel over lay.
   */
    function deletePayment() {
        $scope.showDeleteOverLay = BooleanConstant.BOOL_TRUE;
    }
    
    /* */
    function deleteCurrentPayment() {
        var payData = {};
        payData.id = $scope.paymentData.id;
        LoadingUtil.showLoader();
        PaymentServices.deletePayment(payData).then(function (response) {
            $scope.navigateTo("app.profilePayment");
            WebServiceCache.cleanseCache(7);
            LoadingUtil.hideLoader();
        }, function (error) {
            LoadingUtil.hideLoader();
            PopupUtil.showSimpleAlert($translate.instant('error'),$translate.instant(error['i18n-key']));
            return false;
        });
    }
    
    /* 
        name : isEditForm
        desc : To display delete button and nick name field if form is to update.
    */
    function isEditForm() {
        if (Object.keys($scope.paymentData).length > 0) {
            $scope.editForm = BooleanConstant.BOOL_TRUE;
            $scope.header = "Payment";
        } else {
            $scope.header = "Add Payment";
        }
    }

}
