angular.module('controllers')
    .controller('FaqCategoryArticleCtrl', FaqCategoryArticleCtrl);

function FaqCategoryArticleCtrl($state, $scope, $translate, $stateParams, LocalStorage, LocalStorageKeys, LocalStorage, LocalStorageKeys, FirebaseService) {

    // SCOPE VARIABLES
    // --> All scope variables that are specific to that view will be defined here
    $scope.article = $stateParams.article;

    // SCOPE FUNCTIONS
    // --> All scope functions specific to that view are defined here

    // SCOPE LIFE CYCLE
    // --> All needed life cycle events specific to that view are defined here. Note that we do not write the function directly in it.
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    $scope.$on('$ionicView.enter', ionicViewEnter);

    // FUNCTIONS
    /* 
        name : ionicViewBeforeEnter
        desc : Will call web services and prepare an object for the screen
    */
    function ionicViewBeforeEnter() {

    }

    function ionicViewEnter() {
        FirebaseService.logEvent("select_content", {
            item_name: "Perguntas frequentes", 
            content_type: "faq",
            custom_dimension2: "Perguntas frequentes",
            custom_dimension5: LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID) !== null ? "logged in" : "logged out",
            custom_dimension7: $translate.instant($scope.article + '_question'),
        });
    }

}
