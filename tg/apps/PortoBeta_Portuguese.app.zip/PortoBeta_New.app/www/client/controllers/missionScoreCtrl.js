angular.module('controllers')
    .controller('MissionScoreCtrl', MissionScoreCtrl);

function MissionScoreCtrl($scope, $rootScope, $translate, $state, ScoresServices, GamingServices, CircleProgressUtil, StringUtil, DateUtil, $timeout, LoadingUtil) {

    $scope.$on('$ionicView.loaded', ionicViewLoaded);

    $scope.circle_size = Math.round($(window).width() / 1.75);
    $scope.circle_fontsize = Math.round($scope.circle_size / 2);

    $scope.hac = 0;
    $scope.hbr = 0;
    $scope.hco = 0;
    $scope.spd = 0;
    $scope.txt = null;
    $scope.scoreDetails = 0;
    $scope.user_achievements = 0;
    $scope.user_badges = 0;
    $scope.community_badges = 0;
    $scope.community_achievments = 0;


    $scope.share = function () {
        alertBackend('share.score');
        try {
            window.plugins.socialsharing.share(
                $translate.instant('share_message'),
                $translate.instant('share_title'),
                [],
                $translate.instant('share_link'));
        } catch (e) {
            console.log('Error Sharing');
        }
    };

    function ionicViewLoaded() {

        LoadingUtil.showLoader();

        ScoresServices.getOverallDrivingScores(getScoresCallback);
        getDashboardGamingInfo();
    }

    function alertBackend(tagName) {
        if (tagName) {
            GamingServices.alertCoinTag(tagName).then(function (response) {
                console.log('alertBackend', response);
            }, function (error) {
                console.log('alertBackend error', error);
            });
        }
    }

    function getScoresCallback(pScoresData) {

        $scope.scoresData = pScoresData;
        $scope.hac = pScoresData.lastTrip.hac;
        $scope.hbr = pScoresData.lastTrip.hbr;
        $scope.hco = pScoresData.lastTrip.hco;
        $scope.spd = pScoresData.lastTrip.spd;
        $scope.txt = pScoresData.lastTrip.dd;

        var container = '.show-score .score';

        var score = pScoresData.lastTrip.score;

        $scope.lastTripDate = moment(DateUtil.formatDateAsUTC(StringUtil.getdateinformat(pScoresData.lastTrip.endTime))).format("dddd, MMMM D, YYYY");
        $scope.scoreDetails = score;

        $timeout(function () {
            LoadingUtil.hideLoader();
            $(container).addClass('loaded');
            initCircle(container, score);
            $('.page-hider').fadeOut('fast');
        }, 500);
    }

    function getDashboardGamingInfo() {
        GamingServices.getDashboardGamingData().then(function (response) {
            console.log("success", response);
            $scope.gamingData = response;
        }, function (response) {
            console.log("ERROR", response);
        });
    }


    function initCircle(pE, pV) {
        CircleProgressUtil.init_DefaultCircle(pE, pV, $scope.circle_size, $scope.themeColors.textPrimary, 12);
    }
}
