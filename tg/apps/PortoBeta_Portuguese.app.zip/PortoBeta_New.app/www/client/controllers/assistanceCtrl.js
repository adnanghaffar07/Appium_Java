angular.module('controllers')
    .controller('AssistanceCtrl', AssistanceCtrl);


function AssistanceCtrl($state, $scope, ExternalInteractionUtil, SupportServices, $translate, PopupUtil, $rootScope, AssistanceType, LoggerUtilType, LoadingUtil, FirebaseService, LocalStorage, LocalStorageKeys) {

    // SCOPE VARIABLES
    // --> All scope variables that are specific to that view will be defined here
    $scope.items = [
        {
            title: 'assistance_porto_seguro_auto_title',
            description: 'assistance_porto_seguro_auto_description',
            url: {
                android: 'https://play.google.com/store/apps/details?id=br.com.portoseguro.auto&hl=pt',
                ios: 'https://itunes.apple.com/br/app/porto-seguro-auto-auto-socorro/id940308962?mt=8'
            }
        },
        {
            title: 'assistance_porto_seguro_taxija_title',
            description: 'assistance_porto_seguro_taxija_description',
            url: {
                android: 'https://play.google.com/store/apps/details?id=com.mobinov.taxija.customer',
                ios: 'https://itunes.apple.com/br/app/v%C3%A1-de-t%C3%A1xi-waytaxi/id515952478?mt=8'
            }
        },
        {
            title: 'assistance_porto_seguro_cartoes_title',
            description: 'assistance_porto_seguro_cartoes_description',
            url: {
                android: 'https://play.google.com/store/apps/details?id=br.com.portoseguro.cartoes',
                ios: 'https://itunes.apple.com/us/app/cartao-credito-porto-seguro/id1068230889?l=pt&ls=1&mt='
            }
        },
        {
            title: 'assistance_porto_seguro_saudeodonto_title',
            description: 'assistance_porto_seguro_saudeodonto_description',
            url: {
                android: 'https://play.google.com/store/apps/details?id=br.com.portoseguro.saudeodonto',
                ios: 'https://itunes.apple.com/br/app/saude-odonto-e-portomed/id991010514?mt=8'
            }
        }
    ];


    // SCOPE FUNCTIONS
    // --> All scope functions specific to that view are defined here
    $scope.requestAssistance = requestAssistance;

    // SCOPE LIFE CYCLE
    // --> All needed life cycle events specific to that view are defined here. Note that we do not write the function directly in it.
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    $scope.$on('$ionicView.enter', ionicViewEnter);

    // FUNCTIONS
    /* 
        name : ionicViewBeforeEnter
        desc : Will call web services and prepare an object for the screen
    */

    ////// Functionality when before entering into the view

    function ionicViewBeforeEnter() {
        $rootScope.activeMenuItem = "assistance";
    }

    ////// Functionality when entering into the view
    function ionicViewEnter() {
        // PopupUtil.showSimpleAlert('teste', 'something here');

        FirebaseService.logEvent("view_item", {
            item_name: 'Aplicativos Porto', 
            custom_dimension2: "Aplicativos Porto",
            custom_dimension5: LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID) !== null ? "logged in" : "logged out"
        });
    }

    function requestAssistance(item) {

        FirebaseService.logEvent("select_content", {
            content_type: 'other_apps',
            item_name: 'Aplicativos Porto', 
            custom_dimension2: "Aplicativos Porto",
            custom_dimension5: LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID) !== null ? "logged in" : "logged out",
            custom_dimension7: $translate.instant(item.title)
        });

        if (ionic.Platform.is('browser')) {
            console.log('open browser');
            window.open(item.url.android);
        } else if (ionic.Platform.is('android')) {
            console.log('open android');
            ExternalInteractionUtil.openWebSite(item.url.android);
        } else if (ionic.Platform.is('ios')) {
            console.log('open ios');
            ExternalInteractionUtil.openWebSite(item.url.ios);
        }
    }

}
