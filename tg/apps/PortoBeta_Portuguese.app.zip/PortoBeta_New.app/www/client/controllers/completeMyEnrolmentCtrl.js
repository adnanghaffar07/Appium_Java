angular.module('controllers')
    .controller('CompleteEnrolmentCtrl', CompleteEnrolmentCtrl);

function CompleteEnrolmentCtrl($state, $scope, PopupUtil,BooleanConstant,$translate) {
    
    // SCOPE VARIABLES
    // --> All scope variables that are specific to that view will be defined here
    $scope.completeEnrolment = {};
    $scope.formValid = BooleanConstant.BOOL_FALSE;

    // SCOPE FUNCTIONS
    // --> All scope functions specific to that view are defined here
    $scope.submitEnrolment = submitEnrolment;

    // Events
    $scope.$watchGroup(['completeEnrolment.activationCode', 'completeEnrolment.date_of_birth'], validateForm);

    // SCOPE LIFE CYCLE
    // --> All needed life cycle events specific to that view are defined here. Note that we do not write the function directly in it.
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    $scope.$on('$ionicView.enter', ionicViewEnter);
    
    // FUNCTIONS
        
    ////// Functionality when before entering into the view
    /* 
        name : ionicViewBeforeEnter
        desc : Will call webservices / bind data before entering in to page.
    */
    function ionicViewBeforeEnter() {

    }

    ////// Functionality when entering into the view
    /* 
        name : ionicViewEnter
        desc : Will call webservices / bind data after entering in to page.
    */
    function ionicViewEnter() {

    }
    
    /*
        name : validateForm
        desc : Validate the form input details and handle enable / disable the submit button.
        parameters : newvalues, oldvalues, scope
        response : It'll set the formvalid to true / false based on the input values
    */
    function validateForm(newValues, oldValues, scope) {
        if (newValues[0] && newValues[1]) {
            $scope.formValid = BooleanConstant.BOOL_TRUE;
        } else {
            $scope.formValid = BooleanConstant.BOOL_FALSE;
        }
    }

    /*
        name : submitEnrolment
        desc : Submit the enrolment details. Showing the success alert when click on submit enrolment.
    */
    function submitEnrolment() {
        var buttons = [{
            text: '<span> Ok </span>',
            onTap: function (e) {
                $scope.formValid = BooleanConstant.BOOL_FALSE;
                $scope.completeEnrolment = {};
            }
        }];
        PopupUtil.showCustomPopupLocal("", "<img src='client/images/correct.png' style='height: 8vw;'/><h4>"+$translate.instant("enrolment_Complete")+"</h4><h6>"+$translate.instant("successfully_completed_enrolment")+"</h6>", buttons, "", true);
    }
}
