angular.module('controllers')
    .controller('LtpContentBlockedCtrl', LtpContentBlockedCtrl)

function LtpContentBlockedCtrl($state, $scope, $timeout, LocalStorage, LocalStorageKeys, GlobalConstants, ValidationUtil) {
    $scope.$on('$ionicView.loaded', ionicViewLoaded);
    $scope.submitClicked = submitClicked;
    $scope.settingsObj = LocalStorage.getObject(SHA512(GlobalConstants.BASE_URL + "/getSettings"));

    function ionicViewLoaded() {

    }

    function submitClicked() {
        if (textFirstName.value != null && textFirstName.value != "") {
            if (textLastName.value != null && textLastName.value != "") {
                if (textEmail.value != null && textEmail.value != "") {
                    if (ValidationUtil.validateEmail(textEmail.value)) {
                        var jsonParams = {
                                firstName: textFirstName.value,
                                lastName: textLastName.value,
                                email: textEmail.value
                            }
                            /*
                                TO DO : CALL WEB SERVICE TO SUBMIT FORM WITH THE PARAMS.
                            */
                    } else {
                        console.log("Invalid Email");
                    }
                } else {
                    console.log("EMail Empty");
                }
            } else {
                console.log("LastName Empty");
            }
        } else {
            console.log("FirstName Empty");
        }
    }
}
