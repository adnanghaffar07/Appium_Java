angular.module('controllers')
    .controller('QuoteYourQuoteCtrl', QuoteYourQuoteCtrl);

function QuoteYourQuoteCtrl($rootScope, $state, $scope, QuoteStatus, BooleanConstant, QuoteServices, PaymentServices, LocalStorage, LocalStorageKeys, $filter, LoadingUtil, PopupUtil, LoggerUtilType, $translate, $stateParams) {

    // SCOPE VARIABLES
    // --> All scope variables that are specific to that view will be defined here
    $scope.coverageDetails = {
        showCoverageDetails: false,
        showCoverageDeductibleDetails: false
    }
    $scope.packages = {};
    var packageDetails = {};
    // SCOPE FUNCTIONS
    // --> All scope functions specific to that view are defined here
    $scope.purchaseQuote = purchaseQuote;
    $scope.selectPackage = selectPackage;
    $scope.goToSimulation = goToSimulation;
    $scope.showCollisonDeductHelp = showCollisonDeductHelp;
    $scope.showTortHelp = showTortHelp;
    $scope.showBodilyInjuryHelp = showBodilyInjuryHelp;
    // SCOPE LIFE CYCLE
    // --> All needed life cycle events specific to that view are defined here. Note that we do not write the function directly in it.
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    $scope.$on('$ionicView.enter', ionicViewEnter);

    // FUNCTIONS
    /* 
        name : ionicViewBeforeEnter
        desc : Will call web services and prepare an object for the screen
    */
    function ionicViewBeforeEnter() {
        var createdQuote = $stateParams.createdQuote;
        if (createdQuote) {
            $scope.navigateTo(5);
        }
        LoadingUtil.showLoader();
        $scope.segmentColors = LocalStorage.getObject(LocalStorageKeys.MILE_CATEGORY_COLOR);
        QuoteServices.getQuotePricePerMileRatings().then(function (response) {
            LoadingUtil.hideLoader();
            var vrResponse = response.data.data;
            // $scope.userName = vrResponse.first_name;
            $translate('quoteCompleteText').then(function (completeText) {
                $scope.quoteComplete = completeText.replace("{0}", vrResponse.first_name);
            });
            $scope.confirmationNumber = vrResponse.confirmation_number;
            var vrQuoteVehicle = vrResponse.quote_vehicles[0];
            var pricings = vrQuoteVehicle.quote_vehicle_pricing_items;
            if (createdQuote) {
                // Preparing rootscope object so that we will be able to bind the data in next screens.
                $rootScope.quoteData['user'] = response.data.data;
                $rootScope.quoteData['vehicles'] = $rootScope.quoteData['user'].quote_vehicles;
                if ($rootScope.quoteData['vehicles'][0].address) {
                    $rootScope.quoteData['user']['postal_code'] = $rootScope.quoteData['vehicles'][0].address.zip_code;
                    $rootScope.quoteData['user']['city_name'] = $rootScope.quoteData['vehicles'][0].address.city;
                    $rootScope.quoteData['user']['street_name'] = $rootScope.quoteData['vehicles'][0].address.street_name;
                    $rootScope.quoteData['user']['state'] = $rootScope.quoteData['vehicles'][0].address.state;
                }
                $rootScope.quoteData['drivers'] = $rootScope.quoteData['vehicles'][0].quote_drivers;
                $rootScope.quoteData['finalDetails'] = {};
                $rootScope.quoteData['finalDetails']['email'] = $rootScope.quoteData['drivers'][0].email;
            }
            
            // webservice call to get available premiums/categories
            QuoteServices.getPremiums().then(function (response) {
                var premiums = response.data.data;
                premiums = $filter('orderBy')(premiums, 'id');
                pricings = $filter('orderBy')(pricings, 'premium_id');
                $scope.annualMilage = vrQuoteVehicle.annual_mileage;
                for (var i = 0; i < premiums.length; i++) {
                    for (var j = 0; j < pricings.length; j++) {
                        if (premiums[j].id == pricings[j].premium_id) {
                            pricings[j]['type'] = premiums[j]['name'];
                        }
                    }
                }
                for (var i = 0; i < pricings.length; i++) {
                    switch (pricings[i].type) {
                        case "safe_interstate":
                            $scope.safe_interest = pricings[i].price;
                            break;
                        case "safe_other":
                            $scope.safe_other = pricings[i].price;
                            break;
                        case "risky":
                            $scope.risky = pricings[i].price;
                            break;
                        case "aggressive":
                            $scope.aggressive = pricings[i].price;
                            break;
                        case "dangerous":
                            $scope.dangerous = pricings[i].price;
                            break;
                    }
                }
                $scope.estimatedAnnualUsage = (0.85 * $scope.annualMilage * (($scope.safe_interest + $scope.safe_other) / 2)) + (0.15 * $scope.annualMilage * $scope.aggressive);
            }, function (error) {
                // handle the error
                PopupUtil.showSimpleAlert($translate.instant('error'), $translate.instant(error['i18n-key']));
            });

        }, function (error) {
            LoadingUtil.hideLoader();
            PopupUtil.showSimpleAlert($translate.instant('error'), $translate.instant(error['i18n-key']));
            //handle error
        });

        PaymentServices.getPackages().then(function (response) {
            console.log(111222, response.data);
            $scope.packages = response.data;
            $scope.selprepaid = $scope.packages[0].amount;
            packageDetails.package_id = $scope.packages[0].id;
            packageDetails.amount = $scope.packages[0].amount;
            LocalStorage.setObject(LocalStorageKeys.BUY_PACKAGE_DETAILS, packageDetails);
        }, function (error) {
            PopupUtil.showSimpleAlert($translate.instant('error'), $translate.instant(error['i18n-key']));
        });

        if ($rootScope.steps.yourquote.length == 0) {
            $rootScope.steps.yourquote = QuoteStatus.PROCESS;
        }
    }

    function ionicViewEnter() {

    }

    function purchaseQuote() {
        $rootScope.steps.yourquote = QuoteStatus.DONE;
        $state.go('app.quotePurchase');
    }

    function selectPackage(amount, packageId) {
        $scope.selprepaid = ' $' + amount;
        packageDetails.package_id = packageId;
        packageDetails.amount = amount;
        LocalStorage.setObject(LocalStorageKeys.BUY_PACKAGE_DETAILS, packageDetails);
    }

    function goToSimulation() {
        var qid = LocalStorage.getObject(LocalStorageKeys.QUOTE_ID);
        $state.go('app.quoteSimulation', {
            quoteId: qid
        });
    }

    /*
    name : showCollisonDeductHelp
    return : a popup with some message.
    */
    function showCollisonDeductHelp() {
        PopupUtil.showSimpleAlert($translate.instant('collisionHelpTitle'), $translate.instant('collisionHelpDesc'));
    }

    /*
    name : showTortHelp
    return : a popup with some message.
    */
    function showTortHelp() {
        PopupUtil.showSimpleAlert($translate.instant('tortHelpTitle'), $translate.instant('tortHelpDesc'));
    }

    /*
    name : showBodilyInjuryHelp
    return : a popup with some message.
    */
    function showBodilyInjuryHelp() {
        PopupUtil.showSimpleAlert($translate.instant('bodilyInjuryHelpTitle'), $translate.instant('bodilyInjuryHelpDesc'));
    }
}
