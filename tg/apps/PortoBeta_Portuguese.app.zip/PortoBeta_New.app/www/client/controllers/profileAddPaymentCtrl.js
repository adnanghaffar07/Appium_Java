angular.module('controllers')
    .controller('ProfileAddPaymentCtrl', ProfileAddPaymentCtrl);

function ProfileAddPaymentCtrl($rootScope, $scope, $state, $ionicHistory, LoadingUtil) {
    // SCOPE FUNCTIONS
    $scope.scanCard = scanCard;
    $scope.navigateToPayPal = navigateToPayPal;
    $scope.navigateToCreditCard = navigateToCreditCard;

    //SCOPE VARIABLES

    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    // FUNCTIONS
    /* 
      name : ionicViewBeforeEnter
      desc : Make a call to webservice to fetch data and bind object.
  */
    function ionicViewBeforeEnter() {

    }

    function scanCard() {
        LoadingUtil.showLoader();
        CardIO.scan({
            requireCVV : true,
            requirePostalCode : true,
            scanExpiry : true,
            requireExpiry: true
        },
            onCardIOComplete,
            onCardIOCancel
        );
    }

    function onCardIOComplete(response) {
        LoadingUtil.hideLoader();
        console.log("scan success");
        var cardDetails = {};
        cardDetails.cc_number = response.cardNumber;
        cardDetails.expiration_month = response.expiryMonth.toString();
        cardDetails.expiration_year = response.expiryYear.toString().substr(2);
        cardDetails.cvs_number = response.cvv;
        cardDetails.postal_code = response.postalCode;
        $state.go('app.profileAddPaymentCardDetails', {
            specificPayment : cardDetails,
            isCardScanned : true
        });
    };

    function onCardIOCancel() {
        LoadingUtil.hideLoader();
        console.log("card.io scan cancelled");
    };
    
    function navigateToPayPal(){
        $state.go('app.profileAddPaymentPaypal',{"specificPayment":{}});
    }

    function navigateToCreditCard() {
        $state.go('app.profileAddPaymentCardDetails', {
            specificPayment : {},
            isCardScanned : true
        });
    }
}
