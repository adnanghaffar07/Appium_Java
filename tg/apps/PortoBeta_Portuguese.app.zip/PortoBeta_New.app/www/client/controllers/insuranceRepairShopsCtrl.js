angular.module('controllers')
    .controller('InsuranceRepairShopsCtrl', InsuranceRepairShopsCtrl);
function InsuranceRepairShopsCtrl($rootScope, $state, $scope, InsuranceServices, MapsUtil, $timeout, ExternalInteractionUtil,MapsProperties,LoggerUtilType,PopupUtil,$translate) {
    // SCOPE VARIABLES
    // --> All scope variables that are specific to that view will be defined here
    var markerObj =MapsProperties.MARKER_OBJ;
    var map = {};
    var mapPoints = [];
    var mapArrayPoints = [];
    var currentPosition = {};

    // SCOPE FUNCTIONS
    // --> All scope functions specific to that view are defined here
    $scope.locateRepairShop = locateRepairShop;
    $scope.getDirections = getDirections;
    $scope.callRepairShop = callRepairShop;

    // SCOPE LIFE CYCLE
    // --> All needed life cycle events specific to that view are defined here. Note that we do not write the function directly in it.
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    $scope.$on('$ionicView.enter', ionicViewEnter);

    // FUNCTIONS
    /* 
        name : ionicViewBeforeEnter
        desc : Will call web services and prepare an object for the screen
    */
    function ionicViewBeforeEnter() {
                /* 
            desc : It gets current location's latitude and logitude using geolocation plugin.
        */
        navigator.geolocation.getCurrentPosition(function(position) {
            currentPosition = {
                latitude: position.coords.latitude,
                longitude: position.coords.longitude
            };
            mapArrayPoints = [currentPosition.longitude, currentPosition.latitude];
            /* 
                desc : a webservice call to get list of repair shops near to current location.
            */
            InsuranceServices.getRepairShops(currentPosition).then(function(response) {
                $scope.repairShops = response.data;
                var mapPoints = [];
                for (var i = 0; i < response.length; i++) {
                    var mapPiont = {};
                    mapPiont.lon = parseFloat(response[i].longitude);
                    mapPiont.lat = parseFloat(response[i].latitude);
                    mapPoints[i] = (mapPiont);
                }
                MapsUtil.multiPointMap_init("repair-shops", mapPoints, mapArrayPoints, markerObj, 1);
            }, function(error) {
                PopupUtil.showSimpleAlert($translate.instant('error'),$translate.instant(error['i18n-key']));
                /*
                    Hardcoded the repair shops data for now.
                */
                // $scope.repairShops = [
                //     {
                //         "id": "b6b91acb-d0f2-11e5-b3bf-a0b3cc85f362",
                //         "phone": "",
                //         "longitude": -73.871127,
                //         "name": "Atlas Gym",
                //         "latitude": 45.523598,
                //         "distance": "12477.924838186862",
                //         "address": {
                //             "id": "e04675fb-d0f2-11e5-b3bf-a0b3cc85f362",
                //             "street": "1242 Chemin du Bord-de-l'Eau",
                //             "app": null,
                //             "state": "Québec",
                //             "city": "Laval",
                //             "postal_code": "H7Y 1B6",
                //             "country": "Canada",
                //             "address": "1242 Chemin du Bord-de-l'Eau Laval Québec Canada H7Y 1B6"
                //         }
                //     },
                //     {
                //         "id": "20c786bd-0832-45ed-9552-0f5027d3cffe",
                //         "phone": "1-800-256-3695",
                //         "longitude": -73.799549,
                //         "name": "Repair shop 2",
                //         "latitude": 45.539289,
                //         "distance": "12306.991920848302",
                //         "address": {
                //             "id": "74c02322-ae94-4d06-b2df-8a9c689a3f66",
                //             "street": "1234 sesame street",
                //             "app": null,
                //             "state": "Québec",
                //             "city": "Laval",
                //             "postal_code": "J7Z 2K4",
                //             "country": "Canada",
                //             "address": "1234 sesame street Laval Québec Canada J7Z 2K4"
                //         }
                //     },
                //     {
                //         "id": "4bef145a-91eb-46d6-9160-993fd552c295",
                //         "phone": "1-800-256-3695",
                //         "longitude": -73.829649,
                //         "name": "Repair shop 3",
                //         "latitude": 45.509389,
                //         "distance": "12306.991920848302",
                //         "address": {
                //             "id": "74c02322-ae94-4d06-b2df-8a9c689a3f66",
                //             "street": "1234 sesame street",
                //             "app": null,
                //             "state": "Québec",
                //             "city": "Laval",
                //             "postal_code": "J7Z 2K4",
                //             "country": "Canada",
                //             "address": "1234 sesame street Laval Québec Canada J7Z 2K4"
                //         }
                //     },
                //     {
                //         "id": "4bef145a-91eb-46d6-9160-993fd552c296",
                //         "phone": "1-800-256-3695",
                //         "longitude": -73.88499649,
                //         "name": "Repair shop 4",
                //         "latitude": 45.549389,
                //         "distance": "12306.991920848302",
                //         "address": {
                //             "id": "74c02322-ae94-4d06-b2df-8a9c689a3f66",
                //             "street": "1234 sesame street",
                //             "app": null,
                //             "state": "Québec",
                //             "city": "Laval",
                //             "postal_code": "J7Z 2K4",
                //             "country": "Canada",
                //             "address": "1234 sesame street Laval Québec Canada J7Z 2K4"
                //         }
                //     }
                // ];
                // 
                // var mapPiont = {};
                // var repairSop = {};
                // for (var i = 0; i < $scope.repairShops.length; i++) {
                //     mapPiont = {};
                //     repairSop = $scope.repairShops[i];
                //     mapPiont.lon = parseFloat(repairSop.longitude);
                //     mapPiont.lat = parseFloat(repairSop.latitude);
                //     mapPiont.id = repairSop.id;
                //     mapPoints[i] = mapPiont;
                // }
                // /*
                //     desc : It creates a map and it adds markers for each repair shop.
                // */
                // map = MapsUtil.multiPointMap_init("repair-shops", mapPoints, mapArrayPoints, markerObj);
            });
        }, function (error) {
            console.log(error);
        });
    }

    /* 
        name : ionicViewEnter
        desc : Will call web services and prepare an object for the screen
    */
    function ionicViewEnter() {

    }
    
     /*
        name : locateRepairShop
        parameters : a repair shop id
        desc : It highlights the selected repair shops on map.
        return : none
    */
    function locateRepairShop(repairShopId) {
        map.getOverlays().clear();
        var icon;
        var pSelected = '';
        for (var point = 0; point < mapPoints.length; point++) {
            if (mapPoints[point].id == repairShopId) {
                pSelected = point;
                break;
            }
        }
        for (var pos = 0; pos < mapPoints.length; pos++) {
            if (pos == pSelected) {
                icon = MapsProperties.MAP_BLUE_IMG;
            } else {
                icon = MapsProperties.MAP_BLACK_IMG;
            }
            map.addOverlay(new ol.Overlay({
                position: ol.proj.transform(
                    [mapPoints[pos].lon, mapPoints[pos].lat],
                    'EPSG:4326',
                    'EPSG:3857'
                ),
                element: $("<img src=" + icon + ">")
            }));
        }
    }
    
    /*
        name : getDirections
        parameters : a repair shop position - latitude and longitude
        desc : It opens mobile's native maps app (gmaps for Android and apple-maps for ios) and shows directions from
               current location to selected repair shop.
        return : none
    */
    function getDirections(lat, lon) {
        launchnavigator.navigate([lat, lon], [currentPosition.latitude, currentPosition.longitude],
            function() {

            },
            function(error) {

            }, {

            });
    }
    
    /*
        name : callRepairShop
        parameters : phone number of a repair shop
        desc : It will make a call to selected repairshop using a native intent
        return : none
    */
    function callRepairShop(phone) {
        ExternalInteractionUtil.composePhoneNumber(phone);
    }
}