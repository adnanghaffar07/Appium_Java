angular.module('controllers')
    .controller('ProfileDateOfBirthCtrl', ProfileDateOfBirthCtrl);

function ProfileDateOfBirthCtrl($rootScope, $scope, $state, $timeout, $ionicHistory, LocalStorage, LocalStorageKeys,BooleanConstant, ProfileServices, WebServiceCache, PopupUtil, $translate, ValidationUtil) {
    // SCOPE FUNCTIONS
    $scope.saveProfile = saveProfile;

    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    $scope.$on('$ionicView.loaded', ionicViewLoaded);

    $scope.focus = function ($event) {
        if ($('#dateOfBirth').val().length === 0) {
            setTimeout(function() {
                $('#dateOfBirth')[0].setSelectionRange(0, 0);    
            }, 100);
        }
    }

    //FUNCTIONS
    function ionicViewLoaded() {
        $('#dateOfBirth').mask('99-99-9999');

        $scope.profileData = LocalStorage.getObject(LocalStorageKeys.PROFILE_DATA);
        $scope.dateOfBirth = $scope.profileData.user.date_of_birth ? $scope.profileData.user.date_of_birth.split("-").reverse().join("-") : null;
    }

    function ionicViewBeforeEnter() {
        $scope.profileData = LocalStorage.getObject(LocalStorageKeys.PROFILE_DATA);
    }
    
     /*
        name: saveProfile
        desc: Saves updated user name to local storage and server.
    */ 
    function saveProfile() {

        var _dateOfBirth = dateOfBirth.value ? dateOfBirth.value.split("-").reverse().join("-") : null;

        // Means it is an Insurer code
        if (_dateOfBirth === null || _dateOfBirth === "") {
            PopupUtil.showSimpleAlert($translate.instant('Error'), '<p>' + $translate.instant('date_of_birth_empty') + '</p>');
            return false;
        } else if (!ValidationUtil.isValidDate(_dateOfBirth, 'YYYY-MM-DD')) {
            PopupUtil.showSimpleAlert($translate.instant('Error'), '<p>' + $translate.instant('date_of_birth_invalid')+ '</p>');
            return false;
        }

        $scope.profileData.user.date_of_birth = _dateOfBirth;

        $rootScope.needToSaveProfile = BooleanConstant.BOOL_TRUE;
        LocalStorage.setObject(LocalStorageKeys.PROFILE_DATA, $scope.profileData);

        $ionicHistory.goBack();
    }
}
