angular.module('controllers')
    .controller('InsuranceClaimsLocationSelectionCtrl', InsuranceClaimsLocationSelectionCtrl);

function InsuranceClaimsLocationSelectionCtrl($state, $rootScope, $scope, $ionicHistory,$stateParams,LoadingUtil,TripsServices,StringUtil,TripEventType,MapsUtil,DateUtil, NewClaims) {
    // SCOPE VARIABLES
    // --> All scope variables that are specific to that view will be defined here
       var tripId = $stateParams.tripid;
    // SCOPE FUNCTIONS
    // --> All scope functions specific to that view are defined here
    $scope.selectTrip = selectTrip;
    
    // SCOPE LIFE CYCLE
    // --> All needed life cycle events specific to that view are defined here. Note that we do not write the function directly in it.
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    $scope.$on('$ionicView.enter', ionicViewEnter);
 
    // FUNCTIONS
    /* 
        name : ionicViewBeforeEnter
        desc : Will call web services and prepare an object for the screen
    */
    function ionicViewBeforeEnter() {
         
    }
    
    function ionicViewEnter() {
        
        LoadingUtil.showLoader();
        TripsServices.getTrip(tripId).then(function (data) {
            LoadingUtil.hideLoader();
            MapsUtil.initializeOpenLayerMap(data,TripEventType);
            $scope.tripDetails = data;
            $scope.tripDetails.start_time = moment(StringUtil.getdateinformat(DateUtil.formatDateAsUTC(data.start_time))).format('h:mm A');
            $scope.tripDetails.end_time = moment(StringUtil.getdateinformat(DateUtil.formatDateAsUTC(data.end_time))).format('h:mm A');
    },function(error){
        LoadingUtil.hideLoader();
    });
    }
    
    /* 
        name : selectTrip
        desc : It has to store the selected trip details and it should redirect to previous screen,
               for now, it will redirect to back view as we have hardcoded trips data.
    */
    function selectTrip() {
        $rootScope.claimDetails.location={collidedtripid:tripId};
        $state.go("app.insuranceClaimsCollision",{"claimType":NewClaims.COLLISION});
    }
}