angular.module('controllers')
    .controller('GaqCtrl', GaqCtrl);

function GaqCtrl($state, $scope) {
    $scope.$on('$ionicView.loaded', ionicViewLoaded);

    function ionicViewLoaded() {
        if (!angular.isUndefined(cordova)) {
            cordova.InAppBrowser.open("http://www.google.ca", "_blank", "location=yes");
        }
    }
}
