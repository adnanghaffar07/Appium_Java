angular.module('controllers')
    .controller('CarbitConnectionCtrl', CarbitConnectionCtrl);

function CarbitConnectionCtrl($rootScope, $scope, $ionicHistory, LocalStorage, LocalStorageKeys, CordovaBroadcaster, $timeout) {
    // SCOPE VARIABLES
    $scope.device;
    
    // SCOPE FUNCTIONS
    $scope.callIntent = callIntent;

    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);


    // FUNCTIONS
     /* 
        name : ionicViewBeforeEnter
        desc : It will set a fake variable 'device' to null and calls callIntent method to assign some value to device variable.
    */
    function ionicViewBeforeEnter() {
        $scope.device = null;
        callIntent();
    }
    
     /* 
        name : callIntent
        desc : It is to fake the carBit connection functionality, in reality it should call an intent that scans T2 device. 
    */
    function callIntent() {
        $timeout(function() {
            $scope.device = "found";
            $timeout(function() {
                $scope.navigateTo('app.settings');
            }, 2000);
        }, 3000);
    }
}
