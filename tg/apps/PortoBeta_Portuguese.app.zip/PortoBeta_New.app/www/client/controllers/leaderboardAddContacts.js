angular.module('controllers')
    .controller('LeaderboardAddContactsCtrl', LeaderboardAddContactsCtrl);

function LeaderboardAddContactsCtrl($state, $rootScope, $scope, $ionicHistory,BooleanConstant,ContactsUtil) {
    // SCOPE VARIABLES
    $scope.searchTerm = {};
    $scope.showClear = BooleanConstant.BOOL_FALSE;
    $scope.users = [];

    // SCOPE FUNCTIONS
    $scope.goBack = goBack;
    $scope.searchUpdated = searchUpdated;
    $scope.clearSearchTerm = clearSearchTerm;
    $scope.cancelSearch = cancelSearch;
    $scope.submitSearch = submitSearch;
    $scope.inviteFriend = inviteFriend;

    // SCOPE LIFE CYCLE EVENTS

    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    // FUNCTIONS

    function ionicViewBeforeEnter() {
        fetchUsers();
    }

    function goBack() {
        $ionicHistory.goBack();
    }

    function searchUpdated() {
        console.log(111, $scope.searchTerm.value);
        if ($scope.searchTerm.value.length > 0) {
            $scope.showClear = BooleanConstant.BOOL_TRUE;
        } else {
            $scope.showClear = BooleanConstant.BOOL_FALSE;
        }
    }

    function clearSearchTerm() {
        $scope.searchTerm.value = '';
        $scope.showClear = BooleanConstant.BOOL_FALSE;
    }

    function cancelSearch() {
        $scope.searchTerm.value = '';
        $scope.showClear = BooleanConstant.BOOL_FALSE;
    }

    function submitSearch() {
        console.log('SUBMIT', $scope.searchTerm.value);
    }

    function fetchUsers() {
        ContactsUtil.getAllContacts().then(function (response) {
             $scope.users=response;
            
        }, function (pError) {

        });
    }

    function inviteFriend(pUser) {

    }
}
