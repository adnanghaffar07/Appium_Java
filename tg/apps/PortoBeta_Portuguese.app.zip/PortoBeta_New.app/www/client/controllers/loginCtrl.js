
angular.module('controllers')
    .controller('LoginCtrl', LoginCtrl);

function LoginCtrl($rootScope, 
                   $scope, 
                   $state, 
                   $q, 
                   $timeout, 
                   $translate, 
                   LoginServices, 
                   ProfileServices, 
                   SettingsServices, 
                   CommunicationService, 
                   StringUtil, 
                   ValidationUtil, 
                   LoadingUtil, 
                   ProfileDataUtil, 
                   OfflineLoginFactory, 
                   LoginType, 
                   AccountType, 
                   LocalStorage, 
                   LocalStorageKeys, 
                   SocialUserService, 
                   ApiErrorCode, 
                   CordovaBroadcaster, 
                   PaymentServices, 
                   AppConfigServices, 
                   PopupUtil, 
                   SocialLoginUtil, 
                   GlobalConstants, 
                   FirebaseService, 
                   ApplicationMode) {

    // Scope Functions
    $scope.validateLoginEmail = validateLoginEmail;
    $scope.validateLoginPassword = validateLoginPassword;
    $scope.login = login;
    $scope.goToRegister = goToRegister;
    $scope.goToForgotPassword = goToForgotPassword;
    $scope.facebookLogin = facebookLogin;
    $scope.onClickGoogle = onClickGoogle;
    $scope.goToDebug = goToDebug;

    // Scope Variables
    $scope.loginCreds = {};
    $scope.formValid = false;
    $scope.hasFbLogin = true;
    $scope.hasGpLogin = true;
    $scope.showErrorMessage = false;
    $scope.errorMessage = "";
    $scope.autoLoginTimeout = 0;

    // View Loading Cycle
    $scope.$on('$ionicView.loaded', ionicViewLoaded);
    $scope.$on('$ionicView.enter', ionicViewEnter);
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    // Events
    $scope.$watchGroup(['emailValid', 'passwordValid'], validateForm);
    $scope.$watch('showErrorMessage', setErrorMessageTimer);

    // FUNCTIONS
    LoadingUtil.showLoader();

    function goToDebug() {
        $state.go("debugScreen");
    }

    function ionicViewBeforeEnter() {
        // Make a call too database to know which views I need to show.
        // TODO : Makee the actual call

        $scope.showErrorMessage = false;

        var menuItems = [
            {
                tag: "menu_dashboard",
                state: "app.dashboardPorto",
                selected: "dashboard",
                url: null
            }, {
                tag: "menu_tripHistory",
                state: "app.tripHistory",
                selected: "tripHistory",
                url: null
            }, {
                tag: "menu_badges",
                state: "app.badges",
                selected: "badges",
                url: null
            }, {
                tag: "menu_leaderboard",
                state: "app.leaderboard",
                selected: "leaderboard",
                url: null
            }, {
                tag: "menu_courses",
                state: null,
                selected: null,
                url: "https://cursos.campanhaporto.com.br/inscreva-se"
            }, {
                tag: "menu_coins",
                state: "app.coins",
                selected: "coins",
                url: null
            }, {
                tag: "menu_missions",
                state: "app.missions",
                selected: "missions",
                url: null
            }, {
                tag: "menu_assistance",
                state: "app.assistance",
                selected: "assistance",
                url: null
            }, {
                tag: "menu_faq",
                state: "app.faq",
                selected: "faq",
                url: null
            }, {
                tag: "menu_gaq",
                state: null,
                selected: null,
                url: "https://transitomaisgentil.com.br/cotacaoapp/"
            }
        ];
        LocalStorage.setObject(LocalStorageKeys.MENU_ITEMS, menuItems);

        // Check if we are on a browser or a device
        if (ionic.Platform.is('browser')) {
            // Add a default key when debuging app on PC
            onBrowserReady();
        } else {
            document.addEventListener("deviceready", onDeviceReady, false);
        }
    }

    /*
        Name : onBrowserReady
        Desc : Test environment, on PC, use english as default language
    */
    function onBrowserReady() {
        var current = LocalStorage.get(LocalStorageKeys.CURRENT_LOCALE_KEY);
        if (!current) {
            var key = 'pt-BR'; //-----> pp-PP is used to be splitted and compared to available languages then the system will use the default language        
            LocalStorage.set(LocalStorageKeys.DEVICE_LOCALE_KEY, key);
            $translate.use(key);
            $rootScope.deviceLanguage = key;
        } else {
            $translate.use(current);
        }

        $timeout(function () {
            $('.login-page-hider').fadeOut('fast');
        }, 1000);
    }

    /*
        Name : onDeviceReady
        Desc : Prod environment, on Phone, use Device's locale key
    */
    function onDeviceReady() {
        var current = LocalStorage.get(LocalStorageKeys.CURRENT_LOCALE_KEY);

        if (!current) {
            var key = LocalStorage.get(LocalStorageKeys.DEVICE_LOCALE_KEY);

            if (angular.isUndefined(key) || !key) {
                var key = 'pp-PP'; //-----> pp-PP is used to be splitted and compared to available languages then the system will use the default language
            }

            //            LocalStorage.set(LocalStorageKeys.CURRENT_LOCALE_KEY, key);
            $translate.use(key);
            $rootScope.deviceLanguage = key;
        } else {
            $translate.use(current);
        }

        $timeout(function () {
            $('.login-page-hider').fadeOut('fast');
        }, 1000);
    }

    /*
        NAME : ionicViewLoaded
        DESC : controller initialization. All code will be fired only once at the load of the screen. This is the first step in the screen load cycle.
    */
    function ionicViewLoaded() {

        // Firebase integration adding id when users enter
        if (LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID) === "" || LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID) === null) {

            FirebaseService.logEvent("view_item", {
                item_name: "Login",
                custom_dimension2: "Login"
            });
        }

        if ((GlobalConstants.BASE_URL == null) || (angular.isUndefined(GlobalConstants.BASE_URL)) || (GlobalConstants.BASE_URL == "")) {
            $timeout(function () {
                $("body #btnTranslate").click();
            }, 1500);
        }

        if ($scope.hasFbLogin && $scope.hasGpLogin) {
            $timeout(function () {
                $scope.fb_text = $translate.instant('facebookText');
                $scope.gp_text = $translate.instant('googleText');
            }, 1000);
        } else {
            $timeout(function () {
                $scope.fb_text = $translate.instant('facebookLoginText');
                $scope.gp_text = $translate.instant('googleLoginText');
            }, 1000);
        }
        
    }

    function ionicViewEnter() {
        console.log('Register entrou ionic Enter');

        GlobalConstants.init();
        getThemeSettings();
        var requestedCode = LocalStorage.getBoolean('requestedCode', 'false');

        console.log('Register requestedCode', requestedCode);

        if (requestedCode == 'true') {
            LoadingUtil.hideLoader();
            $state.go('requestCode');
        } else {
            //autoLogin();
            checkAutoLogin();
        }
    }

    function getThemeSettings() {

        // Check for theme colors and set the settings
        var storedModifiedDate = LocalStorage.get(LocalStorageKeys.APP_SETTINGS_MODIFIED_DATE);
        AppConfigServices.getConfigValue("modified").then(function (result) {

            pCurrentModifiedDate = new Date(StringUtil.getdateinformat(storedModifiedDate));
            modifiedDate = new Date(StringUtil.getdateinformat(result));

            AppConfigServices.getThemeColors().then(function (data) {
                setThemeColors(data);
                // Get the logo form settings
                var settingsObj = LocalStorage.getObject(SHA512(GlobalConstants.BASE_URL + "/getSettings"));
                console.log(settingsObj.data, settingsObj.data.AppSetting.onboarding);
                $rootScope.companyLogo = settingsObj.data.AppSetting.logo;
            }, function (error) {

            });
        }, function (error) {

        });
    }

    /*
        NAME : setErrorMessageTimer
        DESC : Set the timout time for the error message
    */
    function setErrorMessageTimer(n) {
        if (n) {
            $timeout(function () {
                $scope.showErrorMessage = false;
            }, 3000);
        }
    }

    /*
        NAME : login
        DESC : Login user
    */
    function login() {

        LoadingUtil.showLoader();
        // Load data for Dynamic Menu items
        AppConfigServices.getAppBehaviorSettings();

        LocalStorage.set(LocalStorageKeys.LOGIN_EMAIL, $scope.loginCreds.email);
        LocalStorage.set(LocalStorageKeys.LOGIN_PASSWORD, $scope.loginCreds.password);
        
        LoginServices.login($scope.loginCreds.email, $scope.loginCreds.password).then(function (data) {
            // Set crds in localstorage for later use
            LocalStorage.set(LocalStorageKeys.LOGIN_TYPE, data.data.application_type_id);
            LocalStorage.set(LocalStorageKeys.ACCOUNT_TYPE, AccountType.NORMAL);

            OfflineLoginFactory.saveLoginCredentials(data.data.application_type_id, $scope.loginCreds.email, $scope.loginCreds.password);

            prepareProfileData(data.data.application_type_id);

            prepareUserSettings();
            prepareCommunicationSettings();

        }, function (error) {
            LoadingUtil.hideLoader();
            // SHOW ERROR MESSAGES
            checkError(error);
        });
    }
    
    /*
        NAME: checkAutoLogin
    */
    function checkAutoLogin() {
        if(LocalStorage.get(LocalStorageKeys.LOGIN_EMAIL)){
            if(LocalStorage.get(LocalStorageKeys.ACCOUNT_TYPE) == AccountType.GOOGLE){
                // GOOGLE LOGIN
                onClickGoogle();
            }else if(LocalStorage.get(LocalStorageKeys.ACCOUNT_TYPE) == AccountType.FACEBOOK){
                // FACEBOOK LOGIN
                facebookLogin();
            } else{
                // NORMAL LOGIN
                autoLogin();
            }
        } else{
            // We do not have creds info, so show login screen
            LoadingUtil.hideLoader();
        }
    }
    
    function autoLogin() {        
        LoginServices.login(LocalStorage.get(LocalStorageKeys.LOGIN_EMAIL), LocalStorage.get(LocalStorageKeys.LOGIN_PASSWORD)).then(function (data) {
            LoadingUtil.hideLoader();
            prepareProfileData(data.data.application_type_id);

            prepareUserSettings();
            prepareCommunicationSettings();

        }, function (error) {
            LoadingUtil.hideLoader();
            // SHOW ERROR MESSAGES
            checkError(error);
        });
        
    }


    /*
        NAME : facebookLogin
        DESC : Login user using facebook plugin
    */
    function facebookLogin() {
        // NEW FACEBOOK LOGIN CODE
        setTimeout(function(){
            SocialUserService.loginFacebookOAuth().then(function (response) {
                getFacebookUserMeta(response.authResponse.accessToken);
            });
        }, 1000);
    }

    /*
       NAME : getFacebookUserMeta
       DESC : Gets user data based on obtained access token.
   */
    function getFacebookUserMeta(accessToken) {
        SocialUserService.getFacebookUserData(accessToken).then(function (response) {

            var firstName = response.first_name;
            var lastName = response.last_name;
            var userId = response.id;
            var email = response.email;
            var jsonParams = {
                "User": {
                    'facebook_id': userId,
                    'access_token': accessToken,
                    'email': email,
                    'first_name': firstName,
                    'last_name': lastName
                }
            };
            LocalStorage.set(LocalStorageKeys.FACEBOOK_USER_SECRET, jsonParams["User"]["access_token"]);

            LocalStorage.setObject(LocalStorageKeys.SOCIAL_META, response);
            LocalStorage.set(LocalStorageKeys.ACCOUNT_TYPE, AccountType.FACEBOOK);
            LocalStorage.set(LocalStorageKeys.APP_MODE, ApplicationMode.TBYB);
            setLocalData(userId, accessToken);
            facebookLoginWebservice(jsonParams);
        }, function (error) {
            LoadingUtil.hideLoader();
            if (angular.isUndefined(error.email)) {
                PopupUtil.showSimpleAlert($translate.instant('ErrorTitle'), '<p>' + $translate.instant("fb_email_missing") + '</p>');
            }
            LocalStorage.set(LocalStorageKeys.ACCESS_TOKEN, null);
            return false;
        });
    }

    /*
        NAME : facebookLoginWebservice
        DESC : Save user data in server and navigate to dashboard.
    */
    function facebookLoginWebservice(jsonParams) {

        console.log(jsonParams, 'jsonParams facebook');

        LoadingUtil.showLoader();
        LoginServices.facebookLogin(jsonParams).then(function (data) {

            LoadingUtil.hideLoader();
            console.log("### FACEBOOK LOGIN SUCCESS ###");
            LocalStorage.set(LocalStorageKeys.LOGIN_TYPE, data.application_type_id);

            OfflineLoginFactory.saveLoginCredentials(data.application_type_id, jsonParams["User"]["email"], "");

            prepareProfileData(data.application_type_id);
            prepareUserSettings();
            prepareCommunicationSettings();
        }, function (error) {
            LoadingUtil.hideLoader();
            checkError(error);
        });
    }

    /*
        NAME : googleLogin
        DESC : Login user using google plugin
    */
    function onClickGoogle() {
        SocialUserService.loginGoogle().then(function (response) {
            //TODO success
            getGoogleUserMeta(response);
        }, function (error) {
            //TODO error
        });
    }

    /*
      NAME : getGoogleUserMeta
      DESC : Gets user data based on obtained access token.
  */
    function getGoogleUserMeta(pResponse) {
        var accessToken = "";
        var idToken = pResponse.idToken;
        if (angular.isDefined(pResponse.accessToken)) {
            // On IOS, Google plugin returns the access token directly
            accessToken = pResponse.accessToken;

            getGoogleUserData(accessToken, idToken);
        } else {
            // On Android, the plugin doesn't return the access token, so I have to get it from a POST request
            var serverAuthCode = pResponse.serverAuthCode;
            getGoogleAccessToken(serverAuthCode).then(function (data) {
                getGoogleUserData(data, idToken);
            });
        }

    }

    function getGoogleUserData(accessToken, idToken) {
        SocialUserService.getGoogleUserData(accessToken).then(function (response) {
            var userId = response.id;
            var email = processEmails(response['emails']);
            var firstName = response['name']['givenName'];
            var lastName = response['name']['familyName'];
            var jsonParams = {
                User: {
                    googleplus_id: userId,
                    access_token: idToken,
                    email: email
                }
            };
            setLocalData(userId, idToken);
            LocalStorage.set(LocalStorageKeys.GOOGLE_ACCESS_TOKEN, idToken);
            LocalStorage.set(LocalStorageKeys.ACCOUNT_TYPE, AccountType.GOOGLE);
            LocalStorage.setObject(LocalStorageKeys.SOCIAL_META, response);
            LocalStorage.set(LocalStorageKeys.APP_MODE, ApplicationMode.TBYB);
            loginGoogleWebservice(jsonParams);
        }, function (error) {
            LoadingUtil.hideLoader();
            LocalStorage.set(LocalStorageKeys.ACCESS_TOKEN, null);
            return false;
        });
    }

    /*
        NAME : getGoogleAccessToken
    */
    function getGoogleAccessToken(code) {
        var q = $q.defer();
        var client_id = "696147384520-6qqvohe48fnrauoav55tt0busa1ut9i9.apps.googleusercontent.com";
        var client_secret = 'joDKYID5unrf-_85bfMRpZCP';
        var redirect_url = 'http://baselinetelematics.com';
        console.log('---> URL TO CALL : ', 'https://www.googleapis.com/oauth2/v4/token?code=' + code + '&client_id=' + client_id + '&client_secret=' + client_secret + '&redirect_uri=' + redirect_url + '&grant_type=authorization_code');
        $.post('https://www.googleapis.com/oauth2/v4/token?code=' + code + '&client_id=' + client_id + '&client_secret=' + client_secret + '&redirect_uri=' + redirect_url + '&grant_type=authorization_code', function (data) {
            q.resolve(data.access_token);
        });
        return q.promise;
    }

    /*
        NAME : setlocalData
    */
    function setLocalData(userId, accessToken) {
        LocalStorage.set(LocalStorageKeys.SOCIAL_USER_ID, userId);
        LocalStorage.set(LocalStorageKeys.ACCESS_TOKEN, accessToken);
    }

    /*
        NAME : processEmails
        DESC : Checks email type from list of emails, and if type is account then returns email value.
    */
    function processEmails(emails) {
        if (emails) {
            for (var i = 0; i < emails.length; i++) {
                var email = emails[i];
                if (email['type'] === 'account') {
                    return email.value;
                }
            }
        }

    }

    /*
        NAME : loginGoogleWebservice
        DESC : Save user data in server and navigate to dashboard.
    */
    function loginGoogleWebservice(jsonParams) {

        console.log(jsonParams, 'jsonParams facebook');

        LoadingUtil.showLoader();
        LoginServices.googleLogin(jsonParams).then(function (data) {

            console.log(jsonParams, "Register google");

            SocialLoginUtil.processGooglePlusData(data);
            LoadingUtil.hideLoader();
            console.log('### GOOGLE LOGIN SUCCESS ###');
            LocalStorage.set(LocalStorageKeys.LOGIN_TYPE, data.application_type_id);
            OfflineLoginFactory.saveLoginCredentials(data.application_type_id, jsonParams["User"]["email"], "");

            prepareProfileData(data.application_type_id);
            prepareUserSettings();
            prepareCommunicationSettings();
        }, function (error) {
            LoadingUtil.hideLoader();
            checkError(error);
        });
    }

    /*
       NAME : checkError
       DESC : If status code is 1022, it makes user to redirect to consent screen.
   */
    function checkError(error) {
        var statusCode = error.data.api_error_code;

        console.log("#### LOGIN ERROR - CHECKERROR FUNCTION ####");
        console.log('--> Error Object', error.data);

        console.log('statusCode :', statusCode, 'Constant for 1022', ApiErrorCode.CONSENT_REQUIRED);

        if (statusCode === ApiErrorCode.LTP_REQUIRED) {
            goToLtpSplash();
        } else if (statusCode === ApiErrorCode.CONSENT_REQUIRED) {
            goToConsent();
        } else {
            $scope.errorMessage = $translate.instant(error.data["i18n-key"]);
            $scope.showErrorMessage = true;
        }

        console.log("######################");
    }

    /*
        NAME : goToConsent
        DESC : If user is logged in for first time, User is redirected to consent screen.
    */
    function goToLtpSplash() {
        $state.go("ltpSplash");
    }

    /*
        NAME : goToConsent
        DESC : If user is logged in for first time, User is redirected to consent screen.
    */
    function goToConsent() {
        $state.go("consent");
    }

    /*
        NAME : goToDashboard
        DESC : If user is logged in for first time, User is redirected to consent screen.
    */
    function goToDashboard() {
        var menuItems = LocalStorage.getObject(LocalStorageKeys.MENU_ITEMS);
        $state.go(menuItems[0].state);
    }

    /*
        NAME : goToSMS
        DESC : Redirects user to SMS Validation screen
    */
    function goToSMS() {
        $state.go("smsValidation");
    }

    /*
        NAME : validateLoginEmail
        DESC : Validate email format
    */
    function validateLoginEmail() {
        $scope.emailValid = false;
        var emailValue = $scope.loginCreds.email;
        if (emailValue != null && emailValue != "" && typeof emailValue != 'undefined') {
            if (ValidationUtil.validateEmail(emailValue)) {
                // Valid Email
                $scope.emailValid = true;
            } else {
                // Invalid Email
                $scope.emailValid = false;
            }
            console.log(456, $scope.emailValid);
        } else {
            $scope.emailValid = false;
        }
    }

    /*
        NAME : validateLoginPassword
        DESC : Validate email strength
    */
    function validateLoginPassword() {
        var pass = $scope.loginCreds.password;
        if (pass != null && pass != "" && typeof pass != 'undefined') {
            if (ValidationUtil.checkPasswordStrength(pass)) {
                $scope.passwordValid = true;
            } else {
                $scope.passwordValid = false;
            }
        }
    }

    /*
        NAME : validateForm
        DESC : Make sure all values are validated then enable the login button.
    */
    function validateForm(newValues, oldValues, scope) {
        if (newValues[0] && newValues[1]) {
            $scope.formValid = true;
        } else {
            $scope.formValid = false;
        }
    }

    /*
        NAME : validateUppercase
        DESC : Validate the presence of an Uppercase character in the given string
        PARAM : pPAss -> Input by user
    */
    function validateUppercase(pPass) {
        return (/[A-Z]/.test(pPass));
    }

    /*
        NAME : validateNumber
        DESC : Validate the presence of a number in the given string
        PARAM : pPAss -> Input by user
    */
    function validateNumber(pPass) {
        return (/[0-9]/.test(pPass));
    }

    /*
        NAME: prepareProfileData
        DESC: Call profile web services and build profileData that will be used in the entire app.
    */
    function prepareProfileData(pMode) {

        var state;
        var isTBYB;
        var menu = LocalStorage.getObject(LocalStorageKeys.MENU_ITEMS);

        if (menu) {
            state = menu[0].state;
        } else {
            state = "app.dashboardPorto";
        }

        switch (pMode) {
            case LoginType.TBYB_PPM:
                isTBYB = true;
                break;
            case LoginType.UBI_PPM:
                isTBYB = false;
                break;
            case LoginType.TBYB_RB:
                isTBYB = true;
                break;
            case LoginType.UBI_RB:
                isTBYB = false;
                break;
        }

        if (isTBYB) {
            ProfileServices.getProfile().then(function (pRawData) {

                FirebaseService.logEvent("select_content", {
                    content_type: "login",
                    item_name: "Login",
                    custom_dimension1: pRawData.User.id,
                    custom_dimension2: "Login",
                    custom_dimension3: '0',
                    custom_dimension4: '0',
                    custom_dimension6: LocalStorage.get(LocalStorageKeys.ACCOUNT_TYPE)
                });

                ProfileDataUtil.createProfileData(pRawData);


                $scope.setPhoneInfo();

                $state.go(state);
                LoadingUtil.hideLoader();
            }, function (error) {
                // error
                LoadingUtil.hideLoader();
            });
        } else {

            var login = LocalStorage.get(LocalStorageKeys.LOGIN_EMAIL);
            var password = LocalStorage.get(LocalStorageKeys.LOGIN_PASSWORD);

            var account_type = LocalStorage.get(LocalStorageKeys.ACCOUNT_TYPE);

            var jsonParams;

            if (account_type === AccountType.NORMAL) {
                jsonParams = {
                    email: login,
                    password: password
                };
            }

            if (account_type === AccountType.GOOGLE) {
                jsonParams = {
                    email: login,
                    access_token: LocalStorage.get(LocalStorageKeys.GOOGLE_ACCESS_TOKEN)
                };
            }

            if (account_type === AccountType.FACEBOOK) {
                jsonParams = {
                    email: login,
                    user_secret: LocalStorage.get(LocalStorageKeys.FACEBOOK_USER_SECRET)
                };
            }

            LoginServices.loginPas(jsonParams).then(function (response) {
                LocalStorage.set(LocalStorageKeys.PAS_USER_TOKEN, response.data.token);

                ProfileServices.getProfile().then(function (responseProfile) {
                    ProfileServices.getProfileData_client(responseProfile).then(function (pRawData) {

                        $scope.setPhoneInfo();

                        var auto_jovem = '0';
                        if (pRawData.User && pRawData.User.marketing_list_id && pRawData.User.marketing_list_id === "59fb7aa0-95f4-4874-9b35-0b5e0a020037") {
                            auto_jovem = '1';
                        }

                        FirebaseService.logEvent("select_content", {
                            content_type: "login",
                            item_name: "Login",
                            custom_dimension1: pRawData.User.id,
                            custom_dimension2: "Login",
                            custom_dimension3: auto_jovem,
                            custom_dimension4: '1',
                            custom_dimension6: LocalStorage.get(LocalStorageKeys.ACCOUNT_TYPE)
                        });

                        ProfileDataUtil.createProfileData(pRawData);
                        var policy_id = pRawData.VehicleProfile.policy_id;
                        LocalStorage.set(LocalStorageKeys.POLICY_ID, policy_id);
                        getBalance();
                        $state.go(state);
                        LoadingUtil.hideLoader();

                    }, function (error) {
                        // error
                        LoadingUtil.hideLoader();
                    });
                }, function (error) {
                    // error
                    LoadingUtil.hideLoader();
                });
            });
        }
    }

    function prepareUserSettings() {
        SettingsServices.getUserSettings().then(function (settings) {
            var use_phone_data = (settings.use_phone_data === '1' ? true : false);
            var auto_start = settings.auto_start;
            if (angular.isDefined(use_phone_data)) {
                CordovaBroadcaster.changeUseOnlyWifi(use_phone_data);
            }
            //            if (language) {
            //                $translate.use(language);
            //                CordovaBroadcaster.setLocaleKey(language);
            //                LocalStorage.set(LocalStorageKeys.CURRENT_LOCALE_KEY, language);
            //            }
            if (angular.isDefined(auto_start)) {
                var start = false;
                var autoStart = "On";
                if (auto_start === '1') {
                    start = true;
                    autoStart = "On";
                } else if (auto_start === '0') {
                    autoStart = "Off";
                } else if (auto_start === '2') {
                    autoStart = "Charging";
                }
                CordovaBroadcaster.setAutoStartValue(start, autoStart);
            }
            LocalStorage.setObject(LocalStorageKeys.USER_APP_SETTINGS, settings);
        });
    }

    function prepareCommunicationSettings() {
        CommunicationService.getCommunicationOptions().then(function (pResponse) {
            var response = pResponse.data;
            // Hard coded true values, as webservices is not yet ready to send all values as true by default.
            if (angular.isArray(response) && response.length == 0) {
                response = {
                    "hbr_sound": true,
                    "hac_sound": true,
                    "contest_push": true,
                    "trip_push": true
                };
            }
            CordovaBroadcaster.updateTripNotification(response.trip_push);
            CordovaBroadcaster.setContestNotification(response.contest_push);
            CordovaBroadcaster.setHardBreakingBeep(response.hbr_sound);
            CordovaBroadcaster.setHardAccelerationBeep(response.hac_sound);
            LocalStorage.set(LocalStorageKeys.LOCAL_SETTINGS, JSON.stringify(response));
        });
    }

    /*
        NAME : goToRegister
        DESC : Redirect user to the register screen
    */
    function goToRegister() {
        $state.go('register');
    }

    function goToForgotPassword() {
        $state.go('forgotPassword');
    }

    function getBalance() {
        console.log('---> GET BALANCE');
        PaymentServices.getBalanceInfo().then(function (response) {
            console.log('---> GET BALANCE SUCCESS', response);
            if (response.data.length > 0) {
                var balance = 0;
                for (var i = 0; i < response.data.length; i++) {
                    balance += parseFloat(response.data[i].balance);
                }
                $scope.balanceAccount = balance;
            }
        }, function (error) {
            console.log('---> GET BALANCE ERROR', error);
        });
    }

    /*
        NAME : setThemeColors
        DESC : Set theme colors and text colors
    */
    function setThemeColors(data) {
        data.mainBackground = "#203252";
        data.secondaryBackground = "#FFF";
        data.menuBackground = "#203252";
        data.textMain = "#7f7f7f";
        data.textPrimary = "#FFF";
        data.textSecondary = "#289fd8";
        data.lightBackground = "#289fd8";
        
        $rootScope.themeColors = data;
        LocalStorage.setObject(LocalStorageKeys.THEME_COLORS, data);
    }

    $scope.setPhoneInfo = function() {

        var osVersion = LocalStorage.get(LocalStorageKeys.OS_VERSION);
        var manufacturer = LocalStorage.get(LocalStorageKeys.MANUFACTURER);
        var model = LocalStorage.get(LocalStorageKeys.MODEL);

        if (!model) {
            model = ionic.Platform.platform();
        }

        if (!osVersion) {
            osVersion = ionic.Platform.version().toString();
        }

        var data = {
            os_version: osVersion,
            phone_model: model,
            phone_manufacturer: manufacturer
        }

        ProfileServices.setPhoneInfo(data).then(function (res) {
            console.log(res);
        }, function (error) {});
    }

    window.addEventListener('native.keyboardshow', function () {
        document.body.classList.add('keyboard-open');
    });

    window.addEventListener('native.keyboardhide', function () {
        document.body.classList.remove('keyboard-open');
    });
}
