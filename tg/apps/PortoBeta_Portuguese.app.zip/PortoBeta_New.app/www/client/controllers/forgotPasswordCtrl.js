angular.module('controllers')
    .controller('ForgotPasswordCtrl', ForgotPasswordCtrl);

function ForgotPasswordCtrl($rootScope, $scope, $state, AppSetupServices, LoginServices, ValidationUtil, PopupUtil, LoadingUtil, LocalStorage, LocalStorageKeys, $translate) {
    $scope.validateForgotPassEmail = validateForgotPassEmail;
    $scope.resetPassword = resetPassword;

    $scope.goToLogin = goToLogin;

    $scope.forgotCreds = {};
    $scope.forgotPasswordEmailSent = false;

    // functions
    function validateForgotPassEmail() {
        var email = $scope.forgotCreds.email;
        if (email != null && email != "" && typeof email != 'undefined') {
            if (ValidationUtil.validateEmail(email)) {
                // Valid Email
                $scope.emailValid = true;
            } else {
                // Invalid Email
                $scope.emailValid = false;
            }
        }
    }

    function resetPassword() {
        LoadingUtil.showLoader();
        var email = $scope.forgotCreds.email;
        LoginServices.forgotPasswordNew(email).then(function () {
            LoadingUtil.hideLoader();
            $scope.forgotPasswordEmailSent = true;
            $scope.userEmail = email;
            //$state.go('login');
        }, function (error) {
            LoadingUtil.hideLoader();
            var error = error.data;
            var title = $translate.instant('Error');
            var template = $translate.instant(error['i18n-key']);
            PopupUtil.showSimpleAlert(title, template);
        });
    }

    function goToLogin() {
        $state.go('login');
    }
}
