angular.module('controllers')
    .controller('CarbitUpdateTextCtrl', CarbitUpdateTextCtrl);

function CarbitUpdateTextCtrl($rootScope, $scope, $ionicHistory, LocalStorage, LocalStorageKeys, CordovaBroadcaster) {
    // SCOPE VARIABLES
    
    // SCOPE FUNCTION

    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    // FUNCTIONS
    function ionicViewBeforeEnter() {

    }
}
