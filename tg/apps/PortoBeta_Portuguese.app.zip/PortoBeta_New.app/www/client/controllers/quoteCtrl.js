angular.module('controllers')
    .controller('QuoteCtrl', QuoteCtrl);

function QuoteCtrl($rootScope, $state, $scope, $ionicConfig, BooleanConstant, QuoteSteps, $ionicPlatform, $ionicHistory, LocalStorage, LocalStorageKeys, LoginType) {
    // SCOPE VARIABLES
    // --> All scope variables that are specific to that view will be defined here
    $scope.exportOptions = BooleanConstant.BOOL_FALSE;
    var state = '';
    var quoteStep = '';

    // SCOPE FUNCTIONS
    // --> All scope functions specific to that view are defined here
    $ionicConfig.views.transition('none');
    $scope.showHeader = showHeader;
    $scope.hideHeader = hideHeader;
    $scope.confirmLeaveQuote = confirmLeaveQuote;
    $scope.navigateTo = navigateTo;
    $scope.goToState = goToState;
    $scope.optionSelected = optionSelected;
    $scope.displayExportOptions = displayExportOptions;

    // SCOPE LIFE CYCLE
    // --> All needed life cycle events specific to that view are defined here. Note that we do not write the function directly in it.
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    // FUNCTIONS
    /* 
        name : ionicViewBeforeEnter
        desc : Will call web services and prepare an object for the screen
    */
    function ionicViewBeforeEnter() {

    }

    /* 
        name   : optionSelected
        desc   : Will execute on user clicks a button he gets in footer.
        params : Any of the 3 options leave, save and cancel.
        return : It does the specific functionality based on user option.
    */
    function optionSelected(option) {
        if (option === QuoteSteps.LEAVE) {
            $rootScope.quoteData = {
                vehicles: {},
                drivers: {}
            };
            goToState('app.quoteGet');
        } else if (option === QuoteSteps.SAVE) {
            //TODO  Do something to save
            goToState('app.quoteGet');
        }
        $scope.displayfooter = BooleanConstant.BOOL_FALSE;
        $scope.exportOptions = BooleanConstant.BOOL_FALSE;
    }

    /* 
        name   : confirmLeaveQuote
        desc   : Will show the options for user at the bottom of the screen.
    */
    function confirmLeaveQuote() {
        $scope.displayfooter = BooleanConstant.BOOL_TRUE;
    }

    /* 
        name   : navigateTo
        desc   : It will navigate the user between different quote steps.
        params : step number.
        return : will navigate the user to provided step of GAQ.
    */
    function navigateTo(pRoute) {
        switch (pRoute) {
            case 1:
                state = "app.quote.quoteAbout";
                quoteStep = QuoteSteps.STEP_1;
                break;
            case 2:
                state = "app.quote.quoteVehicles";
                quoteStep = QuoteSteps.STEP_2;
                break;
            case 3:
                state = "app.quote.quoteDrivers";
                quoteStep = QuoteSteps.STEP_3;
                break;
            case 4:
                state = "app.quote.quoteFinalDetails";
                quoteStep = QuoteSteps.STEP_4;
                break;
            case 5:
                state = "app.quote.quoteYourQuote";
                quoteStep = QuoteSteps.STEP_5;
                break;
        }
        $scope.quoteStep = quoteStep;
        $state.go(state);
    }

    /* 
        name   : goToState
        desc   : Will navigate the user to different states.
        params : step name, and any index.
        return : will navigate the user to specific step with index as state parameter.
    */
    function goToState(state, pIndex) {
        $state.go(state, {
            'pIndex': pIndex
        });
    }

    /* 
        name   : showHeader
        desc   : it is to show the expanded header that is having 5 quote steps.
    */
    function showHeader() {
        $scope.currentStep = $scope.quoteStep;
        $scope.quoteStep = 0;
    }

    /* 
        name   : hideHeader
        desc   : it is to hide the expanded header that is having 5 quote steps.
    */
    function hideHeader() {
        $scope.quoteStep = $scope.currentStep;
    }

    /* 
        name   : displayExportOptions
        desc   : it is to show print, email and cancel options for a generated quote.
    */
    function displayExportOptions() {
        $scope.exportOptions = BooleanConstant.BOOL_TRUE;
    }

    /*
        name : goBackToMainScreen
        desc : It will redirect the user to main screen of GAQ.
    */
    function goBackToMainScreen() {
        var state;
        var pMode = LocalStorage.get(LocalStorageKeys.LOGIN_TYPE);
        switch (pMode) {
            case LoginType.UBI_PPM:
                state = 'app.dashboardPpm';
                break;
            case LoginType.UBI_RB:
                state = 'app.dashboard';
                break;
        }
        $state.go(state);
    }

    $ionicPlatform.registerBackButtonAction(function () {
        if ($state.current.url == "/quote/about" || $state.current.url == "/quote/vehicles" || $state.current.url == "/quote/drivers" || $state.current.url == "/quote/final-details" || $state.current.url == "/quote/your-quote") {
            confirmLeaveQuote();
            $scope.$apply();
        } else if ($state.current.url == "/quote/receipt") {
            goBackToMainScreen();
        } else {
            $ionicHistory.goBack();
        }
    }, 100);
}
