angular.module('controllers')
    .controller('CarbitShippingStatusCtrl', CarbitShippingStatusCtrl);

function CarbitShippingStatusCtrl($rootScope, $scope, $ionicHistory, LocalStorage, LocalStorageKeys, CordovaBroadcaster) {
    // SCOPE VARIABLES
    /*
        Faked the data for now, based on this object, we are showing status of ordered device.
    */
    $scope.carBitStatus = {
        order_processed: {
            status: 'done',
            date: 'Dec 07, 2015'
        }, shipping_prepared: {
            status: 'in-process',
            date: ''
        }
    }

    // SCOPE FUNCTION

    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);


    // FUNCTIONS
    function ionicViewBeforeEnter() {

    }
}