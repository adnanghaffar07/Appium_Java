angular.module('controllers')
    .controller('LanguagesCtrl', LanguagesCtrl);

function LanguagesCtrl($rootScope, $scope, $translate, $timeout, CordovaBroadcaster, LocalStorage, $ionicHistory, HttpProxy, GlobalConstants, WebServiceUrls, LocalStorageKeys, LoadingUtil) {
    $scope.data = {
        language: LocalStorage.get(LocalStorageKeys.CURRENT_LOCALE_KEY)
    };

    $scope.languageChange = function (language) {
        LoadingUtil.showLoader();
        $translate.use(language);
        LocalStorage.set(LocalStorageKeys.CURRENT_LOCALE_KEY, language);
        $timeout(function () {
            LoadingUtil.hideLoader();
            $ionicHistory.goBack();
        }, 1500);
        var jsonParams = {
            language: language
        };
        HttpProxy.post(GlobalConstants.BASE_URL + WebServiceUrls.SET_USER_SETTINGS, jsonParams).then(function (pResponse) {
            // Send intent to native to change language for notifications
            CordovaBroadcaster.setLanguage(language);
        }, function (pError) {
            console.log(pError);
        });
    };
}
