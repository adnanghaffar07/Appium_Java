angular.module('controllers')
    .controller('ProfileEmailCtrl', ProfileEmailCtrl);

function ProfileEmailCtrl($scope, $state, LocalStorage, LocalStorageKeys) {
    // SCOPE FUNCTIONS
    $scope.goToPrivacyPolicy = goToPrivacyPolicy;
    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    // FUNCTIONS
    /*
        name:ionicViewBeforeEnter
        desc: Populate the profile data in corresponding fields
    */ 
    function ionicViewBeforeEnter() {
        $scope.profileData = LocalStorage.getObject(LocalStorageKeys.PROFILE_DATA);
    }
    
    /*
        name:goToPrivacyPolicy
        desc: Go to privacy policy screen by clicking on link 
    */
    function goToPrivacyPolicy(){
        $state.go("app.settingsGeneralConditions");
    }
}
