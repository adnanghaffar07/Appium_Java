angular.module('controllers')
    .controller('SelectInfoCtrl', SelectInfoCtrl);

function SelectInfoCtrl($state, $ionicHistory, $scope, $stateParams, LocalStorage, LocalStorageKeys, $rootScope, $timeout) {
    $scope.itemSelected = itemSelected;

    $scope.$on('$ionicView.loaded', function () {
        $scope.items = $stateParams.list;
        $scope.currentSelectedValue = $stateParams.selectedValue;

        $rootScope.vehicleHasChanged = false;

        if ($scope.currentSelectedValue) {
            $rootScope.selectedValue = $scope.currentSelectedValue;
        }

        $timeout(function () {
            $('ion-content.settings ion-list .item-radio i').css('color', $rootScope.themeColors.mainBackground);
        }, 100);
    });

    function itemSelected(pItem) {
        $rootScope.vehicleHasChanged = true;
        $rootScope.selectedValue = pItem;
        $('ion-content.settings ion-list .item-radio i').css('color', $rootScope.themeColors.mainBackground);
        $ionicHistory.goBack();
    }
}
