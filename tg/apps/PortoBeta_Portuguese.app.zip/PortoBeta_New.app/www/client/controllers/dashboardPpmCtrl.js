angular.module('controllers')
    .controller('DashboardPpmCtrl', DashboardCtrl);

function DashboardCtrl($rootScope, $scope, $state, $ionicSlideBoxDelegate, $timeout, CordovaBroadcaster, AppSetupServices, AchievementsServices, ScoresServices, PopupUtil, LoadingUtil, CircleProgressUtil, LocalStorage, LocalStorageKeys, DOMUtil, LeaderBoardServices, TripsServices, LoggerUtilType, $translate, TripStateFactory, TripState, WebServiceCache, $ionicHistory) {
    // Scope functions
    $scope.changeTab = changeTab;
    $scope.slideHasChanged = slideHasChanged;
    $scope.chartClick = chartClick;
    $scope.endSimulation = endSimulation;
    $scope.triggerScanning = triggerScanning;

    // Scope Variables
    $scope.selectedTab = 'lastTrip';
    $scope.achievementsAvailable = false;
    $scope.circle_size = Math.round($(window).width() / 1.75);
    $scope.circle_fontsize = Math.round($scope.circle_size / 2.5);
    $scope.circle_safemi_fontsize = Math.round($scope.circle_size / 7.5);
    $scope.circle_lineheight = Math.round($scope.circle_size / 1.1);
    $scope.circle_safemi_lineheight = Math.round($scope.circle_size / 0.7);
    $scope.lastWeek_date = moment().subtract(7, "days").format("MMM D") + ' - ' + moment().subtract(1, "days").format("MMM D, YYYY");
    $scope.lastMonth_date = moment().subtract(30, "days").format("MMM D") + ' - ' + moment().subtract(1, "days").format("MMM D, YYYY");
    $scope.thisYear_date = moment().subtract(365, "days").format("MMMM YYYY") + ' - ' + 'Present';
    $scope.user_rank = 0;
    $scope.safe_miles_percent = 0;
    $scope.earned_miles = 0;
    $scope.avgCostPerMi = 0;
    $scope.simAvgCostPerMi = 0;
    $scope.milesDetails = {};
    $scope.distance = 0;
    var segmentColors = {};
    $scope.scoresData = {};
    $scope.scoresData.lastTrip = {};
    $scope.scoresData.lastWeek = {};
    $scope.scoresData.lastMonth = {}
    $scope.scoresData.global = {};
    $scope.savedPrice = 0;
    var qo = {};
    var qo_ppc = {};
    var ppc_si, ppc_so, ppc_ri, ppc_ag, ppc_da;

    $ionicHistory.clearHistory();
    $ionicHistory.clearCache();

    // Scope Life Cycle
    $scope.$on('$ionicView.loaded', ionicViewLoaded);
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    // Normal Variables
    var chartsArr = [null, null, null, null];
    var tooltip_si;
    var tooltip_so;
    var tooltip_ag;
    var tooltip_ri;
    var tooltip_da;


    // ################################################ Functions ##########################################################

    /*
        Name: ionicViewLoaded
        Desc: Fetch data from database
    */
    function ionicViewLoaded() {
        LoadingUtil.showLoader();
        TripStateFactory.registerTripStatusChanged(refreshDashboard);
        getSegmentColors();
        //getScoresCallback({});
        //ScoresServices.getLastTripInfoAndScore("", getScoresCallback);
        //AchievementsServices.getAchievements(LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID)).then(getAchievementsCallback);
        //getUserRank();
    }

    /*
        Name: ionicViewBeforeEnter
        Desc: Prepare screen before loading
    */
    function ionicViewBeforeEnter() {
        $rootScope.activeMenuItem = "dashboard";
        // Quote Simulator
        console.log(4545, $rootScope.quoteSimulatorObj);
        if (angular.isDefined($rootScope.quoteSimulatorObj) && $rootScope.quoteSimulatorObj != null) {
            console.log(4646, "SIMULATION ACTIVE");
            $scope.isSimulation = true;
        } else {
            console.log(4747, "SIMULATION INACTIVE");
            $scope.isSimulation = false;
        }

        console.log(3333333, $scope.isSimulation);

        //Commented here as it is in menuCtrl.
        var lastTripId = LocalStorage.get(LocalStorageKeys.LAST_TRIP_ID, "null");
        TripsServices.getNewTripNotif(lastTripId).then(function (data) {
            if (lastTripId != "null") {
                if (lastTripId != data.trip_id) {
                    LocalStorage.set(LocalStorageKeys.LAST_TRIP_ID, data.trip_id);
                    WebServiceCache.cleanseCache(1);
                    loadDashboard();
                } else {
                    loadDashboard();
                }
            } else if (data.trip_id != "" && data.trip_id != null) {
                LocalStorage.set(LocalStorageKeys.LAST_TRIP_ID, data.trip_id);
                WebServiceCache.cleanseCache(1);
                loadDashboard();
            } else {
                loadDashboard();
            }
        }, function (error) {
            loadDashboard();
        });
    }

    function loadDashboard() {
        if ($scope.isTBYB) {
            ScoresServices.getLastTripInfoAndScore("", getScoresCallback);
            getUserRank();
        } else {
            var vehicleId = $scope.profileData.cars[0].id;
            ScoresServices.getLastTripInfoAndScoreByVehicle(vehicleId).then(function (data) {
                getScoresCallback(data);
            }, function (error) {
                if (error.data.api_error_code == 606) {
                    $scope.scoresData.lastTrip.distance = 0;
                    $scope.scoresData.lastWeek.distance = 0
                    $scope.scoresData.lastMonth.distance = 0;
                    $scope.scoresData.global.distance = 0;
                    $('.page-hider').fadeOut('fast');
                    PopupUtil.showSimpleAlert("", $translate.instant(error.data['i18n-key']));
                    LoadingUtil.hideLoader();
                }
            });
        }
    }

    /*
        Name: getScoresCallback
        Desc: Prepare score object to show on screen
        Param: pScoresData
    */
    function getScoresCallback(pScoresData) {
        console.log(21212121, pScoresData);

        LoadingUtil.hideLoader();
        changeTab(0);
        $scope.lastTripDate = moment(pScoresData.lastTrip.date).format("MMMM D, YYYY");
        $scope.start_location = pScoresData.lastTrip.start_location;
        $scope.end_location = pScoresData.lastTrip.end_location;
        setTripBreakdownDetails(pScoresData.lastTrip);
        $scope.cost_details = pScoresData.lastTrip.price_per_mile_current;
        loadOtherScoreDetails(pScoresData);

        $scope.scoresData = pScoresData;
        console.log(777, $scope.scoresData);


        $timeout(function () {
            //$(container).addClass('loaded');
            if (pScoresData.lastTrip.distance > 0)
                initCircle(0, pScoresData.lastTrip, '#last-trip .score canvas', null, false, null);
            $('.page-hider').fadeOut('fast');
        }, 500);
    }

    /*
        Name: getAchievementsCallback
        Desc: Prepare Achievements object to be shown on screen
        Param: pAchievements
    */
    function getAchievementsCallback(pAchievements) {
        AchievementsServices.getAchievementsList().then(function (pList) {
            console.log(555, pList);
        }, function (error) {
            PopupUtil.showSimpleAlert($translate.instant('error'), $translate.instant(error['i18n-key']));
        });


        console.log(pAchievements);
        if (pAchievements.length > 0) {
            $scope.achievementsAvailable = true;
            // INSERT ACHIEVEMENTS LOGIC HERE
        }
    }

    /*
        Name: slideHasChanged
        Desc: Handles sliding event. Updates the view after slide.
        Param: pI, pScoreData
    */
    function slideHasChanged(pI, pScoreData) {
        var container = null;
        var score = null;
        switch (pI) {
            case 0:
                $scope.selectedTab = 'lastTrip';
                container = '#last-trip .score';
                score = pScoreData.lastTrip;
                setTripBreakdownDetails(pScoreData.lastTrip);
                break;
            case 1:
                $scope.selectedTab = 'lastWeek';
                container = '#last-week .score';
                score = pScoreData.lastWeek;
                setTripBreakdownDetails(pScoreData.lastWeek);
                break;
            case 2:
                $scope.selectedTab = 'lastMonth';
                container = '#last-month .score';
                score = pScoreData.lastMonth;
                setTripBreakdownDetails(pScoreData.lastMonth);
                break;
            case 3:
                $scope.selectedTab = 'thisYear';
                container = '#this-year .score';
                score = pScoreData.global;
                setTripBreakdownDetails(pScoreData.global);
                break;
        }
    }

    /*
        Name: changeTab
        Desc: Use de slidebox delegate to force sliding to a given index.
        Param: pI
    */
    function changeTab(pI) {
        $ionicSlideBoxDelegate.$getByHandle('scoresSlider').slide(pI);
    }

    /*
        Name: getSegmentColors
        Desc: Fetch segment colors from database to for all the driving types
    */
    function getSegmentColors() {
        TripsServices.getSegmentsColors().then(function (response) {
            var obj = response.data;
            var segmentsOptions = [];
            segmentColors = {};
            for (var i = 0; i < obj.length; i++) {
                var option = {};
                switch (obj[i].type) {
                    case 'safe_interstate':
                        option.label = 'Safe Interstate';
                        break;
                    case 'safe_other':
                        option.label = 'Safe Other';
                        break;
                    case 'aggressive':
                        option.label = 'Aggressive';
                        break;
                    case 'risky':
                        option.label = 'Risky';
                        break;
                    case 'dangerous':
                        option.label = 'Dangerous';
                        break;
                }
                segmentColors[obj[i].type + '_color'] = obj[i].hex;
                option.light = obj[i].rgba;
                option.dark = obj[i].hex;
                segmentsOptions.push(option);
            }
            $scope.segmentColors = segmentColors;
            $scope.segmentOptions = segmentsOptions;
            setTripBreakdownColors(false);
            LocalStorage.setObject(LocalStorageKeys.MILE_CATEGORY_COLOR, segmentColors);
        }, function (error) {
            PopupUtil.showSimpleAlert($translate.instant('error'), $translate.instant(error.data['i18n-key']));
        });
    }


    /*
        Name: initCircle
        Desc: Initialize te progress circle animation
        Param: pE (Element), pV (Value)
    */
    function initCircle(pI, pScoreData, pE, pLabel, isClicked, pActiveSegment) {
        console.log(777777, pI, pScoreData, pE, pLabel, isClicked, pActiveSegment);

        var scoreData = prepareChartData(pScoreData, pLabel, isClicked);
        var chartOptions = prepareChartOptions(pI);

        DOMUtil.onElementReady(pE, 100).then(function () {
            var ctx = $(pE)[0].getContext('2d');
            var myChart = new Chart(ctx).Doughnut(scoreData, chartOptions);
            chartsArr[pI] = myChart;
        });
    }

    /*
        Name: prepareChartData
        Desc: build data object to be used by chart
        Param: isClicked - boolean
        Param: pLabel - string
        Return: data
    */
    function prepareChartData(pScoreData, pLabel, isClicked) {
        var safeInter_pourcent;
        var safeInter_distance;
        var safeOther_pourcent;
        var safeOther_distance;
        var aggressive_pourcent;
        var aggressive_distance;
        var risky_pourcent;
        var risky_distance;
        var dangerous_pourcent;
        var dangerous_distance;

        safeInter_pourcent = (pScoreData.distance_per_category.safe_interstate / pScoreData.distance) * 100;
        safeOther_pourcent = (pScoreData.distance_per_category.safe_other / pScoreData.distance) * 100;
        aggressive_pourcent = (pScoreData.distance_per_category.aggressive / pScoreData.distance) * 100;
        risky_pourcent = (pScoreData.distance_per_category.risky / pScoreData.distance) * 100;
        dangerous_pourcent = (pScoreData.distance_per_category.dangerous / pScoreData.distance) * 100;

        safeInter_distance = pScoreData.distance_per_category.safe_interstate;
        safeOther_distance = pScoreData.distance_per_category.safe_other;
        aggressive_distance = pScoreData.distance_per_category.aggressive;
        risky_distance = pScoreData.distance_per_category.risky;
        dangerous_distance = pScoreData.distance_per_category.dangerous;

        console.log(444555, safeOther_distance);

        var si_color = getSegmentColor(isClicked, pLabel, 'Safe Interstate');
        var so_color = getSegmentColor(isClicked, pLabel, 'Safe Other');
        var ag_color = getSegmentColor(isClicked, pLabel, 'Aggressive');
        var ri_color = getSegmentColor(isClicked, pLabel, 'Risky');
        var da_color = getSegmentColor(isClicked, pLabel, 'Dangerous');

        var data = [{
            value: safeInter_pourcent,
            color: si_color,
            label: 'Safe Interstate',
            tooltip: safeInter_distance
        }, {
            value: safeOther_pourcent,
            color: so_color,
            label: 'Safe Other',
            tooltip: safeOther_distance
            }, {
            value: aggressive_pourcent,
            color: ag_color,
            label: 'Aggressive',
            tooltip: aggressive_distance
            }, {
            value: risky_pourcent,
            color: ri_color,
            label: 'Risky',
            tooltip: risky_distance
            }, {
            value: dangerous_pourcent,
            color: da_color,
            label: 'Dangerous',
            tooltip: dangerous_distance
            }];

        tooltip_si = data[0].tooltip;
        tooltip_so = data[1].tooltip;
        tooltip_ag = data[2].tooltip;
        tooltip_ri = data[3].tooltip;
        tooltip_da = data[4].tooltip;

        return data;
    }

    /*
        Name: prepareChartOptions
        Desc: Build an options object to be used by the chart
        Return: options object
    */
    function prepareChartOptions(pI) {
        var options = {
            segmentShowStroke: true,
            segmentStrokeColor: "transparent",
            segmentStrokeWidth: 2,
            percentageInnerCutout: 85,
            animation: false,
            tooltipFontColor: "#007EC3",
            customTooltips: function (tooltip) {
                var tooltipEl;
                switch (pI) {
                    case 0:
                        tooltipEl = $('#chartjs-tooltip-0');
                        break;
                    case 1:
                        tooltipEl = $('#chartjs-tooltip-1');
                        break;
                    case 2:
                        tooltipEl = $('#chartjs-tooltip-2');
                        break;
                    case 3:
                        tooltipEl = $('#chartjs-tooltip-3');
                        break;
                }

                if (!tooltip) {
                    tooltipEl.css({
                        opacity: 0
                    });
                    return;
                }

                tooltipEl.removeClass('above below');
                tooltipEl.addClass(tooltip.yAlign);

                // split out the label and value and make your own tooltip here
                var parts = tooltip.text.split(":");
                var text;
                switch (parts[0]) {
                    case 'Safe Interstate':
                        text = tooltip_si;
                        break;
                    case 'Safe Other':
                        text = tooltip_so;
                        break;
                    case 'Aggressive':
                        text = tooltip_ag;
                        break;
                    case 'Risky':
                        text = tooltip_ri;
                        break;
                    case 'Dangerous':
                        text = tooltip_da;
                        break;
                }

                var innerHtml = '<span><b>' + Math.round(text * 10) / 10 + 'mi</b></span>';
                tooltipEl.html(innerHtml);

                tooltipEl.css({
                    opacity: 1,
                    left: tooltip.chart.canvas.offsetLeft + tooltip.x + 'px',
                    top: tooltip.chart.canvas.offsetTop + tooltip.y + 'px',
                    fontFamily: tooltip.fontFamily,
                    fontSize: tooltip.fontSize,
                    fontStyle: tooltip.fontStyle
                });
            }
        };
        return options;
    }

    /*
        Name: getSegmentColor
        Desc: Get a specific segment color
        return: color.
    */
    function getSegmentColor(isClicked, pLabel, pL) {
        var c = $scope.segmentOptions;
        var i = 0;
        switch (pL) {
            case 'Safe Interstate':
                i = 0;
                break;
            case 'Safe Other':
                i = 1;
                break;
            case 'Aggressive':
                i = 2;
                break;
            case 'Risky':
                i = 3;
                break;
            case 'Dangerous':
                i = 4;
                break;
        }

        if (isClicked) {
            if (pLabel == pL) {
                return c[i].dark;
            } else {
                return c[i].light;
            }
        } else {
            return c[i].dark;
        }
    }

    function chartClick(pI, isCenter) {
        var dashboard_trip_chart = chartsArr[pI];
        var activePoints = dashboard_trip_chart.getSegmentsAtEvent(event);
        if (activePoints.length > 0 && !isCenter) {
            var label = activePoints[0].label;
            var value = activePoints[0].value;
            //vrActiveLabel = label;
            var si_color = getSegmentColor(true, label, 'Safe Interstate');
            var so_color = getSegmentColor(true, label, 'Safe Other');
            var ag_color = getSegmentColor(true, label, 'Aggressive');
            var ri_color = getSegmentColor(true, label, 'Risky');
            var da_color = getSegmentColor(true, label, 'Dangerous');
            $timeout(function () {
                $scope.tarif = value;
            });

            switch (pI) {
                case 0:
                    initCircle(pI, $scope.scoresData.lastTrip, '#last-trip .score canvas', label, true, activePoints);
                    if ($scope.isSimulation) {
                        $scope.totalCost = getSelectedSegment($scope.scoresData.lastTrip.distance_per_category, label);
                    }
                    //prepareBreakDown(pI, $scope.scoreData.lastTrip, si_color, so_color, ag_color, ri_color, da_color);
                    break;
                case 1:
                    initCircle(pI, $scope.scoresData.lastWeek, '#last-week .score canvas', label, true, activePoints);
                    if ($scope.isSimulation) {
                        $scope.totalCost = getSelectedSegment($scope.scoresData.lastWeek.distance_per_category, label);
                    }
                    //prepareBreakDown(pI, $scope.scoreData.lastWeek, si_color, so_color, ag_color, ri_color, da_color);
                    break;
                case 2:
                    initCircle(pI, $scope.scoresData.lastMonth, '#last-month .score canvas', label, true, activePoints);
                    if ($scope.isSimulation) {
                        $scope.totalCost = getSelectedSegment($scope.scoresData.lastMonth.distance_per_category, label);
                    }
                    //prepareBreakDown(pI, $scope.scoreData.lastMonth, si_color, so_color, ag_color, ri_color, da_color);
                    break;
                case 3:
                    initCircle(pI, $scope.scoresData.global, '#this-year .score canvas', label, true, activePoints);
                    if ($scope.isSimulation) {
                        $scope.totalCost = getSelectedSegment($scope.scoresData.global.distance_per_category, label);
                    }
                    //prepareBreakDown(pI, $scope.scoreData.global, si_color, so_color, ag_color, ri_color, da_color);
                    break;
            }
            setTripBreakdownColors(true, si_color, so_color, ag_color, ri_color, da_color)
        } else {

            var tooltip;
            switch (pI) {
                case 0:
                    initCircle(pI, $scope.scoresData.lastTrip, '#last-trip .score canvas', null, false, null);
                    if ($scope.isSimulation) {
                        $scope.totalCost = getSelectedSegment($scope.scoresData.lastTrip.distance_per_category, null);
                    }
                    //prepareBreakDown(pI, $scope.scoreData.lastTrip);
                    tooltip = $('#chartjs-tooltip-0');
                    break;
                case 1:
                    initCircle(pI, $scope.scoresData.lastWeek, '#last-week .score canvas', null, false, null);
                    if ($scope.isSimulation) {
                        $scope.totalCost = getSelectedSegment($scope.scoresData.lastWeek.distance_per_category, null);
                    }
                    //prepareBreakDown(pI, $scope.scoreData.lastWeek);
                    tooltip = $('#chartjs-tooltip-1');
                    break;
                case 2:
                    initCircle(pI, $scope.scoresData.lastMonth, '#last-month .score canvas', null, false, null);
                    if ($scope.isSimulation) {
                        $scope.totalCost = getSelectedSegment($scope.scoresData.lastMonth.distance_per_category, null);
                    }
                    //prepareBreakDown(pI, $scope.scoreData.lastMonth);
                    tooltip = $('#chartjs-tooltip-2');
                    break;
                case 3:
                    initCircle(pI, $scope.scoresData.global, '#this-year .score canvas', null, false, null);
                    if ($scope.isSimulation) {
                        $scope.totalCost = getSelectedSegment($scope.scoresData.global.distance_per_category, null);
                    }
                    //prepareBreakDown(pI, $scope.scoreData.global);
                    tooltip = $('#chartjs-tooltip-3');
                    break;
            }
            setTripBreakdownColors(false);
            tooltip.css({
                opacity: 0
            });
        }
    }

    /*
        Name: setTripBreakdownColors
        Desc: Set colors trip breakdown. When preparing the page and clicking on chart 
    */
    function setTripBreakdownColors(isChartClick, si_color, so_color, ag_color, ri_color, da_color) {
        if (!isChartClick) {
            DOMUtil.onElementReady('body', 100).then(function () {
                $('i.ion-record.si').css('color', segmentColors.safe_interstate_color);
                $('i.ion-record.so').css('color', segmentColors.safe_other_color);
                $('i.ion-record.ag').css('color', segmentColors.aggressive_color);
                $('i.ion-record.ri').css('color', segmentColors.risky_color);
                $('i.ion-record.da').css('color', segmentColors.dangerous_color);
            });
        } else {
            DOMUtil.onElementReady('body', 100).then(function () {
                $('i.ion-record.si').css('color', si_color);
                $('i.ion-record.so').css('color', so_color);
                $('i.ion-record.ag').css('color', ag_color);
                $('i.ion-record.ri').css('color', ri_color);
                $('i.ion-record.da').css('color', da_color);
            });
        }
    }
    /*
        Name: setTripBreakdownDetails
        Desc: Set miles category values and distance, break points , calculate safe miles percent
    */
    function setTripBreakdownDetails(pData) {
        if ($scope.isSimulation) {
            // Set Simulation ammounts to the scoresData object
            qo = $rootScope.quoteSimulatorObj;
            qo_ppc = qo.quote_vehicles[0].quote_vehicle_pricing_items;

            for (var i = 0; i < qo_ppc.length; i++) {
                if (qo_ppc[i].premium_id == 1) {
                    // safe interstate
                    ppc_si = qo_ppc[i].price;
                }

                if (qo_ppc[i].premium_id == 2) {
                    // safe other
                    ppc_so = qo_ppc[i].price;
                }

                if (qo_ppc[i].premium_id == 3) {
                    // aggressive
                    ppc_ag = qo_ppc[i].price;
                }

                if (qo_ppc[i].premium_id == 4) {
                    // risky
                    ppc_ri = qo_ppc[i].price;
                }

                if (qo_ppc[i].premium_id == 5) {
                    // dangerous
                    ppc_da = qo_ppc[i].price
                }
            }

            //var total = ppc_si + ppc_so + ppc_ag + ppc_ri + ppc_da;

            var cd = {
                safe_interstate: ppc_si,
                safe_other: ppc_so,
                aggressive: ppc_ag,
                risky: ppc_ri,
                dangerous: ppc_da
            };

            var csd = {
                safe_interstate: pData.distance_per_category.safe_interstate * ppc_si,
                safe_other: pData.distance_per_category.safe_other * ppc_so,
                aggressive: pData.distance_per_category.aggressive * ppc_ag,
                risky: pData.distance_per_category.risky * ppc_ri,
                dangerous: pData.distance_per_category.dangerous * ppc_da
            }

            var total = (pData.distance_per_category.safe_interstate * ppc_si) +
                (pData.distance_per_category.safe_other * ppc_so) +
                (pData.distance_per_category.aggressive * ppc_ag) +
                (pData.distance_per_category.risky * ppc_ri) +
                (pData.distance_per_category.dangerous * ppc_da);

            $scope.sim_cost_details = cd;
            $scope.totalCost = total;
            $scope.cost_segment_details = csd;
            $scope.simAvgCostPerMi = (total / pData.distance);
            var currEstimatedCost = pData.distance * (qo.annaul_price / qo.quote_vehicles[0].annual_mileage);
            $scope.savedPrice = currEstimatedCost - $scope.totalCost;





        } else {
            // Not simulation
            $scope.milesDetails = pData.distance_per_category;
            $scope.cost_segment_details = pData.price_per_category;
            $scope.avgCostPerMi = (pData.cost / pData.distance);
            $scope.totalCost = pData.cost;
        }

        console.log(1010, $scope.cost_details);
        console.log(2020, $scope.cost_segment_details);
        console.log(3030, $scope.totalCost);

        $scope.distance = pData.distance;
        $scope.trip_break_points = pData.break_points;
        console.log(555555, pData.safe_miles_driven, pData.distance);
        $scope.safe_miles_percent = Math.round((pData.safe_miles_driven / pData.distance) * 100);
        $scope.earned_miles = pData.free_miles_earned;

        setTripBreakdownColors(false);
    }

    /*
        Name: getUserRank
        Desc: Fetch the user general rank details.
    */
    function getUserRank() {
        LeaderBoardServices.getGeneralRankings(function (data) {
            console.log(data.CurrentUser);
            $scope.user_rank = data.CurrentUser.rank != null ? data.CurrentUser.rank : "0";
        }, function (error) {
            console.log(error);
            PopupUtil.showSimpleAlert($translate.instant('error'), error.data['i18n-key']);
        });
    }

    /*
        Name: loadOtherScoreDetails
        Desc: Fetch the data for Last week, Last Month, Life time tabs
        Param : Sending the pData to return the data in same format
    */
    function loadOtherScoreDetails(pData) {
        if ($scope.isTBYB) {
            ScoresServices.getOtherTripsInfoAndScore(pData, loadOtherSlidesCallback);
        } else {
            var vehicleId = $scope.profileData.cars[0].id;
            ScoresServices.getOtherTripsInfoAndScoreByVehicle(pData, loadOtherSlidesCallback, vehicleId);
        }
    }

    /*
        Name: loadOtherSlidesCallback
        Desc: Prepare the charts for Last week, Last Month, Life time tabs
    */
    function loadOtherSlidesCallback(pData) {
        $scope.scoreData = pData;
        $timeout(function () {
            //$(container).addClass('loaded');
            if (pData.lastWeek.distance > 0)
                initCircle(1, pData.lastWeek, '#last-week .score canvas', null, false, null);
            if (pData.lastMonth.distance > 0)
                initCircle(2, pData.lastMonth, '#last-month .score canvas', null, false, null);
            if (pData.global.distance > 0)
                initCircle(3, pData.global, '#this-year .score canvas', null, false, null);
            $('.page-hider').fadeOut('fast');
        }, 500);
    }

    /*
        Name: refreshDashboard
        Desc: Reloads the dashboard when a trip is transmitted 
    */
    function refreshDashboard(pExtras) {
        var tripState = TripStateFactory.getTripState();
        if (typeof (pExtras) != 'undefined') {
            $scope.currentlydriventrip = pExtras.tripId;
        }
        $scope.drivingState = tripState;
        if (tripState != TripState.STOPPED && tripState != TripState.STARTED) {
            WebServiceCache.cleanseCache(1);
            WebServiceCache.cleanseCache(3);
            if ($state.current.url == "/dashboard-ppm") {
                $timeout(function () {
                    $scope.drivingState = TripState.STOPPED;
                    ScoresServices.getLastTripInfoAndScore("", getScoresCallback);
                }, 5000);
            }
        }
    }

    /*
        Name : endSimulation
        Desc : Stop the simulation mode and show current data
    */
    function endSimulation() {
        LoadingUtil.showLoader();
        $rootScope.quoteSimulatorObj = null;
        $scope.isSimulation = false;

        console.log('END SIMULATION - BEFORE REFRESH', $rootScope.quoteSimulatorObj, $scope.isSimulation);
        $state.reload();
    }

    /*
        Name: getSelectedSegment
        Desc: Get a specific segment distance
        return: distance.
    */
    function getSelectedSegment(pData, pLabel) {
        var price = 0;
        if (pLabel) {
            switch (pLabel) {
                case 'Safe Interstate':
                    price = ppc_si * pData.safe_interstate;
                    break;
                case 'Safe Other':
                    price = ppc_so * pData.safe_other;
                    break;
                case 'Aggressive':
                    price = ppc_ag * pData.aggressive;
                    break;
                case 'Risky':
                    price = ppc_ri * pData.risky;
                    break;
                case 'Dangerous':
                    price = ppc_da * pData.dangerous;
                    break;
            }
        } else {
            price = ppc_si * pData.safe_interstate + ppc_so * pData.safe_other + ppc_ag * pData.aggressive + ppc_ri * pData.risky + ppc_da * pData.dangerous;
        }
        return price;
    }

    /*
        Name: triggerScanning
        Desc: Manually start scanning
    */
    function triggerScanning() {
        // SEND INTENT TO T2 TO START SCANNING
        CordovaBroadcaster.startDeviceScan();
    }
}
