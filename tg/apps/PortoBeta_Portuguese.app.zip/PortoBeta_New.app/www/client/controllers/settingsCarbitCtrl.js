angular.module('controllers')
    .controller('CarbitCtrl', CarbitCtrl);

function CarbitCtrl($rootScope, $scope, $ionicHistory, LocalStorage, LocalStorageKeys, CordovaBroadcaster) {
    // SCOPE VARIABLES
    /*
        Faked the data for now.
    */
    $scope.shipping_status = "Prepared for Shipping";
    $scope.notifications = 1;

    // SCOPE FUNCTION

    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    // FUNCTIONS
    function ionicViewBeforeEnter() {
        console.log(1111111, $scope.deviceStatus);
    }
}
