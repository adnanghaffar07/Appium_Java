angular.module('controllers')
    .controller('NewUserTutorialCtrl', NewUserTutorialCtrl)
    .directive('parseStyle', parseStyle);

function NewUserTutorialCtrl($scope, $state, $timeout, $ionicSlideBoxDelegate, LocalStorage, LocalStorageKeys) {
    $scope.onSlideChanged = onSlideChanged;
    $scope.onClickLeftArrow = onClickLeftArrow;
    $scope.onClickRightArrow = onClickRightArrow;
    $scope.onClickDoneLabel = onClickDoneLabel;
    
    $scope.isLastSlide = false;
    $scope.slideIndex = 0;
    
    $timeout(function(){
        $('ion-content#new-user-tutorial-content div#tutorial-page-hider').fadeOut('slow');
    }, 500);
    
    function onSlideChanged(pI){
        $scope.slideIndex = pI;
        var c = $ionicSlideBoxDelegate.$getByHandle('tutorialScroll').slidesCount() - 1;
        if(pI == c){
            $scope.isLastSlide = true;
        }else{
            $scope.isLastSlide = false;
        }
    }
    
    function onClickLeftArrow(){
        $ionicSlideBoxDelegate.$getByHandle('tutorialScroll').slide($scope.slideIndex - 1);
    }
    
    function onClickRightArrow(){
        console.log(4545,$scope.slideIndex);
        $ionicSlideBoxDelegate.$getByHandle('tutorialScroll').slide($scope.slideIndex + 1);
    }
    
    function onClickDoneLabel(){
        LocalStorage.set(LocalStorageKeys.IS_FIRST_TIME, 'false');
        $state.go('login');
    }
}

function parseStyle($interpolate) {
    return function (scope, elem) {
        var exp = $interpolate(elem.html()),
            watchFunc = function () {
                return exp(scope);
            };

        scope.$watch(watchFunc, function (html) {
            elem.html(html);
        });
    };
}
