angular.module('controllers')
    .controller('TripHistoryLegendsCtrl', TripHistoryLegendsCtrl);

function TripHistoryLegendsCtrl($rootScope, $scope, $state, $translate, $stateParams, $ionicHistory) {
  $scope.types = $stateParams.list;
  $scope.tripId = $stateParams.tripId;

  var imagePath = "./client/images/map_icons/";
  var imageType = ".png";

  $scope.$on('$ionicView.loaded', ionicViewLoaded);

  function ionicViewLoaded() {
    $scope.tripLegend = [
      {description: 'legend_interference'},
      {description: 'legend_non_distracter'},
      {description: 'legend_distracter_driver'},
      {description: 'legend_hard_acceleration', icon: imagePath + 'hac-icon' + imageType},
      {description: 'legend_hard_bracking',icon: imagePath + 'hbr-icon' + imageType},
      {description: 'legend_hard_cornering',icon: imagePath + 'hco-icon' + imageType},
      {description: 'legend_over_speed',icon: imagePath + 'osp-icon' + imageType},
      {description: 'legend_trip_start',icon: imagePath + 'marker_a' + imageType},
      {description: 'legend_trip_stop',icon: imagePath + 'marker_b' + imageType}
    ];
  }

}
 