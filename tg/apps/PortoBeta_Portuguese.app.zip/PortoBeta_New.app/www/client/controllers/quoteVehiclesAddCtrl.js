angular.module('controllers')
    .controller('QuoteVehiclesAddCtrl', QuoteVehiclesAddCtrl)
    .directive('numbersOnly', function () {
        return {
            require: 'ngModel',
            link: function (scope, element, attrs, modelCtrl) {
                modelCtrl.$parsers.push(function (inputValue) {
                    // this next if is necessary for when using ng-required on your input. 
                    // In such cases, when a letter is typed first, this parser will be called
                    // again, and the 2nd time, the value will be undefined
                    if (inputValue == undefined) return ''
                    var transformedInput = inputValue.replace(/[^0-9]/g, '');
                    if (transformedInput != inputValue) {
                        modelCtrl.$setViewValue(transformedInput);
                        modelCtrl.$render();
                    }
                    return transformedInput;
                });
            }
        };
    });
function QuoteVehiclesAddCtrl($rootScope, $state, $scope, $ionicHistory, LocalStorage, $stateParams, ProfileServices,BooleanConstant, $filter, QuoteDetails,LoggerUtilType,$translate,PopupUtil, BarcodeScannerUtil, LoadingUtil) {
    
    // SCOPE VARIABLES
    // --> All scope variables that are specific to that view will be defined here
    $scope.quoteData.vehiclesAdd = {};
    
    //// Declare mandatory fields
    var requiredFields = ['year', 'make', 'model', 'annual_mileage'];
    var isVinValid = true;
    
    //// Hard coded data to bind - Real WS not working.
    var vehicleYears = [];
    var vehicleMakes = [];
    var vehicleModels = [];
    var daysDrivenPerWeek = ['0', '1', '2', '3', '4', '5', '6', '7'];
    
    //// Set the selected vehicle index
    var vrVehicleIndex = $stateParams.pIndex;
    
    // SCOPE FUNCTIONS
    // --> All scope functions specific to that view are defined here
    $scope.saveVehicleDetails = saveVehicleDetails;
    $scope.goToSelectInfo = goToSelectInfo;
    $scope.setAnnualEstimateMileage = setAnnualEstimateMileage;
    $scope.scanVinNumber = scanVinNumber;
    $scope.getVehicleInfoByVin = getVehicleInfoByVin;
    
    // SCOPE LIFE CYCLE
    // --> All needed life cycle events specific to that view are defined here. Note that we do not write the function directly in it.
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    $scope.$on('$ionicView.enter', ionicViewEnter)
 
    
    ////// Functionality when before entering into the view
    /*
        name : ionicViewBeforeEnter
        desc : will do the data binding to the scope before entering into the view.
               Will call web services and prepare an object for the screen
    */
    function ionicViewBeforeEnter() {
        
        ////// Code to popluate the vehicle details after selecting the item in select screen / Populate the saved vehicle details 
        var vrSelectedType = $scope.selectedType;
        var vrSelectedVal = $rootScope.selectedValue;
        $scope.selectedType=null;
        $rootScope.selectedValue=null;
        if (vrSelectedType == null) {
            if (vrVehicleIndex == null) {
                $scope.quoteData.vehiclesAdd = {};
                vrVehicleIndex = Object.keys($rootScope.quoteData.vehicles).length;
            } else {
                angular.copy($rootScope.quoteData.vehicles[vrVehicleIndex], $scope.quoteData.vehiclesAdd);
            }
        }
        if (vrSelectedVal == null)
            return false;
        switch (vrSelectedType) {
            case 'vehicleType':
                $scope.quoteData.vehiclesAdd.type = vrSelectedVal;
                break;
            case 'vehicleYears':
                $scope.quoteData.vehiclesAdd.year = vrSelectedVal;
                $scope.quoteData.vehiclesAdd.model = '';
                $scope.quoteData.vehiclesAdd.make = '';
                break;
            case 'vehicleMakes':
                $scope.quoteData.vehiclesAdd.make = vrSelectedVal;
                $scope.quoteData.vehiclesAdd.model = '';
                break;    
            case 'vehicleModels':
                $scope.quoteData.vehiclesAdd.model = vrSelectedVal;
                break;
            case 'moreDetails':
                $scope.quoteData.vehiclesAdd.modelDetails = vrSelectedVal;
                break;
            case 'primaryVehicle':
                $scope.quoteData.vehiclesAdd.primaryVehicleUse = vrSelectedVal;
                break;
            case 'annualKM':
                $scope.quoteData.vehiclesAdd.annualKMS = vrSelectedVal;
                break;
            case 'daysDrivenPerWeek':
                $scope.quoteData.vehiclesAdd.daysDrivenPerWeek = vrSelectedVal;
                break;
            case 'distanceDriven':
                $scope.quoteData.vehiclesAdd.kmDrivenPerWeek = vrSelectedVal;
                break;
            default:
                break;
        }
    }
    
    function ionicViewEnter(){
        if (!$scope.quoteData.vehiclesAdd.annual_mileage)
        $scope.quoteData.vehiclesAdd.annual_mileage = $filter('number')(QuoteDetails.ESTIMATE_ANNUAL_MILEAGE);
    }
    
    //// Function to save vehicle details
    ////// Functionality when before entering into the view
    /*
        name : saveVehicleDetails
        desc : It'll save the vehicle data in rootscope with the respective index number.
    */
    function saveVehicleDetails() {
        $scope.submitted = BooleanConstant.BOOL_TRUE;
        var error = validateData($scope.quoteData.vehiclesAdd);
        if (!error) {
            $rootScope.quoteData.vehicles[vrVehicleIndex] = $scope.quoteData.vehiclesAdd;
            $ionicHistory.goBack();
        }
    }
    
    //// Function to validate mandatory fields
    /*
        name : validateData
        parameter : data
        desc : Validate the mandatory fields details
        return : It'll return 'true' if any of the mandatory fields kept empty. If all the mandatory details are filled it'll return 'false'
    */
    function validateData(data) {
        var isError = BooleanConstant.BOOL_FALSE;
        if (data) {
            for (var i = 0; i < requiredFields.length; i++) {
                if (angular.isUndefined(data[requiredFields[i]]) || data[requiredFields[i]] === '' || data[requiredFields[i]] === null) {
                    if (typeof isError !== 'object') {
                        isError = {};
                    }
                    isError[requiredFields[i]] = BooleanConstant.BOOL_TRUE;
                }
            };
        } else {
            isError = BooleanConstant.BOOL_TRUE;
        }
        return isError;
    }
    
    ///// Function to redirect to select screen to populate data
    /*
        name : goToSelectInfo
        parameter : pType
        desc : Redirect to select screen to show list of items
    */
    function goToSelectInfo(pType) {
        var list = [];
        switch (pType) {
            case 'vehicleType':
                getVehicleTypes();
                break;
            case 'vehicleYears':
                getVehicleYears();
                break;
            case 'vehicleMakes':
                if ($scope.quoteData.vehiclesAdd.year == null)
                    return false;
                getVehicleMakes($scope.quoteData.vehiclesAdd.year);
                break;
            case 'vehicleModels':
                if ($scope.quoteData.vehiclesAdd.make == null)
                    return false;
                getVehicleModels($scope.quoteData.vehiclesAdd.year, $scope.quoteData.vehiclesAdd.make);
                break;
            case 'moreDetails':
                getVehicleMoreDetails();
                break;
            case 'primaryVehicle':
                getPrimaryVehicles();
                break;
            case 'annualKM':
                getAnnualKMs();
                break;
            case 'daysDrivenPerWeek':
                list = daysDrivenPerWeek;
                $state.go('app.selectInfo', { 'list': list });
                break;
            case 'distanceDriven':
                getDistanceDriven();
                break;
            default:
                break;
        }
        $scope.selectedType=pType;
    }
    
    //// Function to get vehicle types
    /*
        name : getVehicleTypes
        desc : Get the vehicle types.
        return : It'll return the type of vehicles.
    */
    function getVehicleTypes() {
        ProfileServices.getVehicleTypes().then(function (response) {
            $state.go('app.selectInfo', { 'list': response });
        }, function (error) {
            
            console.log('ERROR IN VEHICLE TYPES LOAD');
            PopupUtil.showSimpleAlert($translate.instant('error'),$translate.instant(error.data['i18n-key']));
        });
    }
    
    //// Funciton to get vehicle years
    /*
        name : getVehicleYears
        desc : Get the vehicle years.
        return : It'll return the years of vehicles
    */
    function getVehicleYears() {
        ProfileServices.getVehicleMakeYear().then(function (response) {
            vehicleYears = response;
            $state.go('app.selectInfo', { 'list': vehicleYears,'selectedValue': $scope.quoteData.vehiclesAdd.year});
        }, function (error) {
          //  $state.go('app.selectInfo', { 'list': vehicleYears });
            console.log('ERROR IN YEARS LOAD');
            PopupUtil.showSimpleAlert($translate.instant('error'),$translate.instant(error.data['i18n-key']));
        });
    }
    
    //// Function to get vehicle Makes - We've to send the year as input 
    /*
        name : getVehicleMakes
        parameter : pYear
        desc : Get the vehicle makes.
        return : It'll return the makes of vehicles based on the year selected.
    */
    function getVehicleMakes(pYear) {
        ProfileServices.getVehicleMake(pYear).then(function (response) {
            vehicleMakes = response;
            $state.go('app.selectInfo', { 'list': vehicleMakes ,'selectedValue': $scope.quoteData.vehiclesAdd.make});
        }, function (error) {
           // $state.go('app.selectInfo', { 'list': vehicleMakes });
            console.log('ERROR LOADING IN MAKES');
            PopupUtil.showSimpleAlert($translate.instant('error'),$translate.instant(error.data['i18n-key']));
        });
    }
    
    //// Function to get vehicle Models - We've to send the year and make as input 
    /*
        name : getVehicleModels
        parameter : pYear, pMake
        desc : Get the vehicle models
        return : It'll return the models of vehicles based on the year and make of vehicle selected
    */
    function getVehicleModels(pYear, pMake) {
        ProfileServices.getVehicleModel(pYear, pMake).then(function (response) {
            vehicleModels = response;
            $state.go('app.selectInfo', { 'list': vehicleModels ,'selectedValue': $scope.quoteData.vehiclesAdd.model});
        }, function (error) {
           // $state.go('app.selectInfo', { 'list': vehicleModels });
            console.log('ERROR LOADING IN MODELS');
            PopupUtil.showSimpleAlert($translate.instant('error'),$translate.instant(error.data['i18n-key']));
        });
    }
    
    ///// Function to get vehicle more details
    /*
        name : getVehicleMoreDetails
        desc : Get the vehicle more details
    */
    function getVehicleMoreDetails() {
        ProfileServices.getVehicleMoreDetails().then(function (response) {
            $state.go('app.selectInfo', { 'list': response });
        }, function (error) {
            console.log('ERROR IN VEHICLE More Details LOAD');
            PopupUtil.showSimpleAlert($translate.instant('error'),$translate.instant(error.data['i18n-key']));
        });
    }
    
    //// Function to get primary vehicles
    /*
        name : getPrimaryVehicles
        desc : Get the vehicle primary details
    */
    function getPrimaryVehicles() {
        ProfileServices.getPrimaryVehicles().then(function (response) {
            $state.go('app.selectInfo', { 'list': response });
        }, function (error) {
            console.log('ERROR IN VEHICLE Primary vehicle Details LOAD');
            PopupUtil.showSimpleAlert($translate.instant('error'),$translate.instant(error.data['i18n-key']));
        });
    }
    
    ///// Function to get Annual kms
    /*
        name : getAnnualKMs
        desc : Get the vehicle Annual km details
    */
    function getAnnualKMs() {
        ProfileServices.getAnnualKMs().then(function (response) {
            $state.go('app.selectInfo', { 'list': response });
        }, function (error) {
            console.log('ERROR IN VEHICLE Annual KMs LOAD');
            PopupUtil.showSimpleAlert($translate.instant('error'),$translate.instant(error.data['i18n-key']));
        });
    }
    
    //// Function to get distance driven
    /*
        name : getDistanceDriven
        desc : Get the vehicle distance driven details
    */
    function getDistanceDriven() {
        ProfileServices.getDistanceDriven().then(function (response) {
            $state.go('app.selectInfo', { 'list': response });
        }, function (error) {
            console.log('ERROR IN VEHICLE Distance driven LOAD');
            PopupUtil.showSimpleAlert($translate.instant('error'),$translate.instant(error.data['i18n-key']));
        });
    }
    
    /*
        name : setAnnualEstimateMileage
        desc : Set the annual mileage min value to 500 and round up to its 500's decimal
    */
    function setAnnualEstimateMileage() {
        var mileage = $scope.quoteData.vehiclesAdd.annual_mileage.toString().replace(/,/g, '');
        mileage = +mileage;
        mileage = Math.ceil(mileage / 500.0) * 500.0;
        if (mileage==0)
        mileage = 500;
        $scope.quoteData.vehiclesAdd.annual_mileage = $filter('number')(mileage);
    }

    /* 
        name : scanVinNumber
        desc : Scans VIN number and gets vin number.
    */ 
    function scanVinNumber() {
        LoadingUtil.showLoader();
        BarcodeScannerUtil.sacnBarCode().then(function (barCodeData) {
            LoadingUtil.hideLoader();
            if (barCodeData.cancelled == false && barCodeData.format == "CODE_39") {
                var vin = barCodeData.text
                getVehicleInfoByVin(vin);
            } else {
                LoadingUtil.hideLoader();
                //error - unable to scan
            }
        }, function (error) {
            LoadingUtil.hideLoader();
            //error - unable to scan
        });
    }

   /* 
        name : getVehicleInfoByVin
        desc : gets vehicle info based on vin number.
    */ 
    function getVehicleInfoByVin(vin) {
        if (vin == '' || vin == null) {
            return;
        }
        LoadingUtil.showLoader();
        ProfileServices.getVehicleInfoByVIN(vin).then(function (response) {
            LoadingUtil.hideLoader();
            if (response.status != "fail") {
                $scope.quoteData.vehiclesAdd = response[0];
                $scope.quoteData.vehiclesAdd.vin = vin;
                isVinValid = true;
                if (!$scope.quoteData.vehiclesAdd.annual_mileage)
                    $scope.quoteData.vehiclesAdd.annual_mileage = $filter('number')(QuoteDetails.ESTIMATE_ANNUAL_MILEAGE);
            } else {
                //error - scan failed
                $scope.quoteData.vehiclesAdd.vin = '';
                isVinValid = false;
                PopupUtil.showSimpleAlert($translate.instant('error'),response.message);
            }
        }, function (error) {
            LoadingUtil.hideLoader();
            isVinValid = false;
            $scope.quoteData.vehiclesAdd.vin = '';
            PopupUtil.showSimpleAlert($translate.instant('error'),$translate.instant(error.data["i18n-key"]));
            //error - VIN-not found in vinDB
        });
    }
}