angular.module('controllers')
    .controller('ProfileCtrl', ProfileCtrl);

function ProfileCtrl($rootScope, $scope, $state, $timeout, LocalStorage, AccountType, LocalStorageKeys, ConversionUtil, BooleanConstant, Profile, CameraUtil, CameraCapture, ProfileServices, AvatarServices, SocialUserService, LoginType, $translate, PopupUtil, ProfileDataUtil, WebServiceCache, LoadingUtil, FirebaseService) {
    // SCOPE FUNCTIONS
    $scope.closeOverlay = closeOverlay;
    $scope.openOverlay = openOverlay;
    $scope.navigateTo = navigateTo;
    $scope.objgender = Profile.GENDER_OPTIONS;
    $scope.goToSelectInfo = goToSelectInfo;
    var cameraOptions = CameraCapture.IMAGE_SIZE;
    // SCOPE VARIABLES
    $scope.showPictureOverlay = BooleanConstant.BOOL_FALSE;
    var vehicleYears = [],
        vehicleMakes = [],
        vehicleModels = [];
    $scope.hideOutofscope = false;
    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    $scope.$on('$ionicView.loaded', ionicViewLoaded);

    // FUNCTIONS
    function ionicViewBeforeEnter() {
        // Set LoginType
        var loginType = LocalStorage.get(LocalStorageKeys.LOGIN_TYPE);

        var accountType = LocalStorage.get(LocalStorageKeys.ACCOUNT_TYPE);
        if (accountType != AccountType.FACEBOOK && accountType != AccountType.GOOGLE) {
            $scope.isSocial = false;
        } else {
            $scope.isSocial = true;
        }

        // Load ProfileData
        $scope.profileData = LocalStorage.getObject(LocalStorageKeys.PROFILE_DATA);

        $rootScope.activeMenuItem = "profile";
        var vrSelectedType = $scope.selectedType;
        var vrSelectedVal = $rootScope.selectedValue;
        $scope.selectedType = null;
        $rootScope.selectedValue = null;

        if ($rootScope.vehicleHasChanged) {
            switch (vrSelectedType) {
                case 'vehicleYears':
                    if ($scope.profileData.cars) {
                        $scope.profileData.cars[0].year = vrSelectedVal;
                        $scope.profileData.cars[0].model = "";
                        $scope.profileData.cars[0].make = "";
                    }
                    break;
                case 'vehicleModels':
                    if ($scope.profileData.cars) {
                        $scope.profileData.cars[0].model = vrSelectedVal;
                    }
                    break;
                case 'vehicleMakes':
                    if ($scope.profileData.cars) {
                        $scope.profileData.cars[0].make = vrSelectedVal;
                        $scope.profileData.cars[0].model = "";
                    }
                    break;
                default:
                    break;
            }
        }

        if (vrSelectedVal != null) {
            if ($scope.needToSaveVehicle) {
                saveVehicleData();
            }
            LocalStorage.setObject(LocalStorageKeys.PROFILE_DATA, $scope.profileData);

            vrSelectedVal = null;
        }
        // if(angular.isUndefined($scope.profileData.cars[0])){
        //     $scope.profileData.cars[0]={vin:"",year:"",make:"",model:""}
        // }

        if ($rootScope.needToSaveProfile) {
            // CALL SAVE PROFILE WEB SERVICE
            $rootScope.needToSaveProfile = BooleanConstant.BOOL_FALSE;
            saveProfile();
        }
        if ($rootScope.fromRPM) {
            $rootScope.fromRPM = false;
            $rootScope.$emit("CallGetBalanceInfo", {});
        }

        // FORMAT ALL FIELDS
        // --> MOBILE NUMBER
        $scope.mobileNumber = $scope.profileData ? $scope.profileData.user.mobile_phone : '';


        FirebaseService.logEvent("view_item", {
            item_name: "Perfil", 
            custom_dimension2: "Perfil",
            custom_dimension5: LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID) !== null ? "logged in" : "logged out"
        });
    }

    /*
        name   :  ionicViewLoaded  
        desc   :  It gets called after page loaded.
                  To get the count of pictures and binds in profile.
    */
    function ionicViewLoaded() {
        // Load ProfileData
        $scope.profileData = LocalStorage.getObject(LocalStorageKeys.PROFILE_DATA);

        var len = 0;

        if ($scope.profileData) {
        var arrPics = $scope.profileData.user.pictures;
        if (angular.isDefined(arrPics)) {
                for (var i = 0; i < arrPics.length; i++) {
                    if (angular.isDefined(arrPics[i]) && arrPics[i] != null && arrPics[i].length > 0) {
                        len += 1;
                    }
                }
            }
            if (len > 0) {
                $scope.profileData.user.picturescount = len;
            } else {
                $scope.profileData.user.picturescount = "";
            }
        }
    }

    /*
        name   :  closeOverlay  
        desc   :  It closes footer of displaying options to attach picture.
    */
    function closeOverlay(pE) {
        $timeout(function () {
            switch (pE) {
                case "import":
                    $scope.showPictureOverlay = BooleanConstant.BOOL_FALSE;
                    facebookLogin();
                    break;
                case "take":
                    takePhoto();
                    $timeout(function () {
                        $scope.showPictureOverlay = BooleanConstant.BOOL_FALSE;
                    }, 700);
                    break;
                case "choose":
                    chooseFromLibrary();
                    $timeout(function () {
                        $scope.showPictureOverlay = BooleanConstant.BOOL_FALSE;
                    }, 700);
                    break;
                case "picture":
                    $scope.showPictureOverlay = BooleanConstant.BOOL_FALSE;
                    break;
            }
        }, 100);
    }

    /*
        name   :  takePhoto  
        desc   :  It opens camera to take photo.
    */
    function takePhoto() {
        $scope.displayFooter = BooleanConstant.BOOL_FALSE;
        CameraUtil.takePicture(cameraOptions).then(function (image) {
            processImage(image);
        });
    }

    /*
        name   :  chooseFromLibrary  
        desc   :  It shows images in Gallery.
    */
    function chooseFromLibrary() {
        $scope.displayFooter = BooleanConstant.BOOL_FALSE;
        CameraUtil.getPicture(cameraOptions).then(function (image) {
            processImage(image);
        });
    }

    /*
        name   :  processImage  
        desc   :  It will save saves picture to server.
    */
    function processImage(img) {
        LoadingUtil.showLoader();
        AvatarServices.setAvatar('', img).then(function (response) {
            $scope.profileImage = "data:image/png;base64," + img;
            LocalStorage.set(LocalStorageKeys.PROFILE_PIC_SRC, $scope.profileImage);
            LoadingUtil.hideLoader();
            $rootScope.updateProfilePic = true;
        }, function (error) {

            LoadingUtil.hideLoader();
            //    PopupUtil.showSimpleAlert($translate.instant('error'),$translate.instant(error['i18n-key']));

        });
    }

    /*
        name   :  openOverlay  
        desc   :  It closes footer of displaying options to attach picture.
    */
    function openOverlay(pE) {
        $timeout(function () {
            switch (pE) {
                case "picture":
                    $scope.showPictureOverlay = BooleanConstant.BOOL_TRUE;
                    break;
            }
        }, 500);
    }

    /*
        name   :  navigateTo  
        param  :  url
        desc   :  Navigates to provided screen.
    */
    function navigateTo(pRoute) {
        $state.go(pRoute);
    }
    ///// Function to redirect to select screen to populate data
    /*
        name : goToSelectInfo
        parameter : pType
        desc : Redirect to select screen to show list of items
    */
    function goToSelectInfo(pType) {
        var list = [];
        switch (pType) {
            case 'vehicleType':
                //getVehicleTypes();
                break;
            case 'vehicleYears':
                $scope.needToSaveVehicle = false;
                getVehicleYears();
                break;
            case 'vehicleMakes':
                if ($scope.profileData.cars && $scope.profileData.cars[0].year === null) {
                    PopupUtil.showSimpleAlert($translate.instant('Error'), $translate.instant('select_the_year'));
                    return false;
                }

                $scope.needToSaveVehicle = false;
                if ($scope.profileData.cars) {
                    getVehicleMakes($scope.profileData.cars[0].year);
                }
                break;
            case 'vehicleModels':
                if ($scope.profileData.cars && ($scope.profileData.cars[0].make === null || $scope.profileData.cars[0].year === null)) {
                    PopupUtil.showSimpleAlert($translate.instant('Error'), $translate.instant('select_the_year_and_brand'));
                    return false;
                }
                $scope.needToSaveVehicle = true;
                if ($scope.profileData.cars) {
                    getVehicleModels($scope.profileData.cars[0].year, $scope.profileData.cars[0].make);
                }
                break;
            default:
                break;
        }
        $scope.selectedType = pType;
        //$rootScope.needToSaveProfile = BooleanConstant.BOOL_TRUE;
    }

    //// Funciton to get vehicle years
    /*
        name : getVehicleYears
        desc : Get the vehicle years.
        return : It'll return the years of vehicles
    */
    function getVehicleYears() {
        ProfileServices.getVehicleMakeYear().then(function (response) {
            vehicleYears = response;
            $state.go('app.selectInfo', {
                'list': vehicleYears,
                'selectedValue': ($scope.profileData && $scope.profileData.cars) ? $scope.profileData.cars[0].year : ''
            });
        }, function (error) {
            console.log('ERROR IN YEARS LOAD');
            PopupUtil.showSimpleAlert($translate.instant('Error'), $translate.instant(error['i18n-key']));
        });
    }

    //// Function to get vehicle Makes - We've to send the year as input 
    /*
        name : getVehicleMakes
        parameter : pYear
        desc : Get the vehicle makes.
        return : It'll return the makes of vehicles based on the year selected.
    */
    function getVehicleMakes(pYear) {
        ProfileServices.getVehicleMake(pYear).then(function (response) {
            vehicleMakes = response;
            $state.go('app.selectInfo', {
                'list': vehicleMakes,
                'selectedValue': $scope.profileData.cars[0].make
            });
        }, function (error) {
            console.log('ERROR LOADING IN MAKES');
            PopupUtil.showSimpleAlert($translate.instant('Error'), $translate.instant(error['i18n-key']));
        });
    }

    //// Function to get vehicle Models - We've to send the year and make as input 
    /*
        name : getVehicleModels
        parameter : pYear, pMake
        desc : Get the vehicle models
        return : It'll return the models of vehicles based on the year and make of vehicle selected
    */
    function getVehicleModels(pYear, pMake) {
        ProfileServices.getVehicleModel(pYear, pMake).then(function (response) {
            vehicleModels = response;
            $state.go('app.selectInfo', {
                'list': vehicleModels,
                'selectedValue': $scope.profileData.cars[0].model
            });
        }, function (error) {
            console.log('ERROR LOADING IN MODELS');
            PopupUtil.showSimpleAlert($translate.instant('Error'), $translate.instant(error['i18n-key']));
        });
    }
    /*
        name   :  saveProfile  
        param  :  Profile data
        desc   :  Saves profile data to server.
    */
    function saveProfile() {
        ProfileServices.saveProfile("", $scope.profileData).then(function (response) {
            WebServiceCache.cleanseCache(2);
            loadProfileData();
        }, function (error) {
            loadProfileData();
            PopupUtil.showSimpleAlert($translate.instant('Error'), $translate.instant(error.data['i18n-key']));
        });
    }

    function saveVehicleData() {
        ProfileServices.setVehicleProfile($scope.profileData.cars[0]).then(function (response) {
            WebServiceCache.cleanseCache(2);
            console.log(response);
        }, function (error) {
            loadProfileData();
            //error
        });
    }
    /*
        NAME : facebookLogin
        DESC : Login user using facebook plugin
    */
    function facebookLogin() {
        var accessToken = LocalStorage.get(LocalStorageKeys.FB_ACCESS_TOKEN);
        if (accessToken && accessToken !== "null") {
            getFacebookUserMeta(accessToken);

        } else {
            SocialUserService.loginFacebookOAuth().then(function (response) {
                getFacebookUserMeta(response.access_token);
            }, function (error) {

            });
        }
    }

    /*
       NAME : getFacebookUserMeta
       DESC : Gets user data based on obtained access token.
   */
    function getFacebookUserMeta(accessToken) {
        LocalStorage.set(LocalStorageKeys.FB_ACCESS_TOKEN, accessToken);
        SocialUserService.getFacebookUserData(accessToken).then(function (response) {
            var pictureurl = "http://graph.facebook.com/" + response.id + "/picture?type=square";
            AvatarServices.setAvatar('', response.id).then(function (response) {
                $scope.profileImage = pictureurl;
            }, function (error) {

            });
        }, function (error) {
            LocalStorage.set(LocalStorageKeys.FB_ACCESS_TOKEN, null);
            return false;
        });
    }

    /*
       NAME : loadProfileData
       DESC : It'll reload the old data when there is an error and updates the scope
   */
    function loadProfileData() {
        if ($scope.isTBYB) {
            ProfileServices.getProfile().then(function (pRawData) {
                ProfileDataUtil.createProfileData(pRawData);
                $scope.profileData = LocalStorage.getObject(LocalStorageKeys.PROFILE_DATA);
                $rootScope.$emit("CallBindProfData", {});
            }, function (error) {
                // error
                console.log('ERROR IN SET PROFILE DATA', error);
            });
        } else {
            ProfileServices.getProfileData_client().then(function (pRawData) {
                ProfileDataUtil.createProfileData(pRawData);
                $scope.profileData = LocalStorage.getObject(LocalStorageKeys.PROFILE_DATA);
                $rootScope.$emit("CallBindProfData", {});
            }, function (error) {
                // error
                console.log('ERROR IN SET PROFILE DATA', error);
            });
        }
    }
}
