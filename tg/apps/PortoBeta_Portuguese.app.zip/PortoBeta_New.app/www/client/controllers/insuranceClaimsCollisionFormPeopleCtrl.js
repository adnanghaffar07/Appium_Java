angular.module('controllers')
    .controller('InsuranceClaimsCollisionFormPeopleCtrl', InsuranceClaimsCollisionFormPeopleCtrl);

function InsuranceClaimsCollisionFormPeopleCtrl($state, $rootScope, $scope) {
   // SCOPE FUNCTIONS
   $scope.saveData = saveData;
   $scope.goToState = goToState;
   $scope.goToPeopleEdit = goToPeopleEdit;
   //SCOPE VARIABLES
   
    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    // FUNCTIONS
     ////// Functionality when before entering into the view
    /*
        name : ionicViewBeforeEnter
        desc : will do the data binding to the scope before entering into the view
    */
    function ionicViewBeforeEnter() {
    $scope.items = $rootScope.peopleInvolved;
    }
    
      ////// Function to navigate to Form screen after saving data.
    /*
        name : saveData
        parameter:State value
        desc : Saves People involved and navigate to form screen.
    */
    
    function saveData(route){
       $rootScope.form.involved = $rootScope.peopleInvolved.length;
       $rootScope.form.peopleInvolved = $rootScope.peopleInvolved;
        $state.go(route);
    }
    
   ////// Function to navigate to Form People Involved edit screen.
    /*
        name : goToState
        parameter:State value
        desc : Navigates user to people involved edit screen.
    */
    
    function goToState(route){
         $state.go(route);
    }
    
     ////// Function to navigate to Form People Involved edit screen.
    /*
        name : goToPeopleEdit
        parameter:State value
        desc : Navigates user to people involved edit screen with user index.
    */
    function goToPeopleEdit(index){
        $state.go("app.insuranceClaimsCollisionFormPeopleEdit",{
            'pIndex':index
            });
    }
    
    
}
