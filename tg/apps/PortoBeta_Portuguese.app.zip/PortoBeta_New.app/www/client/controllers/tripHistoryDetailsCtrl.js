angular.module('controllers')
    .controller('TripHistoryDetailsCtrl', TripHistoryDetailsCtrl);

function TripHistoryDetailsCtrl($rootScope, $state, $scope, $stateParams, TripsServices, LocalStorageKeys, LocalStorage, TripEventType, MapsUtil, LoadingUtil, DateUtil, StringUtil, LoggerUtilType, PopupUtil, $translate, WebServiceCache, $ionicHistory, FirebaseService) {
    // SCOPE VARIABLES
    $scope.scoreData = {};
    var map = {};
    var target = "";
    var globalMapOptions = {};
    var tempStart = {};
    var tempStop = {};
    $scope.tripEvents = {
        ac: false,
        dc: false,
        osp: false,
        ht: false
    }

    // SCOPE FUNCTIONS
    $scope.showFullMap = showFullMap;
    $scope.closeFullMap = closeFullMap;
    $scope.changeTripType = changeTripType;
    $scope.goLegend = goLegend;
    $scope.selectTripEvent = selectTripEvent;

    var tripTypesData = [];


    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    $scope.$on('$ionicView.enter', ionicViewEnter);

    function ionicViewEnter() {
        FirebaseService.logEvent("view_item", {
            item_name: "Detalhes viagem", 
            custom_dimension2: "Histórico de viagens",
            custom_dimension5: LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID) !== null ? "logged in" : "logged out"
        });
    }


    // FUNCTIONS
    function ionicViewBeforeEnter() {
        var trip = $stateParams.trip_id;
        tripTypesData = $stateParams.tripTypesData;

        getTripDetails(trip);
    }

    function showFullMap() {
        $scope.showMap = true;
        $('section#triphistorydetails-fullmap').fadeIn("fast");
        $('div#footer-content').fadeIn("fast");
        var obj = $scope.mapObjects;
        var element_big = 'triphistorydetails-fullmap';
        MapsUtil.init_mapFromPointsArrayBASEDRIVE(obj.pArray, obj.pInferredArray, obj.pMapPoint, element_big, obj.pIcons, obj.pStrokeSetting, obj.pInferredStrokeSettings);
    }

    function closeFullMap() {
        $('section#triphistorydetails-fullmap').fadeOut("fast");
        $('div#footer-content').fadeOut("fast");
    }

    /*
        Name: getTripDetails
        Desc: Fetch the list of trips of last 30 days
    */
    function getTripDetails(pTripId) {
        LoadingUtil.showLoader();
        TripsServices.getTrip(pTripId).then(function (response) {
            LoadingUtil.hideLoader();
            var tripData = response.data;
            $scope.scoreData = tripData.score;
            $scope.start_time = moment(DateUtil.formatDateAsUTC(StringUtil.getdateinformat(tripData.start_time))).format('h:mm A');
            $scope.end_time = moment(DateUtil.formatDateAsUTC(StringUtil.getdateinformat(tripData.end_time))).format('h:mm A');
            $scope.trip_date = moment(DateUtil.formatDateAsUTC(StringUtil.getdateinformat(tripData.end_time))).format('dddd MMMM D');
            $scope.startLocation = tripData.start_location;
            $scope.endLocation = tripData.end_location;
            $scope.tripType = getTransportTypeIcon(tripData.trip_type.id);

            // Calculate trip duration
            var time = moment(tripData.end_time).format('X') - moment(tripData.start_time).format('X');
            var hours = Math.floor(time / 3600);
            var minutes = Math.floor(time % 3600 / 60);
            tripData.duration_hours = hours;
            tripData.duration_minutes = minutes;
            ////////////////////////////////

            $scope.trip = tripData;

            if ($scope.changeType) {
                $scope.changeType = false;
            } else {
                prepareMap(tripData);
            }
        }, function (error) {
            LoadingUtil.hideLoader();
        });
    }

    /*
        Name: changeTripType
        Desc: A method that navigates to another screen where user is allowed to change his trip type
    */
    function changeTripType() {
        $scope.changeType = true;
        $state.go('app.selectTripType', {
            list: tripTypesData,
            tripId: $stateParams.trip_id
        });
    }

    function goLegend() {
        $state.go('app.tripHistoryDetailsLegends', {
            list: tripTypesData,
            tripId: $stateParams.trip_id
        });
    }

    /*
        Name: prepareMap
        Desc: Prepares the map with the trip data
    */
    function prepareMap(pData) {
        var data = pData;
        var tripPath = data.encoded_path;
        var mapPoints = data.poi || [];
        var array = polyline.decode(tripPath, 3);

        for (var i = 0; i < array.length; i++) {
            for (var j = 0; j < array[i].length; j++) {
                var c = array[i][j] / 100;
                array[i][j] = c;
            }
        }

        // Setup Inferred path
        var inferredPath = data.inferred_encoded_path;
        var inferredArray = [];
        if(inferredPath != null){
            inferredArray = polyline.decode(inferredPath, 3);
        }
        
        for (var i = 0; i < inferredArray.length; i++) {
            for (var j = 0; j < inferredArray[i].length; j++) {
                var c = inferredArray[i][j] / 100;
                inferredArray[i][j] = c;
            }
        }

        tempStart = {
            LN: array[0][1],
            LT: array[0][0],
            type: TripEventType.START
        }

        tempStop = {
            LN: array[array.length - 1][1],
            LT: array[array.length - 1][0],
            type: TripEventType.STOP
        }

        mapPoints.push(tempStart);
        mapPoints.push(tempStop);
        target = "tripMap";
        var strokeSettings = {
            color: '#19acef',
            width: 4
        }

        var inferredStrokeSettings = {
            color: '#666666',
            width: 4
        }

        var icons = {
            START: {
                iconPath: "./client/images/map_icons/marker_a.png",
                anchor: [0.5, 41]
            },
            STOP: {
                iconPath: "./client/images/map_icons/marker_b.png",
                anchor: [0.5, 41]
            },
            HAC: {
                iconPath: "./client/images/map_icons/hac-icon.png",
                anchor: [0.5, 41]
            },
            HBR: {
                iconPath: "./client/images/map_icons/hbr-icon.png",
                anchor: [0.5, 41]
            },
            OSP: {
                iconPath: "./client/images/map_icons/osp-icon.png",
                anchor: [0.5, 41]
            },
            HCO: {
                iconPath: "./client/images/map_icons/hco-icon.png",
                anchor: [0.5, 41]
            }

        };
        $scope.mapObjects = {
            pArray: array,
            pInferredArray: inferredArray,
            pMapPoint: mapPoints,
            pIcons: icons,
            pStrokeSetting: strokeSettings,
            pInferredStrokeSettings: inferredStrokeSettings
        }
        globalMapOptions = angular.copy($scope.mapObjects);
        map = MapsUtil.init_mapFromPointsArrayBASEDRIVE(array, inferredArray, mapPoints, target, icons, strokeSettings, inferredStrokeSettings);
    }

    /**
     * name : selectTripEvent
     * param : eventype clicked
     * return : It hides all the event points on the map and only show points for selected event.
     */
    function selectTripEvent(eventType, pTarget) {
        for (var prop in $scope.tripEvents) {
            if (prop != eventType) {
                $scope.tripEvents[prop] = true;
            }
        }
        if (eventType == $rootScope.tripEvent) {
            for (var prop in $scope.tripEvents) {
                if (prop != eventType) {
                    $scope.tripEvents[prop] = false;
                }
            }
            $rootScope.tripEvent = null;
            $("#" + pTarget).find(".ol-viewport").remove();
            map = MapsUtil.init_mapFromPointsArrayBASEDRIVE(globalMapOptions.pArray, globalMapOptions.pInferredArray, globalMapOptions.pMapPoint, pTarget, globalMapOptions.pIcons, globalMapOptions.pStrokeSetting, globalMapOptions.pInferredStrokeSettings);
        } else {
            $rootScope.tripEvent = eventType;
            $scope.tripEvents[eventType] = false;
            $("#" + pTarget).find(".ol-viewport").remove();
            var singleEventMapPoints = [];
            singleEventMapPoints.push(tempStart);
            singleEventMapPoints.push(tempStop);
            var temp = {};
            for (var i = 0; i < globalMapOptions.pMapPoint.length; i++) {
                temp = globalMapOptions.pMapPoint[i];
                if (temp.type == eventType) {
                    singleEventMapPoints.push(temp);
                }
            }
            map = MapsUtil.init_mapFromPointsArrayBASEDRIVE(globalMapOptions.pArray, globalMapOptions.pInferredArray, singleEventMapPoints, pTarget, globalMapOptions.pIcons, globalMapOptions.pStrokeSetting, globalMapOptions.pInferredStrokeSettings);
        }
    }

    function getTransportTypeIcon(transportTypeId) {
        var tripType = {};
        var imagePath = './client/images/transports/';
        var imageType = '.svg';

        for (var i = 0; i < tripTypesData.length; i++) {
            if (transportTypeId == tripTypesData[i].id) {
                tripType = tripTypesData[i];
                tripType.icon = imagePath + tripTypesData[i].name + imageType;
            }
        }
        return tripType;
    }
}
