angular.module('controllers')
    .controller('SettingsCtrl', SettingsCtrl);

function SettingsCtrl($rootScope, $scope, $state, HttpProxy, GlobalConstants, WebServiceUrls, SettingsServices, LoginServices, LocalStorage, LocalStorageKeys, WebServiceCache, CordovaBroadcaster, FileUtil, StringUtil, PopupUtil, $translate, $timeout, FirebaseService) {
    // SCOPE VARIABLES
    $scope.settings;
    $scope.useWifi;
    $scope.visibleLeaderboard;
    var settingsData = {};

    // SCOPE FUNCTIONS
    $scope.navigateTo = navigateTo;
    $scope.logout = logout;
    $scope.useWifiChanged = useWifiChanged;
    $scope.visibleLeaderboarChanged = visibleLeaderboarChanged;
    $scope.tripNotificationChanged = tripNotificationChanged;
    $scope.contestNotificationChanged = contestNotificationChanged;
    $scope.hbrAlertsChanged = hbrAlertsChanged;
    $scope.hacAlertsChanged = hacAlertsChanged;
    $scope.goToDebug = goToDebug;

    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    $scope.$on('$ionicView.enter', ionicViewEnter);

    // FUNCTIONS
    function ionicViewBeforeEnter() {
        $rootScope.activeMenuItem = "settings";

        SettingsServices.getUserSettings().then(function (settings) {
            $scope.settings = settings;
            LocalStorage.setObject(LocalStorageKeys.USER_APP_SETTINGS, settings);

            $scope.localSettings = LocalStorage.getObject(LocalStorageKeys.LOCAL_SETTINGS);

            setSwitches();
            getGitVersion();
        });
    }

    function goToDebug() {
        var btns = [{
                text: '<div>Confirm </div>',
                onTap: function (e) {
                    if (debug_pass.value == 'D3v0ps') {
                        $state.go("debugScreen");
                    }
                }
            },
            {
                text: '<div> Cancel</div>',
                onTap: function (e) {

                }
            }
        ];
        PopupUtil.showSimpleAlert('RESTRICTED', '<p>This section is restricted. Please enter password below :</p><p><input id="debug_pass" type="password"></input></p>', btns);
    }

    function ionicViewEnter() {
        $timeout(function () {
            $('.toggle-big').removeClass('toggle-small');
        }, 100);

        FirebaseService.logEvent("view_item", {
            item_name: "Configurações", 
            custom_dimension2: "Configurações",
            custom_dimension5: LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID) !== null ? "logged in" : "logged out"
        });
    }

    function setSwitches(pS, pL) {
        // Auto Start
        switch ($scope.settings.auto_start) {
            case "0":
                // Off
                $scope.autostart_label = "Off";
                break
            case "1":
                // On
                $scope.autostart_label = "On";
                break;
            case "2":
                // Only when plugged in
                $scope.autostart_label = "Only When Plugged In";
                break;
            default:
                // Off
                $scope.autostart_label = "Off";
                break
        }

        // Wifi
        switch ($scope.settings.use_phone_data) {
            case "0":
            case false:
                // Use WIFI
                $scope.useWifi = true;
                break;
            case "1":
            case true:
                // Use Phone Data
                $scope.useWifi = false;
                break;
        }

        // Visible in leaderboard
        switch ($scope.settings.visible_in_leaderboard) {
            case "0":
            case false:
                // Use WIFI
                $scope.visibleLeaderboard = false;
                break;
            case "1":
            case true:
                // Use Phone Data
                $scope.visibleLeaderboard = true;
                break;
        }

        if ($scope.localSettings) {
            //Trip Notification
            switch ($scope.localSettings.trip_push) {
                case "0":
                case false:
                    $scope.tripNotification = false;
                    break;
                case "1":
                case true:
                    $scope.tripNotification = true;
                    break;
            }

            //New Contest Notification
            switch ($scope.localSettings.contest_push) {
                case "0":
                case false:
                    $scope.contestNotification = false;
                    break;
                case "1":
                case true:
                    $scope.contestNotification = true;
                    break;
            }
            //Hard Braking Beep Alerts
            switch ($scope.localSettings.hbr_sound) {
                case "0":
                case false:
                    $scope.hbrAlerts = false;
                    break;
                case "1":
                case true:
                    $scope.hbrAlerts = true;
                    break;
            }

            //Hard Acceleration Beep Alerts
            switch ($scope.localSettings.hac_sound) {
                case "0":
                case false:
                    $scope.hacAlerts = false;
                    break;
                case "1":
                case true:
                    $scope.hacAlerts = true;
                    break;
            }
        }

        // Language
        $scope.language_label = $translate.instant('languagePickerLocale_' + $scope.settings.language);
    }


    /*
        NAME: navigateTo
        DESC: Navigate to specific screen.
    */
    function navigateTo(pRoute) {
        $state.go(pRoute);
    }

    /*
         NAME: logout
         DESC: Logsout account.
     */
    function logout() {

        FirebaseService.logEvent("select_content", {
            item_name: "Perfil", 
            content_type: "logout",
            custom_dimension1: LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID), 
            custom_dimension2: "Perfil",
            custom_dimension5: LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID) !== null ? "logged in" : "logged out"
        });
        
        LoginServices.logout().then(function () {

            // stopping the quote simulation on logout 
            $rootScope.quoteSimulatorObj = null;
            $scope.isSimulation = false;

            $state.go('login');
        });
    }

    /*
         NAME: saveSettings
         DESC: Saves user selected settings.
     */
    function saveSettings(pData) {
        SettingsServices.setUserSettings(pData).then(function (result) {
            WebServiceCache.cleanseCache(6);
            LocalStorage.setObject(LocalStorageKeys.USER_APP_SETTINGS, $scope.settings);
        }, function (error) {
            PopupUtil.showSimpleAlert($translate.instant('error'), $translate.instant(error['i18n-key']));
            console.log(error);
        });
    }

    /*
        NAME: useWifiChanged
        DESC: Triggers on change of wifi.
    */
    function useWifiChanged() {
        // Set new value
        if ($scope.useWifi) {
            $scope.useWifi = false;
            $scope.settings.use_phone_data = "1";
            CordovaBroadcaster.changeUseOnlyWifi(false);
        } else {
            $scope.useWifi = true;
            $scope.settings.use_phone_data = "0";
            CordovaBroadcaster.changeUseOnlyWifi(true);
        }
        settingsData = {
            use_phone_data: $scope.settings.use_phone_data
        };
        saveSettings(settingsData);
    }

    /*
        NAME: visibleLeaderboarChanged
        DESC: Triggers on change of wifi.
    */
    function visibleLeaderboarChanged() {
        if ($scope.visibleLeaderboard) {
            $scope.visibleLeaderboard = false;
            $scope.settings.visible_in_leaderboard = "0";
        } else {
            $scope.visibleLeaderboard = true;
            $scope.settings.visible_in_leaderboard = "1";
        }
        settingsData = {
            visible_in_leaderboard: $scope.settings.visible_in_leaderboard
        };
        saveSettings(settingsData);
    }

    /*
       NAME: tripNotificationChanged
       DESC: Triggers on change of trip notification option.
   */
    function tripNotificationChanged() {
        if ($scope.tripNotification || $scope.tripNotification == "1") {
            $scope.tripNotification = false;
            $scope.localSettings.trip_push = "0";
            CordovaBroadcaster.updateTripNotification(false);
        } else {
            $scope.tripNotification = true;
            $scope.localSettings.trip_push = "1";
            CordovaBroadcaster.updateTripNotification(true);
        }
        settingsData = {
            trip_push: $scope.localSettings.trip_push
        };
        updateCommSettings(settingsData);
    }

    /*
        NAME: contestNotificationChanged
        DESC: Triggers on change of contest notification option.
    */
    function contestNotificationChanged() {
        if ($scope.contestNotification || $scope.contestNotification == "1") {
            $scope.contestNotification = false;
            $scope.localSettings.contest_push = "0";
            CordovaBroadcaster.setContestNotification(false);
        } else {
            $scope.contestNotification = true;
            $scope.localSettings.contest_push = "1";
            CordovaBroadcaster.setContestNotification(true);
        }
        settingsData = {
            contest_push: $scope.localSettings.contest_push
        };
        updateCommSettings(settingsData);
    }

    /*
        NAME: hbrAlertsChanged
        DESC: Triggers on change of Braking option in settings.
    */
    function hbrAlertsChanged() {
        if ($scope.hbrAlerts || $scope.hbrAlerts == "1") {
            $scope.hbrAlerts = false;
            $scope.localSettings.hbr_sound = "0";
            CordovaBroadcaster.setHardBreakingBeep(false);
        } else {
            $scope.hbrAlerts = true;
            $scope.localSettings.hbr_sound = "1";
            CordovaBroadcaster.setHardBreakingBeep(true);
        }
        settingsData = {
            hbr_sound: $scope.localSettings.hbr_sound
        };
        updateCommSettings(settingsData);
    }

    /*
        NAME: hacAlertsChanged
        DESC: Triggers on change of Acceleration option in settings.
    */
    function hacAlertsChanged() {
        if ($scope.hacAlerts || $scope.hacAlerts == "1") {
            $scope.hacAlerts = false;
            $scope.localSettings.hac_sound = "0";
            CordovaBroadcaster.setHardAccelerationBeep(false);
        } else {
            $scope.hacAlerts = true;
            $scope.localSettings.hac_sound = "1";
            CordovaBroadcaster.setHardAccelerationBeep(true);
        }
        settingsData = {
            hac_sound: $scope.localSettings.hac_sound
        };
        updateCommSettings(settingsData);
    }

    /*
        NAME: updateCommSettings
        DESC: Updates modified setting data to server.
    */
    function updateCommSettings(pData) {
        SettingsServices.updateClientCommunicationConfig(pData).then(function (response) {
            LocalStorage.setObject(LocalStorageKeys.LOCAL_SETTINGS, $scope.localSettings);
        }, function error(error) {
            PopupUtil.showSimpleAlert($translate.instant('error'), $translate.instant(error['i18n-key']));
        });
    }

    function getGitVersion() {
        //        HttpProxy.get(GlobalConstants.BASE_URL + WebServiceUrls.GET_GIT_VERSION).then(onGitVersionSuccess, onGitVersionFail);
        var isBrowser = LocalStorage.get(LocalStorageKeys.IS_IN_BROWSER);
        if (isBrowser == "true") {
            $scope.appVersion = "N/A";
        } else {
            $scope.appVersion = LocalStorage.get(LocalStorageKeys.BUILD_NUMBER);
            if (!$scope.appVersion) {
                $scope.appVersion = "N/A";
            }
        }
    }

    //    function onGitVersionSuccess(pResponse) {
    //        var serverVersion = StringUtil.format("Branch : {0}, Revision : {1}", pResponse.data.branch, pResponse.data.version.substring(0, 7));
    //        displayGitVersion(serverVersion);
    //    }
    //
    //    function onGitVersionFail(pError) {
    //        var serverVersion = "Unable to reach " + WebServiceUrls.GET_GIT_VERSION;
    //        displayGitVersion(serverVersion);
    //    }
    //
    //
    //    function displayGitVersion(pGitServerVersion) {
    //        try {
    //            var infoFile = cordova.file.applicationDirectory;
    //            if (ionic.Platform.isIOS()) {
    //                infoFile = infoFile + 'www/';
    //            }
    //            var fileName = 'build.info';
    //            FileUtil.checkIfFileExist(infoFile, fileName)
    //                .then(function (response) {
    //                    FileUtil.readFile(infoFile, fileName)
    //                        .then(function (gitCommitCode) {
    //                            var text = "\n" + pGitServerVersion + "\n" + gitCommitCode;
    //                            var index = text.indexOf('Build version number') + 21;
    //                            var version = text.substring(index, text.length);
    //
    //                            $scope.appVersion = version;
    //                        });
    //
    //                }, function (error) {
    //                    $scope.appVersion = "N/A";
    //                });
    //        } catch (e) {
    //            // fake
    //            //            text = "Branch : release/2.1.2, Revision : d1b1b87\nAndroid code : c878dd7 on branch release\nIonic client code : 3a4e10f on branch develop\nIonic core hash tag ecadd5c\nBuild version number 2.1.2";
    //            //
    //            //            var index = text.indexOf('Build version number') + 21;
    //            //            var version = text.substring(index, text.length);
    //            //
    //            //            $scope.appVersion = version;
    //            ////////////////////////
    //            $scope.appVersion = "N/A";
    //        }
    //    }
}
