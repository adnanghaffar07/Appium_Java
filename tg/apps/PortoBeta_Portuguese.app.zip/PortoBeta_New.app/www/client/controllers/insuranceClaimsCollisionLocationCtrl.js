angular.module('controllers')
    .controller('InsuranceClaimsCollisionLocationCtrl', InsuranceClaimsCollisionLocationCtrl);

function InsuranceClaimsCollisionLocationCtrl($state, $rootScope, $scope,TripsServices,StringUtil,DateUtil,LoadingUtil,LoggerUtilType,PopupUtil,$translate) {
    // SCOPE FUNCTIONS
    $scope.goToSpecificLocation = goToSpecificLocation;
    //SCOPE VARIABLES

    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    // FUNCTIONS
    ////// Functionality when before entering into the view
    /*
        name : ionicViewBeforeEnter
        desc : will do the data binding to the scope before entering into the view
    */
    function ionicViewBeforeEnter() {
        LoadingUtil.showLoader();
        var today = new Date();
        var lastmonth = new Date().add(-1).month();
        TripsServices.getTrips(lastmonth, today, false).then(function (response) {
             var tripsData = [];
                for (var i = 0; i < response.data.trips.length; i++) {
                    var oneTrip = {
                       date: moment(StringUtil.getdateinformat(DateUtil.formatDateAsUTC(response.data.trips[i].date))).format('dddd MMMM D'),
                        time: moment(StringUtil.getdateinformat(DateUtil.formatDateAsUTC(response.data.trips[i].date))).format('h:mm a'),
                        id: response.data.trips[i].id,
                        distance: StringUtil.roundOfNumber(response.data.trips[i].distance,1)
                    };
                    tripsData.push(oneTrip);
                }
                $scope.locations = tripsData;
                LoadingUtil.hideLoader();
        }, function (error) {
            LoadingUtil.hideLoader();
            PopupUtil.showSimpleAlert($translate.instant('error'),$translate.instant(error.data['i18n-key']));
        });
    }
    
    ////// Function to navigate to specific screen.
    /*
        name : goToSpecificPage
        parameter:State value
        desc : It navigates to specific screen.
    */
    function goToSpecificLocation(id) {
        $state.go('app.insuranceClaimsLocationSelection', { tripid: id });
    }

}
