angular.module('controllers')
    .controller('InsuranceClaimsCollisionCtrl', InsuranceClaimsCollisionCtrl);

function InsuranceClaimsCollisionCtrl($state, $rootScope, $stateParams, $scope, PopupUtil, InsuranceServices, BooleanConstant, $translate, LoadingUtil) {
    // SCOPE FUNCTIONS
    $scope.goToSpecificPage = goToSpecificPage;
    $scope.submitClaim = submitClaim;
    $scope.goToClaimTypes = goToClaimTypes;
    //SCOPE VARIABLES
    $scope.pictures = BooleanConstant.BOOL_FALSE;
    $scope.location = BooleanConstant.BOOL_FALSE;
    $scope.position = BooleanConstant.BOOL_FALSE;
    $scope.form = BooleanConstant.BOOL_FALSE;
    $scope.formValid = BooleanConstant.BOOL_FALSE;

    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    $scope.$on('$ionicView.enter', ionicViewEnter);

    // Events

    // FUNCTIONS

    function ionicViewEnter() {
        
    }
    
    ////// Functionality when before entering into the view
    /*
        name : ionicViewBeforeEnter
        desc : will do the data binding to the scope before entering into the view
    */
    function ionicViewBeforeEnter() {
        $scope.claimType = $stateParams.claimType;
        if ($stateParams.location.length != "") {
            $rootScope.isLocationRequired = $stateParams.location;
        }
        if ($rootScope.isLocationRequired) {
            $scope.$watchGroup(['pictures', 'location', 'position', 'form'], validateFormIncludeLocation);
        } else {
            $scope.$watchGroup(['pictures', 'position', 'form'], validateFormExcludeLocation);
        }
        if (!angular.equals({}, $rootScope.claimDetails.pictures))
            if(Object.keys($rootScope.claimDetails.pictures).length==5)
            $scope.pictures = BooleanConstant.BOOL_TRUE;
        if (!angular.equals({}, $rootScope.claimDetails.position))
            $scope.position = BooleanConstant.BOOL_TRUE;
        if (!angular.equals({}, $rootScope.claimDetails.location) && $rootScope.isLocationRequired)
            $scope.location = BooleanConstant.BOOL_TRUE;
        if (!angular.equals({}, $rootScope.claimDetails.form))
            $scope.form = BooleanConstant.BOOL_TRUE;
    }

    ////// Function to navigate to specific screen.
    /*
        name : goToSpecificPage
        parameter:State value
        desc : It navigates to specific screen.
    */

    function goToSpecificPage(route) {
        $state.go(route);
    }

    /*
        name : submitClaim
        desc : Submit the claim with the claim data.
    */
    function submitClaim() {
        LoadingUtil.showLoader();
        var claimData = formatClaimsData($rootScope.claimDetails);
        InsuranceServices.submitClaim(claimData).then(function (response) {
            LoadingUtil.hideLoader();
            claimSubmittedSuccess();
        }, function (error) {
            LoadingUtil.hideLoader();
            PopupUtil.showSimpleAlert($translate.instant('error'), $translate.instant(error['i18n-key']));
        });
    }

    /*
        name : claimSubmittedSuccess
        desc : show success alert after submit the claim and redirect to list of claims screen when click on ok button
    */
    function claimSubmittedSuccess() {
        var buttons = [{
            text: '<span> ' + $translate.instant("common_OK") + ' </span>',
            onTap: function (e) {
                $state.go('app.insuranceClaims');
            }
        }];
        PopupUtil.showCustomPopupLocal("", "<img src='client/images/correct.png' style='height: 8vw;'/><h4>" + $translate.instant("claims_submitted") + " </h4>", buttons, "", true);
    }

    /*
        name : validateFormIncludeLocation
        desc : Validate the form input details and handle enable / disable the submit button.
        parameters : newvalues, oldvalues, scope
        response : It'll set the formvalid to true / false based on the input values
    */
    function validateFormIncludeLocation(newValues, oldValues, scope) {
        if (newValues[0] && newValues[1] && newValues[2] && newValues[3]) {
            $scope.formValid = BooleanConstant.BOOL_TRUE;
        } else {
            $scope.formValid = BooleanConstant.BOOL_FALSE;
        }
    }

    /*
        name : validateFormExcludeLocation
        desc : Validate the form input details and handle enable / disable the submit button.
        parameters : newvalues, oldvalues, scope
        response : It'll set the formvalid to true / false based on the input values
    */
    function validateFormExcludeLocation(newValues, oldValues, scope) {
        if (newValues[0] && newValues[1] && newValues[2]) {
            $scope.formValid = BooleanConstant.BOOL_TRUE;
        } else {
            $scope.formValid = BooleanConstant.BOOL_FALSE;
        }
    }
    /*
    name : formatClaimsData
    desc:Formats claims data according to format accepts by server.
     */
    function formatClaimsData(claimDetails) {
        var data = claimDetails;
        var vrresData = {};
        vrresData.longitude = data.position.longitude;
        vrresData.latitude = data.position.latitude;
        vrresData.trip_id = data.location.collidedtripid;
        vrresData.injured = data.form.injured;
        vrresData.involved = data.form.involved;
        vrresData.details = data.form.details;
        vrresData.occured = data.form.occured;
        vrresData.pictures = data.pictures;
        vrresData.vehicle_id = $rootScope.userVehicles[0].id;
        vrresData.claim_type_id = $rootScope.claimDetails.claim_id;
        return vrresData;
    }

    /*
        name : goToClaimTypes
        desc:Navigate to new claims screen when click on back button
    */
    function goToClaimTypes() {
        $state.go('app.insuranceNewClaim');
    }

}
