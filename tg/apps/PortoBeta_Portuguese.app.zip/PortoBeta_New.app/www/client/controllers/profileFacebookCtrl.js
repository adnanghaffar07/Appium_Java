angular.module('controllers')
    .controller('ProfileFacebookCtrl', ProfileFacebookCtrl);

function ProfileFacebookCtrl($rootScope, $scope, $state, $timeout, $ionicHistory, LocalStorage, LocalStorageKeys,BooleanConstant,SocialUserService,ProfileServices,PopupUtil,$translate,LoggerUtilType) {
    // SCOPE VARIABLES
    $scope.fbConnected = false;
    
    // SCOPE FUNCTIONS
    $scope.connectFacebook =connectFacebook;
    $scope.disconnectFacebook = disconnectFacebook;
    
    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    // FUNCTIONS
   /*
        name   :  ionicViewBeforeEnter  
        desc   :  Binding profile data to scope before entering.
    */
    function ionicViewBeforeEnter() {
        $scope.profileData = LocalStorage.getObject(LocalStorageKeys.PROFILE_DATA);
        var accesstoken = LocalStorage.get(LocalStorageKeys.FB_ACCESS_TOKEN,"");
        if(accesstoken.length > 0){
            connectFacebook();
        }
    }
    
    /*
        name   :  connectFacebook  
        desc   :  If fb access token is empty, then it opens facebook login screen
        else makes a call to method to get user data.
    */
    function connectFacebook() {
        // Do all the stuff for connecting user facebook account
        var accessToken = LocalStorage.get(LocalStorageKeys.FB_ACCESS_TOKEN);
        if (accessToken && accessToken !== "null") {
            getFacebookUserMeta(accessToken);

        } else {
            SocialUserService.loginFacebookOAuth().then(function (response) {
                getFacebookUserMeta(response.access_token);
            }, function (error) {

            });
        }
    }
    
    /*
       NAME : getFacebookUserMeta
       DESC : Gets user data based on obtained access token.
   */
    function getFacebookUserMeta(accessToken) {
        LocalStorage.set(LocalStorageKeys.FB_ACCESS_TOKEN, accessToken);
        SocialUserService.getFacebookUserData(accessToken).then(function (response) {
            linkFacebook(accessToken,response.id,response);
        }, function (error) {
            LocalStorage.set(LocalStorageKeys.FB_ACCESS_TOKEN, null);
            return false;
        });
    }
    
   /*
       NAME : linkFacebook
       DESC : Links with facebook, to identify users those are linked with Facebook.
   */
    function linkFacebook(accessToken, fbUid,userdata){
        ProfileServices.linkFacebookProfile(accessToken,fbUid).then(function(response){
                  fbconnectedas(accessToken,userdata);                 
                },function(error){
                   //fbconnectedas("234","Jonathan Smith"); 
                    PopupUtil.showSimpleAlert($translate.instant('error'), $translate.instant(error['i18n-key']));
                });
    }
    
   /*
       NAME : fbconnectedas
       DESC : Displays connected with facebook field and holds user token in local storage.
   */
    function fbconnectedas(token,userData){
        $scope.fbConnected = true;
        $scope.profileData.user.fb_name=userData.name;
        $scope.profileData.fbUid=userData.id;
        LocalStorage.set(LocalStorageKeys.FB_ACCESS_TOKEN,token);
    }
    
   /*
       NAME : disconnectFacebook
       DESC : Call to server to disconnect with facebook.
   */
    function disconnectFacebook() {
        // Do all the stuff for disconnecting the connected facebook.
        LocalStorage.set(LocalStorageKeys.FB_ACCESS_TOKEN,"");
        $scope.profileData.user.fb_name="";
        $scope.profileData.fbUid="";
        ProfileServices.disconnectFacebook().then(function(response){
        $scope.fbConnected = false;
            },function(error){
        //
         PopupUtil.showSimpleAlert($translate.instant('error'), $translate.instant(error['i18n-key']));
        $scope.fbConnected = false;
        });
    }
}
