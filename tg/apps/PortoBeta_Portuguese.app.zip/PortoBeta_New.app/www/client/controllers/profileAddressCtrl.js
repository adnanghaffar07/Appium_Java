angular.module('controllers')
    .controller('ProfileAddressCtrl', ProfileAddressCtrl);

function ProfileAddressCtrl($rootScope, $scope, $state, $timeout, $ionicHistory, LocalStorage, LocalStorageKeys,BooleanConstant, ProfileServices, $filter, CountryName, $translate, PopupUtil) {
    
    // SCOPE VARIABLES
    var statesList = [];
    
    // SCOPE FUNCTIONS
    $scope.saveProfile = saveProfile;
    $scope.goToSelectState = goToSelectState;
    
    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    // FUNCTIONS
    /*
        name:ionicViewBeforeEnter
        desc: Populate the profile data in corresponding fields
    */ 
    function ionicViewBeforeEnter() {
      
        var vrSelectedVal = $rootScope.selectedValue;
        if (angular.isDefined(vrSelectedVal) && vrSelectedVal !== null) {
            $rootScope.selectedValue =null;
            if (angular.isUndefined($scope.profileData.Address))
            $scope.profileData.Address = {};
            $scope.profileData.Address.state = vrSelectedVal;
        }else{
        $scope.profileData = LocalStorage.getObject(LocalStorageKeys.PROFILE_DATA);      
        }
    }
    
    // Webservice call to get list of states.
    /*
        desc : fetching the list of states
    */
    ProfileServices.getStatesList(CountryName.USA).then(function(response) {
        statesList = $filter('orderBy')(response, 'name');
        var states = [];
        for(var i=0; i<statesList.length ; i++){
            states.push(statesList[i].name);
        }
        statesList = states;
    }, function(error) {
        PopupUtil.showSimpleAlert($translate.instant('error'),$translate.instant(error['i18n-key']));
    });
    
    /*
        name:saveProfile
        desc: Store the data to be saved in database in rootscope.
              Storing the details in local storage.
    */ 
    function saveProfile() {
        $rootScope.needToSaveProfile = BooleanConstant.BOOL_TRUE;
        LocalStorage.setObject(LocalStorageKeys.PROFILE_DATA, $scope.profileData);
        $ionicHistory.goBack();
    }
    
    /*
        name:goToSelectState
        desc : go to select state details screen with list of states 
    */
    function goToSelectState(){
        $state.go('app.selectInfo', { 'list': statesList });
    }
}
