angular.module('controllers')
    .controller('RequestActivationCodeCtrl', RequestActivationCodeCtrl);

function RequestActivationCodeCtrl($scope, $state, $q, HttpProxy, $timeout, LocalStorage, GlobalConstants, $translate, ValidationUtil, LoadingUtil, CordovaBroadcaster) {
    $scope.formValid = false;
    $scope.showForm = true;
    $scope.showThankyou = false;
    $scope.request = {};

    $scope.emailChanged = emailChanged;
    $scope.firstnameChanged = firstnameChanged;
    $scope.lastnameChanged = lastnameChanged;
    $scope.sendRequest = sendRequest;
    $scope.closeApplication = closeApplication;

    /*
        Name : emailChanged
        Desc : Raise event when a key is typed into Email field
    */
    function emailChanged() {
        isFormValid();
    }

    /*
        Name : firstNameChanged
        Desc : Raise event when a key is types in First Name field
    */
    function firstnameChanged() {
        isFormValid();
    }

    /*
        Name : lastNameChanged
        Desc : Raise event when a key is typed in Last Name field
    */
    function lastnameChanged() {
        isFormValid();
    }

    /*
        Name : isFormValid
        Desc : Validate form information. Rules : Must have a name, last name and the email must be in a valid format.
    */
    function isFormValid() {
        if (!angular.isUndefined($scope.request.firstname) && $scope.request.firstname != "" && !angular.isUndefined($scope.request.lastname) && $scope.request.lastame != "" && !angular.isUndefined($scope.request.email) && $scope.request.email != "") {
            if (ValidationUtil.validateEmail($scope.request.email)) {
                $scope.formValid = true;
            } else {
                $scope.formValid = false;
            }
        } else {
            $scope.formValid = false;
        }
    }

    /*
        Name : sendRequest
        Desc : Hide screen content and call createZendeskTicket function
    */
    function sendRequest() {
        $scope.showForm = false;
        LoadingUtil.showLoader();
        createZendeskTicket().then(function (response) {
            // Success
            LoadingUtil.hideLoader();
            $scope.showThankyou = true;
            $timeout(function () {
                closeApplication();
            }, 3000);
        });
    }

    /*
        Name : createZendeskTicket
        Desc : Call Zendesk API to create a ticket with following information Name, Lastname, Email
    */
    function createZendeskTicket() {
        LocalStorage.set('ZENDESK_TOKEN', "ZGhpbnNlQGJhc2VsaW5ldGVsZW1hdGljcy5jb20vdG9rZW46ZDRuQ2I1ZzJtck45WlNZUm5naUozcXl1S0x1ZjNkZExVUEFtcURYeQ==");
        var q = $q.defer();
        var jsonParams = {
            "ticket": {
                "subject": "Testdrive app - activation request",
                "comment": {
                    "body": "A new activation request from " + $scope.request.firstname + " " + $scope.request.lastname + ", " + $scope.request.email
                },
                "priority": "urgent"
            }
        }
        HttpProxy.post(GlobalConstants.ZENDESK_API + "/tickets.json", jsonParams).then(function (response) {
            // Success
            q.resolve(response);
        });

        return q.promise;
    }

    /*
        Name : closeApplication
        Desc : Send a Native Intent to force closing of the application.
    */
    function closeApplication() {
        LocalStorage.clear("requestedCode");
        CordovaBroadcaster.exitApp();
    }
}
