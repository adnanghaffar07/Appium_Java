angular.module('controllers')
    .controller('OnboardingCtrl', OnboardingCtrl);

function OnboardingCtrl($state, $rootScope, $scope, LocalStorage, $translate, LocalStorageKeys, GlobalConstants, FirebaseService) {
    $scope.startClicked = startClicked;

    $scope.$on('$ionicView.loaded', ionicViewLoaded);
    $scope.onSlideChanged = onSlideChanged;

    $scope.completed = false;

    function ionicViewLoaded() {
        FirebaseService.logEvent("tutorial_begin", {
            content_type: "tutorial",
            item_name: "Tutorial", 
            custom_dimension1: LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID), 
            custom_dimension2: "Tutorial",
            custom_dimension5: LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID) !== null ? "logged in" : "logged out"
        });
    }

    $scope.options = {
        loop: false,
        effect: 'fade',
        speed: 500
    }

    function startClicked() {
        // Get Setting Object
        var settingsObj = LocalStorage.getObject(SHA512(GlobalConstants.BASE_URL + "/getSettings"));

        var menuItems = LocalStorage.getObject(LocalStorageKeys.MENU_ITEMS);

        $state.go(menuItems[0].state);
    }

    function onSlideChanged(i) {
        FirebaseService.logEvent("view_item", {
            item_name: "Tutorial - Passo " + (i+1), 
            custom_dimension2: "Tutorial",
            custom_dimension5: LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID) !== null ? "logged in" : "logged out"
        });

        if ( (i+1) === 5 && $scope.completed === false) {

            $scope.completed = true;

            FirebaseService.logEvent("tutorial_complete", {
                content_type: "tutorial",
                item_name: "Tutorial", 
                custom_dimension1: LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID), 
                custom_dimension2: "Tutorial",
                custom_dimension5: LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID) !== null ? "logged in" : "logged out"
            });
        }
    }
}
