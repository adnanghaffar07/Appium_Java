angular.module('controllers')
    .controller('InsurancePolicyCtrl', InsurancePolicyCtrl);
function InsurancePolicyCtrl($rootScope, $state, $scope) {
    // SCOPE VARIABLES
    // --> All scope variables that are specific to that view will be defined here
   
    // SCOPE FUNCTIONS
    // --> All scope functions specific to that view are defined here
    
    // SCOPE LIFE CYCLE
    // --> All needed life cycle events specific to that view are defined here. Note that we do not write the function directly in it.
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    $scope.$on('$ionicView.enter', ionicViewEnter);
 
    // FUNCTIONS
    /* 
        name : ionicViewBeforeEnter
        desc : Will call web services and prepare an object for the screen
    */
    function ionicViewBeforeEnter() {
         
    }
    
    function ionicViewEnter() {
        
    }
}