angular.module('controllers')
    .controller('DashboardPortoCtrl', DashboardPortoCtrl);

function DashboardPortoCtrl($state, $scope, $rootScope, $ionicHistory, $translate, $timeout, $ionicSlideBoxDelegate, GamingServices, ScoresServices, GlobalConstants, DateUtil, StringUtil, LoadingUtil, CircleProgressUtil, LocalStorage, LocalStorageKeys, FirebaseService) {
    // Scope functions
    $scope.changeTab = changeTab;
    $scope.slideHasChanged = slideHasChanged;
    $scope.goToGaq = goToGaq;
    $scope.goToCoins = goToCoins;
    $scope.goToRanking = goToRanking;
    $scope.goToMissions = goToMissions;
    $scope.goToBadges = goToBadges;
    //    $scope.goToBadges = goToBadges;
    //    $scope.goToGaq = goToGaq;

    // Scope Variables
    $rootScope.activeMenuItem = "dashboard";
    $scope.selectedTab = 'lastTrip';
    $scope.achievementsAvailable = false;
    $scope.circle_size = Math.round($(window).width() / 2);
    console.log("CIRCLE SIZE", $scope.circle_size);
    $scope.circle_fontsize = Math.round($scope.circle_size / 2.5);
    $scope.hac = 0;
    $scope.hbr = 0;
    $scope.hco = 0;
    $scope.spd = 0;
    $scope.txt = null;
    $scope.scoreDetails = 0;
    $scope.user_achievements = 0;
    $scope.user_badges = 0;
    $scope.community_badges = 0;
    $scope.community_achievments = 0;
    $scope.settingsObj = LocalStorage.getObject(SHA512(GlobalConstants.BASE_URL + "/getSettings"));
    $scope.coinsTotal = null;
    $scope.currentDistance = 0;

    $scope.firstThisYear = true;

    $ionicHistory.clearHistory();
    $ionicHistory.clearCache();

    $scope.$on('$ionicView.loaded', ionicViewLoaded);

    $scope.changeTab = changeTab;

    function ionicViewLoaded() {

        // force colors changed
        $scope.user_id = LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID);

        ScoresServices.getOverallDrivingScores(getScoresCallback);
        getDashboardGamingInfo();
        loadCoinsTotal();

        $scope.themeColors = LocalStorage.getObject(LocalStorageKeys.THEME_COLORS);

    }

    function changeTab(p) {
        $scope.selectedTab = p;
    }

    function loadCoinsTotal() {
        
        GamingServices.getCoinsTotal().then(function (response) {
            $scope.coinsTotal = response.coins.value;
        }, function (error) {
            console.log('ERROR', error);
        });
    }

    /*
        Name : getScoresCallback
        Param: pScoresData -> Score object formated to fit our needs
        Description: Calls a series of function to get score info and format to a specific format.
    */
    function getScoresCallback(pScoresData) {

        if (pScoresData && pScoresData.global.score === -1) {
            $scope.firstThisYear = true;
        } else if (pScoresData && pScoresData.global.score > 0) {
            $scope.firstThisYear = false;
        }

        console.log("##### SCORES DATA #####", pScoresData);
        console.log(JSON.stringify($scope.profileImage));
        $scope.scoresData = pScoresData;
        $scope.hac = pScoresData.lastTrip.hac;
        $scope.hbr = pScoresData.lastTrip.hbr;
        $scope.hco = pScoresData.lastTrip.hco;
        $scope.spd = pScoresData.lastTrip.spd;
        $scope.txt = pScoresData.lastTrip.dd;
        $scope.currentDistance = pScoresData.lastTrip.distance;

        slideHasChanged();

        var container = '#last-trip .show-score .score';
        var score = pScoresData.lastTrip.score;
        var of_date = $translate.instant('time_of');
        $scope.lastTripDate = moment(DateUtil.formatDateAsUTC(StringUtil.getdateinformat(pScoresData.lastTrip.endTime))).format("dddd, D ["+ of_date + "] MMMM ["+ of_date + "] YYYY");
        $scope.scoreDetails = score;

        var creationDate = moment(LocalStorage.get(LocalStorageKeys.PROFILE_CREATION_DATE));

        if (creationDate.diff(moment(), 'days') > 365) {
            $scope.thisYearDatesRange = moment().subtract(365, 'days').format('MMMM YYYY') + ' - ' + $translate.instant('presentText');
        } else {
            $scope.thisYearDatesRange = creationDate.format('MMM D, YYYY') + ' - ' + $translate.instant('presentText');
        }

        $timeout(function () {
            LoadingUtil.hideLoader();
            $(container).addClass('loaded');
            initCircle(container, score);
            $('.page-hider').fadeOut('fast');
        }, 500);

        if ($scope.scoreDetails !== -1 && $scope.scoreDetails !== 0) {

            FirebaseService.logEvent("view_item", {
                item_name: 'Painel - Última viagem', 
                custom_dimension1: LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID), 
                custom_dimension2: "Painel",
                custom_dimension5: LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID) !== null ? "logged in" : "logged out",
                custom_dimension8: $scope.scoreDetails,
                custom_dimension9: $scope.hac,
                custom_dimension10: $scope.hbr,
                custom_dimension11: $scope.hco,
                custom_dimension12: $scope.spd,
                custom_dimension13: $scope.txt
            });
        }
    }

    /*
        Name: getDashboardGamingInfo
        Desc: Call web service to get all gaming information for dashboard
    */
    function getDashboardGamingInfo() {
        GamingServices.getDashboardGamingData().then(function (response) {
            console.log("success", response);
            $scope.gamingData = response;
        }, function (response) {
            console.log("ERROR", response);
        });
    }

    /*
        Name: initCircle
        Desc: Initialize te progress circle animation
        Param: pE (Element), pV (Value)
    */
    function initCircle(pE, pV) {
        //CircleProgressUtil.init_DefaultCircle(pE, pV, $scope.circle_size, $scope.themeColors.lightBackground, 12);
    }

    /*
        Name: changeTab
        Desc: Use de slidebox delegate to force sliding to a given index.
        Param: pI
    */
    function changeTab(pI) {
        $ionicSlideBoxDelegate.$getByHandle('scoresSlider').slide(pI);
    }

    /*
        Name: slideHasChanged
        Desc: Handles sliding event. Updates the view after slide.
        Param: pI, pScoreData
    */
    function slideHasChanged(pI, pScoreData) {

        var container = null;
        var score = null;
        var firebaseLabel = "";

        if (pScoreData && pScoreData.global.score === -1) {
            $scope.firstThisYear = true;
        } else if (pScoreData && pScoreData.global.score > 0) {
            $scope.firstThisYear = false;
        }

        $scope.lastWeekDatesRange = moment().subtract(7, "days").format("MMM D") + ' - ' + moment().subtract(0, "days").format("MMM D, YYYY");
        $scope.lastMonthDatesRange = moment().subtract(1, "month").format("MMM D") + ' - ' + moment().subtract(0, "days").format("MMM D, YYYY");

        switch (pI) {
            case 0:
                $scope.selectedTab = 'lastTrip';
                $scope.hac = pScoreData.lastTrip.hac > 0 ? pScoreData.lastTrip.hac : 0;
                $scope.hbr = pScoreData.lastTrip.hbr > 0 ? pScoreData.lastTrip.hbr : 0;
                $scope.hco = pScoreData.lastTrip.hco > 0 ? pScoreData.lastTrip.hco : 0;
                $scope.spd = pScoreData.lastTrip.spd > 0 ? pScoreData.lastTrip.spd : 0;
                $scope.txt = (pScoreData.lastTrip && pScoreData.lastTrip.dd) > 0 ? pScoreData.lastTrip.dd : 0;
                container = '#last-trip .show-score .score';
                score = pScoreData.lastTrip.score;
                $scope.scoreDetails = score;
                firebaseLabel = "Painel - Última viagem";
                $scope.currentDistance = pScoreData.lastTrip.distance;

                break;
            case 1:
                $scope.selectedTab = 'lastWeek';
                $scope.hac = pScoreData.lastWeek.hac > 0 ? pScoreData.lastWeek.hac : 0;
                $scope.hbr = pScoreData.lastWeek.hbr > 0 ? pScoreData.lastWeek.hbr : 0;
                $scope.hco = pScoreData.lastWeek.hco > 0 ? pScoreData.lastWeek.hco : 0;
                $scope.spd = pScoreData.lastWeek.spd > 0 ? pScoreData.lastWeek.spd : 0;
                $scope.txt = (pScoreData.lastWeek && pScoreData.lastWeek.dd) > 0 ? pScoreData.lastWeek.dd : 0;

                container = '#last-week .show-score .score';
                score = pScoreData.lastWeek.score;
                $scope.scoreDetails = score;
                firebaseLabel = "Painel - Semana";
                $scope.currentDistance = pScoreData.lastWeek.distance;

                break;
            case 2:
                $scope.selectedTab = 'lastMonth';
                $scope.hac = pScoreData.lastMonth.hac > 0 ? pScoreData.lastMonth.hac : 0;
                $scope.hbr = pScoreData.lastMonth.hbr > 0 ? pScoreData.lastMonth.hbr : 0;
                $scope.hco = pScoreData.lastMonth.hco > 0 ? pScoreData.lastMonth.hco : 0;
                $scope.spd = pScoreData.lastMonth.spd > 0 ? pScoreData.lastMonth.spd : 0;
                $scope.txt = (pScoreData.lastMonth && pScoreData.lastMonth.dd) > 0 ? pScoreData.lastMonth.dd : 0;

                container = '#last-month .show-score .score';
                score = pScoreData.lastMonth.score;
                $scope.scoreDetails = score;
                firebaseLabel = "Painel - Mês";
                $scope.currentDistance = pScoreData.lastMonth.distance;

                break;
            case 3:
                $scope.selectedTab = 'thisYear';
                $scope.hac = pScoreData.global.hac > 0 ? pScoreData.global.hac : 0;
                $scope.hbr = pScoreData.global.hbr > 0 ? pScoreData.global.hbr : 0;
                $scope.hco = pScoreData.global.hco > 0 ? pScoreData.global.hco : 0;
                $scope.spd = pScoreData.global.spd > 0 ? pScoreData.global.spd : 0;
                $scope.txt = (pScoreData.global && pScoreData.global.dd) ? pScoreData.global.dd : 0;
                container = '#this-year .show-score .score';
                score = pScoreData.global.score;
                $scope.scoreDetails = score;
                firebaseLabel = "Painel - Este ano";
                $scope.currentDistance = pScoreData.global.distance;

                break;
        }

        if (!$(container).hasClass('loaded')) {
            $(container).addClass('loaded');
            initCircle(container, score);
        }

        if ($scope.scoreDetails !== -1 && $scope.scoreDetails !== 0) {
            FirebaseService.logEvent("view_item", {
                item_name: firebaseLabel, 
                custom_dimension1: LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID), 
                custom_dimension2: "Painel",
                custom_dimension5: LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID) !== null ? "logged in" : "logged out",
                custom_dimension8: $scope.scoreDetails,
                custom_dimension9: $scope.hac,
                custom_dimension10: $scope.hbr,
                custom_dimension11: $scope.hco,
                custom_dimension12: $scope.spd,
                custom_dimension13: $scope.txt
            });
        }

    }

    /*
        Name : goToGaq
        Desc : Redirect to the GAQ Process
    */
    function goToGaq() {
        /*
            GET INFORMATION FOR USER ID AND USER EXTERNAL ID AND BUILD THE URL FOR THE GAQ PROCESS
        */

        var pd = LocalStorage.getObject(LocalStorageKeys.PROFILE_DATA);
        var gaq_url = $scope.settingsObj.data.AppSetting.get_a_quote_url + "?internal_id=" + pd.user.id;
        

        FirebaseService.logEvent("select_content", {
            content_type: "panel_quotation",
            item_name: 'Painel', 
            custom_dimension2: "Painel",
            custom_dimension5: LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID) !== null ? "logged in" : "logged out"
        });

        // window.open(gaq_url, "_system");

        try {
            if (cordova) {
                cordova.InAppBrowser.open(gaq_url, '_blank', 'location=yes');
            }
        } catch(e) {
            console.log(gaq_url);
            console.log(e);
        }
    }

    /*
        Name : goToCoins
        Desc : RRedirect to coins screen
    */
    function goToCoins() {

        FirebaseService.logEvent("select_content", {
            content_type: "panel_ranking",
            item_name: 'Painel', 
            custom_dimension2: "Painel",
            custom_dimension5: LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID) !== null ? "logged in" : "logged out"
        });

        $state.go('app.coins');
    }

    function goToRanking() {

        FirebaseService.logEvent("select_content", {
            content_type: "panel_coins",
            item_name: 'Painel', 
            custom_dimension2: "Painel",
            custom_dimension5: LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID) !== null ? "logged in" : "logged out"
        });
        
        $state.go('app.leaderboard');
    }

    $scope.totalRecalc = function(total) {

        if (total > 999) {
            total = (total / 1000) + 'k';
        }

        return total;
    }

    function goToMissions() {
        $state.go('app.missions');
    }

    function goToBadges() {
        $state.go('app.badges');
    }
}
