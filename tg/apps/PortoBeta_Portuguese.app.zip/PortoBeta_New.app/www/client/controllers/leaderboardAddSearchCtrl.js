angular.module('controllers')
    .controller('LeaderboardAddSearchCtrl', LeaderboardAddSearchCtrl);

function LeaderboardAddSearchCtrl($state, $rootScope, $scope, $ionicHistory, PopupUtil, GamingServices, $translate, $state, LoadingUtil)  {
  
  $scope.friendsList = [];
  $scope.contentHeight = $(window).height() - $('.bar-header').height() - $('section#selector').height() - 50;
  $scope.friendsSearched = false;

  $scope.newFriend = function(id, name, username) {

    if (!name) {
      name = username;
    }

    PopupUtil.confirmPopup($translate.instant('add_user_title'), $translate.instant('add_user_description_question').replace('@user', name), function(res) {
        if(res) {
            $scope.addFriend(id);
        }
    });
  }

  $scope.addFriend = function(id) {
      LoadingUtil.showLoader();

      GamingServices.addFriend({id: id}).then(function (response) {
          
          LoadingUtil.hideLoader();
          $("#txtSearch").val("");
          $scope.friendsList = [];

          setTimeout(function() {
            $state.go('app.leaderboard');
          }, 100);

          //goes to list of friends (go back history)
      }, function (error) {
          LoadingUtil.hideLoader();
          console.log (error);
      });
  }

  $scope.searchUpdated = function($event) {

    $scope.friendsSearched = false;  

    if ($event.currentTarget.value.length > 4) {
      $scope.search($event.currentTarget.value);
    } else {
      $scope.friendsList = [];
    }
  }

  $scope.search = function(q) {

    LoadingUtil.showLoader();

    GamingServices.searchFriends({q: q}).then(function (response) {
        
        LoadingUtil.hideLoader();

        $scope.friendsList = response.friends;

        if (response.friends.length === 0) {
          $scope.friendsSearched = true;  
        }

        //goes to list of friends (go back history)
    }, function (error) {

        LoadingUtil.hideLoader();
        $scope.friendsSearched = true;

        console.log (error);
    });
  }

  $scope.formatDate = function(mask, date) {

    if (!mask || !date) {
      return '';
    }

    return moment(date).format(mask);
  }



}
