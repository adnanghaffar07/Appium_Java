angular.module('controllers')
    .controller('FaqCtrl', FaqCtrl);

function FaqCtrl($state, $scope, $rootScope, $translate, FaqPlaceholderService, AppDocuments, $sce, PopupUtil, LoggerUtilType, LocalStorage, FirebaseService, LocalStorageKeys, GlobalConstants, WebServiceUrls) {

    var imagePath = "./client/images/faq-icons/";
    var imageType = ".png";

    // SCOPE VARIABLES
    // --> All scope variables that are specific to that view will be defined here
    $rootScope.activeMenuItem = "faq";

    // SCOPE FUNCTIONS
    // --> All scope functions specific to that view are defined here
    $scope.goToCategory = goToCategory;
    $scope.goToReportProblem = goToReportProblem;

    // SCOPE LIFE CYCLE
    // --> All needed life cycle events specific to that view are defined here. Note that we do not write the function directly in it.
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    $scope.$on('$ionicView.enter', ionicViewEnter);

    function ionicViewEnter() {
        FirebaseService.logEvent("view_item", {
            item_name: "Perguntas frequentes",
            custom_dimension2: "Perguntas frequentes",
            custom_dimension5: LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID) !== null ? "logged in" : "logged out"
        });
    }

    $scope.faqCategories = [];

    // FUNCTIONS
    /* 
        name : ionicViewBeforeEnter
        desc : Will call web services and prepare an object for the screen
    */
    function ionicViewBeforeEnter() {
        console.log('aqui');
        FaqPlaceholderService.get(GlobalConstants.BASE_URL + WebServiceUrls.GET_FAQS).then(function (response) {
            console.log('AppDocumentServices', response);
            $scope.faqCategories = response.data;
        });
    }

    /*
        
        NAME: goToCategory
        DESC: Retrieve the clicked category and redirect the user to the list of articles in that category.
        @PARAMS: fc --> A Category Object
    */
    function goToCategory(category) {
        console.log('goToCategory', category);
        $state.go('app.faqCategory', {
            category: category
        });
    }

    function goToReportProblem() {
        console.log('goToReportProblem');
        $state.go('app.settingsReportProblem');
    }

}
