angular.module('controllers')
    .controller('ProfileVehicleInfoCtrl', ProfileVehicleInfoCtrl);

function ProfileVehicleInfoCtrl($rootScope, $scope, $state, $timeout, $ionicHistory, LocalStorage, LocalStorageKeys, BooleanConstant, ProfileServices, BarcodeScannerUtil, LoadingUtil,PopupUtil,LoggerUtilType,$translate) {
    // SCOPE VARIABLES
    $scope.vehicle = [];
    $scope.errors = {};
    
    // SCOPE FUNCTIONS
    $scope.saveProfile = saveProfile;
    $scope.scanVinNumber = scanVinNumber;
    
    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    // FUNCTIONS
    function ionicViewBeforeEnter() {
        ////// Code to popluate the vehicle details after selecting the item in select screen / Populate the saved vehicle details 
        if ($scope.profileData && $scope.profileData.cars && angular.isDefined($scope.profileData.cars[0])) {
            $scope.vehicle = $scope.profileData.cars[0];
        }
    }
    
   /* 
        name : saveProfile
        desc : Confirms is vin valid and saves data.
    */
    function saveProfile() {
        getVehicleInfoByVin($scope.vehicle.vin);
    }
    
   /* 
        name : scanVinNumber
        desc : Scans VIN number and gets vin number.
    */ 
    function scanVinNumber() {
        LoadingUtil.showLoader();
        BarcodeScannerUtil.sacnBarCode().then(function (barCodeData) {
            LoadingUtil.hideLoader();
            if (barCodeData.cancelled == false && barCodeData.format == "CODE_39") {
                var vin = barCodeData.text
                $scope.vehicle.vin = vin;
                $scope.scannedvin = true;
                getVehicleInfoByVin(vin);
            } else {
                LoadingUtil.hideLoader();
                //error - unable to scan
            }
        }, function (error) {
            LoadingUtil.hideLoader();
            //error - unable to scan
        });
    }

   /* 
        name : getVehicleInfoByVin
        desc : gets vehicle info based on vin number.
    */ 
    function getVehicleInfoByVin(vin) {
        if (vin == '' || vin == null) {
            $scope.errors.vin = true;
            return;
        }
        $scope.errors.vin = false;
        LoadingUtil.showLoader();
        ProfileServices.getVehicleInfoByVIN(vin).then(function (response) {

            $scope.vehicle.vin = vin;
            if(!$scope.scannedvin){
                saveVehicleProfile();
            }
            
            LoadingUtil.hideLoader();
            $scope.scannedvin=false;

            // if (response.status != "fail") {
            //     $scope.vehicle = response[0];
            //     $scope.vehicle.vin = vin;
            //     if(!$scope.scannedvin){
            //     saveVehicleProfile();
            //     }
            //     LoadingUtil.hideLoader();
            //     $scope.scannedvin=false;
            // } else {
            //     //error - scan failed
            //     LoadingUtil.hideLoader();
            //      PopupUtil.showSimpleAlert($translate.instant('Error'), $translate.instant('vin_not_found'));
            // }
        }, function (error) {
            LoadingUtil.hideLoader();
            $scope.vehicle.vin = vin;
            PopupUtil.showSimpleAlert($translate.instant('Error'),$translate.instant(error.data["i18n-key"]));
            //error - VIN-not found in vinDB
        });
    }
    
       /* 
        name : saveVehicleProfile
        desc : save vehicle profile and redirect the user to settings screen.
    */ 
    function saveVehicleProfile(){
        ProfileServices.setVehicleProfile($scope.vehicle).then(function (response) {
            console.log(response);
            LoadingUtil.hideLoader();
        }, function (error) {
            LoadingUtil.hideLoader();
            //error
        });
        $scope.profileData.cars[0] = $scope.vehicle;
        LocalStorage.setObject(LocalStorageKeys.PROFILE_DATA, $scope.profileData);
        $ionicHistory.goBack();
    }
}
