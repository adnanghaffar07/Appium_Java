angular.module('controllers')
    .controller('QuoteDriversCtrl', QuoteDriversCtrl);
function QuoteDriversCtrl($rootScope, $state, $scope, QuoteStatus) {
    
    // SCOPE VARIABLES
    // --> All scope variables that are specific to that view will be defined here
    //$rootScope.quoteData.drivers={};
    $scope.drivers = $rootScope.quoteData.drivers;
    $scope.disableContinue = false;
    $scope.primaryDriverDOB = moment($rootScope.quoteData.user.date_of_birth).format('YYYY-MM-DD');
    $scope.dobDisplay = $scope.formatDate($scope.primaryDriverDOB);
    $scope.driverData = {
        primaryDriver : null
    }

    // SCOPE FUNCTIONS
    // --> All scope functions specific to that view are defined here
    $scope.goNextStep = goNextStep;

    // SCOPE LIFE CYCLE
    // --> All needed life cycle events specific to that view are defined here. Note that we do not write the function directly in it.
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    $scope.$on('$ionicView.enter', ionicViewEnter);
    
    // FUNCTIONS
    /* 
        name : ionicViewBeforeEnter
        desc : Will call web services and prepare an object for the screen
    */
    
    ////// Functionality when before entering into the view
    /* 
        name : ionicViewBeforeEnter
        desc : It will set the step number to handle the current step in before entering into the view. 
    */
    function ionicViewBeforeEnter() {
        $scope.drivers = $rootScope.quoteData.drivers;
        if ($rootScope.steps.drivers.length == 0) {
            //$scope.disableContinue = true;
            $rootScope.steps.drivers = QuoteStatus.PROCESS;
        } else {
            //$scope.disableContinue = false;
        }
        if ($rootScope.quoteData.drivers[0].license){
            $scope.disableContinue = false;
        }else{
            $scope.disableContinue = true;
        }
        if ($scope.drivers.length == 1 && !$scope.disableContinue) {
            $scope.driverData.primaryDriver = 1;
        } else {
            $scope.driverData.primaryDriver = null;
        }
    }

    ////// Functionality when entering into the view
    function ionicViewEnter() {
        $scope.navigateTo(3);
    }
    
    ////// Function to go to Final details screen
    /* 
        name : ionicViewBeforeEnter
        parameter : val
        desc : It will navigate to paritcualr screen when click on the header based on the val.
    */
    function goNextStep(val) {
        $rootScope.steps.drivers = QuoteStatus.DONE;
        $scope.navigateTo(val);
    }

}