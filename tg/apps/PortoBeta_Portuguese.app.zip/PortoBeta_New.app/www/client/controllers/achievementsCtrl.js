angular.module('controllers')
    .controller('AchievementsCtrl', AchievementsCtrl);

function AchievementsCtrl($state, $rootScope, $scope, AchievementsServices, $timeout, LoadingUtil, WebServiceCache, $translate, PopupUtil,AchievementType) {
    //SCOPE VARIABLES
    $scope.achievements = [];
    
    // SCOPE FUNCTIONS
    $scope.goToAchievementDetails = goToAchievementDetails;

    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    $scope.$on('$ionicView.enter', ionicViewEnter);

    // FUNCITIONS
    function ionicViewBeforeEnter() {
        $rootScope.activeMenuItem = "achievements";
    }

    function ionicViewEnter() {
        prepareAchievements();
    }
    
    /*
        name : prepareAchievements
        description : It calls webservice to get achievement lists and prepares a list to be displayed
    */
    function prepareAchievements() {
        // Get list of all achievements
        var achievements = [];
        var userAchievements = [];
        LoadingUtil.showLoader();
        AchievementsServices.getAchievementsList().then(function(response) {
            AchievementsServices.getAchievements().then(function(userAchievements) {
                LoadingUtil.hideLoader();
                for (var i = 0; i < response.length; i++) {
                    if (response[i].Achievement.AchievementType.id == AchievementType.Id) {
                        achievements.push(response[i].Achievement);
                    } else {
                        continue;
                    }
                }
                userAchievements = userAchievements;
                $scope.achievements = formatAchievements(achievements, userAchievements);
                $timeout(function() {
                    loadProgressBars();
                }, 100)
                //WebServiceCache.cleanseCache(1);
            }, function(error) {
                LoadingUtil.hideLoader();
                PopupUtil.showSimpleAlert($translate.instant('error'),$translate.instant(error['i18n-key']));
                // handle error
            });
        }, function(error) {
            LoadingUtil.hideLoader();
                PopupUtil.showSimpleAlert($translate.instant('error'),$translate.instant(error['i18n-key']));
            // handle error
        });
    }

    /*
        name : formatAchievements
        description : It compares the user achievements with all the available achievement types and formats them to display 
        params : It accepts two lists, 1. All_Achievements, 2. User Achievements
        return : It returns an formatted Array with user achievements which have some progress
    */
    function formatAchievements(pA, pUA) {
        var finalAchievementList = [];
        for (var i = 0; i < pA.length; i++) {
            var found = false;
            for (var j = 0; j < pUA.length; j++) {
                pA[i].order_number = parseInt(pA[i].order_number);
                if (pA[i].id == pUA[j].UserAchievement.achievement_id) {
                    pA[i].progress = Math.round(pUA[j].UserAchievement.progress);
                    pA[i].previous_progress = Math.round(pUA[j].UserAchievement.previous_progress);
                    found = true;
                } else {
                    continue;
                }
            }
            if (!found) {
                pA[i].progress = 0;
                pA[i].previous_progress = null;
            }
            finalAchievementList.push(pA[i]);
        }
        return finalAchievementList;
    }
    
    /*
        name : loadProgressBars
        description : It prepares the progress bars to show current progress out of 100.
        // Used Jquery as I didn't find any better alternatives.
    */
    function loadProgressBars() {
        var progressBars = $('.progressBar');
        for (var i = 0; i < progressBars.length; i++) {
            var score = $(progressBars[i]).parent().parent().parent().children('span').children('label').html();
            $(progressBars[i]).progressBar({
                value: score
            });
        }
    }
    
    
    /*
        name : goToAchievementDetails
        description : It redirects the user to achievement detail screen
        params : It accepts achievement Id as a parameter.
    */
    function goToAchievementDetails(pA_id) {
        var achievementList = $scope.achievements;
        var achievement;
        for (var i = 0; i < achievementList.length; i++) {
            if (achievementList[i].id == pA_id) {
                achievement = achievementList[i];
                break;
            }
        }
        $state.go('app.achievementsDetails', {
            'achievement': achievement
        });
    }
}
