angular.module('controllers')
    .controller('SmsValidationCtrl', SmsValidationCtrl)

function SmsValidationCtrl($state, $rootScope, $ionicHistory, $scope, $timeout, LocalStorage, LocalStorageKeys, GlobalConstants, LtpServices, PopupUtil, $translate, LoadingUtil, BooleanConstant) {
    $scope.goToTermsConditions = goToTermsConditions;
    $scope.verifyClicked = verifyClicked;
    $scope.ltpContinueClicked = ltpContinueClicked;

    $scope.$on('$ionicView.loaded', ionicViewLoaded);
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    $scope.labelTC = $translate.instant('app_smsValidation_seeTermsConditions');
    $scope.pinSent = false;
    $scope.showContinue = false;

    function ionicViewLoaded() {
        $scope.noValue($('#ltp-verify').val());
    }

    $scope.keyUp = function ($event) {
        $scope.noValue($event.target.value);
    }

    $scope.noValue = function (currentValue) {

        var canContinue = false;

        if (currentValue.trim() === '') {
            canContinue = true;
        }

        $('#ltp-verify').prop("disabled", canContinue);
    }

    function ionicViewBeforeEnter() {
        $scope.profileData = LocalStorage.getObject(LocalStorageKeys.PROFILE_DATA);
    }

    function goToTermsConditions() {
        $state.go("app.settingsGeneralConditions");
    }

    function verifyClicked() {
        
        var formattedNumber = formatNumber(textSmsPhoneNumber.value);
        var email = LocalStorage.get(LocalStorageKeys.LOGIN_EMAIL, "");
        var lang = LocalStorage.get(LocalStorageKeys.DEVICE_LOCALE_KEY, "");
        var validCodes = [11, 12, 13, 14, 15, 16, 17, 18, 19, 21, 22, 24, 27, 28, 31, 32, 33, 34, 35, 37, 38, 41, 42, 43, 44, 45, 46, 47, 48, 49, 51, 53, 54, 55, 61, 62, 63, 64, 65, 66, 67, 68, 69, 71, 73, 74, 75, 77, 79, 81, 82, 83, 84, 85, 86, 87, 88, 89, 91, 92, 93, 94, 95, 96, 97, 98, 99];
        var jsonParam = {
            email: email,
            mobile_no: formattedNumber,
            language: lang
        };

        if ( textSmsPhoneNumber.value.length < 10 || textSmsPhoneNumber.value.length > 11 || validCodes.indexOf(parseInt(textSmsPhoneNumber.value.substring(0, 2))) === -1) {
            PopupUtil.showSimpleAlert($translate.instant('Error'), '<p>' + $translate.instant('code_area_required') + '</p>');
            return false;
        }

        LoadingUtil.showLoader();

        LtpServices.smsValidation(jsonParam).then(function (response) {
            LoadingUtil.hideLoader();
            $scope.pinSent = true;
            $timeout(function () {
                // Register KeyUp Event on PIN Input
                $('input#textSmsPin').keyup(inputPinKeyUp);
            }, 100);
        }, function (error) {
            LoadingUtil.hideLoader();

            if (error.data['i18n-key']) {
                PopupUtil.showSimpleAlert($translate.instant('Error'), '<p>' + $translate.instant(error.data['i18n-key']) + '</p>');
            } else {
                PopupUtil.showSimpleAlert($translate.instant('Error'), '<p>' + $translate.instant('undefined') + '</p>');
            }
            

        });
    }

    function ltpContinueClicked() {
        LoadingUtil.showLoader();

        var formattedNumber = formatNumber(textSmsPhoneNumber.value);
        var email = LocalStorage.get(LocalStorageKeys.LOGIN_EMAIL, "");
        var lang = LocalStorage.get(LocalStorageKeys.DEVICE_LOCALE_KEY, "");
        var pin = textSmsPin.value;

        var jsonParam = {
            email: email,
            mobile_no: formattedNumber,
            language: lang,
            code: pin
        };

        LtpServices.validateCode(jsonParam).then(function (response) {
            LoadingUtil.hideLoader();
            $scope.saveProfile();
        }, function (error) {
            LoadingUtil.hideLoader();

            PopupUtil.showSimpleAlert($translate.instant('Error'), '<p>' + $translate.instant(error.data['i18n-key']) + '</p>');

        });
    }

    function inputPinKeyUp(e) {
        var sc = $scope.showContinue;
        if (textSmsPin.value != "") {
            if (!sc)
                sc = true;

        } else {
            if (sc)
                sc = false;
        }

        if (sc != $scope.showContinue) {
            $scope.showContinue = sc;
        }

        $scope.$apply();
    }

    function formatNumber(pN) {
        return pN.replace(new RegExp(/[-.,_!@#$%?&*()+=¤{}'"<>:/ ]/g), '');
    }

    $scope.saveProfile = function () {

        $scope.profileData.user.mobile_phone = textSmsPhoneNumber.value;

        $rootScope.needToSaveProfile = BooleanConstant.BOOL_TRUE;
        LocalStorage.setObject(LocalStorageKeys.PROFILE_DATA, $scope.profileData);

        $ionicHistory.goBack();
    }
}
