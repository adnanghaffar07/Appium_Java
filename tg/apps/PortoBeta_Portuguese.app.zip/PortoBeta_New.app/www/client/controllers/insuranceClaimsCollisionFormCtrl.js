angular.module('controllers')
    .controller('InsuranceClaimsCollisionFormCtrl', InsuranceClaimsCollisionFormCtrl);

function InsuranceClaimsCollisionFormCtrl($state, $rootScope, $scope,BooleanConstant,DateUtil,$ionicHistory) {
   // SCOPE FUNCTIONS
   $scope.saveForm = saveForm;
   $scope.goToSpecificScreen = goToSpecificScreen;
   $scope.goToFormDetails = goToFormDetails;
   
   //SCOPE VARIABLES
   $rootScope.form = {};
   $scope.hideOutofscope=false;
    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    
    // Events
    $scope.$watchGroup(['form.date','form.time', 'form.injured', 'form.involved', 'form.details'], validateForm);
    
    // FUNCTIONS
     ////// Functionality when before entering into the view
    /*
        name : ionicViewBeforeEnter
        desc : will do the data binding to the scope before entering into the view
    */
    function ionicViewBeforeEnter() {
        if (!angular.equals({}, $rootScope.claimDetails.form)){
            $scope.form = $rootScope.claimDetails.form;    
        }else{
            $scope.form.date=DateUtil.getFormDateFmt(new Date());
            $scope.form.time=moment(new Date()).format("h:mm A");   
        }
    }
    
      ////// Function to navigate to Collision screen after saving data.
    /*
        name : saveForm
        parameter:State value
        desc : Saves Form data and navigate to collision screen.
    */
    
    function saveForm(route){
       // $rootScope.form.involved = $rootScope.peopleInvolved;
       $rootScope.form.occured=moment(new Date()).format("YYYY-MM-DD HH:MM:SS");
       var formData = $rootScope.form;
        $rootScope.claimDetails.form = formData;
        //$state.go(route);
        $ionicHistory.goBack();
    }
    
    ////// Function to navigate to specific screen.
    /*
        name : goToSpecificPage
        parameter:State value
        desc : Navigates user to specific screen.
    */
    function goToSpecificScreen(route){
        $state.go(route);
    }
    
    /*
        name : goToFormDetails
        parameter:State value
        desc : Navigates user to form screen.
    */
    function goToFormDetails(route){
        $state.go(route,{
            "details": $scope.form.details
        });
    }
    
    /*
        name : validateForm
        desc : Validate the form input details and handle enable / disable the submit button.
        parameters : newvalues, oldvalues, scope
        response : It'll set the formvalid to true / false based on the input values
    */
    function validateForm(newValues, oldValues, scope) {
        if (newValues[0] && newValues[1] && newValues[2] && newValues[3]&& newValues[4]) {
            $scope.formValid = BooleanConstant.BOOL_TRUE;
        } else {
            $scope.formValid = BooleanConstant.BOOL_FALSE;
        }
    }   
    
}
