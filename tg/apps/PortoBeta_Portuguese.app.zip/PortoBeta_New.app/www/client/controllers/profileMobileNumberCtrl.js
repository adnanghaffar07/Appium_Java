angular.module('controllers')
    .controller('ProfileMobileNumberCtrl', ProfileMobileNumberCtrl);

function ProfileMobileNumberCtrl($scope, $state, $timeout, LocalStorage, LocalStorageKeys, DOMUtil, ValidationUtil, PopupUtil, BooleanConstant, $ionicHistory, $rootScope, $translate) {

    // SCOPE VARIABLES
    $scope.mobileNumberText = 'Verify';
    var vrBtnText = $scope.mobileNumberText;
    $scope.isVerify = false;
    $scope.isVerified = false;

    // SCOPE FUNCTIONS
    $scope.goToPrivacyPolicy = goToPrivacyPolicy;
    $scope.verifyMobile = verifyMobile;
    $scope.saveProfile = saveProfile;
    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    // FUNCTIONS
    /*
        name:ionicViewBeforeEnter
        desc: Populate the profile data in corresponding fields
    */
    function ionicViewBeforeEnter() {
        $scope.profileData = LocalStorage.getObject(LocalStorageKeys.PROFILE_DATA);
    }

    /*
        name : goToPrivacyPolicy
        desc : By clicking on Privacy policy it'll redirect to privacy policy screen.
    */
    function goToPrivacyPolicy() {
        $state.go('app.settingsPrivacyPolicy');
    }

    /*
        name : verifyMobile
        desc : Changing the text of the button based on the navigations  
    */
    function verifyMobile() {
        switch (vrBtnText) {
            case 'Verify':
                $scope.mobileNumberText = 'Send Code Again';
                vrBtnText = 'Send_Code_Again';
                $scope.isVerify = true;
                break;
            case 'Send_Code_Again':
                showVerifcaitonCodePopup();
                break;
            case 'Verify_activation_code':
                $scope.mobileNumberText = "";
                $scope.isVerified = true;
                $scope.isVerify = false;
                break;
        }
        LocalStorage.setObject(LocalStorageKeys.PROFILE_DATA, $scope.profileData);

    }

    /*
        name : showVerifcaitonCodePopup,
        desc : show the verificaiton code options in popup.
    */
    function showVerifcaitonCodePopup() {
        var pNumber = $scope.profileData.user.mobile_number;
        var buttons = [{
                text: '<div> Send via SMS </div>',
                onTap: function (e) {
                    $scope.mobileNumberText = 'Verify';
                    vrBtnText = 'Verify_activation_code';
                }
            },
            {
                text: '<div> Call me instead </div>',
                onTap: function (e) {

                }
            },
            {
                text: '<div> Cancel</div>',
                onTap: function (e) {

                }
            }
        ];
        PopupUtil.showCustomPopupLocal("", "<h4>" + $translate.instant("will_send_verification_code") + " " + pNumber + "</h4>" + $translate.instant("to_complete_number_verification") + "", buttons, "", true);
    }

    /*
        name:saveProfile
        desc: Store the data to be saved in database in rootscope.
              Storing the details in local storage.
    */
    function saveProfile() {
        var newNumber = txtprofilephonenumber.value;
        if (!angular.isUndefined(newNumber)) {
            newNumber = newNumber.replace(' ', '').replace('-', '');
            $scope.profileData.user.mobile_phone = newNumber;
        }

        console.log("INPUT PHONE : ", $scope.profileData.user.mobile_phone);

        if (ValidationUtil.validatePhoneNumber($scope.profileData.user.mobile_phone)) {
            $rootScope.needToSaveProfile = BooleanConstant.BOOL_TRUE;
            LocalStorage.setObject(LocalStorageKeys.PROFILE_DATA, $scope.profileData);
            $ionicHistory.goBack();
        } else {
            var title = $translate.instant('error');
            var body = "<p>" + $translate.instant('profile_phoneNumber_validationError') + "</p>";
            PopupUtil.showSimpleAlert(title, body);
        }
    }
}
