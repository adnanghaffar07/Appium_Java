angular.module('controllers')
    .controller('ProfileInsuranceExpirancyCtrl', ProfileInsuranceExpirancyCtrl);

function ProfileInsuranceExpirancyCtrl($rootScope, $scope, $state, $timeout, $ionicHistory, LocalStorage, LocalStorageKeys,BooleanConstant, ProfileServices, WebServiceCache, PopupUtil, $translate, ValidationUtil) {
    // SCOPE FUNCTIONS
    $scope.saveProfile = saveProfile;

    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    $scope.$on('$ionicView.loaded', ionicViewLoaded);

    // FUNCTIONS
    function ionicViewBeforeEnter() {
        $scope.profileData = LocalStorage.getObject(LocalStorageKeys.PROFILE_DATA);
    }

    function ionicViewLoaded() {
        $('#insuranceDate').mask('99-99-9999');

        $scope.profileData = LocalStorage.getObject(LocalStorageKeys.PROFILE_DATA);
        $scope.insuranceDate = $scope.profileData.Insurance.expiry ? $scope.profileData.Insurance.expiry.split("-").reverse().join("-") : null;
    }

    
     /*
        name: saveProfile
        desc: Saves updated user name to local storage and server.
    */ 
    function saveProfile() {
        $rootScope.updateMenuHeader = true;

        var _insuranceDate = insuranceDate.value ? insuranceDate.value.split("-").reverse().join("-") : null;

        if (_insuranceDate === null || _insuranceDate === "") {
            PopupUtil.showSimpleAlert($translate.instant('Error'), '<p>' + $translate.instant('invalid_date') + '</p>');
            return false;
        } else if (!ValidationUtil.isNormalValidDate(_insuranceDate, 'YYYY-MM-DD')) {
            PopupUtil.showSimpleAlert($translate.instant('Error'), '<p>' + $translate.instant('invalid_date')+ '</p>');
            return false;
        } 
         
        $scope.profileData.Insurance.expiry = _insuranceDate;

        ProfileServices.saveProfile("", $scope.profileData).then(function (response) {
            WebServiceCache.cleanseCache(2);
            LocalStorage.setObject(LocalStorageKeys.PROFILE_DATA, $scope.profileData);
            $ionicHistory.goBack();
        }, function (error) {
            PopupUtil.showSimpleAlert($translate.instant('error'),$translate.instant(error.data['i18n-key']));
        });
    }

    $scope.focus = function ($event) {
        if ($('#insuranceDate').val().length === 0) {
            setTimeout(function() {
                $('#insuranceDate')[0].setSelectionRange(0, 0);    
            }, 100);
        }
    }
}
