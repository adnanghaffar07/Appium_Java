angular.module('controllers')
    .controller('QuoteDriversAddCtrl', QuoteDriversAddCtrl);

function QuoteDriversAddCtrl($rootScope, $state, $scope, $ionicHistory, $timeout, $ionicScrollDelegate, LocalStorage, NumberSuffixArray, $stateParams, ProfileServices, BooleanConstant, CountryName, $filter, LoggerUtilType, $translate, PopupUtil) {

    // SCOPE VARIABLES
    // --> All scope variables that are specific to that view will be defined here
    $rootScope.quoteData.driversAdd = {
        'first_name': '',
        'last_name': '',
        'license': '',
        'aboutHadIncident': 'off',
        'gender': 'M',
        'incidents': []
    };

    //// Mandatory fields declarations                         
    var requiredFields = ['first_name', 'last_name', 'license_state', 'license', 'marital_status', 'driver_type', 'phone_number', 'email'];

    var suffix = ['Mr.', 'Mrs.'];
    var license_age = ['16', '17', '18', '19', '20', '21', '22', '23', '24'];
    var statesList = [];
    var driverTypes = [];
    var driverTypeNames = [];
    var maritalStatus = [];
    var maritalStatusNames = [];
    $scope.driverTypes = {};


    $scope.quoteData.violation = {};
    var vrDriverIndex = $stateParams.pIndex;
    $scope.driverIndex = vrDriverIndex;

    // SCOPE FUNCTIONS
    // --> All scope functions specific to that view are defined here
    $scope.saveDriverDetails = saveDriverDetails;
    $scope.goToSelectInfo = goToSelectInfo;
    $scope.hadIncident = hadIncident;
    $scope.addIncident = addIncident;
    $scope.removeIncident = removeIncident;
    $scope.changeIncidentType = changeIncidentType;
    $scope.getSuffix = getSuffix;



    // SCOPE LIFE CYCLE
    // --> All needed life cycle events specific to that view are defined here. Note that we do not write the function directly in it.
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);


    // FUNCTIONS
    // Webservice call to get list of states.
    ProfileServices.getStatesList(CountryName.USA).then(function (response) {
        statesList = $filter('orderBy')(response, 'name');
        var states = [];
        for (var i = 0; i < statesList.length; i++) {
            states.push(statesList[i].name);
        }
        statesList = states;
    }, function (error) {
        PopupUtil.showSimpleAlert($translate.instant('error'), $translate.instant(error['i18n-key']));
    });

    // Webservice call to get list of driver types
    ProfileServices.getDriverTypes().then(function (response) {
        driverTypes = response.data;
        driverTypeNames = [];
        angular.forEach(driverTypes, function (value, key) {
            driverTypeNames.push(value.name);
        });
    }, function (error) {
        PopupUtil.showSimpleAlert($translate.instant('error'), $translate.instant(error['i18n-key']));
    });

    // Webservice call to get list of maritial status
    ProfileServices.getMaritalStatus().then(function (response) {
        maritalStatus = response.data;
        maritalStatusNames = [];
        angular.forEach(maritalStatus, function (value, key) {
            maritalStatusNames.push(value.name);
        });
    }, function (error) {
        PopupUtil.showSimpleAlert($translate.instant('error'), $translate.instant(error['i18n-key']));
    });

    ////// Functionality when before entering into the view
    /*
        name : ionicViewBeforeEnter
        desc : will do the data binding to the scope before entering into the view
    */
    function ionicViewBeforeEnter() {
        var vrSelectedType = $scope.selectedType;
        var vrSelectedVal = $rootScope.selectedValue;
        $scope.selectedType = null;
        $scope.selectedType = vrSelectedVal;
        if (vrSelectedType == null) {
            if (vrDriverIndex == null) {
                //$scope.quoteData.driversAdd = {};
                vrDriverIndex = Object.keys($rootScope.quoteData.drivers).length;
            } else {
                var tempDriver = $rootScope.quoteData.drivers[vrDriverIndex];
                $scope.quoteData.driversAdd = JSON.parse(JSON.stringify(tempDriver));
                tempDriver = $scope.quoteData.driversAdd;
                for (var i=0;i< tempDriver.incidents.length ; i++) {
                    incident = tempDriver.incidents[i];
                    incident.date = new Date(incident.date);
                    tempDriver.incidents[i] = incident;
                }
                $scope.quoteData.driversAdd = tempDriver; 
            }
        }
        if (vrSelectedVal == null)
            return false;
        switch (vrSelectedType) {
            case 'suffix':
                $scope.quoteData.driversAdd.suffix = vrSelectedVal;
                break;
            case 'maritalStatus':
                angular.forEach(maritalStatus, function (value, key) {
                    if (value.name == vrSelectedVal)
                        $scope.quoteData.driversAdd.marital_status_id = value.id;
                    $scope.quoteData.driversAdd.marital_status = vrSelectedVal;
                });
                break;
            case 'license_age':
                $scope.quoteData.driversAdd.license_age = vrSelectedVal;
                break;
            case 'state':
                $scope.quoteData.driversAdd.license_state = vrSelectedVal;
                break;
            case 'driverType':
                angular.forEach(driverTypes, function (value, key) {
                    if (value.name == vrSelectedVal)
                        $scope.quoteData.driversAdd.driver_type_id = value.id;
                    $scope.quoteData.driversAdd.driver_type = vrSelectedVal;
                });
                break;
            case 'typeOfAccident':
                $scope.quoteData.driversAdd.incidents[$scope.selTypeIndex].typeOfAccident = vrSelectedVal;
            default:
                break;
        }
    }

    ///// Funciton to show the incident related info 
    /*
        name : hadIncident
        parameter : sending the parameter as on/off to check the show the incident related info
        desc : It'll show / hide the accident related info details dynamically
    */
    function hadIncident(option) {
        $scope.quoteData.driversAdd.aboutHadIncident = option;
        if (option === 'on') {
            $scope.incidentexist = BooleanConstant.BOOL_TRUE;
            if (angular.isUndefined($scope.quoteData.driversAdd.incidents) || $scope.quoteData.driversAdd.incidents.length === 0) {
                $scope.quoteData.driversAdd.incidents.push({});
                $scope.quoteData.driversAdd.incidents[0].type = "violation";
            }
            $ionicScrollDelegate.resize();
        } else {
            $scope.incidentexist = BooleanConstant.BOOL_FALSE;
            $scope.quoteData.driversAdd.incidents = [];
        }
        $timeout(function () {
            $('.btn-radio-gaq').buttonset();
        })
    }

    //// Function to check the no.of items added dynamically
    /*
        name : getSuffix
        parameter : index vlaue
        desc : Set the index value to identify the list of incident to remove.
    */
    function getSuffix(i) {
        var vrSuffixval = "";
        if (i < NumberSuffixArray.SUFFIXES.length) {
            vrSuffixval = NumberSuffixArray.SUFFIXES[i];
        } else {
            vrSuffixval = NumberSuffixArray.SUFFIXES[4];
        }
        return vrSuffixval;
    }

    //// Show incident related details when click on radio button
    /*
        name : changeIncidentType
        parameter : index vlaue, incident type
        desc : It 'll add incident type details dynamically based on the index and incident type.
    */
    function changeIncidentType(index, incidenttype) {
        $scope.quoteData.driversAdd.incidents[index].type = incidenttype;
        $ionicScrollDelegate.resize();
    }

    ///// Function to add incidents
    /*
        name : addIncident
        desc : It 'll add incident details dynamically.
    */
    function addIncident() {
        $scope.quoteData.driversAdd.incidents.push({});
        $scope.quoteData.driversAdd.incidents[$scope.quoteData.driversAdd.incidents.length - 1].type = "violation";
        $timeout(function () {
            $('.btn-radio-gaq').buttonset();
        });
        $ionicScrollDelegate.resize();
    }

    ///// Function to remove incidents
    /*
        name : removeIncident
        parameter : index value
        desc : It 'll remove incident details based on the index number dynamically.
    */
    function removeIncident(index) {
        $scope.quoteData.driversAdd.incidents.splice(index, 1);
        if ($scope.quoteData.driversAdd.incidents.length === 0) {
            $scope.quoteData.driversAdd.aboutHadIncident = 'off';
            $scope.incidentexist = BooleanConstant.BOOL_FALSE;
            $('#btnMultiPolicyNo').button('refresh');
        }
        $ionicScrollDelegate.resize();
    }

    ///// Funciton to save the drivers details
    /*
        name : saveDriverDetails
        desc : Save the driver details in rootscope with the index number
    */
    function saveDriverDetails() {
        $scope.submitted = BooleanConstant.BOOL_TRUE;
        var error = validateData($scope.quoteData.driversAdd);
        if (!error) {
            $rootScope.quoteData.drivers[vrDriverIndex] = $scope.quoteData.driversAdd
                //$rootScope.quoteData.drivers.push($scope.quoteData.driversAdd);
            $ionicHistory.goBack();
        } else {
            $timeout(function () {
                var anchorScrollId = $('.required-error').first().attr('id');
                var quotePosition = $('#' + anchorScrollId).offset();
                $ionicScrollDelegate.scrollBy("", quotePosition.top - 64);
            }, 100);
        }
    }

    ///// Funciton to validate mandatory fields
    /*
        name : validateData
        parameter : data
        desc : Validate the mandatory fields details
        return : It'll return 'true' if any of the mandatory fields kept empty. If all the mandatory details are filled it'll return 'false'
    */
    function validateData(data) {
        var isError = BooleanConstant.BOOL_FALSE;
        if (data) {
            for (var i = 0; i < requiredFields.length; i++) {
                if (angular.isUndefined(data[requiredFields[i]]) || data[requiredFields[i]] === '' || data[requiredFields[i]] === null) {
                    isError = BooleanConstant.BOOL_TRUE;
                    break;
                }
            };
            if (!isError) {
                var incidentsList = data.incidents;
                for (var i = 0; i < incidentsList.length; i++) {
                    if (!angular.isDefined(incidentsList[i].amount) && incidentsList[i].type == 'accident') {
                        isError = BooleanConstant.BOOL_TRUE;
                        break;
                    }
                    if (!angular.isDefined(incidentsList[i].date)) {
                        isError = BooleanConstant.BOOL_TRUE;
                        break;
                    }
                }
            }
        } else {
            isError = BooleanConstant.BOOL_TRUE;
        }
        return isError;
    }

    //// Function to populate the selected data.
    /*
        name : goToSelectInfo
        parameter : pType,index
        desc : Redirect to select screen to show list of items
    */
    function goToSelectInfo(pType, index) {
        var list = [];
        switch (pType) {
            case 'suffix':
                list = suffix;
                $state.go('app.selectInfo', {
                    'list': list
                });
                break;
            case 'maritalStatus':
                console.log(55555, maritalStatus, maritalStatusNames);
                list = maritalStatusNames;
                $state.go('app.selectInfo',{'list':list, 'selectedValue': $scope.quoteData.driversAdd.marital_status});
                break;
            case 'license_age':
                list = license_age;
                $state.go('app.selectInfo', {
                    'list': list
                });
                break;
            case 'state':
                list = statesList;
                $state.go('app.selectInfo',{'list':list, 'selectedValue': $scope.quoteData.driversAdd.license_state});
                break;
            case 'driverType':
                if (index == 0) {
                    break;
                }
                list = driverTypeNames;
                $state.go('app.selectInfo', {
                    'list': list
                });
                break;
            case 'typeOfAccident':
                $scope.selTypeIndex = index;
                getTypeOfAccidents();
                break;
            default:
                break;
        }

        $scope.selectedType = pType;
    }

    //// Function to get distance driven
    /*
        name : getTypeOfAccidents
        desc : Get accident types.
        return : list of accident types.
    */
    function getTypeOfAccidents() {
        ProfileServices.getTypeOfAccidents().then(function (response) {
            $state.go('app.selectInfo', {
                'list': response
            });
        }, function (error) {
            //console.log('ERROR IN Type of accudents LOAD');
            PopupUtil.showSimpleAlert($translate.instant('error'), $translate.instant(error['i18n-key']));
        });
    }

    ////// Setting the button set to radio buttons - To render the radio button as visual grouping for related buttons
    // Jquery methods
    $timeout(function (e) {
        $('.btn-radio-gaq').buttonset();
    }, 100)
}
