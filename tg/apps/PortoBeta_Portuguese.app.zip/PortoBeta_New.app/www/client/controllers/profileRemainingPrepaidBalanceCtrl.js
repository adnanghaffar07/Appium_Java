angular.module('controllers')
    .controller('ProfileRemainingPrepaidBalanceCtrl', ProfileRemainingPrepaidBalanceCtrl);
function ProfileRemainingPrepaidBalanceCtrl($rootScope, $state, $scope,LoadingUtil,PaymentServices,$translate,PopupUtil,DateUtil,LocalStorage,LocalStorageKeys) {
    // SCOPE VARIABLES
    // --> All scope variables that are specific to that view will be defined here
   
    // SCOPE FUNCTIONS
    // --> All scope functions specific to that view are defined here
    $scope.onAmountChange = onAmountChange;
    $scope.submitPrepaidBalance = submitPrepaidBalance;
    $scope.prepaid = 0;
    // SCOPE LIFE CYCLE
    // --> All needed life cycle events specific to that view are defined here. Note that we do not write the function directly in it.
    $scope.$on('$ionicView.loaded', ionicViewLoaded);
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    $scope.$on('$ionicView.enter', ionicViewEnter);
 
    // FUNCTIONS
    
    function ionicViewLoaded(){
        $scope.isDisabled=true;
        LoadingUtil.showLoader();
         $scope.todaydate=DateUtil.eriedateformat();
         PaymentServices.getPackages().then(function (response) {
             LoadingUtil.hideLoader();
            $scope.packages=response.data;
          },function(error){
              LoadingUtil.hideLoader();
          });
    }
    
    /* 
        name : ionicViewBeforeEnter
        desc : Will call web services and prepare an object for the screen
    */
    function ionicViewBeforeEnter() {
         
    }
    
      /* 
        name : ionicViewEnter
        desc : Will call web services and prepare an object for the screen
    */
    function ionicViewEnter() {
          LoadingUtil.showLoader();
		  PaymentServices.getBalanceInfo().then(function (response) {
              var balance = 0;
                 if (response.data.length>0){
                     for (var i=0; i<response.data.length;i++){
                       balance +=  parseFloat(response.data[i].balance);
                    }
                     $scope.remainingbalance=balance;
                 }
            LoadingUtil.hideLoader();
          },function(error){
              var vrError = $translate.instant(error['i18n-key']);
              PopupUtil.showSimpleAlert($translate.instant('error'), vrError);
              LoadingUtil.hideLoader();
          });
    }
    
     /* 
        name : onAmountChange
        desc : Will call on option change.
        param: Amount, package id.
    */
       function onAmountChange (amount,packageId) {
         $scope.isDisabled=false;
         $scope.selprepaid=' $'+amount;
         var packageDetails={};
         packageDetails.package_id=packageId;
         packageDetails.amount = amount;
         $rootScope.packageDetailsObj = packageDetails;
         console.log('$'+amount);
     }
     
    /* 
        name : submitPrepaidBalance
        desc : Navigate to payment types screen.
    */
     function submitPrepaidBalance(){
            LoadingUtil.showLoader();
            PaymentServices.getPaymentMethods().then(function (response) {
                LoadingUtil.hideLoader();
                $rootScope.fromRPM = true;
                $rootScope.packageId=$rootScope.packageDetailsObj.package_id;
                if (response.data.length==0){
                    $state.go("app.profileAddPayment");
                }
                else{
                    $state.go("app.profilePayment");
                    
                }
            }, function (error) {
                LoadingUtil.hideLoader();
                return false;
            });   
     }
}