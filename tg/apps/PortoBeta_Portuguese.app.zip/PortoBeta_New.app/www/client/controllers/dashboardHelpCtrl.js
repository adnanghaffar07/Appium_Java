angular.module('controllers')
    .controller('DashboardHelpCtrl', DashboardHelpCtrl);

function DashboardHelpCtrl($scope, $state, LocalStorage, LocalStorageKeys) {
    // Scope functions
    $scope.toggleList = toggleList;

    // Scope Variables
    var vrOldIndex = '';
    var vrScope = '';
    var vrOldScope = '';


    // Scope Life Cycle
    $scope.$on('$ionicView.loaded', ionicViewLoaded);
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    // Functions

    /*
        Name: ionicViewLoaded
        Desc: Fetch data from database
    */
    function ionicViewLoaded() {

    }

    /*
        Name: ionicViewBeforeEnter
        Desc: Prepare screen before loading
    */
    function ionicViewBeforeEnter() {
        $scope.segmentColors=LocalStorage.getObject(LocalStorageKeys.MILE_CATEGORY_COLOR);
    }
    
    /*
        name : toggleList
        desc : Toggle the content of the list.  
        parameter : pIndex
    */
    function toggleList(pIndex){
        vrScope = 'showContent'+pIndex;
        if ($scope[vrScope] == true){
            $scope[vrScope] = false;   
        }else{
            vrOldScope = "showContent"+vrOldIndex;
            $scope[vrOldScope] = false;
            $scope[vrScope] = true;
            vrOldIndex = pIndex;
        }
    }
}
