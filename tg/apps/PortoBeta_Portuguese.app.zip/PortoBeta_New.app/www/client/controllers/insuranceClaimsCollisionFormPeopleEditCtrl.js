angular.module('controllers')
    .controller('InsuranceClaimsCollisionFormPeopleEditCtrl', InsuranceClaimsCollisionFormPeopleEditCtrl);

function InsuranceClaimsCollisionFormPeopleEditCtrl($state, $rootScope, $scope,LocalStorage,$stateParams,CameraUtil,InsuranceServices,BooleanConstant,CameraCapture,UploadImage) {
   // SCOPE FUNCTIONS
   $scope.saveData = saveData;
   $scope.optionSelected = optionSelected;
   $scope.choosePhotoOption = choosePhotoOption;
   $scope.gotoSelectInfo = gotoSelectInfo;
   //SCOPE VARIABLES
   $scope.displayFooter  = BooleanConstant.BOOL_FALSE;
    var involvedList = ["witness"];
    $scope.people={};
    var vruserindex='';
    var cameraOptions = CameraCapture.IMAGE_SIZE;
        var imageData={};
   
    // Events
    $scope.$watchGroup(['people.involvement','people.first_name', 'people.last_name', 'people.mobile', 'people.email','people.image'], validateForm);
    
//    $scope.personImage ="client/images/insurance/witness1.png";
    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    $scope.$on('$ionicView.enter', ionicViewEnter);

    // FUNCTIONS
     ////// Functionality when before entering into the view
    /*
        name : ionicViewBeforeEnter
        desc : will do the data binding to the scope before entering into the view
    */
    function ionicViewBeforeEnter() {
        var vrSelectedVal = $rootScope.selectedValue;
        if (vrSelectedVal !== null) {
            $rootScope.selectedValue = null;
            $scope.people.involvement = vrSelectedVal;
        }
    }
    
    function ionicViewEnter(){
        vruserindex = $stateParams.pIndex;
        if(!isNaN(vruserindex)){
           $scope.people=$rootScope.peopleInvolved[vruserindex];
          }
    }
    
      ////// Function to navigate to People involved list screen after saving data.
    /*
        name : saveData
        parameter:State value
        desc : Saves People involved data and navigate to people involved list screen.
    */
    
    function saveData(route){
        if(angular.isUndefined($rootScope.peopleInvolved)){
            $rootScope.peopleInvolved=[];
        }
        var vrVal =$rootScope.peopleInvolved.length;
        if(vruserindex.length > 0){
            vrVal = vruserindex;
        }
        $rootScope.peopleInvolved[vrVal] = $scope.people;
        
        
        $state.go(route);
    }
    
     // Function to navigate to People involved list screen after saving data.
    /*
        name : optionSelected
        parameter:Selected option
        desc : (Take Picture / Choose from Gallery / Cancel)
    */
    function optionSelected(option){
        if(option==UploadImage.CANCEL){
            $scope.displayFooter  = BooleanConstant.BOOL_FALSE;
        }else if(option==UploadImage.TAKE){
            takePhoto();
        }else if(option==UploadImage.CHOOSE){
            chooseFromLibrary();
        }
    }
     /*
        name   :  takePhoto  
        desc   :  It opens camera to take photo.
    */
    function takePhoto() {
        $scope.displayFooter  = BooleanConstant.BOOL_FALSE;
        CameraUtil.takePicture(cameraOptions).then(function (image) {
            processImage(image);
        });
    }
    /*
        name   :  chooseFromLibrary  
        desc   :  It shows images in Gallery.
    */
    function chooseFromLibrary() {
        $scope.displayFooter  = BooleanConstant.BOOL_FALSE;
        CameraUtil.getPicture(cameraOptions).then(function (image) {
            processImage(image);
        });
    }
      /*
        name   :  choosePhotoOption  
        desc   :  It will show the options to choose photo from Gallery / Take Picture.
    */
    
    function choosePhotoOption(){
        $scope.displayFooter  = BooleanConstant.BOOL_TRUE;
    }
    
     /*
        name   :  gotoSelectInfo  
        desc   :  It will save the user data filled till this moment and navigates the user to a screen where he will select a state.
    */
    function gotoSelectInfo() {
        $rootScope.quoteData['user'] = $scope.userData;
        $state.go('app.selectInfo', { 'list': involvedList });
    }
    
     /*
        name   :  processImage  
        desc   :  It will save saves picture to server.
    */
    function processImage(img){
        imageData.image =  UploadImage.BASE_64+ img;
        imageData.title = "People Involved";
        InsuranceServices.postPicture(imageData).then(function (response) {       
                $scope.people.image = imageData.image;
                $scope.people.imageId=response.data.id;
            }, function (error) {
                
            });
    }
    
        /*
        name : validateForm
        desc : Validate the form input details and handle enable / disable the submit button.
        parameters : newvalues, oldvalues, scope
        response : It'll set the formvalid to true / false based on the input values
    */
    function validateForm(newValues, oldValues, scope) {
        if (newValues[0] && newValues[1] && newValues[2] && newValues[3]&& newValues[4] && newValues[5]) {
            $scope.formValid = BooleanConstant.BOOL_TRUE;
        } else {
            $scope.formValid = BooleanConstant.BOOL_FALSE;
        }
    }   
}
