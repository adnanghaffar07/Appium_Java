angular.module('controllers')
    .controller('TripHistorySelectTypeCtrl', TripHistorySelectTypeCtrl);

function TripHistorySelectTypeCtrl($state, $scope, $ionicHistory, $stateParams, TripsServices, PopupUtil, $translate, FirebaseService, LocalStorage, LocalStorageKeys) {
    $scope.types = $stateParams.list;
    $scope.tripId = $stateParams.tripId;

    $scope.selectTripType = selectTripType;

    $scope.$on('$ionicView.loaded', ionicViewLoaded);

    /*
        NAME : ionicViewLoaded
        DESC : Life cycle event of ionic, called when controller is loaded
    */
    function ionicViewLoaded() {
        // ORGANIZE LIST IN ARRAYS OF 3 TYPES
        var types = [];

        angular.forEach($scope.types, function (type, index) {
            if (type.name !== 'car' && type.name !== 'taxi') {
                type.icon = './client/images/transports/' + type.name + '.svg';
                types.push(type);
            }
        });

        $scope.types = types;
    }

    /*
    NAME : selectTripType
    DESC : Call web service SET_TRANSPORT_TYPE with selected trip type
    @PARAM : type -> TripType object selected by user
    */
    function selectTripType(type) {
        var btn = [{
            text: $translate.instant('cancel'),
            onTap: function (e) {}
        }, {
            text: $translate.instant('tripType_buttonDisqualify'),
            onTap: function (e) {
                saveTripType(type);
            }
        }]

        FirebaseService.logEvent("select_content", {
            content_type: "transport_type",
            item_name: "Histórico de viagens", 
            custom_dimension2: "Histórico de viagens",
            custom_dimension5: LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID) !== null ? "logged in" : "logged out",
            custom_dimension7: type.name
        });

        PopupUtil.showSimpleAlert($translate.instant('tripType_popupTitle'), '<p>' + $translate.instant('tripType_popupText') + '</p>', btn);
    }

    function saveTripType(type) {
        TripsServices.setTransportType(type.id, $scope.tripId).then(function (result) {
            if (result.data.success) {
                $ionicHistory.goBack();
            }
        });
    }
}
