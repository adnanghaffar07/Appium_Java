angular.module('controllers')
    .controller('QuotePurchaseCtrl', QuotePurchaseCtrl);
function QuotePurchaseCtrl($rootScope, $state, $scope, $ionicHistory, BooleanConstant, QuoteServices, LoadingUtil, PaymentServices, LocalStorageKeys, LocalStorage, ApplicationMode, $filter, LoginType, ProfileServices, PopupUtil, $translate, LoggerUtilType, CordovaBroadcaster, DeviceFactory) {
    // SCOPE VARIABLES
    // --> All scope variables that are specific to that view will be defined here
    $scope.payments = {};
    $scope.options = {
        showDetailedQuote: BooleanConstant.BOOL_FALSE,
        payment: null
    }
    var vehicleId = '';
    // SCOPE FUNCTIONS
    // --> All scope functions specific to that view are defined here
    $scope.toggleDetailedQoute = toggleDetailedQoute;
    $scope.purchase = purchase;
    $scope.selectPaymentMethod = selectPaymentMethod;
    $scope.navigateToPayment = navigateToPayment;

    // SCOPE LIFE CYCLE
    // --> All needed life cycle events specific to that view are defined here. Note that we do not write the function directly in it.
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    // FUNCTIONS
    /* 
        name : ionicViewBeforeEnter
        desc : Will call web services and prepare an object for the screen
    */
    function ionicViewBeforeEnter() {
        LoadingUtil.showLoader();
        PaymentServices.getPaymentMethods().then(function(response) {
            $scope.payments = response.data;
            if ($scope.payments.length == 0) {
                $rootScope.createPaymentMethodsGAQ = true;
                //$state.go('app.profileAddPayment');
            }
        }, function(error) {
            // handle error
            LoadingUtil.hideLoader();
        });

        $scope.packageDetails = LocalStorage.getObject(LocalStorageKeys.BUY_PACKAGE_DETAILS);
        $scope.segmentColors = LocalStorage.getObject(LocalStorageKeys.MILE_CATEGORY_COLOR);
        QuoteServices.getQuotePricePerMileRatings().then(function(response) {
            var vrResponse = response.data.data;
            $scope.userName = vrResponse.first_name;
            $scope.confirmationNumber = vrResponse.confirmation_number;
            var vrQuoteVehicle = vrResponse.quote_vehicles[0];
            vehicleId = vrQuoteVehicle.id;
            var pricings = vrQuoteVehicle.quote_vehicle_pricing_items;
            // webservice call to get available premiums/categories
            QuoteServices.getPremiums().then(function(response) {
                LoadingUtil.hideLoader();
                var premiums = response.data.data;
                premiums = $filter('orderBy')(premiums, 'id');
                pricings = $filter('orderBy')(pricings, 'premium_id');
                $scope.annualMilage = vrQuoteVehicle.annual_mileage;
                for (var i = 0; i < premiums.length; i++) {
                    for (var j = 0; j < pricings.length; j++) {
                        if (premiums[j].id == pricings[j].premium_id) {
                            pricings[j]['type'] = premiums[j]['name'];
                        }
                    }
                }
                for (var i = 0; i < pricings.length; i++) {
                    switch (pricings[i].type) {
                        case "safe_interstate":
                            $scope.safe_interest = pricings[i].price;
                            break;
                        case "safe_other":
                            $scope.safe_other = pricings[i].price;
                            break;
                        case "risky":
                            $scope.risky = pricings[i].price;
                            break;
                        case "aggressive":
                            $scope.aggressive = pricings[i].price;
                            break;
                        case "dangerous":
                            $scope.dangerous = pricings[i].price;
                            break;
                    }
                }
                $scope.estimatedAnnualUsage = (0.85 * $scope.annualMilage * (($scope.safe_interest + $scope.safe_other) / 2)) + (0.15 * $scope.annualMilage * $scope.aggressive);
            }, function(error) {
                PopupUtil.showSimpleAlert($translate.instant('error'),$translate.instant(error['i18n-key']));
                // handle the error
            });

        }, function(error) {
            //handle error
        });
    }

    // FUNCTIONS
    /* 
        name : toggleDetailedQoute
        desc : It will show/hide the in-detailed quote.
    */
    function toggleDetailedQoute() {
        $scope.options.showDetailedQuote = !$scope.options.showDetailedQuote;
    }

    /* 
        name : purchase
        desc : It should call a webservice to purchase a quote and then it should redirect to Receipt screen.
    */
    function purchase() {
        var packagedetails = {
            payment_option_id: $scope.packageDetails.package_id,
            user_payment_method_id: $scope.paymentDetails
        };
        LoadingUtil.showLoader();
        QuoteServices.purchaseQuote(packagedetails).then(function(response) {
            updateProfileDetails();
            LoadingUtil.hideLoader();
            LocalStorage.set(LocalStorageKeys.LOGIN_TYPE, LoginType.UBI_PPM);
            $scope.isTBYB = false;
            var policyId = response.data.data.policy_payments[0].policy_id;
            LocalStorage.set(LocalStorageKeys.POLICY_ID, policyId);
            CordovaBroadcaster.sendPolicyInformation();
            sendUserInformation();
            $state.go('app.quoteReceipt', { "receipt": response.data.data });
        }, function(error) {
            LoadingUtil.hideLoader();
            //$state.go('app.quoteReceipt');
            PopupUtil.showSimpleAlert($translate.instant('error'),$translate.instant(error['i18n-key']));
            console.log(error);
        });
    }

    /* 
        name : selectPaymentMethod
        desc : It'll set the seleted user payment method id to scope value 
    */
    function selectPaymentMethod(paymentMethodId, id) {
        $scope.paymentDetails = id;
    }

    /* 
        name : navigateToPayment
        desc : It'll navigate to payment methods screen and set the root scope value to true. 
    */
    function navigateToPayment(pRoute, pEvent) {
        $rootScope.createPaymentMethodsGAQ = true;
        $state.go(pRoute);
    }

    /*
        name   :  saveProfile  
        param  :  Profile data
        desc   :  Saves profile data to server.
    */
    function updateProfileDetails() {
        var pQuoteData = $rootScope.quoteData;
        $scope.profileData.user.first_name = pQuoteData.user.first_name;
        $scope.profileData.user.last_name = pQuoteData.user.last_name;
        $scope.profileData.user.full_name = pQuoteData.user.first_name + ' ' + pQuoteData.user.last_name;
        if (pQuoteData.user.gender) {
            $scope.profileData.user.gender = pQuoteData.user.gender[0];
        }
        $scope.profileData.Address = {};
        $scope.profileData.Address.zip_code = pQuoteData.user.postal_code;
        $scope.profileData.Address.street_number = pQuoteData.user.street_name;
        $scope.profileData.Address.city = pQuoteData.user.city_name;
        $scope.profileData.Address.state = pQuoteData.user.state;
        var tempData = $scope.profileData;
        ProfileServices.saveProfile("", $scope.profileData).then(function(response) {
            saveVehicleData(tempData);
        }, function(error) {
            PopupUtil.showSimpleAlert($translate.instant('error'),$translate.instant(error['i18n-key']));
        });
    }
    /*
        name   :  saveVehicleData  
        param  :  Vehicle data
        desc   :  Saves Vehicle data to server.
    */
    function saveVehicleData(tempData) {
        $scope.profileData = tempData;
        var pQuoteData = $rootScope.quoteData;
        $scope.profileData.cars[0].year = pQuoteData.vehicles[0].year;
        $scope.profileData.cars[0].make = pQuoteData.vehicles[0].make;
        $scope.profileData.cars[0].model = pQuoteData.vehicles[0].model;
        $scope.profileData.cars[0].id = vehicleId;
        tempData = $scope.profileData;
        ProfileServices.setVehicleProfile($scope.profileData.cars[0]).then(function(response) {
            console.log(response);
            LocalStorage.setObject(LocalStorageKeys.PROFILE_DATA, tempData);
        }, function(error) {
            //error
            PopupUtil.showSimpleAlert($translate.instant('error'), $translate.instant(error['i18n-key']));
        });
    }

    function sendUserInformation() {
        DeviceFactory.getDevices().then(function(pDevices) {
            CordovaBroadcaster.sendUserInformation(
                LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID),
                LocalStorage.get(LocalStorageKeys.USER_TOKEN),
                pDevices);
        }, function(pError) {
            CordovaBroadcaster.sendUserInformation(
                LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID),
                LocalStorage.get(LocalStorageKeys.USER_TOKEN),
                null);
        });
    }
}