angular.module('controllers')
    .controller('BadgesCtrl', BadgesCtrl);

function BadgesCtrl($state, $rootScope, $scope, $timeout, $translate, GamingServices, FirebaseService, LocalStorageKeys, LocalStorage) {
    /*
        SCOPE FUNCTION DECLARATION
        FUNCTIONS THAT ARE PART OF THE LIFE CYCLE OF A SCREEN
    */
    $scope.$on('$ionicView.loaded', ionicViewLoaded);
    $scope.$on('$ionicView.enter', ionicViewEnter);

    $scope.getLevels = getLevels;

    /*
        SCOPE VARIABLES
    */
    $rootScope.activeMenuItem = "badges";

    /*
        #######################
        ###### FUNCTIONS ######
        #######################
    */

    function ionicViewEnter() {
        FirebaseService.logEvent("view_item", {
            item_name: "Medalhas", 
            custom_dimension2: "Medalhas",
            custom_dimension5: LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID) !== null ? "logged in" : "logged out"
        });
    }

    /*
        NAME : ionicViewLoaded
        DESC : Fired once the screen is loaded.
    */
    function ionicViewLoaded() {
        fetchBadgesData();
    }

    /*
        NAME: hidePageHider
        DESC: hide the white page hider during this pageload so we do not see weird stuff happening.
    */
    function hidePageHider() {
        $('div#page-load-hider').fadeOut('fast');
    }

    /*
        NAME : fetchBadgesData
        DESC : Calls web service to get all Badges data
    */
    function fetchBadgesData() {
        $scope.badges = [];
        GamingServices.getBadgesData().then(function (response) {
            $scope.badges = response;
        }, function (response) {})
    }

    /*
        NAME: getLevels
        DESC: WIll define an array with number of levels per badge
    */
    function getLevels(pN) {
        return new Array(pN);
    }
}
