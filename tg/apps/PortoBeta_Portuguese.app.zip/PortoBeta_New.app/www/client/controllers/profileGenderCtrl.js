angular.module('controllers')
    .controller('ProfileGenderCtrl', ProfileGenderCtrl);

function ProfileGenderCtrl($rootScope, $scope, $state, $timeout, $ionicHistory, LocalStorage, LocalStorageKeys, BooleanConstant, Profile) {
    // SCOPE FUNCTIONS
    $scope.saveProfile = saveProfile;

    //SCOPE VARIABLES
    $scope.objgender = Profile.GENDER_OPTIONS;


    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    // FUNCTIONS
    /* 
        name : ionicViewBeforeEnter
        desc : Binds local storage data to scope before entering to page.
    */
    function ionicViewBeforeEnter() {
        $scope.profileData = LocalStorage.getObject(LocalStorageKeys.PROFILE_DATA);
    }

    /* 
        name : saveProfile
        desc : Saves data to localstorage and redirect to profile screen.
    */
    function saveProfile() {
        $rootScope.needToSaveProfile = BooleanConstant.BOOL_TRUE;
        LocalStorage.setObject(LocalStorageKeys.PROFILE_DATA, $scope.profileData);
        $ionicHistory.goBack();
    }
}
