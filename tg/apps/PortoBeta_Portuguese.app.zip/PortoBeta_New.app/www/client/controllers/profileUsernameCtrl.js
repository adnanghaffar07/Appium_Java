angular.module('controllers')
    .controller('ProfileUsernameCtrl', ProfileUsernameCtrl);

function ProfileUsernameCtrl($rootScope, $scope, $state, $timeout, $ionicHistory, LocalStorage, LocalStorageKeys,BooleanConstant, ProfileServices, WebServiceCache, PopupUtil, $translate) {
    // SCOPE FUNCTIONS
    $scope.saveProfile = saveProfile;

    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    // FUNCTIONS
    function ionicViewBeforeEnter() {
        $scope.profileData = LocalStorage.getObject(LocalStorageKeys.PROFILE_DATA);
    }
    
     /*
        name: saveProfile
        desc: Saves updated user name to local storage and server.
    */ 
    function saveProfile() {
        $rootScope.updateMenuHeader = true;
        //$rootScope.needToSaveProfile = BooleanConstant.BOOL_TRUE;
        ProfileServices.saveProfile("", $scope.profileData).then(function (response) {
            WebServiceCache.cleanseCache(2);
            LocalStorage.setObject(LocalStorageKeys.PROFILE_DATA, $scope.profileData);
            $ionicHistory.goBack();
        }, function (error) {
            PopupUtil.showSimpleAlert($translate.instant('error'),$translate.instant(error.data['i18n-key']));
        });
    }
}
