angular.module('controllers')
    .controller('InsuranceInvoiceDetailsCtrl', InsuranceInvoiceDetailsCtrl);
function InsuranceInvoiceDetailsCtrl($rootScope, $state, $scope, $stateParams, InsuranceServices,PopupUtil,LoggerUtilType, QuoteServices, $filter, LoadingUtil, LocalStorage, LocalStorageKeys,$translate) {
    // SCOPE VARIABLES
    // --> All scope variables that are specific to that view will be defined here
    $scope.invoice = {};
    $scope.safe_interest = {};
    $scope.safe_other = {};
    $scope.aggressive = {};
    $scope.dangerous = {};
    $scope.risky = {};

    // SCOPE FUNCTIONS
    // --> All scope functions specific to that view are defined here

    // SCOPE LIFE CYCLE
    // --> All needed life cycle events specific to that view are defined here. Note that we do not write the function directly in it.
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    $scope.$on('$ionicView.enter', ionicViewEnter);

    // FUNCTIONS
    /* 
        name : ionicViewBeforeEnter
        desc : Will call web services and prepare an object for the screen
    */
    function ionicViewBeforeEnter() {
        $scope.segmentColors=LocalStorage.getObject(LocalStorageKeys.MILE_CATEGORY_COLOR);
        var invoiceId = $stateParams.invoiceId;
        var invoiceData = {
            'invoice_id': invoiceId
        }
        if ($scope.isPPM) {
            getInvoiceDetailsPPM(invoiceData);
        } else {
            getInvoiceDetailsRebate(invoiceData);
        }
    }

    /* 
        name : ionicViewEnter
        desc : Will call web services and prepare an object for the screen every time user enters the screen
    */
    function ionicViewEnter() {
        
    }

    function getInvoiceDetailsPPM(invoiceData) {
        LoadingUtil.showLoader();
        InsuranceServices.getInvoice(invoiceData).then(function(response) {
            $scope.invoice = response.data;
            $scope.issued_date = $scope.formatDate($scope.invoice.issued_date);
            $scope.date_from = $scope.formatDate($scope.invoice.date_from);
            $scope.date_to = $scope.formatDate($scope.invoice.date_to);
            $scope.date_range = $scope.date_from.split(',')[0] + ' to ' + $scope.date_to;
            var policyInvoicePricings = $scope.invoice.policy_invoice_pricings[Object.keys($scope.invoice.policy_invoice_pricings)[0]];
            policyInvoicePricings['totalAmount'] = 0;
            for (var i = 0; i < policyInvoicePricings.length; i++) {
                policyInvoicePricings[i].distance = fixDecimals(policyInvoicePricings[i].distance, 1);
                policyInvoicePricings[i].unit_price = fixDecimals(policyInvoicePricings[i].unit_price, 3);
                policyInvoicePricings[i].amount = fixDecimals(policyInvoicePricings[i].unit_price * policyInvoicePricings[i].distance, 2);
                if (policyInvoicePricings[i].type === 'free_miles') {
                    policyInvoicePricings.totalAmount -= policyInvoicePricings[i].amount;
                    continue;
                }
                policyInvoicePricings.totalAmount += policyInvoicePricings[i].amount;
            }
            $scope.totalAmount = fixDecimals(policyInvoicePricings.totalAmount, 2);
            // webservice call to get available premiums/categories
            QuoteServices.getPremiums().then(function(response) {
                LoadingUtil.hideLoader();
                var premiums = response.data.data;
                premiums = $filter('orderBy')(premiums, 'id');
                var pricings = $filter('orderBy')(policyInvoicePricings, 'premium_id');
                for (var i = 0; i < premiums.length; i++) {
                    for (var j = 0; j < pricings.length; j++) {
                        if (premiums[j].id == pricings[j].premium_id) {
                            pricings[j]['type'] = premiums[j]['name']; 
                        }
                    }
                }
                for (var i = 0; i < pricings.length; i++) {
                    switch (pricings[i].type) {
                        case "safe_interstate":
                        $scope.safe_interest['unit_price'] = pricings[i].unit_price;
                        $scope.safe_interest['miles'] = pricings[i].distance;
                        $scope.safe_interest['amount'] = pricings[i].amount;
                        break;
                    case "safe_other":
                        $scope.safe_other['unit_price'] = pricings[i].unit_price;
                        $scope.safe_other['miles'] = pricings[i].distance;
                        $scope.safe_other['amount'] = pricings[i].amount;
                        break;
                    case "risky":
                        $scope.risky['unit_price'] = pricings[i].unit_price;
                        $scope.risky['miles'] = pricings[i].distance;
                        $scope.risky['amount'] = pricings[i].amount;
                        break;
                    case "aggressive":
                        $scope.aggressive['unit_price'] = pricings[i].unit_price;
                        $scope.aggressive['miles'] = pricings[i].distance;
                        $scope.aggressive['amount'] = pricings[i].amount;
                        break;
                    case "dangerous":
                        $scope.dangerous['unit_price'] = pricings[i].unit_price;
                        $scope.dangerous['miles'] = pricings[i].distance;
                        $scope.dangerous['amount'] = pricings[i].amount;
                        break;
                    case "free_miles":
                        $scope.freeMiles['unit_price'] = pricings[i].unit_price;
                        $scope.freeMiles['miles'] = pricings[i].distance;
                        $scope.freeMiles['amount'] = pricings[i].amount;
                    }
                }
                $scope.policyInvoicePricings = pricings;
            });
        }, function(error) {
             LoadingUtil.hideLoader();
              PopupUtil.showSimpleAlert($translate.instant('error'),$translate.instant(error['i18n-key']));
//             $scope.invoice = {
//                 "id": "dd80c9be-1d9b-4033-b424-aa052050fccf",
//                 "policy_id": "2df37577-167f-460c-99e8-39668972fae8",
//                 "reference_number": "2355 8374 3937",
//                 "date_from": "2016-02-01T00:00:00+0000",
//                 "date_to": "2016-02-29T00:00:00+0000",
//                 "issued_date": "2016-02-29T00:00:00+0000",
//                 "price": 0,
//                 "refund": 0,
//                 "policy_invoice_pricings": {
//                     "1c81f15c-f9f2-4f4e-80cf-f86f09a9e0f0": [
//                         {
//                             "id": "2c5c3626-9b1d-413b-b2b7-8ea4fd652ba9",
//                             "policy_invoice_id": "dd80c9be-1d9b-4033-b424-aa052050fccf",
//                             "distance": 0,
//                             "unit_price": 0.0604894,
//                             "vehicle_id": "1c81f15c-f9f2-4f4e-80cf-f86f09a9e0f0",
//                             "type": "safe_interstate"
//                         },
//                         {
//                             "id": "426547a1-3fe7-4641-a90d-139384efd7d7",
//                             "policy_invoice_id": "dd80c9be-1d9b-4033-b424-aa052050fccf",
//                             "distance": 0,
//                             "unit_price": 0.4835236,
//                             "vehicle_id": "1c81f15c-f9f2-4f4e-80cf-f86f09a9e0f0",
//                             "type": "risky"
//                         },
//                         {
//                             "id": "68a743de-2aaf-4cae-8856-a2440705f6a3",
//                             "policy_invoice_id": "dd80c9be-1d9b-4033-b424-aa052050fccf",
//                             "distance": 0,
//                             "unit_price": 0.1208809,
//                             "vehicle_id": "1c81f15c-f9f2-4f4e-80cf-f86f09a9e0f0",
//                             "type": "safe_other"
//                         },
//                         {
//                             "id": "a1e2cb42-0a22-4084-9dcc-e3041a3bf42d",
//                             "policy_invoice_id": "dd80c9be-1d9b-4033-b424-aa052050fccf",
//                             "distance": 0,
//                             "unit_price": 1.9340946,
//                             "vehicle_id": "1c81f15c-f9f2-4f4e-80cf-f86f09a9e0f0",
//                             "type": "dangerous"
//                         },
//                         {
//                             "id": "c3fb8cdd-d971-4d7c-a9b7-17c05b005a61",
//                             "policy_invoice_id": "dd80c9be-1d9b-4033-b424-aa052050fccf",
//                             "distance": 0,
//                             "unit_price": 0.2417618,
//                             "vehicle_id": "1c81f15c-f9f2-4f4e-80cf-f86f09a9e0f0",
//                             "type": "aggressive"
//                         }
//                     ]
//                 }
//             };
//             /*
//                 desciption : This is to format the dates in required format. 
//             */
//             $scope.invoice.issued_date = $scope.formatDate($scope.invoice.issued_date);
//             $scope.invoice.date_from = $scope.formatDate($scope.invoice.date_from);
//             $scope.invoice.date_to = $scope.formatDate($scope.invoice.date_to);
//             $scope.invoice['date_range'] = $scope.invoice.date_from.split(',')[0] + ' to ' + $scope.invoice.date_to;
// 
//             var policyInvoicePricings = $scope.invoice.policy_invoice_pricings[Object.keys($scope.invoice.policy_invoice_pricings)[0]];
//             policyInvoicePricings['totalAmount'] = 0;
//             for (var i = 0; i < policyInvoicePricings.length; i++) {
//                 policyInvoicePricings[i].distance = fixDecimals(policyInvoicePricings[i].distance, 1);
//                 policyInvoicePricings[i].unit_price = fixDecimals(policyInvoicePricings[i].unit_price, 3);
//                 policyInvoicePricings[i].amount = fixDecimals(policyInvoicePricings[i].unit_price * policyInvoicePricings[i].distance, 2);
//                 if (policyInvoicePricings[i].type === 'free_miles') {
//                     policyInvoicePricings.totalAmount -= policyInvoicePricings[i].amount;
//                     continue;
//                 }
//                 policyInvoicePricings.totalAmount += policyInvoicePricings[i].amount;
//             }
//             policyInvoicePricings.totalAmount = fixDecimals(policyInvoicePricings.totalAmount, 2);
//             for (var i = 0; i < policyInvoicePricings.length; i++) {
//                 switch (policyInvoicePricings[i].type) {
//                     case "safe_interstate":
//                         $scope.safe_interest['unit_price'] = policyInvoicePricings[i].unit_price;
//                         $scope.safe_interest['miles'] = policyInvoicePricings[i].distance;
//                         $scope.safe_interest['amount'] = policyInvoicePricings[i].amount;
//                         break;
//                     case "safe_other":
//                         $scope.safe_other['unit_price'] = policyInvoicePricings[i].unit_price;
//                         $scope.safe_other['miles'] = policyInvoicePricings[i].distance;
//                         $scope.safe_other['amount'] = policyInvoicePricings[i].amount;
//                         break;
//                     case "risky":
//                         $scope.risky['unit_price'] = policyInvoicePricings[i].unit_price;
//                         $scope.risky['miles'] = policyInvoicePricings[i].distance;
//                         $scope.risky['amount'] = policyInvoicePricings[i].amount;
//                         break;
//                     case "aggressive":
//                         $scope.aggressive['unit_price'] = policyInvoicePricings[i].unit_price;
//                         $scope.aggressive['miles'] = policyInvoicePricings[i].distance;
//                         $scope.aggressive['amount'] = policyInvoicePricings[i].amount;
//                         break;
//                     case "dangerous":
//                         $scope.dangerous['unit_price'] = policyInvoicePricings[i].unit_price;
//                         $scope.dangerous['miles'] = policyInvoicePricings[i].distance;
//                         $scope.dangerous['amount'] = policyInvoicePricings[i].amount;
//                         break;
//                 }
//             }
//             $scope.policyInvoicePricings = policyInvoicePricings;
        });
    }

    function getInvoiceDetailsRebate(invoiceData) {
        LoadingUtil.showLoader();
        InsuranceServices.getInvoice(invoiceData).then(function(response) {
            LoadingUtil.hideLoader();
            $scope.invoice = respone.data;
            //$scope.policyInvoicePricings = policyInvoicePricings;
        }, function(error) {
            LoadingUtil.hideLoader();
            PopupUtil.showSimpleAlert($translate.instant('error'),$translate.instant(error['i18n-key']));
            // $scope.invoice = {
            //     "id": "dd80c9be-1d9b-4033-b424-aa052050fccf",
            //     "policy_id": "2df37577-167f-460c-99e8-39668972fae8",
            //     "reference_number": "2355 8374 3937",
            //     "date_from": "2016-02-01T00:00:00+0000",
            //     "date_to": "2016-02-29T00:00:00+0000",
            //     "issued_date": "2016-02-29T00:00:00+0000",
            //     "price": 0,
            //     "refund": 0
            // }
            // /*
            //     desciption : This is to format the dates in required format. 
            // */
            // $scope.invoice.issued_date = $scope.formatDate($scope.invoice.issued_date);
            // $scope.invoice.date_from = $scope.formatDate($scope.invoice.date_from);
            // $scope.invoice.date_to = $scope.formatDate($scope.invoice.date_to);
            // $scope.invoice['date_range'] = $scope.invoice.date_from.split(',')[0] + ' to ' + $scope.invoice.date_to;
        });
    }

    function fixDecimals(val, number) {
        val = parseFloat(val.toFixed(number));
        return val;
    }
}