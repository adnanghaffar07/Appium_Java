angular.module('controllers')
    .controller('LeaderboardConnectFacebookCtrl', LeaderboardConnectFacebookCtrl);

function LeaderboardConnectFacebookCtrl($state, $rootScope, $scope, $ionicHistory,LocalStorage,LocalStorageKeys,SocialUserService) {
    // SCOPE VARIABLES


    // SCOPE FUNCTIONS
    $scope.connectFacebook = connectFacebook;
    $scope.accessFacebook = accessFacebook;
    // SCOPE LIFE CYCLE EVENTS

    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    // FUNCTIONS

    function ionicViewBeforeEnter() {

    }
    
    /*
        NAME : connectFacebook
        DESC : Connect to Facebook.
    */
    function connectFacebook(){
        accessFacebook();
        
    }
    
    /*
        NAME : accessFacebook
        DESC : Login user using facebook access token.
    */
    function accessFacebook() {
        var accessToken = LocalStorage.get(LocalStorageKeys.FB_ACCESS_TOKEN);
        if (accessToken && accessToken !== "null") {
            navigateTo();

        } else {
            SocialUserService.loginFacebookOAuth().then(function (response) {
                LocalStorage.set(LocalStorageKeys.FB_ACCESS_TOKEN,response.access_token);
                navigateTo();
            }, function (error) {

            });
        }
    }
    
    /*
        name : navigateTo.
        desc : Redirects to screen displaying list of user friends.
        param: redirect state. 
    */
    function navigateTo(route){
        $state.go("app.leaderboardAddFacebookFriends");
    }
}
