angular.module('controllers')
    .controller('ConsentCtrl', ConsentCtrl)
    .directive('scrollDetector', function ($window) {
        return {
            restrict: 'A',
            link: function ($scope, element, attrs, rootScope) {
                element.on('scroll', function () {
                    if ($('#is_scrolled_to_end').isOnScreen()) {
                        $('#consentsubmit').prop('disabled', false);
                    }
                });
            }
        };
    });

function ConsentCtrl($rootScope, $scope, $translate, $sce, GlobalConstants, LoginServices, AppDocumentServices, ConsentServices, LoadingUtil, PopupUtil, AppDocuments, ConsentStatus, LocalStorage, LocalStorageKeys, LoginType, AccountType, $state, SettingsServices, CordovaBroadcaster, ProfileServices, ProfileDataUtil, CommunicationService, OfflineLoginFactory, AppConfigServices, UserPrefLanguage, FirebaseService) {

    $scope.acceptClicked = acceptClicked;
    $scope.$on('$ionicView.loaded', ionicViewLoaded);
    var docId;

    function ionicViewLoaded() {
        $scope.isReachedBottom = false;
        // Load data for Dynamic Menu items
        AppConfigServices.getAppBehaviorSettings();
        AppDocumentServices.getDocument(AppDocuments.CONSENT_TEXT).then(function (response) {
            var preferedLanguage = LocalStorage.get(LocalStorageKeys.DEVICE_LOCALE_KEY);
            var defaultLanguage = LocalStorage.get(LocalStorageKeys.DEFAULT_LOCALE_KEY);
            var html = response['AppDocument'][preferedLanguage];
            if (!html) {
                html = response['AppDocument'][defaultLanguage];
            }

            $scope.consent = $sce.trustAsHtml(html);
            docId = response['AppDocument']['id'];
        }, function (error) {
            console.log(3);
            var buttons = [{
                text: '<span class="popupbtncolor"> ' + $translate.instant(error['common_OK']) + ' </span>'
            }];
            var vrError = $translate.instant(error['i18n-key']);
            if ($(".popup-title").html() != $translate.instant("noNetworkTitle")) {
                PopupUtil.showCustomPopupLocal("", "<h5 class='clsNoNetworkError'>" + $translate.instant('error') + "</h5><h6>" + vrError + "</h6>", buttons, "", true);
            }
        });


        FirebaseService.logEvent("view_item", {
            item_name: "Termos de Uso", 
            custom_dimension2: "Registro"
        });
    }

    function acceptClicked() {

        FirebaseService.logEvent("select_content", {
            content_type: "use_terms",
            item_name: "Termos de Uso", 
            custom_dimension2: "Registro"
        });

        LoadingUtil.showLoader();
        ConsentServices.recordConsent(true, docId, function (error) {
            if (error == null) {
                var socialLoginType = LocalStorage.get(LocalStorageKeys.ACCOUNT_TYPE, 'null');
                switch (socialLoginType) {
                    case AccountType.FACEBOOK:
                        fbLogin();
                        break;
                    case AccountType.GOOGLE:
                        gPlusLogin();
                        break;
                    default:
                        login();
                        break;
                }
                // Get Settings to recover onboarding and ltp settings
                var settingsObj = LocalStorage.getObject(SHA512(GlobalConstants.BASE_URL + "/getSettings"));

                // Check if Onboarding is enabled
                // ELSE : We check if LTP setting is enabled
                // ELSE : We then redirect to dashboard
                var onboarding = true;
                if (onboarding) {
                    $state.go('onboarding');
                } else {
                    var menuItems = LocalStorage.getObject(LocalStorageKeys.MENU_ITEMS);
                    $state.go(menuItems[0].state);
                }
            } else {
                LoadingUtil.hideLoader();
            }
        });
    }

    function login() {

        var email = LocalStorage.get(LocalStorageKeys.LOGIN_EMAIL);
        var password = LocalStorage.get(LocalStorageKeys.LOGIN_PASSWORD);


        LoginServices.login(email, password).then(function (result) {
            LocalStorage.set(LocalStorageKeys.LOGIN_TYPE, result.data.application_type_id);
            
            LocalStorage.set(LocalStorageKeys.ACCOUNT_TYPE, AccountType.NORMAL);
            OfflineLoginFactory.saveLoginCredentials(result.data.application_type_id, LocalStorage.get(LocalStorageKeys.LOGIN_EMAIL), LocalStorage.get(LocalStorageKeys.LOGIN_PASSWORD));
            
            prepareProfileData(result.data.application_type_id);
            
            prepareUserSettings();
            prepareCommunicationSettings();
        });
    }

    /*
        NAME : fbLogin
        DESC : Logged in as with facebook account and navigates to dashboard.
    */
    function fbLogin() {
        var userData = LocalStorage.getObject(LocalStorageKeys.SOCIAL_META);
        
        var application_mode = LocalStorage.get(LocalStorageKeys.APP_MODE);
        var email = LocalStorage.get(LocalStorageKeys.LOGIN_EMAIL);
        var userID = LocalStorage.get(LocalStorageKeys.SOCIAL_USER_ID);
        var accessToken = LocalStorage.get(LocalStorageKeys.ACCESS_TOKEN);

        jsonParams = {
            mode: application_mode,
            User: {
                facebook_id: userID,
                access_token: accessToken,
                email: email
            }
        };

        LoginServices.facebookLogin(jsonParams).then(function (result) {
            prepareProfileData(result.application_type_id);
            prepareUserSettings();
            prepareCommunicationSettings();
            LocalStorage.set(LocalStorageKeys.LOGIN_TYPE, result.application_type_id);
            LocalStorage.set(LocalStorageKeys.ACCOUNT_TYPE, AccountType.FACEBOOK);
        }, function (error) {
            PopupUtil.showSimpleAlert($translate.instant('error'), $translate.instant(error['i18n-key']));
        });
    }

    /*
      NAME : gPlusLogin
      DESC : Logged in as with Google Plus account and navigates to dashboard.
  */
    function gPlusLogin() {
        //        var userData = LocalStorage.getObject(LocalStorageKeys.SOCIAL_META);
        var jsonParams = {
            User: {
                googleplus_id: LocalStorage.get(LocalStorageKeys.SOCIAL_USER_ID),
                access_token: LocalStorage.get(LocalStorageKeys.ACCESS_TOKEN)
            }
        };
        LoginServices.googleLogin(jsonParams).then(function (result) {
            prepareProfileData(result.application_type_id);
            prepareUserSettings();
            prepareCommunicationSettings();
            LocalStorage.set(LocalStorageKeys.LOGIN_TYPE, result.application_type_id);
            LocalStorage.set(LocalStorageKeys.ACCOUNT_TYPE, AccountType.GOOGLE);
        }, function (error) {
            PopupUtil.showSimpleAlert($translate.instant('error'), $translate.instant(error['i18n-key']));
        });

    }

    /*
     NAME : prepareCommunicationSettings
     DESC : Gets User communication settings
    */
    function prepareCommunicationSettings() {
        CommunicationService.getCommunicationOptions().then(function (pResponse) {
            var response = pResponse.data;
            // Hard coded true values, as webservices is not yet ready to send all values as true by default.
            if (angular.isArray(response) && response.length == 0) {
                response = {
                    "hbr_sound": true,
                    "hac_sound": true,
                    "contest_push": true,
                    "trip_push": true
                };
            }
            CordovaBroadcaster.updateTripNotification(response.trip_push);
            CordovaBroadcaster.setContestNotification(response.contest_push);
            CordovaBroadcaster.setHardBreakingBeep(response.hbr_sound);
            CordovaBroadcaster.setHardAccelerationBeep(response.hac_sound);
            LocalStorage.set(LocalStorageKeys.LOCAL_SETTINGS, JSON.stringify(response));
        });
    }

    /*
        NAME: prepareProfileData
        DESC: Call profile web services and build profileData that will be used in the entire app.
    */
    function prepareProfileData(pMode) {
        var state;
        var isTBYB;

        var menuItems = LocalStorage.getObject(LocalStorageKeys.MENU_ITEMS);
        
        if (menuItems) {
            state = menuItems[0].state;
        } else {
            state = "app.dashboardPorto";
        }

        switch (pMode) {
            case LoginType.TBYB_PPM:
                isTBYB = true;
                break;
            case LoginType.UBI_PPM:
                isTBYB = false;
                break;
            case LoginType.TBYB_RB:
                isTBYB = true;
                break;
            case LoginType.UBI_RB:
                isTBYB = false;
                break;
        }

        if (isTBYB) {

            ProfileServices.getProfile().then(function (pRawData) {

                FirebaseService.logEvent("sign_up", {
                    content_type: "register",
                    item_name: "Registro", 
                    custom_dimension1: pRawData.User.id, 
                    custom_dimension2: "Registro",
                    custom_dimension3: "0", 
                    custom_dimension4: "0",
                    custom_dimension6: LocalStorage.get(LocalStorageKeys.ACCOUNT_TYPE)
                });


                ProfileDataUtil.createProfileData(pRawData);
                $rootScope.$emit("CallBindProfData", {});
                //                $state.go(state);
                LoadingUtil.hideLoader();
            }, function (error) {
                // error
                console.log('ERROR IN SET PROFILE DATA', error);
            });

            
        } else {

            var login = LocalStorage.get(LocalStorageKeys.LOGIN_EMAIL);
            var password = LocalStorage.get(LocalStorageKeys.LOGIN_PASSWORD);

            var account_type = LocalStorage.get(LocalStorageKeys.ACCOUNT_TYPE);
            
            var jsonParams;

            if (account_type === AccountType.NORMAL) {
                jsonParams = {
                    email: login,
                    password: password
                };
            }

            if (account_type === AccountType.GOOGLE) {
                jsonParams = {
                    email: login,
                    access_token: LocalStorage.get(LocalStorageKeys.GOOGLE_ACCESS_TOKEN)
                };
            }

            if (account_type === AccountType.FACEBOOK) {
                jsonParams = {
                    email: login,
                    user_secret: LocalStorage.get(LocalStorageKeys.FACEBOOK_USER_SECRET)
                };
            }

            LoginServices.loginPas(jsonParams).then(function (response) { 
                LocalStorage.set(LocalStorageKeys.PAS_USER_TOKEN, response.data.token);

                ProfileServices.getProfile().then(function (responseProfile) {

                    LoadingUtil.hideLoader();

                    ProfileServices.getProfileData_client(responseProfile).then(function (pRawData) {

                        var auto_jovem = '0';
                        if (pRawData.User && pRawData.User.marketing_list_id && pRawData.User.marketing_list_id === "59fb7aa0-95f4-4874-9b35-0b5e0a020037") {
                            auto_jovem = '1';
                        }

                        FirebaseService.logEvent("sign_up", {
                            content_type: "register",
                            item_name: "Registro", 
                            custom_dimension1: pRawData.User.id, 
                            custom_dimension2: "Registro",
                            custom_dimension3: auto_jovem, 
                            custom_dimension4: "1",
                            custom_dimension6: LocalStorage.get(LocalStorageKeys.ACCOUNT_TYPE)
                        });

                        ProfileDataUtil.createProfileData(pRawData);
                        var policy_id = pRawData.VehicleProfile.policy_id;
                        LocalStorage.set(LocalStorageKeys.POLICY_ID, policy_id);
                        
                    }, function (error) {
                        // error
                        console.log('ERROR IN SET PROFILE DATA', error);
                    });
                }, function (error) {
                    // error
                    console.log('ERROR IN SET PROFILE DATA', error);
                });
            });
        }
    }

    function prepareUserSettings() {
        SettingsServices.getUserSettings().then(function (settings) {
            var use_phone_data = (settings.use_phone_data === '1' ? true : false);
            //            var language = angular.isDefined(settings.language) ? settings.language : UserPrefLanguage.English;
            var auto_start = settings.auto_start;
            if (angular.isDefined(use_phone_data)) {
                CordovaBroadcaster.changeUseOnlyWifi(use_phone_data);
            }
            //            if (language) {
            //                $translate.use(language);
            //                CordovaBroadcaster.setLocaleKey(language);
            //            }
            if (angular.isDefined(auto_start)) {
                var start = false;
                var autoStart = "On";
                if (auto_start === '1') {
                    start = true;
                    autoStart = "On";
                } else if (auto_start === '0') {
                    autoStart = "Off";
                } else if (auto_start === '2') {
                    autoStart = "Charging";
                }
                CordovaBroadcaster.setAutoStartValue(start, autoStart);
            }
            LocalStorage.setObject(LocalStorageKeys.USER_APP_SETTINGS, settings);
        });
    }
}
