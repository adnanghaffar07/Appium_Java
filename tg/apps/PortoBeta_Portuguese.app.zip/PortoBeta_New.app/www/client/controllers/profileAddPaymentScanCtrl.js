angular.module('controllers')
    .controller('ProfileAddPaymentScanCtrl', ProfileAddPaymentScanCtrl);

function ProfileAddPaymentScanCtrl($rootScope, $scope, $state,  $ionicHistory) {
    // SCOPE FUNCTIONS
    $scope.goToCardDetails = goToCardDetails;
    
    //SCOPE VARIABLES
    
    
    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    // FUNCTIONS
      /* 
        name : ionicViewBeforeEnter
        desc : Make a call to webservice to fetch data and bind object.
    */
    function ionicViewBeforeEnter() {
        
    }
    
    /* 
        name : goToCardDetails
        desc : Get scanned data and navigate to payment card details screen.
    */
    function goToCardDetails(){
        $scope.navigateTo("app.profileAddPaymentCardDetails");
    }
}