angular.module('controllers')
    .controller('TripHistoryCtrl', TripHistoryCtrl);

function TripHistoryCtrl($rootScope, $state, $scope, TripsServices, DateUtil, LoggerUtilType, PopupUtil, StringUtil, LoadingUtil, LocalStorage, LocalStorageKeys, WebServiceCache, $translate, FirebaseService) {
    // SCOPE FUNCTIONS
    ////////////////////////////////////////////////////////////////////////////
    $scope.goToDetails = goToDetails;
    $scope.goToCalendar = goToCalendar;
    $scope.goToTripTypes = goToTripTypes;

    var tripTypesData = [];

    TripsServices.getTripTypes().then(function (response) {
        tripTypesData = response;
    }, function (error) {
        //handle error
    });

    // SCOPE LIFE CYCLE
    ////////////////////////////////////////////////////////////////////////////
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    $scope.$on('$ionicView.enter', ionicViewEnter);

    function ionicViewEnter() {
        FirebaseService.logEvent("view_item", {
            item_name: "Histórico de viagens", 
            custom_dimension2: "Histórico de viagens",
            custom_dimension5: LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID) !== null ? "logged in" : "logged out"
        });
    }


    // FUNCTIONS
    ////////////////////////////////////////////////////////////////////////////

    /*
        NAME : ionicViewBeforeEnter
        DESC : Life cycle event of ionic. Called before the controller loads
    */
    function ionicViewBeforeEnter() {
        //$scope.hasTrip = true; // SET TO TRUE TO SEE TRIP LIST AND FALSE TO SEE EMPTY TRIPS VIEW
        $rootScope.activeMenuItem = "tripHistory";
        $scope.appMode = LocalStorage.get(LocalStorageKeys.LOGIN_TYPE);

        //Commented here as it is in menuCtrl.
        var lastTripId = LocalStorage.get(LocalStorageKeys.LAST_TRIP_ID, "null");

        TripsServices.getNewTripNotif(lastTripId).then(function (data) {
            if (lastTripId != "null") {
                if (lastTripId != data.trip_id) {
                    LocalStorage.set(LocalStorageKeys.LAST_TRIP_ID, data.trip_id);
                    WebServiceCache.cleanseCache(1);
                    getTripsList();
                } else {
                    getTripsList();
                }
            } else if (data.trip_id != "" && data.trip_id != null) {
                LocalStorage.set(LocalStorageKeys.LAST_TRIP_ID, data.trip_id);
                WebServiceCache.cleanseCache(1);
                getTripsList();
            } else {
                getTripsList();
            }
        }, function (error) {
            getTripsList();
        });
    }

    /*
        Name: goToDetails
        Desc: Go to trip history details screen.
        param : trip id for respective trip
    */
    function goToDetails(pTrip) {
        // WE WILL SEND THE TRIP ID IN PARAMETER
        if ($scope.isPPM) {
            $state.go('app.tripHistoryDetailsPpm', {
                "trip_id": pTrip.id,
                "tripTypesData": tripTypesData
            });
        } else {
            $state.go('app.tripHistoryDetails', {
                "trip_id": pTrip.id,
                "tripTypesData": tripTypesData
            });
        }
    }

    /*
        Name: GoToCalendar
        Desc: Based on mode, go to PPM Calendar or RB Calendar
    */
    function goToCalendar() {
        if ($scope.isPPM) {
            $state.go('app.tripHistoryCalendarPpm');
        } else {
            $state.go('app.tripHistoryCalendar');
        }
    }

    /*
        NAME : goToTripTypes
        DESC : Redirect user to the Trip Types selection screen
    */
    function goToTripTypes(pTripId) {
        $state.go('app.selectTripType', {
            list: tripTypesData,
            tripId: pTripId
        });
    }

    /*
        Name: getTripsList
        Desc: Fetching the list of trips.
    */
    function getTripsList() {
        var today = new Date();
        today.setDate(today.getDate() + 1);
        var lastmonth = new Date().add(-2).month();

        if (true) {//$scope.isTBYB) {
            LoadingUtil.showLoader();
            TripsServices.getTrips(lastmonth, today, true).then(function (response) {
                LoadingUtil.hideLoader();

                getTripHistoryCallback(response.data.data);

                // if ($scope.isPPM) {
                //     if (angular.isDefined(response.data.data)) {
                //         getTripHistoryPPMCallback(response.data.data);
                //     } else if (angular.isDefined(response.data.trips)) {
                //         getTripHistoryPPMCallback(response.data.trips);
                //     } else {
                //         getTripHistoryPPMCallback(response.data);
                //     }

                // } else {
                //     getTripHistoryCallback(response.data.data);
                // }
            }, function (error) {
                LoadingUtil.hideLoader();
                PopupUtil.showSimpleAlert($translate.instant("error"), $translate.instant(error.data['i18n-key']));
            });
        } else {

            if ($scope.profileData) {

                var vehicleId = $scope.profileData.cars[0].id;

                LoadingUtil.showLoader();
                TripsServices.getTripsByVehicleId(lastmonth, today, vehicleId).then(function (response) {
                    LoadingUtil.hideLoader();
                    if ($scope.isPPM) {
                        getTripHistoryPPMCallback(response.data.data);
                    } else {
                        getTripHistoryCallback(response.data.data);
                    }
                }, function (error) {
                    LoadingUtil.hideLoader();
                    PopupUtil.showSimpleAlert($translate.instant("error"), $translate.instant(error.data['i18n-key']));
                });
            }
        }
    }

    /*
        Name: getTripHistoryPPMCallback
        Desc: process the trip data for a PPM mode as per the requirement.
    */
    function getTripHistoryPPMCallback(data) {
        
        for (var i = 0; i < data.length; i++) {
            data[i].distance = Math.round(data[i].distance * 10) / 10;
            if ($scope.isTBYB) {
                data[i].tripTypeIcon = getTransportTypeIcon(data[i].trip_type.id);
            }
            if (angular.isDefined(data[i].end_time)) {
                data[i].day = moment(DateUtil.formatDateAsUTC(StringUtil.getdateinformat(data[i].end_time))).format("dddd MMMM D");
                data[i].endTime = moment(DateUtil.formatDateAsUTC(data[i].end_time)).format("h:mm a");
            } else {
                data[i].end_time = data[i].date;
                data[i].day = moment(DateUtil.formatDateAsUTC(StringUtil.getdateinformat(data[i].date))).format("dddd MMMM D");
            }

            // Calculate trip duration
            var time = moment(data[i].end_time).format('X') - moment(data[i].start_time).format('X');
            var hours = Math.floor(time / 3600);
            var minutes = Math.floor(time % 3600 / 60);
            data[i].duration_hours = hours;
            data[i].duration_minutes = minutes;
            ////////////////////////////////
        }
        $scope.tripsList = data;
    }

    /*
        Name: getTripHistoryCallback
        Desc: process the trip data for a RB mode user as per the requirement.
    */
    function getTripHistoryCallback(data) {

        if (angular.isUndefined(data)) {
            $scope.tripsList = [];
        } else {
            angular.forEach(data, function (type, index) {
                type.startTime = DateUtil.formatDateAsUTC(type.start_time);
                type.endTime = DateUtil.formatDateAsUTC(type.end_time);
                type.distance = Math.round(type.distance * 10) / 10;
                type.day = moment(DateUtil.formatDateAsUTC(StringUtil.getdateinformat(type.endTime))).format("dddd");
                type.currentDay = moment(DateUtil.formatDateAsUTC(StringUtil.getdateinformat(type.endTime))).format("D");
                type.month = moment(DateUtil.formatDateAsUTC(StringUtil.getdateinformat(type.endTime))).format("MMMM");
                type.endTime = moment(DateUtil.formatDateAsUTC(StringUtil.getdateinformat(type.endTime))).format("H:mm");
                type.tripTypeIcon = './client/images/transports/' + type.trip_type.name + '.svg';
                
                var time = moment(type.end_time).format('X') - moment(type.start_time).format('X');
                var hours = Math.floor(time / 3600);
                var minutes = Math.floor(time % 3600 / 60);
                type.duration_hours = hours;
                type.duration_minutes = minutes;
            })

            $scope.tripsList = data;
        }
    }
}
