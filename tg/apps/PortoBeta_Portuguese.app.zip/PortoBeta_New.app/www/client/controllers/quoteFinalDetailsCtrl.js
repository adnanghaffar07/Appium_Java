angular.module('controllers')
    .controller('QuoteFinalDetailsCtrl', QuoteFinalDetailsCtrl);

function QuoteFinalDetailsCtrl($rootScope, $state, $scope, $timeout, QuoteStatus, BooleanConstant, QuoteServices, LocalStorageKeys, LocalStorage, ApiStatusCode, PopupUtil, LoadingUtil, WebServiceCache, $translate) {
    // SCOPE VARIABLES
    // --> All scope variables that are specific to that view will be defined here

    /*
        name : requiredFields
        use  : It is a list of fields in template that are to be validated.
    */
    var requiredFields = ['email', 'mobile_number'];
    $scope.finalDetails = {};
    var defaultDetails = {
        email: $scope.profileData.user.email,
        canText: BooleanConstant.FALSE,
        multiPolicy: BooleanConstant.TRUE
    }

    // SCOPE FUNCTIONS
    // --> All scope functions specific to that view are defined here
    $scope.goState = goState;

    // SCOPE LIFE CYCLE
    // --> All needed life cycle events specific to that view are defined here. Note that we do not write the function directly in it.
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    // FUNCTIONS
    /* 
         name : ionicViewBeforeEnter
         desc : Will prepopulate the data in GAQ-Final details screen with user data filled in his profile.
     */
    function ionicViewBeforeEnter() {
        var filledDetails = $rootScope.quoteData.finalDetails;
        if (filledDetails) {
            filledDetails = JSON.parse(JSON.stringify(filledDetails));
        }
        $scope.finalDetails = filledDetails || defaultDetails;
        if ($rootScope.steps.final.length == 0) {
            $rootScope.steps.final = QuoteStatus.PROCESS;
        }
    }

    /*
        name   :  validateData
        params :  An object.
        desc   :  Will check for null and empty values in the given object
        return :  It will return true if all mandatory fields are filled, 
                  and false if any fields listed in mandatory fields array are not filled.
    */
    function validateData(data) {
        var isError = BooleanConstant.BOOL_FALSE;
        if (data) {
            for (var i = 0; i < requiredFields.length; i++) {
                console.log(78787878, data[requiredFields[i]]);
                if (angular.isUndefined(data[requiredFields[i]]) || data[requiredFields[i]] === '' || data[requiredFields[i]] === null) {
                    console.log(123123123, data[requiredFields[i]]);
                    isError = BooleanConstant.BOOL_TRUE;
                    break;
                }
            };
        } else {
            isError = BooleanConstant.BOOL_TRUE;
        }
        return isError;
    }

    /*
        name   :  goState
        params :  state number ex: 1 for about, 2 for vehicles etc.
        desc   :  Will validate the details and navigate the user to required state.
    */
    function goState(route) {
        $scope.submitted = BooleanConstant.BOOL_TRUE;
        var error = validateData($scope.finalDetails);
        if (!error) {
            // Webservice call to create a quote with all the details given by the user.
            var quoteData = formatQuoteData($rootScope.quoteData);
            LoadingUtil.showLoader();
            QuoteServices.createQuote(quoteData).then(function (response) {
                LoadingUtil.hideLoader();
                WebServiceCache.cleanseCache(8);
                var vrQuoteID = response.data.data.id;
                LocalStorage.setObject(LocalStorageKeys.QUOTE_ID, vrQuoteID);
                $scope.navigateTo(route);
            }, function (error) {
                LoadingUtil.hideLoader();
                //$scope.navigateTo(route);
                var buttons = [
                    {
                        text: "OK",
                        onTap: function (e) {}
                    }];
                if (angular.isDefined(error.data['i18n-key'])) {
                    if (error.status == ApiStatusCode.METHOD_NOT_ALLOWED && $rootScope.networkStatus.isAvailable == false) {
                        // no network
                    }
                } else {
                    PopupUtil.showCustomPopupLocal("", "<h5>" + $translate.instant("fill_all_drivers_vehicles") + "</h5>", buttons, "", true);
                }
                return false;
            })
            $rootScope.quoteData.finalDetails = $scope.finalDetails;
            $rootScope.steps.final = QuoteStatus.DONE;
        }
    }

    //Jquery methods.
    $timeout(function (e) {
        $('.btn-radio-gaq').buttonset();
    }, 100);


    /*
        name   :  formatQuoteData
        params :  pQuoteData
        desc   :  Format the rootsocpe data as per quote create input request.
    */
    function formatQuoteData(pQuoteData) {
        var quoteDatils = {};
        quoteDatils.user_id = pQuoteData.user.id;
        quoteDatils.gender = pQuoteData.user.gender[0];
        quoteDatils.first_name = pQuoteData.user.first_name;
        quoteDatils.last_name = pQuoteData.user.last_name;
        quoteDatils.date_of_birth = moment(pQuoteData.user.date_of_birth).format('YYYY-MM-DD');

        quoteDatils.quote_vehicles = [];
        pQuoteData.vehicles[0].annual_mileage = parseInt($rootScope.quoteData.annual_mileage.replace(',', ''))
        quoteDatils.quote_vehicles.push(pQuoteData.vehicles[0]);
        quoteDatils.quote_vehicles[0].address = {};
        quoteDatils.quote_vehicles[0].address.street_number = pQuoteData.user.street_number;
        quoteDatils.quote_vehicles[0].address.street_name = pQuoteData.user.street_name;
        quoteDatils.quote_vehicles[0].address.zip_code = pQuoteData.user.postal_code;
        quoteDatils.quote_vehicles[0].address.state = pQuoteData.user.state;
        quoteDatils.quote_vehicles[0].address.city = pQuoteData.user.city_name;
        quoteDatils.quote_vehicles[0].address.country = "USA";

        quoteDatils.quote_vehicles[0].quote_drivers = [];
        quoteDatils.quote_vehicles[0].quote_drivers = pQuoteData.drivers;


        console.log(66666666, quoteDatils);

        return quoteDatils;
    }
}
