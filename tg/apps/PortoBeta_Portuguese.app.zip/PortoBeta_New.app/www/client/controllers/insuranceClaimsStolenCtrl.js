angular.module('controllers')
    .controller('InsuranceClaimsStolenCtrl', InsuranceClaimsStolenCtrl);

function InsuranceClaimsStolenCtrl($state, $rootScope, $scope, InsuranceServices, PopupUtil, BooleanConstant, LoggerUtilType, $translate, LoadingUtil) {

    // SCOPE FUNCTIONS

    //SCOPE VARIABLES
    $scope.submitClaim = submitClaim;
    $scope.stolenVehicle = {};
    //var vrValue = '';

    // Events
    $scope.$watchGroup(['stolenVehicle.license', 'stolenVehicle.make', 'stolenVehicle.model', 'stolenVehicle.year', 'stolenVehicle.vin'], validateForm);

    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    // FUNCTIONS
    ////// Functionality when before entering into the view
    /*
        name : ionicViewBeforeEnter
        desc : will do the data binding to the scope before entering into the view
               Get the vehicle details and populate the details
    */
    function ionicViewBeforeEnter() {
        $scope.stolenVehicle = $rootScope.userVehicles[0];
        $rootScope.claimDetails.claim_id = $rootScope.claimDetails.claim_id;
        $rootScope.claimDetails.vehicle_id = $rootScope.userVehicles[0].id;
    }

    /*
        name : submitClaim
        desc : Submit the claim with the claim data.
    */
    function submitClaim() {
        LoadingUtil.showLoader();
        var claimData = $rootScope.claimDetails;
        InsuranceServices.submitClaim(claimData).then(function (response) {
            LoadingUtil.hideLoader();
            notifyAuthoritiesAlert();
        }, function (error) {
            LoadingUtil.hideLoader();
            PopupUtil.showSimpleAlert($translate.instant('error'), $translate.instant(error['i18n-key']));
        });
    }


    /*
       name : validateForm
       desc : Validate the form input details and handle enable / disable the submit button.
       parameters : newvalues, oldvalues, scope
       response : It'll set the formvalid to true / false based on the input values
   */
    function validateForm(newValues, oldValues, scope) {
        if (newValues[0] && newValues[1] && newValues[2] && newValues[3] && newValues[4]) {
            $scope.formValid = BooleanConstant.BOOL_TRUE;
        } else {
            $scope.formValid = BooleanConstant.BOOL_FALSE;
        }
    }

    /*
        name : notifyAuthoritiesAlert
        desc : It'll show the the notify authorities alert
    */
    function notifyAuthoritiesAlert() {
        var buttons = [{
            text: '<span> Ok </span>',
            onTap: function (e) {
                $state.go('app.insuranceClaims')
            }
        }];
        PopupUtil.showCustomPopupLocal("", "<h4>" + $translate.instant("please_notify") + "</h4> <h4>" + $translate.instant("the_authorities") + "</h4>", buttons, "", true);
    }
}
