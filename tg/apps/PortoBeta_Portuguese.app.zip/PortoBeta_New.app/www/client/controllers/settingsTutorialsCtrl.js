angular.module('controllers')
    .controller('TutorialsCtrl', TutorialsCtrl);

function TutorialsCtrl($state, $scope, $translate, AppDocumentServices, AppDocuments, $sce, PopupUtil, LoggerUtilType, LocalStorage, LocalStorageKeys) {

    // SCOPE VARIABLES
    // --> All scope variables that are specific to that view will be defined here

    // SCOPE FUNCTIONS
    // --> All scope functions specific to that view are defined here


    // SCOPE LIFE CYCLE
    // --> All needed life cycle events specific to that view are defined here. Note that we do not write the function directly in it.
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    $scope.$on('$ionicView.enter', ionicViewEnter);

    // FUNCTIONS
    /* 
        name : ionicViewBeforeEnter
        desc : Will call web services and prepare an object for the screen
    */

    ////// Functionality when before entering into the view
    /* 
        name : ionicViewBeforeEnter
        desc : It will fetch the tutorials conetent before enter into the view 
    */
    function ionicViewBeforeEnter() {
        AppDocumentServices.getDocument(AppDocuments.TUTORIALS).then(function (response) {
            var preferedLanguage = $translate.use();
            var html = response['AppDocument'][preferedLanguage];
            if (!html) {
                var defaultLanguage = LocalStorage.get(LocalStorageKeys.DEFAULT_LOCALE_KEY);
                html = response['AppDocument'][defaultLanguage];
            }
            $scope.tutorialsContent = $sce.trustAsHtml(html);
        }, function (error) {
            PopupUtil.showSimpleAlert($translate.instant('error'), $translate.instant(error['i18n-key']));
        });
    }

    ////// Functionality when entering into the view
    function ionicViewEnter() {

    }
}
