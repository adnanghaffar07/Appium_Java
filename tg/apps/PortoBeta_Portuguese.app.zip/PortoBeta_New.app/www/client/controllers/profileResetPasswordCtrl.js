angular.module('controllers')
    .controller('ProfileResetPasswordCtrl', ProfileResetPasswordCtrl);

function ProfileResetPasswordCtrl($scope, $state, LocalStorage, LocalStorageKeys, PopupUtil,LoginServices,LoadingUtil,$translate) {
    // SCOPE FUNCTIONS
    $scope.resetPassword = resetPassword;

    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    // FUNCTIONS
    function ionicViewBeforeEnter() {
        
    }

    /*
        name:resetPassword
        desc: Show the success alert after resetting the password.
    */ 
    function resetPassword(){
        LoadingUtil.showLoader();
       var vrEmail = $scope.profileData.user.email;
       LoginServices.forgotPasswordNew(vrEmail).then(function () {
            LoadingUtil.hideLoader();
            onSuccess();
        }, function (error) {
            LoadingUtil.hideLoader();
            error = error.data;
            var title = 'Error !';
            var template = $translate.instant(error["i18n-key"]);
            PopupUtil.showSimpleAlert(title, template);
        });
    }
    
    /*
        name: onSuccess
        desc: Displays success message on updation of password.
    */ 
    function onSuccess() {
        var vrEmail = $scope.profileData.user.email;
        var buttons = [{
            text: '<span> Ok </span>',
            onTap: function (e) {
                $state.go('app.profile');
            }
        }];
        PopupUtil.showCustomPopupLocal("", "<i class='ion-checkmark-circled clspopupcheckmark'></i> "+$translate.instant("check_your_mailbox")+"</h4>"+$translate.instant("have_sent_email")+vrEmail+". "+$translate.instant("check_spam") , buttons, "", true);
    }
}
