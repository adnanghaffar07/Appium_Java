angular.module('controllers')
    .controller('QuoteReceiptCtrl', QuoteReceiptCtrl);
function QuoteReceiptCtrl($rootScope, $state, $scope, LocalStorage, LocalStorageKeys, $stateParams, LoginType) {
    // SCOPE VARIABLES
    // --> All scope variables that are specific to that view will be defined here
   
    // SCOPE FUNCTIONS
    // --> All scope functions specific to that view are defined here
    $scope.goBackToMainScreen = goBackToMainScreen; 
    
    // SCOPE LIFE CYCLE
    // --> All needed life cycle events specific to that view are defined here. Note that we do not write the function directly in it.
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    $scope.$on('$ionicView.enter', ionicViewEnter);
 
    // FUNCTIONS
    /* 
        name : ionicViewBeforeEnter
        desc : Will call web services and prepare an object for the screen
    */
    function ionicViewBeforeEnter() {
         $scope.purchaseDetails = LocalStorage.getObject(LocalStorageKeys.BUY_PACKAGE_DETAILS);
         $scope.receiptData = $stateParams.receipt;
    }
    
    function ionicViewEnter() {
        
    }
    
    /*
        name : goBackToMainScreen
        desc : It will redirect the user to main screen of GAQ.
    */
    function goBackToMainScreen() {
        var state;
        var pMode = LocalStorage.get(LocalStorageKeys.LOGIN_TYPE);
        switch (pMode) {
            case LoginType.UBI_PPM:
                state = 'app.dashboardPpm';
                break;
            case LoginType.UBI_RB:
                state = 'app.dashboard';
                break;
        }
        $state.go(state);
    }
}