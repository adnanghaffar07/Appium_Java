angular.module('controllers')
    .controller('ProfilePictureZoomCtrl', ProfilePictureZoomCtrl);

function ProfilePictureZoomCtrl($rootScope, $scope, $stateParams,BooleanConstant,UploadImage,CameraUtil,CameraCapture,InsuranceServices) {
    // SCOPE FUNCTION
    $scope.optionSelected = optionSelected;
    $scope.showFooter = showFooter;
    
    // SCOPE VARIABLES
    $scope.selPicture = $stateParams.specificPicture;
    $scope.showPictureOverlay =BooleanConstant.BOOL_FALSE;
    var cameraOptions = CameraCapture.IMAGE_SIZE;
    var imageData={};
    
    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    $scope.$on('$ionicView.loaded', ionicViewLoaded);
    

    // FUNCTIONS
    /*
        name : ionicViewBeforeEnter
        desc : will do the data binding to the scope before entering into the view
    */
    function ionicViewBeforeEnter() {
        
    }
    
    /*
        name : ionicViewLoaded
        desc : Loads data after current page loads.
    */
    function ionicViewLoaded(){
         $scope.pictitle =$scope.selPicture.title;
         $scope.fullImage=$scope.selPicture.image;
    }
    
    // Function to navigate to People involved list screen after saving data.
    /*
        name : optionSelected
        parameter:Selected option
        desc : (Take Picture / Choose from Gallery / Cancel)
    */
    function optionSelected(option) {
        if (option == UploadImage.CANCEL) {
            $scope.showPictureOverlay = BooleanConstant.BOOL_FALSE;
        }else if(option == UploadImage.DELETE){
            $rootScope.deleteSpecificPic=$scope.selPicture.index;
            $scope.showPictureOverlay = BooleanConstant.BOOL_FALSE;
            $scope.goBack();
        }else if(option==UploadImage.TAKE){
            takePhoto();
        }else if(option==UploadImage.CHOOSE){
            chooseFromLibrary();
        }
    }
    
     /*
        name   :  takePhoto  
        desc   :  It opens camera to take photo.
    */
    function takePhoto() {
        $scope.showPictureOverlay  = BooleanConstant.BOOL_FALSE;
        CameraUtil.takePicture(cameraOptions).then(function (image) {
            processImage(image);
        });
    }
    /*
        name   :  chooseFromLibrary  
        desc   :  It shows images in Gallery.
    */
    function chooseFromLibrary() {
        $scope.showPictureOverlay  = BooleanConstant.BOOL_FALSE;
        CameraUtil.getPicture(cameraOptions).then(function (image) {
            processImage(image);
        });
    }
    
     /*
        name   :  processImage  
        desc   :  It will save saves picture to server.
    */
    function processImage(img){
        imageData.image = UploadImage.BASE_64 + img;
            imageData.title = "";
            $rootScope.updatedPic={imageKey:imageData.image,
                                      index:$scope.selPicture.index
                   
               }
        InsuranceServices.postPicture(imageData).then(function (response) {       
            //   $rootScope.updatedPic={imageKey:"123",
            //                          index:$scope.selPicture.index
            //       
            //   }
            }, function (error) {

            });
    }
    
     /*
        name   :  showFooter  
        desc   :  Displays footer and options of (Take Picture / Choose from Gallery / Cancel).
    */
    function showFooter(){
        $scope.showPictureOverlay = BooleanConstant.BOOL_TRUE;
    }
}
