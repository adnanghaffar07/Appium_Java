angular.module('controllers')
    .controller('NoLocationServiceCtrl', NoLocationServiceCtrl);

function NoLocationServiceCtrl($state, $scope, $rootScope, $ionicHistory, $ionicPlatform, $timeout, CordovaBroadcaster, ListenerUtil, BridgeIntentType, CordovaReceiver, FirebaseService, LocalStorageKeys, LocalStorage) {
    $scope.openLocationSettings = openLocationSettings;

    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    $scope.$on('$ionicView.enter', ionicViewEnter);

    $rootScope.$on(BridgeIntentType.GPS_STATE, onGpsStateChanged);

    function ionicViewBeforeEnter() {
        validateGeolocalisationService();
    }

    function ionicViewEnter() {

        // send to firebase that user has gps error
        FirebaseService.logEvent("view_item", {
            item_name: "GPS Desabilitado", 
            custom_dimension2: "GPS Desabilitado",
            custom_dimension5: LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID) !== null ? "logged in" : "logged out"
        });
    }

    /*
        NAME: openLocationSettings
        DESC : Sends Native intent to open phone's settings
    */
    function openLocationSettings() {

        // send to firebase that user has gps error
        FirebaseService.logEvent("select_content", {
            content_type: "access_config",
            item_name: "GPS Desabilitado", 
            custom_dimension2: "GPS Desabilitado",
            custom_dimension5: LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID) !== null ? "logged in" : "logged out"
        });

        CordovaBroadcaster.openLocationSettings();
    }

    /*
        NAME : validateGeolocalisationService
    */
    function validateGeolocalisationService() {
        var options = {
            timeout: 5000
        };
        navigator.geolocation.getCurrentPosition(onLocationSuccess, onLocationFailed, options);
    }

    function onLocationSuccess() {
        $rootScope.locationStatus.isAvailable = true;

        // TODO : CHECK THE USER MODE TO REDIRECT TO THE RIGHT DASHBOARD OR ANY CUSTOM DASHBOARD
        $ionicHistory.goBack();
    }

    function onLocationFailed() {
        $rootScope.locationStatus.isAvailable = false;
    }

    function onGpsStateChanged(pEvent, pExtras) {
        if (pExtras.gps_state) {
            onLocationSuccess();
        }
    }

    $ionicPlatform.registerBackButtonAction(function (event) {
        event.preventDefault();
    }, 100);
}
