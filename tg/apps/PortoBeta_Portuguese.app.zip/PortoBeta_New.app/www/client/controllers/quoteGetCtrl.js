angular.module('controllers')
    .controller('QuoteGetCtrl', QuoteGetCtrl);

function QuoteGetCtrl($rootScope, $state, $scope, $timeout, BooleanConstant, QuoteServices, LoadingUtil, PopupUtil, LoggerUtilType, WebServiceCache,$translate, LocalStorageKeys, LocalStorage) {
    // SCOPE VARIABLES
    // --> All scope variables that are specific to that view will be defined here
    //    $scope.hasQuotes = true;
    //    $scope.quoteItems = [{
    //        "vehicle": "Volkswagen",
    //        "model": "GTI 2015",
    //        "value": "$106.50"
    //    },
    //        {
    //            "vehicle": "Honda",
    //            "model": "Civic 2015",
    //            "value": "Incomplete"
    //        },
    //        {
    //            "vehicle": "Honda",
    //            "model": "Civic 2015",
    //            "value": "$91.25"
    //        },
    //        {
    //            "vehicle": "Audi",
    //            "model": "A3 2015",
    //            "value": "$121.75"
    //        }];
    $rootScope.steps = {};

    // SCOPE FUNCTIONS
    // --> All scope functions specific to that view are defined here
    $scope.goToQuoteAbout = goToQuoteAbout;
    $scope.deleteQuote = deleteQuote;
    $scope.goToSimulation = goToSimulation;
    $scope.viewQuoteDetails =viewQuoteDetails;


    // SCOPE LIFE CYCLE
    // --> All needed life cycle events specific to that view are defined here. Note that we do not write the function directly in it.
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    // FUNCTIONS
    /* 
        name : ionicViewBeforeEnter
        desc : Will call web services and prepare an object for the screen
    */
    function ionicViewBeforeEnter() {
        $scope.hasQuotes = true;
        $rootScope.activeMenuItem = "gaq";
        $rootScope.steps = {
            'about': '',
            'vehicle': '',
            'drivers': '',
            'final': '',
            'yourquote': ''
        };
        getQuotes();
    }

    function goToQuoteAbout() {
        $rootScope.quoteData = {
            vehicles: {},
            drivers: []
        };

        $rootScope.quoteData.drivers[0] = {};
        $state.go("app.quote.quoteAbout");
    }

    function goToSimulation(qId) {
        $state.go('app.quoteSimulation', {
            quoteId: qId
        });
    }

    /* 
        name : deleteQuote
        desc : Delete the quote based on quote id
    */
    function deleteQuote(quoteId) {
        QuoteServices.deleteQuote(quoteId).then(function (response) {
            WebServiceCache.cleanseCache(8);
            getQuotes();
        }, function (error) {
            PopupUtil.showSimpleAlert($translate.instant('error'),$translate.instant(error['i18n-key']));
        });
    }

    /* 
        name : getQuotes
        desc : Get list quotes 
    */
    function getQuotes() {
        LoadingUtil.showLoader();
        QuoteServices.getQuotes().then(function (response) {
            LoadingUtil.hideLoader();
            if (response.data.data.length > 0) {
                $scope.hasQuotes = true;
            } else {
                $scope.hasQuotes = false;
            }
            $scope.quoteItems = response.data.data;
        }, function (error) {
            $scope.hasQuotes = false;
            LoadingUtil.hideLoader();
            PopupUtil.showSimpleAlert($translate.instant('error'),$translate.instant(error['i18n-key']));
        });
    }

    function viewQuoteDetails(quote) {
        console.log(quote);
        LocalStorage.setObject(LocalStorageKeys.QUOTE_ID, quote.id);
        $state.go("app.quote.quoteYourQuote", {
            "createdQuote" : true
        });
    }
}
