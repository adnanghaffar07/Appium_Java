angular.module('controllers')
    .controller('ContestRulesCtrl', ContestRulesCtrl);

function ContestRulesCtrl($state, $scope, $translate, AppDocumentServices, AppDocuments, $sce, LocalStorage, LocalStorageKeys) {

    // SCOPE VARIABLES
    // --> All scope variables that are specific to that view will be defined here
    // $scope.ContestRulesContent = "<h></h><h5>1. INTRODUCTION</h5><h></h><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis non lobortis nisl, et imperdiet tortor. Etiam feugiat purus sit amet risus laoreet, eget varius lacus lacinia. Donec et elit id elit luctus lobortis. Morbi at mi non mi pellentesque tristique. Aenean pellentesque nunc eget tellus blandit, eu feugiat metus consectetur. Morbi tristique tortor elit, sit amet euismod mi lacinia sed. In non ligula malesuada, interdum eros ac, iaculis justo. Suspendisse sit amet mollis massa, at maximus eros. Nam eu est ullamcorper, congue felis sit amet, interdum urna.</p><h></h><p>Sed egestas feugiat tempor. Sed porttitor laoreet dictum. Pellentesque in varius purus, nec laoreet odio. Fusce quis consectetur tellus. Praesent tortor dolor, accumsan a diam ut, cursus ultrices magna. Fusce vitae rutrum augue. Sed sit amet molestie sem, pulvinar eleifend leo. Aliquam blandit, mauris eu mollis mollis, nisi neque varius enim, in pulvinar nunc elit non nulla. Sed nec blandit ipsum, at molestie mi. Donec luctus lectus a massa vestibulum commodo. Nullam vel sapien eu felis porttitor sagittis nec ac diam. Morbi non porta nulla. Nam tempus rutrum justo, et mattis sem posuere at.</p>"

    // SCOPE FUNCTIONS
    // --> All scope functions specific to that view are defined here


    // SCOPE LIFE CYCLE
    // --> All needed life cycle events specific to that view are defined here. Note that we do not write the function directly in it.
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    $scope.$on('$ionicView.enter', ionicViewEnter);

    // FUNCTIONS
    /* 
        name : ionicViewBeforeEnter
        desc : Will call web services and prepare an object for the screen
    */

    ////// Functionality when before entering into the view
    /* 
        name : ionicViewBeforeEnter
        desc : It will fetch the contest rules conetent before enter into the view 
    */
    function ionicViewBeforeEnter() {
        AppDocumentServices.getDocument(AppDocuments.CONTEST_RULE).then(function (response) {
            var preferedLanguage = $translate.use();
            var html = response['AppDocument'][preferedLanguage];
            if (!html) {
                var defaultLanguage = LocalStorage.get(LocalStorageKeys.DEFAULT_LOCALE_KEY);
                html = response['AppDocument'][defaultLanguage];
            }
            $scope.ContestRulesContent = $sce.trustAsHtml(html);
        });
    }

    ////// Functionality when entering into the view
    function ionicViewEnter() {

    }
}
