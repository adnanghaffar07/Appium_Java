angular.module('controllers')
    .controller('TripHistoryCalendarCtrl', TripHistoryCalendarCtrl);

function TripHistoryCalendarCtrl($rootScope, $scope, $ionicHistory, LocalStorage, LocalStorageKeys, CordovaBroadcaster, $ionicSlideBoxDelegate, TripDefaultValues, TripsUtil, ScoresServices, DOMUtil, LoadingUtil, $compile, DateUtil, AppDocumentServices, $translate, $sce) {
    // SCOPE VARIABLES
    /*
        Faked the data for now.
    */
    $scope.selectedTab = 'score';
    var element = "distance-chart";
    var data = {};
    var vrCurDate = new Date();
    var vrCurYear = vrCurDate.getFullYear();
    var vrCurMonth = vrCurDate.getMonth();
    var vrCurMonthFirstDay = new Date(vrCurYear, vrCurMonth, 1);
    var vrMonthFirstDay = vrCurMonthFirstDay.getDay();
    var vrCurDay = vrCurDate.getDate();
    $scope.tripSelectedDate = moment(new Date()).format("dddd MMMM D, YYYY");
    $scope.dailyScore = {};
    $scope.showScoreDetails = false;
    $scope.vrWeeks = [{
        "weekday": "S"
    }, {
        "weekday": "M"
        }, {
        "weekday": "T"
        }, {
        "weekday": "W"
        }, {
        "weekday": "T"
        }, {
        "weekday": "F"
        }, {
        "weekday": "S"
        }];
    $scope.hac = 45;
    $scope.hbr = 30;
    $scope.hco = 10;
    $scope.spd = 20;
    $scope.tripDailyScores = {};
    var vrTripsList = [],
        vrTimeList = [],
        vrDistanceList = [];
    var options = {
        // Boolean - If we want to override with a hard coded scale
        scaleOverride: true,

        //  Required if scaleOverride is true 
        // Number - The number of steps in a hard coded scale
        scaleSteps: 3,
        // Number - The value jump in the hard coded scale
        scaleStepWidth: 25,
        // Number - The scale starting value
        scaleStartValue: 0,

        scaleLabel: "<%= value + ' % '%>",

        ///Boolean - Whether grid lines are shown across the chart
        scaleShowGridLines: true,

        //String - Colour of the grid lines
        scaleGridLineColor: "rgba(0,0,0,0.1)",

        //Number - Width of the grid lines
        scaleGridLineWidth: 0.5,

        //Boolean - Whether to show horizontal lines (except X axis)
        scaleShowHorizontalLines: true,

        //Boolean - Whether to show vertical lines (except Y axis)
        scaleShowVerticalLines: false,

        //Boolean - Whether the line is curved between points
        bezierCurve: true,

        //Number - Tension of the bezier curve between points
        bezierCurveTension: 0.4,

        //Boolean - Whether to show a dot for each point
        pointDot: true,

        //Number - Radius of each point dot in pixels
        pointDotRadius: 5,

        //Number - Pixel width of point dot stroke
        pointDotStrokeWidth: 3,

        //Number - amount extra to add to the radius to cater for hit detection outside the drawn point
        pointHitDetectionRadius: 20,

        //Boolean - Whether to show a stroke for datasets
        datasetStroke: true,

        //Number - Pixel width of dataset stroke
        datasetStrokeWidth: 2,

        //Boolean - Whether to fill the dataset with a colour
        datasetFill: true,

        // Boolean - Determines whether to draw tooltips on the canvas or not
        showTooltips: false
    }


    // SCOPE FUNCTION
    $scope.changeTab = changeTab;
    $scope.slideHasChanged = slideHasChanged;


    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    $scope.$on('$ionicView.enter', ionicViewEnter);

    // FUNCTIONS
    function ionicViewBeforeEnter() {
        LoadingUtil.showLoader();
        var vrMonthDates = TripsUtil.getMonthStartEndDates();
        ScoresServices.getDailyScores(vrMonthDates.StartDate, vrMonthDates.EndDate, getDailyScoresSuccessCallback, getDailyScoresErrorCallback);
        ScoresServices.getOverallScores(vrMonthDates.StartDate, vrMonthDates.EndDate, getOverallScoresSuccessCallback, getDailyScoresErrorCallback);
    }

    function ionicViewEnter() {
        getTripDetailsText();
    }

    /*
        Name: slideHasChanged
        Desc: Handles sliding event. Updates the view after slide.
        Param: pI, pScoreData
    */
    function slideHasChanged(pI, pScoreData) {
        var container = null;
        var score = null;
        var yAxislabels = 3;
        var yAxislabelsData = 0;
        switch (pI) {
            case 0:
                $scope.selectedTab = 'score';
                break;
            case 1:
                yAxislabelsData = Math.max.apply(null, vrDistanceList);
                if (Math.round(yAxislabelsData) > 3) {
                    yAxislabels = Math.round(yAxislabelsData);
                }
                $scope.selectedTab = 'distance';
                element = "distance-chart";
                options.scaleLabel = "<%= value + ' km '%>";
                options.scaleStepWidth = Math.ceil((yAxislabels / 3).toFixed(1));
                setupChart(element, '', vrDistanceList);
                break;
            case 2:
                yAxislabelsData = Math.max.apply(null, vrTimeList);
                if (Math.round(yAxislabelsData) > 3) {
                    yAxislabels = Math.round(yAxislabelsData);
                }
                $scope.selectedTab = 'time';
                element = "time-chart";
                options.scaleLabel = "<%= value + ' min '%>";
                options.scaleStepWidth = Math.ceil((yAxislabels / 3).toFixed(1));
                setupChart(element, '', vrTimeList);
                break;
            case 3:
                yAxislabelsData = Math.max.apply(null, vrTripsList);
                if (Math.round(yAxislabelsData) > 3) {
                    yAxislabels = Math.round(yAxislabelsData);
                }
                $scope.selectedTab = 'trips';
                element = "trips-chart";
                options.scaleLabel = "<%= value + ' trips '%>";
                options.scaleStepWidth = Math.ceil((yAxislabels / 3).toFixed(1)),
                    setupChart(element, '', vrTripsList);
                break;
        }
    }

    /*
        Name: changeTab
        Desc: Use de slidebox delegate to force sliding to a given index.
        Param: pI
    */
    function changeTab(pI) {
        $ionicSlideBoxDelegate.$getByHandle('dataSlider').slide(pI);
    }


    function setupChart(element, type, yAxisLabels) {
        //elementId = "#" + element;
        $("#" + element).css("width", $scope.windowwidth - 20);
        $("#" + element).css("height", $scope.windowwidth * 0.8);

        var vrTodayDate = new Date();
        var vrCurYear = vrTodayDate.getFullYear();
        var vrCurMonth = vrTodayDate.getMonth();
        var days = new Date(vrCurYear, vrCurMonth + 1, 1, -1).getDate();
        var xAxisData = [];
        for (var i = 0; i <= days; i++) {
            xAxisData.push(i);
        }

        var chartData = {
            Xs: xAxisData
        };

        var fillRgbObject = hexToRgb($rootScope.themeColors.mainBackground);

        data = {
            labels: chartData.Xs,
            datasets: [{
                fillColor: "rgba(" + fillRgbObject.r + "," + fillRgbObject.g + "," + fillRgbObject.b + ", 0.3)",
                strokeColor: "rgba(" + fillRgbObject.r + "," + fillRgbObject.g + "," + fillRgbObject.b + ", 0.3)",
                pointColor: $rootScope.themeColors.mainBackground,
                pointStrokeColor: $rootScope.themeColors.textPrimary,
                pointStrokeWidth: 10,
                data: yAxisLabels
            }]
        };

        Chart.types.Line.extend({
            name: "LineAlt",
            initialize: function (data) {
                Chart.types.Line.prototype.initialize.apply(this, arguments);
                var xLabels = this.scale.xLabels;
                for (var i = 0; i < xLabels.length; i++)
                    if (i % 10 != 0)
                        xLabels[i] = '';
            }
        });

        var ctx = document.getElementById(element).getContext("2d");
        new Chart(ctx).LineAlt(data, options);
    }

    function hexToRgb(hex) {
        var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
        return result ? {
            r: parseInt(result[1], 16),
            g: parseInt(result[2], 16),
            b: parseInt(result[3], 16)
        } : null;
    }

    /*
        Name: getDailyScoresSuccessCallback
        Desc: Process the data 
        param : Daily aggregates response.
    */

    function getDailyScoresSuccessCallback(response) {
        LoadingUtil.hideLoader();
        if (angular.isDefined(response.data.data)) {
            response = response.data.data;
        } else if (angular.isDefined(response.data.DailyScores)) {
            response = response.data.DailyScores.data;
        } else {
            response = response.data;
        }
        $scope.tripDailyScores = response;
        prepareCalendar(response);
    }

    /*
        Name: getOverallScoresSuccessCallback
        Desc: Process the data 
        param : Daily aggregates response.
    */

    function getOverallScoresSuccessCallback(response) {
        LoadingUtil.hideLoader();
        if (angular.isDefined(response.data.data)) {
            $scope.overAllScores = response.data.data;
        } else {
            $scope.overAllScores = response.data;
        }
        var pUserCreatedDate = $scope.profileData.user.created_on;
        var vrSubscriptionDateDiff = DateUtil.getDateDiff(moment(pUserCreatedDate));

        if (vrSubscriptionDateDiff > 30) {
            $scope.avgScore = parseInt($scope.overAllScores.score_average / 30);
            $scope.avgTrips = Math.round(parseInt($scope.overAllScores.trip_count / 30));
            $scope.avgTime = parseInt($scope.overAllScores.duration / (30 * 60));
            $scope.avgDistance = parseInt($scope.overAllScores.distance / 30);
        } else if (!angular.isUndefined($scope.overAllScores.score_average) || $scope.overAllScores.score_average != null) {
            $scope.avgScore = parseInt($scope.overAllScores.score_average / vrSubscriptionDateDiff);
            $scope.avgTrips = Math.round(Math.floor($scope.overAllScores.trip_count / vrSubscriptionDateDiff * 10) / 10);
            $scope.avgTime = parseInt($scope.overAllScores.duration / (vrSubscriptionDateDiff * 60));
            $scope.avgDistance = Math.floor($scope.overAllScores.distance / vrSubscriptionDateDiff * 10) / 10;
        } else {
            $scope.avgScore = 0;
            $scope.avgTrips = 0;
            $scope.avgTime = 0;
            $scope.avgDistance = 0;
        }
    }

    /*
        Name: prepareCalendar
        Desc: prepares the calendar and process the data of the daily aggregates.
        param : Daily aggregates data.
    */
    function prepareCalendar(pResponse) {
        var vrNoOfDaysPerWeek = TripDefaultValues.TOTAL_DAYS;
        var vrTodayDate = new Date();
        var vrCurYear = vrTodayDate.getFullYear();
        var vrCurMonth = vrTodayDate.getMonth();
        var vrCurMonthFirstDay = new Date(vrCurYear, vrCurMonth, 1);
        var vrMonthFirstDay = vrCurMonthFirstDay.getDay();
        var days = new Date(vrCurYear, vrCurMonth + 1, 1, -1).getDate();
        var vrTotalDays = vrMonthFirstDay + days;
        $scope.calendarContent = '<div class="row">';
        var calendarContent = $scope.calendarContent;
        var vrTtlDays = (parseInt(vrTotalDays / vrNoOfDaysPerWeek) * vrNoOfDaysPerWeek) + vrNoOfDaysPerWeek;
        var vrDateToCheck = moment(new Date(vrCurYear, vrCurMonth, 1)).format("YYYY-MM-DD");
        var j = 1;
        var maxScore = '',
            maxScoreValue = 0;
        var noOfDaysHasTrips = 0;
        for (var i = 1; i <= vrTtlDays; i++) {
            if (i % vrNoOfDaysPerWeek == 0 && i <= vrTotalDays) {
                if (pResponse[vrDateToCheck] && angular.isDefined(pResponse[vrDateToCheck].distance)) {
                    if (angular.isDefined(pResponse[vrDateToCheck].score_average)) {
                        //maxScore = getMaxScore(pResponse[vrDateToCheck].score_details)[0];
                        maxScoreValue = pResponse[vrDateToCheck].score_average.toFixed(0);
                    }
                    calendarContent += '<div class="col"><div class="has-trip" data-attr=' + vrDateToCheck + '>' + maxScoreValue + '</div></div></div><div class="row">';
                    noOfDaysHasTrips += 1;
                    $scope.dailyScore = pResponse[vrDateToCheck];
                    $scope.tripSelectedDate = moment(new Date(vrDateToCheck)).format("dddd MMMM D, YYYY");
                    vrTripsList.push(pResponse[vrDateToCheck].trip_count);
                    vrTimeList.push(pResponse[vrDateToCheck].duration / 60);
                    vrDistanceList.push(pResponse[vrDateToCheck].distance);
                } else {
                    calendarContent += '<div class="col"><i class="ion-record"></i></div></div><div class="row">';
                    if (new Date(vrDateToCheck) < vrTodayDate) {
                        vrTripsList.push('');
                        vrTimeList.push('');
                        vrDistanceList.push('');
                    }
                }
                vrDateToCheck = moment(new Date(vrCurYear, vrCurMonth, ++j)).format("YYYY-MM-DD");
            } else if (i <= vrMonthFirstDay || i > vrTotalDays) {
                calendarContent += '<div class="col"><i></i></div>';
            } else {
                if (pResponse[vrDateToCheck] && angular.isDefined(pResponse[vrDateToCheck].distance)) {
                    if (angular.isDefined(pResponse[vrDateToCheck].score_average)) {
                        //maxScore = getMaxScore(pResponse[vrDateToCheck].score_details)[0];
                        maxScoreValue = pResponse[vrDateToCheck].score_average.toFixed(0);
                    }
                    vrTripsList.push(pResponse[vrDateToCheck].trip_count);
                    vrTimeList.push(pResponse[vrDateToCheck].duration / 60);
                    vrDistanceList.push(pResponse[vrDateToCheck].distance);
                    calendarContent += '<div class="col"><div class="has-trip" data-attr=' + vrDateToCheck + '>' + maxScoreValue + '</div></div>';
                    $scope.dailyScore = pResponse[vrDateToCheck];
                    $scope.tripSelectedDate = moment(new Date(vrDateToCheck)).format("dddd MMMM D, YYYY");
                    noOfDaysHasTrips += 1;
                } else {
                    calendarContent += '<div class="col"><i class="ion-record"></i></div>';
                    if (new Date(vrDateToCheck) < vrTodayDate) {
                        vrTripsList.push('');
                        vrTimeList.push('');
                        vrDistanceList.push('');
                    }
                }
                vrDateToCheck = moment(new Date(vrCurYear, vrCurMonth, ++j)).format("YYYY-MM-DD");
            }
        }
        $scope.calendarContent = calendarContent + '</div>';
        var divTemplate = $scope.calendarContent;
        $compile(divTemplate)($scope);
        angular.element(document.getElementById('showCalendarContent')).append(divTemplate);

        DOMUtil.onElementReady('body', 100).then(function () {
            $('.col div.has-trip').css('background-color', $rootScope.themeColors.mainBackground);
            $($('.col div.has-trip')[noOfDaysHasTrips - 1]).css('background-color', $rootScope.themeColors.textMain);
            if (noOfDaysHasTrips > 0) {
                $scope.showScoreDetails = true;
            }
        });
    }

    /*
        Name: getDailyScoresErrorCallback
        Desc: Error call back of get daily aggregates.
    */
    function getDailyScoresErrorCallback() {
        LoadingUtil.hideLoader();
    }

    /*
        Name: getMaxScore
        Desc: prepares the calendar and process the data of the daily aggregates.
        param : pScoresList - List of score details
        output : return the list of soreted data based on the score in descresing order.
    */
    function getMaxScore(pScoresList) {
        var vrScoresList = pScoresList;
        return Object.keys(vrScoresList).sort(function (a, b) {
            return vrScoresList[a] - vrScoresList[b]
        }).reverse()
    }

    /*
        Desc : Onclick of has-trip functionaliy - show the calendar trip details and it avegrage score details when click on avg score value.
    */
    $('body').on('click', '.has-trip', function () {
        $('.has-trip').css('background-color', $rootScope.themeColors.mainBackground);
        var selectedCalendarDate = $(this).attr("data-attr");
        $(this).css('background-color', $rootScope.themeColors.textMain);
        $scope.dailyScore = $scope.tripDailyScores[selectedCalendarDate];
        $scope.$apply(function () {
            $scope.tripSelectedDate = moment(new Date(selectedCalendarDate)).format("dddd MMMM D, YYYY");
        });
    });

    /*
        Name: getTripDetailsText
        Desc: Webservice call to get the document in trip history screen
    */
    function getTripDetailsText() {
        AppDocumentServices.getDocument("tripDistanceDetailsText").then(function (response) {
            var preferedLanguage = $translate.use();
            var html = response['AppDocument'][preferedLanguage];
            $scope.trip_distance_details = $sce.trustAsHtml(html);
        }, function (error) {

        });
        AppDocumentServices.getDocument("tripTimeDetailsText").then(function (response) {
            var preferedLanguage = $translate.use();
            var html = response['AppDocument'][preferedLanguage];
            $scope.trip_time_details = $sce.trustAsHtml(html);
        }, function (error) {

        });
        AppDocumentServices.getDocument("tripTripsDetailsText").then(function (response) {
            var preferedLanguage = $translate.use();
            var html = response['AppDocument'][preferedLanguage];
            $scope.trip_trips_details = $sce.trustAsHtml(html);
        }, function (error) {

        });
    }
}
