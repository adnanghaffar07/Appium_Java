angular.module('controllers')
    .controller('LeaderboardCtrl', LeaderboardCtrl);

function LeaderboardCtrl($state, $rootScope, $scope, $timeout, $ionicSlideBoxDelegate, GamingServices, PopupUtil, LoggerUtilType, $translate, LoadingUtil, LocalStorage, LocalStorageKeys, $ionicScrollDelegate, BooleanConstant, $ionicListDelegate, BackGround, $stateParams, FirebaseService ) {

    var selectedTab = 0;

    $scope.selectedTab = 0;
    $scope.friendsList = [];
    $scope.communityList = [];
    $scope.contentHeight = $(window).height() - $('.bar-header').height() - $('section#selector').height() - 15;
    
    $scope.tabClicked = tabClicked;

    $scope.noFriends = false;

    $scope.$on('$ionicView.loaded', ionicViewLoaded);
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    function ionicViewBeforeEnter() {
        $rootScope.activeMenuItem = "leaderboard";
        $scope.achievement = $stateParams.achievement;

        FirebaseService.logEvent("view_item", {
            item_name: "Ranking Amigos", 
            custom_dimension2: "Ranking",
            custom_dimension5: LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID) !== null ? "logged in" : "logged out"
        });
    }

    function ionicViewLoaded() {
        $scope.user_id = LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID);

        $scope.update();
    }

    $scope.update = function () {
        $scope.noFriends = false;
        LoadingUtil.showLoader();
        GamingServices.getRankings().then(function (response) {
            LoadingUtil.hideLoader();
            $scope.friendsList = response.friends;
            $scope.communityList = response.community;

            if ($scope.noFriends.length === 0) {
                $scope.noFriends = true;
            } else {
                $scope.noFriends = false;
            }

        }, function (error) {
            LoadingUtil.hideLoader();
        });
    }

    $scope.lockSlide = function () {
        $ionicSlideBoxDelegate.enableSlide( false );
    }
    /*
        Name : tabClicked
        Desc : Change the Selected Tab, Slides the slider and load the right content
    */
    function tabClicked(pTab) {
        $scope.selectedTab = pTab;
        $ionicSlideBoxDelegate.$getByHandle('leaderboardSlideBox').slide(pTab);

        var tab = "Ranking Amigos";

        if (pTab === 1) {
            tab = "Ranking Comunidade";         
        }

        if (pTab !== selectedTab) {
            FirebaseService.logEvent("view_item", {
                item_name: tab, 
                custom_dimension2: "Ranking",
                custom_dimension5: LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID) !== null ? "logged in" : "logged out"
            });

            selectedTab = pTab
        }
    }

    $scope.goToAddFriends = function () {
        $state.go('app.leaderboardAddSearch');
    }

    $scope.deleteFriend = function(id) {
        PopupUtil.confirmPopup($translate.instant('remove_user_title'), $translate.instant('remove_user_description_question'), function(res) {
            if(res) {
                $scope.removeFriend(id);
            }
        });
    }

    $scope.removeFriend = function(id) {
        
        var i = 0;

        // remove dinamicly
        angular.forEach($scope.friendsList, function (value, key) {
            if (value.id === id) {
                $scope.friendsList.splice(i, 1);
            }
            i++;
        });

        // api removal
        // if has error will add the user back and update list
        GamingServices.removeFriend({id: id}).then(function (response) {
            console.log(response);
            //$scope.update();
        }, function (error) {
            $scope.update();
        });
    }

    $scope.totalRecalc = function(total) {

        if (total > 999) {

            total = (total / 1000);

            var charsMax = total.toString().split('.');

            if (charsMax[1]) {
                total = charsMax[0] + "." + charsMax[1].substring(0, 2);
            }
        }

        return total;
    }
}
