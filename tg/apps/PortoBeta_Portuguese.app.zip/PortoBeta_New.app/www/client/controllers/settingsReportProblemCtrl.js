angular.module('controllers')
    .controller('ReportProblemCtrl', ReportProblemCtrl)
    .directive('customOnChange', function () {
        return {
            restrict: 'A',
            link: function (scope, element, attrs) {
                var onChangeHandler = scope.$eval(attrs.customOnChange);
                element.bind('change', onChangeHandler);
            }
        };
    });

function ReportProblemCtrl($state, $scope, $cordovaDevice, $timeout, PopupUtil, $ionicHistory, SettingsServices, $translate, LoadingUtil, CameraUtil, CameraCapture, FirebaseService, LocalStorage, LocalStorageKeys) {

    // SCOPE VARIABLES
    // --> All scope variables that are specific to that view will be defined here
    $scope.report = {
        "ProblemContent": ""
    };
    $scope.screenshotsCount = 0;
    $scope.charCount = 0;
    $scope.screenshots = [null, null, null, null, null];
    $scope.showFullscreenImage = false;
    $scope.fullImage = null;

    // SCOPE FUNCTIONS
    // --> All scope functions specific to that view are defined here
    $scope.submitReport = submitReport;
    $scope.choosePictureFromLibrary = choosePictureFromLibrary;
    $scope.openImage = openImage;
    $scope.closeImage = closeImage;
    $scope.removeImage = removeImage;
    $scope.fileChange = fileChange;

    // SCOPE LIFE CYCLE
    // --> All needed life cycle events specific to that view are defined here. Note that we do not write the function directly in it.
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    $scope.$on('$ionicView.enter', ionicViewEnter);
    $scope.$on('$ionicView.loaded', ionicViewLoaded);

    // FUNCTIONS
    /* 
        name : ionicViewBeforeEnter
        desc : Will call web services and prepare an object for the screen
    */

    ////// Functionality when before entering into the view
    /* 
        name : ionicViewBeforeEnter
        desc :  
    */
    function ionicViewBeforeEnter() {
    }

    ////// Functionality when entering into the view
    function ionicViewEnter() {

        $scope.profile = LocalStorage.getObject(LocalStorageKeys.PROFILE_DATA);

        console.log($scope.profile);

    }

    ////// Functionality when view is loaded
    function ionicViewLoaded() {

        FirebaseService.logEvent("view_item", {
            item_name: "Reportar problema", 
            custom_dimension2: "Reportar problema",
            custom_dimension5: LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID) !== null ? "logged in" : "logged out"
        });

        var h = $(window).height() - 45;
        $timeout(function () {
            $('ion-content#report-problem-content div.scroll').css('height', h + 'px');
        });
    }

    /*
        name : submitReport
        desc : submits the report content and show the success alert  
    */
    function submitReport() {

        FirebaseService.logEvent("select_content", {
            item_name: "Reportar problema", 
            content_type: "report_problem",
            custom_dimension2: "Reportar problema",
            custom_dimension5: LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID) !== null ? "logged in" : "logged out"
        });


        LoadingUtil.showLoader();

        var arr = [];
        for (var i = 0; i < $scope.screenshots.length; i++) {
            if ($scope.screenshots[i] != null) {
                arr.push($scope.screenshots[i]);
            }
        }

        console.log(44, arr);

        var obj = {
            screenshots: arr,
            description: $scope.report.ProblemContent,
            phone_model: ionic.Platform.platform(),
            os_version: ionic.Platform.version().toString(),
            timestamp: moment().format("YYYY-MM-DD HH:mm:ss"),
            user_id: $scope.profile.user.id,
            company_id: $scope.profile.user.company_id
        };

        SettingsServices.reportProblem(obj).then(function (response) {
            LoadingUtil.hideLoader();
            onSuccess();
        }, function (error) {
            LoadingUtil.hideLoader();
            PopupUtil.showSimpleAlert($translate.instant('error'), $translate.instant(error['i18n-key']));
        });

    }

    /*
       name : onSuccess
       desc : Gets executed on success callback.  
   */
    function onSuccess() {
        var buttons = [{
            text: '<span> Ok </span>',
            onTap: function (e) {
                $ionicHistory.goBack();
            }
        }];
        PopupUtil.showCustomPopupLocal("", "<h4>" + $translate.instant("thanks") + "</h4><h6>" + $translate.instant("one_of_technical_support_agent") + "</h6>", buttons, "", true);
    }

    /*
        name : choosePictureFromLibrary
        desc : Open native picture gallery so user can choose an image
    */
    function choosePictureFromLibrary(event) {
        if (!ionic.Platform.is('browser')) {
            CameraUtil.getPicture().then(function (image) {
                processImage(image);
            });
        } else {
            document.querySelectorAll('#fileInput')[0].click();
        }
    }

    /*
        name : processImage
        desc : Takes a Base64 image string and add it to the screenshot object
        @Param : pImg -> Base64 string
    */
    function processImage(pImg) {
        if ($scope.screenshotsCount < 5) {
            for (var i = 0; i < $scope.screenshots.length; i++) {
                if ($scope.screenshots[i] == null) {
                    $scope.screenshots[i] = pImg;
                    $scope.screenshotsCount++;
                    break;
                }
            }
        }
        console.log(777, $scope.screenshots);
    }

    /*
        name : openImage
        desc : Open the image in full screen
        @Param : repeater index (int)
    */
    function openImage(pI) {
        $scope.fullImage = {
            index: pI,
            src: $scope.screenshots[pI]
        };
        $scope.showFullscreenImage = true;
    }

    /*
        name : closeImage
        desc : Close the image in full screen
        @Param : repeater index (int)
    */
    function closeImage() {
        $scope.fullImage = null;
        $scope.showFullscreenImage = false;
    }

    /*
        name : removeImage
        desc : Remove the image from the list
        @Param : image index (int)
    */
    function removeImage(pI) {
        $scope.fullImage = null;
        $scope.showFullscreenImage = false;
        $scope.screenshots[pI] = null;
        $scope.screenshotsCount--;
    }

    function fileChange(event) {
        $scope.screenshots = [null, null, null, null, null];
        for (var i = 0; i < event.target.files.length; i++) {
            var reader = new FileReader();
            reader.addEventListener('load', function (index) {
                return function (event) {
                    var base64image = event.target.result.split(',')[1];
                    $scope.screenshots[index] = base64image;
                    $scope.$apply();
                };
            }(i));
            reader.readAsDataURL(event.target.files[i]);
        }
        $scope.screenshotsCount = event.target.files.length;
    }

    /*
        DETECT WHEN A KEY IS TYPED
    */
    $scope.$watch(function () {
        return $scope.report.ProblemContent;
    }, function (newValue) {
        $scope.charCount = newValue.length;
    });
}
