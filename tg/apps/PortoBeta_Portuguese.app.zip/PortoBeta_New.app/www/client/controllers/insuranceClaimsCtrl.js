angular.module('controllers')
    .controller('InsuranceClaimsCtrl', InsuranceClaimsCtrl);

function InsuranceClaimsCtrl($state, $rootScope, $scope, InsuranceServices, PopupUtil, LoggerUtilType, LoadingUtil, StringUtil, DateUtil, $translate) {
    // SCOPE FUNCTIONS
    $scope.goToNewClaim = goToNewClaim;
    $scope.goToInsurance = goToInsurance
   
    //SCOPE VARIABLES
    
    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    // FUNCITIONS
    ////// Functionality when before entering into the view
    /*
        name : ionicViewBeforeEnter
        desc : will do the data binding to the scope before entering into the view
    */
    function ionicViewBeforeEnter() {
        LoadingUtil.showLoader();
        getListofClaims(1);
    }
    
    ////// Function to navigate to new claim screen.
    /*
        name : goToNewClaim
        parameter:State value
        desc : It navigates to new claim screen.
    */
    function goToNewClaim() {
        $state.go("app.insuranceNewClaim");
    }

    /*
        name : getListofClaims
        parameter:pNumber
        desc : It'll fetch the list of claims details based on the page number.
        response : list of claims with the status, type and date of the claim
    */
    function getListofClaims(pNumber) {
        InsuranceServices.getClaims(pNumber).then(function (response) {
            LoadingUtil.hideLoader();
            for (var i = 0; i < response.length; i++) {
                response[i].date = moment(DateUtil.formatDateAsUTC(StringUtil.getdateinformat(response[i].created)).replace("+00:00","")).format("MMM. D, YYYY");
            }
            $scope.claims = response;
        }, function (error) {
            LoadingUtil.hideLoader();
            //             $scope.claims = $scope.claimsList
         PopupUtil.showSimpleAlert($translate.instant('error'),$translate.instant(error['i18n-key']));
        });
    }
    
    /*
        name : goToInsurance
        desc : It navigates to insurance screen
    */
    function goToInsurance() {
        $state.go("app.insurance");
    }
}
