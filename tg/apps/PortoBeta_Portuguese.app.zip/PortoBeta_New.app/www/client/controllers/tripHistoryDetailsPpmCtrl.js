angular.module('controllers')
    .controller('TripHistoryDetailsPpmCtrl', TripHistoryDetailsPpmCtrl);

function TripHistoryDetailsPpmCtrl($state, $scope, $stateParams, TripsServices, TripEventType, LoginType, MapsUtil, DateUtil, LocalStorage, LocalStorageKeys, LoggerUtilType, PopupUtil, LoadingUtil, StringUtil, $rootScope, WebServiceCache, $ionicHistory) {
    // SCOPE VARIABLES
    $scope.distance_per_category = {};

    // SCOPE FUNCTIONS
    $scope.showFullMap = showFullMap;
    $scope.closeFullMap = closeFullMap;
    $scope.changeTripType = changeTripType;
    $scope.setTripType = setTripType;
    $scope.tripTypeChanged = tripTypeChanged;


    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);


    // FUNCTIONS
    function ionicViewBeforeEnter() {
        var trip = $stateParams.trip_id;
        tripTypes = $stateParams.tripTypes;
        tripTypesData = $stateParams.tripTypesData;
        if (angular.isDefined($rootScope.tripTypeChange) && $rootScope.tripTypeChange) {
            if ($rootScope.selectedValue != null) {
                tripTypeChanged($rootScope.selectedValue, trip);
                $rootScope.selectedValue = null;
            }
        }
        $scope.isUBI_PPM = LocalStorage.get(LocalStorageKeys.LOGIN_TYPE) == LoginType.UBI_PPM ? true : false;
        $scope.segmentColors = LocalStorage.getObject(LocalStorageKeys.MILE_CATEGORY_COLOR);
        getSegmentColors();
        /// Fetch the segment colors
    }

    /*
        Name: getSegmentColors
        Desc: Fetch the segment colors to show the path in map
    */
    function getSegmentColors() {
        TripsServices.getSegmentsColors().then(function (colors) {
            var obj = colors.data;
            var segmentsOptions = [];
            for (var i = 0; i < obj.length; i++) {
                var option = {};
                switch (obj[i].type) {
                    case 'safe_interstate':
                        option.label = 'Safe Interstate';
                        option.type = 'safe_interstate';
                        break;
                    case 'safe_other':
                        option.label = 'Safe Other';
                        option.type = 'safe_other';
                        break;
                    case 'aggressive':
                        option.label = 'Aggressive';
                        option.type = 'aggressive';
                        break;
                    case 'risky':
                        option.label = 'Risky';
                        option.type = 'risky';
                        break;
                    case 'dangerous':
                        option.label = 'Dangerous';
                        option.type = 'dangerous';
                        break;
                }
                option.light = obj[i].rgba;
                option.dark = obj[i].hex;
                segmentsOptions.push(option);
            }
            $scope.segmentsOptions = segmentsOptions;
            var tripId = $stateParams.trip_id;
            if (!$rootScope.tripTypeChange) {
                getTripDetails(tripId);
            } else {
                $rootScope.tripTypeChange = false;
            }
        }, function (error) {
            PopupUtil.showSimpleAlert($translate.instant('error'), error.data['i18n-key']);
        });
    }

    /*
        Name: showFullMap
        Desc: Zoom in the map when click on the map
    */
    function showFullMap() {
        $('section#triphistorydetailsPpm-fullmap').fadeIn("fast");
        var obj = $scope.mapObjects;
        var full_map_ppm = 'triphistorydetailsPpm-fullmap';
        MapsUtil.init_mapFromPointsArray_multipleColors(obj.points, obj.start, obj.end, full_map_ppm, $scope.segmentsOptions, obj.mileColors);
    }

    /*
        Name: closeFullMap
        Desc: Zoom out the map when click on the map
    */
    function closeFullMap() {
        $('section#triphistorydetailsPpm-fullmap').fadeOut("fast");
    }


    /*
        Name: getTripDetails
        Desc: Fetch the list of trips of last 30 days
    */
    function getTripDetails(pTripId) {
        LoadingUtil.showLoader();
        TripsServices.getTrip(pTripId).then(function (data) {
            LoadingUtil.hideLoader();
            if (angular.isDefined(data.data)) {
                var tripData = data.data;
            } else {
                var tripData = data;
            }

            console.log(21212121, tripData);

            if (angular.isDefined(tripData.score)) {
                $scope.price_per_mile_current = tripData.score.price_per_mile_current;
                $scope.price_per_category = tripData.score.price_per_category;
                $scope.distance_per_category.safe_interstate = Math.round(tripData.score.distance_per_category.safe_interstate * 10) / 10;
                $scope.distance_per_category.safe_other = Math.round(tripData.score.distance_per_category.safe_other * 10) / 10;
                $scope.distance_per_category.aggressive = Math.round(tripData.score.distance_per_category.aggressive * 10) / 10;
                $scope.distance_per_category.risky = Math.round(tripData.score.distance_per_category.risky * 10) / 10;
                $scope.distance_per_category.dangerous = Math.round(tripData.score.distance_per_category.dangerous * 10) / 10;
                $scope.safe_miles = Math.round(tripData.score.safe_miles_driven * 10) / 10;
                $scope.totalCost = tripData.score.cost;
            } else {
                $scope.price_per_mile_current = tripData.price_per_mile_current;
                $scope.price_per_category = tripData.price_per_category;
                $scope.distance_per_category.safe_interstate = Math.round(tripData.distance_per_category.safe_interstate * 10) / 10;
                $scope.distance_per_category.safe_other = Math.round(tripData.distance_per_category.safe_other * 10) / 10;
                $scope.distance_per_category.aggressive = Math.round(tripData.distance_per_category.aggressive * 10) / 10;
                $scope.distance_per_category.risky = Math.round(tripData.distance_per_category.risky * 10) / 10;
                $scope.distance_per_category.dangerous = Math.round(tripData.distance_per_category.dangerous * 10) / 10;
                $scope.safe_miles = Math.round(tripData.safe_miles_driven * 10) / 10;
                $scope.totalCost = tripData.cost;
            }
            $scope.start_time = moment(DateUtil.formatDateAsUTC(StringUtil.getdateinformat(tripData.start_time))).format('h:mm A');
            $scope.end_time = moment(DateUtil.formatDateAsUTC(StringUtil.getdateinformat(tripData.end_time))).format('h:mm A');
            $scope.trip_date = moment(DateUtil.formatDateAsUTC(StringUtil.getdateinformat(tripData.end_time))).format('dddd MMMM D');
            $scope.startLocation = tripData.start_location;
            $scope.endLocation = tripData.end_location;
            setTripType(tripData.trip_type.id);
            prepareMap(tripData);
        }, function (error) {
            LoadingUtil.hideLoader();
            PopupUtil.showSimpleAlert($translate.instant('error'), error.data['i18n-key']);
        });
    }

    /*
        Name: prepareMap
        Desc: Prepares the map with the trip data
    */
    function prepareMap(pData) {
        var data = pData;
        setupMaps(data);
    }

    /*
        Name : setupMaps
        Desc : It'll process the data and trip path to show the trip path with multicolored
    */

    function setupMaps(pData) {
        console.log(11441144, pData);

        var array = polyline.decode(pData.encoded_path, 3);
        var miles = [];
        var c = 0;
        var m = 0;
        var milesArr = [];
        var mileArr = [];

        // Logic that will decompose the trip in segment and prepare each segments for map.
        for (var i = 0; i <= array.length - 2; i++) {
            var lon1 = array[i][1] / 100;
            var lat1 = array[i][0] / 100;
            var lon2 = array[i + 1][1] / 100;
            var lat2 = array[i + 1][0] / 100;
            var d = Math.round(getDistanceFromLatLonInMi(lat1, lon1, lat2, lon2) * 100) / 100;
            if (angular.isDefined(pData.score)) {
                var t = pData.score.category_per_mile[milesArr.length];
            } else {
                var t = pData.category_per_mile[milesArr.length];
            }

            var obj = {
                x1: lon1,
                x2: lon2,
                y1: lat1,
                y2: lat2,
                type: t,
                distance: d
            };
            c += d;
            if (c >= 1) {
                // At least one mile, one segment is complete.
                if (m == 0 && i == 0) {
                    mileArr.push(obj);
                }
                milesArr[m] = mileArr;
                mileArr = [];
                mileArr.push(obj);
                m++;
                c = c - 1;
            } else {
                mileArr.push(obj);
            }
        }
        milesArr[m] = mileArr;
        var startMrkr = './client/images/marker_a.png';
        var endMrkr = './client/images/marker_b.png';
        var element_small = 'tripMap';

        if (angular.isDefined(pData.score)) {
            $scope.mapObjects = {
                points: milesArr,
                start: startMrkr,
                end: endMrkr,
                mileColors: pData.score.category_per_mile
            };
            MapsUtil.init_mapFromPointsArray_multipleColors(milesArr, startMrkr, endMrkr, element_small, $scope.segmentsOptions, pData.score.category_per_mile);
        } else {
            $scope.mapObjects = {
                points: milesArr,
                start: startMrkr,
                end: endMrkr,
                mileColors: pData.category_per_mile
            };
            MapsUtil.init_mapFromPointsArray_multipleColors(milesArr, startMrkr, endMrkr, element_small, $scope.segmentsOptions, pData.category_per_mile);
        }

    }

    /*
        Name: getDistanceFromLatLonInMi
        Desc: Calculate the distance between 2 lattitude and longitude points
        param : latitude and longitude of 2 geo-location points
    */
    function getDistanceFromLatLonInMi(lat1, lon1, lat2, lon2) {
        var R = 3959; // km 
        var x1 = lat2 - lat1;
        var dLat = deg2rad(x1);
        var x2 = lon2 - lon1;
        var dLon = deg2rad(x2);
        var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
            Math.sin(dLon / 2) * Math.sin(dLon / 2);
        var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        var d = R * c;
        return d;
    }

    function deg2rad(deg) {
        return deg * (Math.PI / 180)
    }

    /*
        Name: changeTripType
        Desc: A method that navigates to another screen where user is allowed to change his trip type
    */
    function changeTripType() {
        $rootScope.tripTypeChange = true;
        $state.go('app.selectInfo', {
            'list': tripTypes
        });
    }

    /*
        Name: setTripType
        params : selected trip_type
        Desc: It makes a webservice call to change trip type for a particular trip
    */
    function setTripType(tripTypeId) {
        $scope.tripTypeIcon = getTransportTypeIcon(tripTypeId);
        $scope.tripType = getTransportType(tripTypeId, null);
        // A webservice call should be done here.
    }

    /*
        Name: tripTypeChanged
        params : selected trip_type
        Desc: It makes a webservice call to change trip type for a particular trip
    */
    function tripTypeChanged(tripType, tripId) {
        $scope.tripType = tripType;
        var tripTypeId = getTransportType(null, tripType);
        $scope.tripTypeIcon = getTransportTypeIcon(+tripTypeId);
        TripsServices.setTransportType(tripTypeId, tripId).then(function (response) {
            WebServiceCache.cleanseCache(1);
            $ionicHistory.goBack();
        }, function (error) {
            // Error
        })
    }

    function getTransportTypeIcon(transportTypeId) {
        var icon = null;
        switch (transportTypeId) {
            case 1:
                icon = "fa fa-car";
                break;
            case 2:
                icon = "fa fa-bus";
                break;
            case 3:
                icon = "fa fa-train";
                break;
            case 4:
                icon = "fa fa-bicycle";
                break;
            case 5:
                icon = "fa fa-plane";
                break;
            case 6:
                icon = "icon ion-android-boat";
                break;
            case 7:
                icon = "icon ion-android-walk";
                break;
            case 8:
                icon = "fa fa-user";
                break;
            default:
                icon = "fa fa-car";
                break;
        }
        return icon;
    }

    function getTransportType(pId, pName) {
        var transportType = null;
        for (var i = 0; i < tripTypesData.length; i++) {
            if (pId == null) {
                if (pName == tripTypesData[i].name) {
                    transportType = tripTypesData[i].id;
                }
            } else {
                if (pId == tripTypesData[i].id) {
                    transportType = tripTypesData[i].name;
                }
            }
        }
        return transportType;
    }
}
