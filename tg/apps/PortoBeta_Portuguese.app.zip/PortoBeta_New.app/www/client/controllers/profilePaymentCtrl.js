angular.module('controllers')
    .controller('ProfilePaymentCtrl', ProfilePaymentCtrl);

function ProfilePaymentCtrl($rootScope, $scope, $state, $timeout, $ionicHistory, LocalStorage, LocalStorageKeys, BooleanConstant, LoadingUtil, PaymentServices, PaymentTypes, QuoteServices, PopupUtil, $translate,WebServiceCache) {
    // SCOPE FUNCTIONS
    $scope.editDetails = editDetails;
    $scope.navigateToHistory = navigateToHistory;
    //SCOPE VARIABLES

    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    // FUNCTIONS
    /* 
      name : ionicViewBeforeEnter
      desc : Make a call to webservice to fetch data and bind object.
    */
    function ionicViewBeforeEnter() {
        getPayments();
    }

    /* 
        name : getPayments
        desc : Fetches list of payments.
    */
    function getPayments() {
        LoadingUtil.showLoader();
        PaymentServices.getPaymentMethods().then(function (response) {
            LoadingUtil.hideLoader();
            if (response.data.length > 0) {
                $scope.payments = response.data;
            }
        }, function (error) {
            $scope.payments = [];
            LoadingUtil.hideLoader();
        });
    }

    /* 
        name : editDetails
        param: Is Paypal? true / false
        desc : Navigates to paypal screen or card details screen.
    */
    function editDetails(i) {
        if ($rootScope.fromRPM) {
            makePurchase($scope.payments[i].id);
        } else {
            if ($scope.payments[i].payment_method_id == PaymentTypes.PAYPAL) {
                $state.go("app.profileAddPaymentPaypal", { "specificPayment": $scope.payments[i] });
            } else {
                $state.go("app.profileAddPaymentCardDetails", { "specificPayment": $scope.payments[i] });
            }
        }
    }
    
    /* 
       name : purchase
       desc : It should call a webservice to add balance to user.
       param: payment method id
   */
    function makePurchase(payment_method_id) {
        var packagedetails = {
            payment_option_id: $rootScope.packageDetailsObj.package_id,
            user_payment_method_id: payment_method_id
        };
        LoadingUtil.showLoader();
        PaymentServices.buyPackage(packagedetails).then(function (response) {
            LoadingUtil.hideLoader();
            WebServiceCache.cleanseCache(10);
            var buttons = [{ text: '<span> '+$translate.instant("common_OK")+' </span>', onTap: function (e) { $state.go("app.profile"); } }];
            PopupUtil.showCustomPopupLocal("", "<i class='ion-checkmark-circled clspopupcheckmark'></i><h4>" + $translate.instant("purchase_complete") + "</h4><h5>$" + $rootScope.packageDetailsObj.amount + ".00 " + $translate.instant("was_added") + "</h5>", buttons, "", true);
        }, function (error) {
            LoadingUtil.hideLoader();
            var vrError = $translate.instant(error['i18n-key']);
            PopupUtil.showSimpleAlert($translate.instant('error'), vrError);
            console.log(error);
        });
    }
    /* 
        name : navigateToHistory
        desc : Navigates profile or GAQ - purchase screen based on rootscope.
    */
    function navigateToHistory() {
        if ($rootScope.createPaymentMethodsGAQ) {
            $rootScope.createPaymentMethodsGAQ = null;
            $state.go('app.quotePurchase');
        } else {
            $state.go('app.profile');
        }
    }

}
