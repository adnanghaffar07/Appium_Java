angular.module('controllers')
    .controller('InsuranceNewClaimCtrl', InsuranceNewClaimCtrl);

function InsuranceNewClaimCtrl($state, $rootScope, $scope, InsuranceServices, NewClaims, ClaimTypesIcons, LoggerUtilType, PopupUtil, LoadingUtil) {
    // SCOPE FUNCTIONS
    $scope.setClaimType = setClaimType;
    $scope.goToInsClaimType = goToInsClaimType;
    $scope.goToClaims = goToClaims
    // SCOPE VARIABLES
    $scope.claimTypes = [];
    $scope.data = {
        name: 1
    };

    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    $scope.$on('$ionicView.enter', ionicViewEnter);

    // FUNCTIONS
    ////// Functionality when before entering into the view
    /*
        name : ionicViewBeforeEnter
        desc : will do the data binding to the scope before entering into the view
    */
    function ionicViewBeforeEnter() {
        if (angular.isDefined($rootScope.claimDetails)) {
            $scope.claim_id = $rootScope.claimDetails.claim_id;
        }

        $rootScope.claimDetails = {
            pictures: {},
            position: {},
            location: {},
            form: {}
        };
        if (angular.isUndefined($scope.claim_id)) {
            $rootScope.claimDetails.claim_id = 1;
        } else {
            $rootScope.claimDetails.claim_id = $scope.claim_id;
        }
    }

    function ionicViewEnter() {
        /*
            description : a webservice call to list of claims available.
        */
        LoadingUtil.showLoader();
        InsuranceServices.claimTypes().then(function (response) {
            LoadingUtil.hideLoader();
            $scope.claimTypes = response.data;
            $scope.claimIcons = ClaimTypesIcons;
        }, function (error) {
            LoadingUtil.hideLoader();
            PopupUtil.showSimpleAlert($translate.instant('error'), $translate.instant(error['i18n-key']));
        })
    }

    ////// Function to navigate to specific screen.
    /*
        name : goToInsClaimType
        parameter:State value
        desc : It navigates to specific screen.
    */
    function goToInsClaimType() {
        $scope.data.claimType = $scope.claimTypes[$rootScope.claimDetails.claim_id - 1].name;
        if (NewClaims.STOLEN_VEHICLE == $scope.data.claimType) {
            $state.go("app.insuranceClaimsStolen");
        } else if (NewClaims.COLLISION == $scope.data.claimType) {
            $state.go("app.insuranceClaimsCollision", {
                'claimType': $scope.data.claimType,
                'location': true
            });
        } else {
            $state.go("app.insuranceClaimsCollision", {
                'claimType': $scope.data.claimType,
                'location': false
            });
        }
    }


    /*
        name : setClaimType
        parameter: pType
        desc : Saving the type of the cliam in rootscope
    */
    function setClaimType(pType) {
        $rootScope.claimDetails.claim_id = pType;
    }

    /*
        name : goToClaims
        desc : Go to list of claims when clicking on back button.
    */
    function goToClaims() {
        $state.go('app.insuranceClaims');
    }
}
