angular.module('controllers')
    .controller('RegisterCtrl', RegisterCtrl);

function RegisterCtrl(LoginType, $rootScope, $scope, $state, $translate, $timeout, AppSetupServices, GlobalConstants, RegisterServices, LoginServices, ValidationUtil, LocalStorage, LocalStorageKeys, ApiErrorCode, LoadingUtil, FirebaseService, AccountType) {
    // Scope functions declaration
    $scope.goToLogin = goToLogin;
    $scope.validateRegisterEmail = validateRegisterEmail;
    $scope.validateRegisterPassword = validateRegisterPassword;
    $scope.validateRegisterPasswordConfirm = validateRegisterPasswordConfirm;
    //    $scope.validateRegisterUsername = validateRegisterUsername;
    $scope.register = register;

    // Scope variables
    $scope.registerCreds = {};
    $scope.showErrorMessage = false;
    $scope.errorMessage = "";
    $scope.emailValid = false;
    $scope.passwordConfirmValid = false;

    $scope.registerCreds.email = '';
    $scope.registerCreds.password = '';
    $scope.registerCreds.passwordConfirm = '';
    // Events
    $scope.$watchGroup(['emailValid', 'passwordValid', 'passwordConfirmValid'], validateForm);
    $scope.$watch('showErrorMessage', setErrorMessageTimer);

    // Scope Life Cycle
    $scope.$on('$ionicView.enter', ionicViewEnter);
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);


    function ionicViewBeforeEnter() {
        $scope.registerCreds.email = '';
        $scope.registerCreds.password = '';
        $scope.registerCreds.passwordConfirm = '';
    }

    // FUNCTIONS

    /*
        Name: ionicViewEnter
        Desc: Set backbround to the view
    */
    function ionicViewEnter() {

        $('#register-content').parent().css('background-color', $rootScope.themeColors.mainBackground);

        // send to firebase that user has register
        FirebaseService.logEvent("view_item", {
            item_name: "Registro", 
            custom_dimension2: "Registro"
        });
    }

    /*
        NAME : setErrorMessageTimer
        DESC : Set the timout time for the error message
    */
    function setErrorMessageTimer(n) {
        if (n) {
            $timeout(function () {
                $scope.showErrorMessage = false;
            }, 3000);
        }
    }

    /*
        NAME : register
        DESC : register the user using givent information
    */
    function register() {
        LoadingUtil.showLoader();
        var lang = LocalStorage.get(LocalStorageKeys.DEVICE_LOCALE_KEY);
        RegisterServices.register($scope.registerCreds.email, $scope.registerCreds.password, lang).then(function (response) {

            // Set local storage login informations
            LocalStorage.set(LocalStorageKeys.LOGIN_EMAIL, $scope.registerCreds.email);
            LocalStorage.set(LocalStorageKeys.LOGIN_PASSWORD, $scope.registerCreds.password);

            LoginServices.login($scope.registerCreds.email, $scope.registerCreds.password).then(function (result) {
                // Login successful, redirect to dashboard. Normally, this should never be called because user need to accept consent.
                LoadingUtil.hideLoader();

                var menuItems = LocalStorage.getObject(LocalStorageKeys.MENU_ITEMS);
                var state = menuItems[0].state;

                $state.go(state);
            }, function (error) {
                LoadingUtil.hideLoader();
                checkError(error);
            });
        }, function (error) {
            // An error occured during the register process, show error message
            LoadingUtil.hideLoader();
            if (error.api_error_code == ApiErrorCode.DISPLAY_NAME_ALREADY_USED) {
                $scope.usernameValid = false;
            }
            if (error.api_error_code == ApiErrorCode.EMAIL_ALREADY_USED) {
                $scope.emailValid = false;
            }
            $scope.errorMessage = $translate.instant(error["i18n-key"]);
            $scope.showErrorMessage = true;
        });
    }

    /*
       NAME : checkError
       DESC : If status code is 1022, it makes user to redirect to consent screen.
   */
    function checkError(error) {
        var statusCode = error.data.api_error_code;
        
        if (statusCode === ApiErrorCode.LTP_REQUIRED) {
            goToLtpSplash();
        } else if (statusCode === ApiErrorCode.CONSENT_REQUIRED) {
            goToConsent();
        } else {
            $scope.errorMessage = $translate.instant(error.data["i18n-key"]);
            $scope.showErrorMessage = true;
        }

    }

    /*
        NAME : validateRegisterEmail
        DESC : Validate input email by user
    */
    function validateRegisterEmail($event) {
        var emailValue = $scope.registerCreds.email;

        $scope.emailValid = false;

        if (emailValue != null && 
            emailValue != "" && 
            typeof emailValue != 'undefined' && 
            ValidationUtil.validateEmail(emailValue)) {
            $scope.emailValid = true;
        } 

        console.log($scope.emailValid);

        //$scope.$apply();
    }

    /*
        NAME : validateRegisterPassword
        DESC : Validate input password by user
    */
    function validateRegisterPassword() {
        var pass = $scope.registerCreds.password;
        var confirm = $scope.registerCreds.passwordConfirm;

        $scope.passwordValid = false;

        if (pass != null && 
            pass != "" && 
            typeof pass != 'undefined' && 
            ValidationUtil.checkPasswordStrength(pass)) {
            $scope.passwordValid = true;
        }

        validateRegisterPasswordConfirm();
    }

    /*
        NAME : validateRegisterPasswordConfirm
        DESC : Validate input password confirmation is the same as password
    */
    function validateRegisterPasswordConfirm() {
        var pass = $scope.registerCreds.password;
        var confirm = $scope.registerCreds.passwordConfirm;

        $scope.passwordConfirmValid = false;

        if ((pass != null || pass != "" ) && pass === confirm) {
            $scope.passwordConfirmValid = true;
        }
    }

    /*
        NAME : validateForm
        DESC : Make sure all information is validated and enable register button
    */
    function validateForm(newValues, oldValues, scope) {
        if (newValues[0] && newValues[1] && newValues[2]) {
            $scope.formValid = true;
        } else {
            $scope.formValid = false;
        }
    }

    /*
        NAME : goToLogin
        DESC : Navigate to Login screen
    */
    function goToLogin() {
        $state.go('login');
    }

    /*
        NAME : goToDashboard
        DESC : If user is logged in for first time, User is redirected to consent screen.
    */
    function goToDashboard() {
        var menuItems = LocalStorage.getObject(LocalStorageKeys.MENU_ITEMS);
        $state.go(menuItems[0].state);
    }

    /*
        NAME : goToConsent
        DESC : If user is logged in for first time, User is redirected to consent screen.
    */
    function goToConsent() {
        $state.go('consent');
    }

    /*
        NAME : goToSMS
        DESC : Redirects user to SMS Validation screen
    */
    function goToLtpSplash() {
        $state.go("ltpSplash");
    }
}
