angular.module('controllers')
    .controller('ProfilePasswordCtrl', ProfilePasswordCtrl);

function ProfilePasswordCtrl($scope, $state, $ionicHistory, LocalStorage, LocalStorageKeys, LoginServices, BooleanConstant, PopupUtil, $translate) {
    
    //SCOPE VARIABLES
    $scope.password = {};
    var requiredFields = ['current_password', 'new_password', 'confirm_password'];
    
    // SCOPE FUNCTIONS
    $scope.savePassword = savePassword;
    $scope.goToResetPassword = goToResetPassword;

    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    // FUNCTIONS
    function ionicViewBeforeEnter() {

    }
    
    /*
        name : savePassword
        desc : update the current password
        param : current password and new password 
    */
    function savePassword() {
        var error = validateData($scope.password);
        $scope.submitted = BooleanConstant.BOOL_TRUE;
        if (!error) {
            var vrNewPassword = $scope.password.new_password;
            var vrCurrentPassword = $scope.password.current_password;
            var vrConfirmPassword = $scope.password.confirm_password;
            if (vrCurrentPassword == vrNewPassword) {
                PopupUtil.showSimpleAlert($translate.instant('Error'), "<p>" + $translate.instant('current_password_same') + "</p>");
            } else if (vrNewPassword != vrConfirmPassword) {
                PopupUtil.showSimpleAlert($translate.instant('Error'), "<p>" + $translate.instant('new_password_confirm_password_different') + ".</p>");
            } else {
                LoginServices.changePassword(vrCurrentPassword, vrNewPassword).then(function (response) {
                    LocalStorage.set(LocalStorageKeys.LOGIN_PASSWORD, vrNewPassword);
                    onSuccess();

                }, function (error) {
                    PopupUtil.showSimpleAlert($translate.instant('Error'), "<p>" + $translate.instant(error["i18n-key"]) + "</p>");
                    // var buttons = [{ text: '<span> Ok </span>', onTap: function (e) { } }];
                    // var errorMsg = $translate.instant(error['i18n-key']);
                    // PopupUtil.showCustomPopupLocal("", "<h4>Error!</h4><h6>" + errorMsg + "</h6>", buttons, "", true);
                });
            }
        }
    }
    
    /*
        name:goToResetPassword
        desc: go to reset password screen when click on forgot password link
    */
    function goToResetPassword() {
        $state.go('app.profileResetPassword');
    }

    function validateData(data) {
        var isError = BooleanConstant.BOOL_FALSE;
        if (data) {
            for (var i = 0; i < requiredFields.length; i++) {
                if (angular.isUndefined(data[requiredFields[i]]) || data[requiredFields[i]] === '' || data[requiredFields[i]] === null) {
                    isError = BooleanConstant.BOOL_TRUE;
                    break;
                }
            };
        } else {
            isError = BooleanConstant.BOOL_TRUE;
        }
        return isError;
    }

    function onSuccess() {
        var vrEmail = $scope.profileData.user.email;
        var buttons = [{
            text: '<span> '+$translate.instant("common_OK")+' </span>',
            onTap: function (e) {
                $ionicHistory.goBack();
            }
        }];
        PopupUtil.showCustomPopupLocal("", $translate.instant("password_changed_successfully"), buttons, "", true);
    }
}
