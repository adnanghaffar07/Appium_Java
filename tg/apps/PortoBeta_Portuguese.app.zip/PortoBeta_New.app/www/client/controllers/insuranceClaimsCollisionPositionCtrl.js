angular.module('controllers')
    .controller('InsuranceClaimsCollisionPositionCtrl', InsuranceClaimsCollisionPositionCtrl);

function InsuranceClaimsCollisionPositionCtrl($state, $rootScope, $scope, MapsUtil,$ionicHistory) {
    // SCOPE FUNCTIONS
    $scope.savePosition = savePosition;
   
    //SCOPE VARIABLES
    var vrDragDetails = {};
    var markerObj = {
        anchor: [0.5, 40],
        anchorXUnits: 'fraction',
        anchorYUnits: 'pixels',
        opacity: 0.95,
        icon: 'client/images/insurance/map_marker.png'
    };
    var mapArrayPoints = [];
    var vrDragPosition=[];
    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    $scope.$on('$ionicView.enter', ionicViewEnter);

    // FUNCTIONS
    ////// Functionality when before entering into the view
    /*
        name : ionicViewBeforeEnter
        desc : will do the data binding to the scope before entering into the view
    */
    function ionicViewBeforeEnter() {

    }
    
    // FUNCTIONS
    ////// Functionality when before entering into the view
    /*
        name : ionicViewBeforeEnter
        desc : will do the data binding to the scope after entering into the view.
               Here using to bind Maps showing user current location.
    */
    function ionicViewEnter() {
        navigator.geolocation.getCurrentPosition(function (position) {
            var pos = {
                lat: position.coords.latitude,
                lng: position.coords.longitude
            };
            mapArrayPoints = [position.coords.latitude, position.coords.longitude];
            var mapPoints = [];
            var mapPiont = {};
            mapPiont.lat = parseFloat(pos.lat);
            mapPiont.lon = parseFloat(pos.lng);
            vrDragDetails.lat = parseFloat(pos.lat);
            vrDragDetails.lng = parseFloat(pos.lng);
            if (vrDragPosition.longitude != "" && vrDragPosition.latitude != "" && angular.isDefined(vrDragPosition.longitude) && angular.isDefined(vrDragPosition.latitude)) {
                mapPiont.lat = vrDragPosition.longitude;
                mapPiont.lon = vrDragPosition.latitude;
                mapArrayPoints[1] = vrDragPosition.latitude;
                mapArrayPoints[0] = vrDragPosition.longitude;
            }
            mapPoints[0] = (mapPiont);
            MapsUtil.dragEnabledMap_init("showUserPosition", mapPoints, mapArrayPoints, markerObj, getDragCord);
        });
        // navigator.geolocation.getCurrentPosition(function (position) {
        //     mapArrayPoints = [position.coords.latitude, position.coords.longitude];
        //     MapsUtil.displayUserLocation_Map("showUserPosition", mapArrayPoints);
        // });
    }
    ////// Function to navigate to Collision screen after saving data.
        /*
        name : getDragCord
        desc : Returns drag positions.
    */
           function getDragCord(evt){
            console.log(evt);
            vrDragDetails.lng=evt[0];
            vrDragDetails.lat=evt[1];
        }
    /*
        name : goToSpecificPage
        parameter:State value
        desc : Saves Position data and navigate to collision screen.
    */

    function savePosition(route) {
        $rootScope.claimDetails.position={longitude:vrDragDetails.lng,latitude:vrDragDetails.lat};
        //$state.go(route);
        $ionicHistory.goBack();
    }
}
