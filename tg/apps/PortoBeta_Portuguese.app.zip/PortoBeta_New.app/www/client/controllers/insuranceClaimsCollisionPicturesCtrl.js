angular.module('controllers')
    .controller('InsuranceClaimsCollisionPicturesCtrl', InsuranceClaimsCollisionPicturesCtrl);

function InsuranceClaimsCollisionPicturesCtrl($state, $rootScope, $scope,CameraUtil,InsuranceServices,BooleanConstant,CameraCapture,UploadImage,LoadingUtil,$ionicHistory,PopupUtil,LoggerUtilType, $translate) {
    // SCOPE FUNCTIONS
    $scope.goToSpecificPage = goToSpecificPage;
    $scope.optionSelected = optionSelected;
    $scope.showSelectOptions = showSelectOptions;
    $scope.getPictures = getPictures;
    $scope.goBack = goBack;
    //SCOPE VARIABLES
    $scope.showDelete = false;
    $scope.displayFooter = false;
    $scope.selIndex = "";
    $scope.pictures = [{ "title": "Damages", "imgTitle": "Damages" }, { "title": "Accident Area", "imgTitle": "Accident Area" },
        { "title": "Driver's License", "imgTitle": "Drivers License" }, { "title": "Completed Claim", "imgTitle": "Completed Claim" }, { "title": "Insurance Slip", "imgTitle": "Insurance Slip" }];
    // $scope.pictures = ["client/images/insurance/accident.png", "client/images/insurance/accident_area.png", "client/images/insurance/license.png", "client/images/insurance/accident_form.png"];
    var cameraOptions = CameraCapture.IMAGE_SIZE_CLAIMS;
    var imageData = {};
    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    $scope.$on('$ionicView.enter', ionicViewEnter);

    // FUNCTIONS
    ////// Functionality when before entering into the view
    /*
        name : ionicViewBeforeEnter
        desc : will do the data binding to the scope before entering into the view
    */
    function ionicViewBeforeEnter() {

    }

    function ionicViewEnter() {
        if ($scope.pictures.length == 0) {
            $scope.displayFooter = BooleanConstant.BOOL_TRUE;
        }
        //getInsurancePictures();
    }
    ////// Function to navigate to specific screen.
    /*
        name : goToSpecificPage
        parameter:State value
        desc : It navigates to specific screen.
    */
    function goToSpecificPage(route) {
        $state.go(route);
    }
    
    // Function to navigate to People involved list screen after saving data.
    /*
        name : optionSelected
        parameter:Selected option
        desc : (Take Picture / Choose from Gallery / Cancel)
    */
    function optionSelected(option) {
        if (option == UploadImage.CANCEL) {
            $scope.displayFooter = BooleanConstant.BOOL_FALSE;
        } else if (option == UploadImage.DELETE) {
            deletePicture();
            $scope.displayFooter = BooleanConstant.BOOL_FALSE;
        } else if (option == UploadImage.TAKE) {
            takePhoto();
        } else if (option == UploadImage.CHOOSE) {
            chooseFromLibrary();
        }
    }
    /*
       name   :  takePhoto  
       desc   :  It opens camera to take photo.
   */
    function takePhoto() {
        $scope.displayFooter = BooleanConstant.BOOL_FALSE;
        cameraOptions.quality =  20
        CameraUtil.takePicture(cameraOptions).then(function (image) {
            processImage(image);
        });
    }
    /*
        name   :  chooseFromLibrary  
        desc   :  It shows images in Gallery.
    */
    function chooseFromLibrary() {
        $scope.displayFooter = BooleanConstant.BOOL_FALSE;
        cameraOptions.quality =  20
        CameraUtil.getPicture(cameraOptions).then(function (image) {
            processImage(image);
        });
    }
    // Function to navigate to People involved list screen after saving data.
    /*
        name : showSelectOptions
        parameter:index, flag to show / hide delete option
        desc : Display footer to select options to upload picture.
    */
    function showSelectOptions(index, flag, title) {
        $scope.displayFooter = BooleanConstant.BOOL_TRUE;
        $scope.imageTitle = title;
        $scope.showDelete = flag;
        $scope.selIndex = index;
    }
    /*
        name   :  processImage  
        desc   :  It will save saves picture to server.
    */
    function processImage(img) {
        LoadingUtil.showLoader();
        imageData.image = UploadImage.BASE_64 + img;
        imageData.title = $scope.imageTitle;
        InsuranceServices.postPicture(imageData).then(function (response) {
            LoadingUtil.hideLoader();
            $scope.pictures[$scope.selIndex].id = response.data.id;
            $scope.pictures[$scope.selIndex].file = imageData.image;
        }, function (error) {
            LoadingUtil.hideLoader();
            PopupUtil.showSimpleAlert($translate.instant('error'),$translate.instant(error['i18n-key']));        
        });
    }

    function deletePicture() {
        LoadingUtil.showLoader();
        imageData.id = $scope.pictures[$scope.selIndex].id; 
        //imageData.image="";
        imageData.title = $scope.imageTitle;
        InsuranceServices.deletePicture(imageData).then(function (response) {
            LoadingUtil.hideLoader();
            $scope.pictures[$scope.selIndex].file = null;
        }, function (error) {
            LoadingUtil.hideLoader();
            PopupUtil.showSimpleAlert($translate.instant('error'),$translate.instant(error['i18n-key']));
        });
    }

    function getPictures() {
        LoadingUtil.showLoader();
        InsuranceServices.getPicture("").then(function (response) {
            LoadingUtil.hideLoader();
            $scope.pictures = response.data.picture_url;
        }, function (error) {
            LoadingUtil.hideLoader();
        });
    }

    function goBack() {
        var vrpics = $scope.pictures;
        var vrpicsSave = {}, j = 0;
        for (var i = 0; i < vrpics.length; i++) {
            if (angular.isDefined(vrpics[i].id)) {
                vrpicsSave[j] = {};
                vrpicsSave[j].file = vrpics[i].id;
                vrpicsSave[j].title = vrpics[i].title;
                j++;
            }
        }
        $rootScope.claimDetails.pictures = vrpicsSave;
        $ionicHistory.goBack();
    }

    function getInsurancePictures(){
        for (var i=0; i<Object.keys($rootScope.claimDetails.pictures).length; i++){
            switch ($rootScope.claimDetails.pictures[i].title){
                case 'Damages':
                    InsuranceServices.getPicture($rootScope.claimDetails.pictures[i].file).then(function (response) {
                        LoadingUtil.hideLoader();
                        $scope.pictures[0].file = response.url;
                    }, function (error) {
                        LoadingUtil.hideLoader();
                    });
                    break;
                case 'Accident Area':
                    InsuranceServices.getPicture($rootScope.claimDetails.pictures[i].file).then(function (response) {
                        LoadingUtil.hideLoader();
                        $scope.pictures[1].file = response.url;
                    }, function (error) {
                        LoadingUtil.hideLoader();
                    });
                    break;
                case 'Driver"s License':
                    InsuranceServices.getPicture($rootScope.claimDetails.pictures[i].file).then(function (response) {
                        LoadingUtil.hideLoader();
                        $scope.pictures[2].file = response.url;
                    }, function (error) {
                        LoadingUtil.hideLoader();
                    });
                    break;
                case 'Completed Claim':
                    InsuranceServices.getPicture($rootScope.claimDetails.pictures[i].file).then(function (response) {
                        LoadingUtil.hideLoader();
                        $scope.pictures[3].file = response.url;
                    }, function (error) {
                        LoadingUtil.hideLoader();
                    });
                    break;
                case 'Insurance Slip':
                    InsuranceServices.getPicture($rootScope.claimDetails.pictures[i].file).then(function (response) {
                        LoadingUtil.hideLoader();
                        $scope.pictures[4].file = response.url;
                    }, function (error) {
                        LoadingUtil.hideLoader();
                    });
                    break;
            }
        }
    }
}
