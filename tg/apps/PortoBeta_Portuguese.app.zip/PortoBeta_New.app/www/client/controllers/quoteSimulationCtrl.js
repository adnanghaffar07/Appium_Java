angular.module('controllers')
    .controller('QuoteSimulationCtrl', QuoteSimulationCtrl);

function QuoteSimulationCtrl($state, $scope, $rootScope, $stateParams, QuoteServices, LoadingUtil, LocalStorage, LocalStorageKeys, LoginType, BooleanConstant) {
    // $scope Functions
    $scope.startSimulation = startSimulation;
    $scope.goToSelectInfo = goToSelectInfo;

    // SCOPE VARIABLES
    //// Mandatory fields declarations
    var requiredFields = ['company', 'price'];
    $scope.insurance = {};
    var insurancesNames = [];
    var insurancesList = []; 
    $scope.insurancesList = [];

    // $scope View Cycle
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    $scope.$on('$ionicView.loaded', ionicViewLoaded);

    // Functions
    /*
        Name: ionicViewLoaded
        Desc: Fetch data from database
    */
    function ionicViewLoaded() {
        LoadingUtil.showLoader();
        QuoteServices.getInsurances().then(function (results) {
            LoadingUtil.hideLoader();
            insurancesList = results.data.data;
            $scope.driverTypes = insurancesList; 
            insurancesNames = [];
            angular.forEach(insurancesList, function (value, key) {
                insurancesNames.push(value.name);
            });
        }, function (error) {
            LoadingUtil.hideLoader();
            console.log("ERROR", error);
        });
    }
    /*
        name : ionicViewBeforeEnter
        desc : will do the data binding to the scope before entering into the view
    */
    function ionicViewBeforeEnter() {
        var vrSelectedVal = $rootScope.selectedValue;
        if (vrSelectedVal == null)
            return false;
        else {
            angular.forEach(insurancesList, function (value, key) {
                if (value.name == vrSelectedVal) {
                    $scope.insurance.company_id = value.id;
                    $scope.insurance.company = vrSelectedVal;
                }
            });
        }

    }
    
    /*
        Name : startSimulation
        Desc : fetch quote information and redirect to dashboard in a simulation mode.
    */
    function startSimulation() {
        console.log($stateParams.quoteId);
        $scope.submitted = BooleanConstant.BOOL_TRUE;
        var error = validateData($scope.insurance);
        if (error) {
            return false;
        }
        LoadingUtil.showLoader();
        var quoteId = $stateParams.quoteId;
        if (quoteId == "") {
            quoteId = null;
        }
        QuoteServices.getQuote(quoteId).then(function (results) {
            LoadingUtil.hideLoader();
            $rootScope.quoteSimulatorObj = results.data.data;
            var insuranceDetails = {
                insurance_id: $scope.insurance.company_id,
                price: $scope.insurance.price
            };
            $rootScope.quoteSimulatorObj.insurance_id = $scope.insurance.company.id;
            $rootScope.quoteSimulatorObj.annaul_price = $scope.insurance.price;
            QuoteServices.saveQuoteSimulations(quoteId, insuranceDetails).then(function (response) {

            }, function (error) {
                console.log("ERROR", error);
            });
            goToDashboard();
        }, function (error) {
            LoadingUtil.hideLoader();
            console.log("ERROR", error);
        });
    }

    /*
        Name : goToDashboard
        Desc : Depending on the mode, go to the right dashboard
    */
    function goToDashboard() {
        if ($scope.isPPM) {
            $state.go('app.dashboardPpm');
        } else {
            $state.go('app.dashboard');
        }
    }
    
    //// Function to validate mandatory fields
    /*
        name : validateData
        parameter : data
        desc : Validate the mandatory fields details
        return : It'll return 'true' if any of the mandatory fields kept empty. If all the mandatory details are filled it'll return 'false'
    */
    function validateData(data) {
        var isError = BooleanConstant.BOOL_FALSE;
        if (data) {
            for (var i = 0; i < requiredFields.length; i++) {
                if (angular.isUndefined(data[requiredFields[i]]) || data[requiredFields[i]] === '' || data[requiredFields[i]] === null) {
                    if (typeof isError !== 'object') {
                        isError = {};
                    }
                    isError[requiredFields[i]] = BooleanConstant.BOOL_TRUE;
                }
            };
        } else {
            isError = BooleanConstant.BOOL_TRUE;
        }
        return isError;
    }
    
     /*
        name : goToSelectInfo
        desc : Navigate to selet info screen.
    */
    function goToSelectInfo() {
        $state.go('app.selectInfo', { 'list': insurancesNames });
    }
}
