angular.module('controllers')
    .controller('TripHistoryCalendarPpmCtrl', TripHistoryCalendarPpmCtrl);

function TripHistoryCalendarPpmCtrl($rootScope, $scope, $ionicHistory, LocalStorage, LocalStorageKeys, CordovaBroadcaster, $ionicSlideBoxDelegate, TripDefaultValues, ScoresServices, TripsUtil, DOMUtil, LoadingUtil, DateUtil) {
    // SCOPE VARIABLES
    /*
        Faked the data for now.
    */
    $scope.selectedTab = 'score';
    var element = "distance-chart";
    var data = {};
    $scope.vrWeeks = [{
        "weekday": "S"
    }, {
        "weekday": "M"
        }, {
        "weekday": "T"
        }, {
        "weekday": "W"
        }, {
        "weekday": "T"
        }, {
        "weekday": "F"
        }, {
        "weekday": "S"
        }];
    $scope.todayDate = moment(new Date()).format("dddd MMMM D, YYYY");
    $scope.avgDistance = {};
    $scope.trips_count = [];
    $scope.trips_distance = [];
    $scope.trips_time = [];
    $scope.avgSafeMileDistance = 0;
    $scope.avgTrips = 0;
    $scope.avgTime = 0;
    $scope.avgMiles = 0;
    $scope.cost = 0;
    $scope.avgCost = 0;
    $scope.cost_details = {};
    $scope.price_per_mile_current = {};



    // SCOPE FUNCTION
    $scope.changeTab = changeTab;
    $scope.slideHasChanged = slideHasChanged;

    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    // FUNCTIONS
    function ionicViewBeforeEnter() {
        getCurrentMonthDailyScores();
    }

    /*
        Setup Options for Chart
    */
    var options = prepareChartOptions();

    /*
        Name: slideHasChanged
        Desc: Handles sliding event. Updates the view after slide.
        Param: pI, pScoreData
    */
    function slideHasChanged(pI) {
        var container = null;
        var score = null;
        if ($scope.isTBYB) {
            switch (pI) {
                case 0:
                    $scope.selectedTab = 'score';
                    break;
                case 1:
                    $scope.selectedTab = 'distance';
                    element = "distance-chart";
                    options.scaleLabel = "<%= value + ' mi '%>";
                    setupChart(element, '', $scope.trips_distance);
                    break;
                case 2:
                    $scope.selectedTab = 'time';
                    element = "time-chart";
                    options.scaleLabel = "<%= value + ' min '%>";
                    setupChart(element, '', $scope.trips_time);
                    break;
                case 3:
                    $scope.selectedTab = 'trips';
                    element = "trips-chart";
                    options.scaleLabel = "<%= value + ' trips '%>";
                    setupChart(element, '', $scope.trips_count);
                    break;
            }
        } else {
            switch (pI) {
                case 0:
                    $scope.selectedTab = 'avgCost';
                    break;
                case 1:
                    $scope.selectedTab = 'cost';
                    element = "cost-chart";
                    options.scaleLabel = "<%= value + ' mi '%>";
                    setupChart(element, '', $scope.trips_distance);
                    break;
                case 2:
                    $scope.selectedTab = 'distance';
                    element = "distance-chart";
                    options.scaleLabel = "<%= value + ' mi '%>";
                    setupChart(element, '', $scope.trips_distance);
                    break;
                case 3:
                    $scope.selectedTab = 'time';
                    element = "time-chart";
                    options.scaleLabel = "<%= value + ' min '%>";
                    setupChart(element, '', $scope.trips_time);
                    break;
                case 4:
                    $scope.selectedTab = 'trips';
                    element = "trips-chart";
                    options.scaleLabel = "<%= value + ' trips '%>";
                    setupChart(element, '', $scope.trips_count);
                    break;
            }
        }

    }

    /*
        Name: changeTab
        Desc: Use de slidebox delegate to force sliding to a given index.
        Param: pI
    */
    function changeTab(pI) {
        $ionicSlideBoxDelegate.$getByHandle('dataSlider').slide(pI);
    }

    /*
        Name: setupChart
        Desc: Prepare the chart when sliding the tabs.
        Param: element, type, yAxisLabels
    */
    function setupChart(element, type, yAxisLabels) {
        //elementId = "#" + element;
        $("#" + element).css("width", $scope.windowwidth - 20);
        $("#" + element).css("height", $scope.windowwidth * 0.8);


        var vrTodayDate = new Date();
        var vrCurYear = vrTodayDate.getFullYear();
        var vrCurMonth = vrTodayDate.getMonth();
        var days = new Date(vrCurYear, vrCurMonth + 1, 1, -1).getDate();
        var xAxisData = [];
        for (var i = 0; i <= days; i++) {
            xAxisData.push(i);
        }

        var chartData = {
            Xs: xAxisData
        };
        if ($scope.selectedTab != 'cost') {
            data = {
                labels: chartData.Xs,
                datasets: [{
                    fillColor: "rgba(1, 174, 240,0.3)",
                    strokeColor: "rgba(0,0,0,0)",
                    pointColor: $scope.themeColors.mainBackground,
                    pointStrokeColor: "#fff",
                    data: yAxisLabels
                }]
            };
            options.pointDot = true;
            Chart.types.Line.extend({
                name: "LineAlt",
                initialize: function (data) {
                    Chart.types.Line.prototype.initialize.apply(this, arguments);
                    var xLabels = this.scale.xLabels;
                    for (var i = 0; i < xLabels.length; i++)
                        if (i % 10 != 0)
                            xLabels[i] = '';
                }
            });

            var ctx = document.getElementById(element).getContext("2d");
            new Chart(ctx).LineAlt(data, options);
        } else {
            data = {
                labels: chartData.Xs,
                datasets: [
                    {
                        fillColor: $scope.segmentColors.risky_color,
                        data: $scope.cost_details.risky
                    },
                    {
                        fillColor: $scope.segmentColors.safe_interstate_color,
                        data: $scope.cost_details.safe_interstate
                    },
                    {
                        fillColor: $scope.segmentColors.safe_other_color,
                        data: $scope.cost_details.safe_other
                    },
                    {
                        fillColor: $scope.segmentColors.aggressive_color,
                        data: $scope.cost_details.aggressive
                    },
                    {
                        fillColor: $scope.segmentColors.dangerous_color,
                        data: $scope.cost_details.dangerous
                    }
                ]
            };
            options.pointDot = false;
            Chart.types.Bar.extend({
                name: "BarAlt",
                initialize: function (data) {
                    Chart.types.Bar.prototype.initialize.apply(this, arguments);
                    var xLabels = this.scale.xLabels;
                    for (var i = 0; i < xLabels.length; i++)
                        if (i % 10 != 0)
                            xLabels[i] = '';
                }
            });
            var ctx = document.getElementById(element).getContext("2d");
            new Chart(ctx).BarAlt(data, options);
        }
    }

    function prepareChartOptions() {
        var opt = {
            // Boolean - If we want to override with a hard coded scale
            scaleOverride: false,

            //  Required if scaleOverride is true 
            // Number - The number of steps in a hard coded scale
            scaleSteps: 4,
            // Number - The value jump in the hard coded scale
            scaleStepWidth: 5,
            // Number - The scale starting value
            scaleStartValue: 0,

            scaleLabel: "<%= value + ' % '%>",

            ///Boolean - Whether grid lines are shown across the chart
            scaleShowGridLines: true,

            //String - Colour of the grid lines
            scaleGridLineColor: "rgba(0,0,0,0.1)",

            //Number - Width of the grid lines
            scaleGridLineWidth: 0.5,

            //Boolean - Whether to show horizontal lines (except X axis)
            scaleShowHorizontalLines: true,

            //Boolean - Whether to show vertical lines (except Y axis)
            scaleShowVerticalLines: false,

            //Boolean - Whether the line is curved between points
            bezierCurve: true,

            //Number - Tension of the bezier curve between points
            bezierCurveTension: 0.4,

            //Boolean - Whether to show a dot for each point
            pointDot: true,

            //Number - Radius of each point dot in pixels
            pointDotRadius: 5,

            //Number - Pixel width of point dot stroke
            pointDotStrokeWidth: 3,

            //Number - amount extra to add to the radius to cater for hit detection outside the drawn point
            pointHitDetectionRadius: 20,

            //Boolean - Whether to show a stroke for datasets
            datasetStroke: true,

            //Number - Pixel width of dataset stroke
            datasetStrokeWidth: 2,

            //Boolean - Whether to fill the dataset with a colour
            datasetFill: true,

            // Boolean - Determines whether to draw tooltips on the canvas or not
            showTooltips: false
        }

        return opt;
    }

    /*
        Name: getCurrentMonthDailyScores
        Desc: Fetch the daily aggregate month scores.
    */
    function getCurrentMonthDailyScores() {
        if ($scope.isTBYB) {
            $scope.selectedTab = 'score';
        } else {
            $scope.selectedTab = 'avgCost';
        }
        LoadingUtil.showLoader();
        ScoresServices.getDailyScores_currentMonth().then(function (response) {
            LoadingUtil.hideLoader();
            console.log(9999966666, response);
            if (angular.isDefined(response.data.data)) {
                prepareCalendar(response.data.data);
            } else {
                prepareCalendar(response.data);
            }
        }, function (error) {
            LoadingUtil.hideLoader();
            //prepareCalendar(vrDailyAggregatesresponse.data);
        });
    }

    /*
        Name: prepareCalendar
        Desc: prepares the calendar and process the data of the daily aggregates.
    */
    function prepareCalendar(data) {
        if (angular.isDefined(data.daily_aggregates)) {
            var vrData = data.daily_aggregates;
        } else {
            var vrData = data;
        }

        var vrNoOfDaysPerWeek = TripDefaultValues.TOTAL_DAYS;
        var vrTodayDate = new Date();
        var vrCurYear = vrTodayDate.getFullYear();
        var vrCurMonth = vrTodayDate.getMonth();
        var vrCurMonthFirstDay = new Date(vrCurYear, vrCurMonth, 1);
        var vrMonthFirstDay = vrCurMonthFirstDay.getDay();
        var days = new Date(vrCurYear, vrCurMonth + 1, 1, -1).getDate();
        var vrTotalDays = vrMonthFirstDay + days;
        var pDailyScoresCalendar = [],
            pAvgDistance = [],
            pNoOfTrips = [],
            pDistance = [],
            pTime = [],
            pCost = [],
            pPrice_mile = [];
        var price_per_category_safe_interstate = [],
            price_per_category_safe_other = [],
            price_per_category_aggressive = [],
            price_per_category_risky = [],
            price_per_category_dangerous = [];
        pAvgDistance.safe_interstate = 0, pAvgDistance.safe_other = 0, pAvgDistance.aggressive = 0, pAvgDistance.risky = 0, pAvgDistance.dangerous = 0;
        pCost.safe_interstate = 0, pCost.safe_other = 0, pCost.aggressive = 0, pCost.risky = 0, pCost.dangerous = 0;
        pPrice_mile.safe_interstate = 0, pPrice_mile.safe_other = 0, pPrice_mile.aggressive = 0, pPrice_mile.risky = 0, pPrice_mile.dangerous = 0;
        $scope.price_per_mile_current = pPrice_mile;
        var vrTotalSafeMiles = 0;
        var vrNoOfTrips = 0;
        var vrTotalDistance = 0;
        var vrTotalTime = 0;
        var vrTotalCost = 0;
        for (i = 0; i < vrData.length; i++) {
            var vrDistance = vrData[i].distance_per_category;
            var vrSortDetails = Object.keys(vrDistance).sort(function (a, b) {
                return vrDistance[a] - vrDistance[b]
            })
            var maxDistanceDriven = vrSortDetails[vrSortDetails.length - 1];
            vrData[i].maxDistance = vrDistance[maxDistanceDriven];
            vrData[i].maxDistanceDrivenType = maxDistanceDriven;
            var vrCost = vrData[i].price_per_mile_current;
            $scope.price_per_mile_current = vrCost;
            $scope.price_per_category = {};
            var vrSortCostDetails = Object.keys(vrCost).sort(function (a, b) {
                return vrCost[a] - vrCost[b]
            })
            if (angular.isDefined(vrData[i].last_trip_date)) {
                pDailyScoresCalendar[vrData[i].last_trip_date.split(' ')[0]] = vrData[i];
            } else {
                pDailyScoresCalendar[vrData[i].date] = vrData[i];
            }

            //// Caculation of miles category details
            pAvgDistance.safe_interstate += Math.round(vrData[i].distance_per_category.safe_interstate * 10) / 10;
            pAvgDistance.safe_other += Math.round(vrData[i].distance_per_category.safe_other * 10) / 10;
            pAvgDistance.aggressive += Math.round(vrData[i].distance_per_category.aggressive * 10) / 10;
            pAvgDistance.risky += Math.round(vrData[i].distance_per_category.risky * 10) / 10;
            pAvgDistance.dangerous += Math.round(vrData[i].distance_per_category.dangerous * 10) / 10;

            //// Calculation of cumulative cost details
            pCost.safe_interstate += vrData[i].price_per_category.safe_interstate;
            pCost.safe_other += vrData[i].price_per_category.safe_other;
            pCost.aggressive += vrData[i].price_per_category.aggressive;
            pCost.risky += vrData[i].price_per_category.risky;
            pCost.dangerous += vrData[i].price_per_category.dangerous;

            //// Sum of total safe miles to calculate the average safe miles distance 
            vrTotalSafeMiles += vrData[i].distance_per_category.safe_interstate + vrData[i].distance_per_category.safe_other;
            vrTotalCost += vrData[i].cost;
            vrNoOfTrips += vrData[i].trip_count;
            vrTotalDistance += vrData[i].distance;
            vrTotalTime += vrData[i].duration;
        }
        $scope.calendarContent = '<div class="row">';
        $scope.avgDistance = pAvgDistance;
        $scope.price_per_category = pCost;
        var pUserCreatedDate = $scope.profileData.user.created_on;
        var vrSubscriptionDateDiff = DateUtil.getDateDiff(moment(pUserCreatedDate));
        if (vrSubscriptionDateDiff > 30) {
            $scope.avgSafeMileDistance = parseInt(vrTotalSafeMiles / 30);
            $scope.avgTrips = parseInt(vrNoOfTrips / 30);
            $scope.avgTime = parseInt(vrTotalTime / 30);
            $scope.avgMiles = parseInt(vrTotalDistance / 30);
            $scope.cost = (vrTotalCost / 30);
            if (vrTotalCost > 0)
                $scope.avgCost = vrTotalCost / vrTotalDistance;
        } else {
            $scope.avgSafeMileDistance = parseInt(vrTotalSafeMiles / vrSubscriptionDateDiff);
            $scope.avgTrips = parseInt(vrNoOfTrips / vrSubscriptionDateDiff);
            $scope.avgTime = parseInt(vrTotalTime / vrSubscriptionDateDiff);
            $scope.avgMiles = parseInt(vrTotalDistance / vrSubscriptionDateDiff);
            $scope.cost = (vrTotalCost / vrSubscriptionDateDiff);
            if (vrTotalCost > 0)
                $scope.avgCost = vrTotalCost / vrTotalDistance;
        }

        var calendarContent = $scope.calendarContent;
        var vrTtlDays = (parseInt(vrTotalDays / vrNoOfDaysPerWeek) * vrNoOfDaysPerWeek) + vrNoOfDaysPerWeek;
        var vrDateToCheck = moment(new Date(vrCurYear, vrCurMonth, 1)).format("YYYY-MM-DD");
        var j = 1;
        for (var i = 1; i <= vrTtlDays; i++) {
            if (i % vrNoOfDaysPerWeek == 0 && i <= vrTotalDays) {
                if (pDailyScoresCalendar[vrDateToCheck]) {
                    if ($scope.isTBYB) {
                        pDailyScoresCalendar[vrDateToCheck].maxDistance = Math.round(pDailyScoresCalendar[vrDateToCheck].maxDistance * 10) / 10;
                        calendarContent += '<div class="col"><div class="has-trip ' + pDailyScoresCalendar[vrDateToCheck].maxDistanceDrivenType + '">' + pDailyScoresCalendar[vrDateToCheck].maxDistance + '</div></div></div><div class="row">';
                    } else {
                        pDailyScoresCalendar[vrDateToCheck].avgCost = Math.round((pDailyScoresCalendar[vrDateToCheck].cost / pDailyScoresCalendar[vrDateToCheck].distance) * 100)
                        var vrAvgCost = pDailyScoresCalendar[vrDateToCheck].cost / pDailyScoresCalendar[vrDateToCheck].distance;
                        var mileType = "";
                        if (vrAvgCost >= pDailyScoresCalendar[vrDateToCheck].price_per_mile_current[vrSortCostDetails[0]] && vrAvgCost <= pDailyScoresCalendar[vrDateToCheck].price_per_mile_current[vrSortCostDetails[1]]) {
                            mileType = vrSortCostDetails[0];
                        } else if (vrAvgCost >= pDailyScoresCalendar[vrDateToCheck].price_per_mile_current[vrSortCostDetails[1]] && vrAvgCost <= pDailyScoresCalendar[vrDateToCheck].price_per_mile_current[vrSortCostDetails[2]]) {
                            mileType = vrSortCostDetails[1];
                        } else if (vrAvgCost >= pDailyScoresCalendar[vrDateToCheck].price_per_mile_current[vrSortCostDetails[2]] && vrAvgCost <= pDailyScoresCalendar[vrDateToCheck].price_per_mile_current[vrSortCostDetails[3]]) {
                            mileType = vrSortCostDetails[2];
                        } else if (vrAvgCost >= pDailyScoresCalendar[vrDateToCheck].price_per_mile_current[vrSortCostDetails[3]] && vrAvgCost <= pDailyScoresCalendar[vrDateToCheck].price_per_mile_current[vrSortCostDetails[4]]) {
                            mileType = vrSortCostDetails[3];
                        } else {
                            mileType = vrSortCostDetails[4];
                        }
                        calendarContent += '<div class="col"><div class="has-trip ' + mileType + '">' + pDailyScoresCalendar[vrDateToCheck].avgCost + '</div></div></div><div class="row">';
                    }
                    price_per_category_safe_interstate.push(pDailyScoresCalendar[vrDateToCheck].price_per_category.safe_interstate);
                    price_per_category_safe_other.push(pDailyScoresCalendar[vrDateToCheck].price_per_category.safe_other);
                    price_per_category_aggressive.push(pDailyScoresCalendar[vrDateToCheck].price_per_category.aggressive);
                    price_per_category_risky.push(pDailyScoresCalendar[vrDateToCheck].price_per_category.risky);
                    price_per_category_dangerous.push(pDailyScoresCalendar[vrDateToCheck].price_per_category.dangerous);
                    pNoOfTrips.push(pDailyScoresCalendar[vrDateToCheck].trip_count);
                    pDistance.push(pDailyScoresCalendar[vrDateToCheck].distance);
                    pTime.push(pDailyScoresCalendar[vrDateToCheck].duration);
                } else {
                    calendarContent += '<div class="col"><i class="ion-record"></i></div></div><div class="row">';
                    if (new Date(vrDateToCheck) < vrTodayDate) {
                        pNoOfTrips.push('');
                        pDistance.push();
                        pTime.push('');
                        price_per_category_safe_interstate.push('');
                        price_per_category_safe_other.push('');
                        price_per_category_aggressive.push('');
                        price_per_category_risky.push('');
                        price_per_category_dangerous.push('');
                    }
                }
                vrDateToCheck = moment(new Date(vrCurYear, vrCurMonth, ++j)).format("YYYY-MM-DD");
            } else if (i <= vrMonthFirstDay || i > vrTotalDays) {
                calendarContent += '<div class="col"><i></i></div>';
            } else {
                if (pDailyScoresCalendar[vrDateToCheck]) {
                    if ($scope.isTBYB) {
                        pDailyScoresCalendar[vrDateToCheck].maxDistance = Math.round(pDailyScoresCalendar[vrDateToCheck].maxDistance * 10) / 10;
                        calendarContent += '<div class="col"><div class="has-trip ' + pDailyScoresCalendar[vrDateToCheck].maxDistanceDrivenType + '">' + pDailyScoresCalendar[vrDateToCheck].maxDistance + '</div></div>';
                    } else {
                        pDailyScoresCalendar[vrDateToCheck].avgCost = Math.round((pDailyScoresCalendar[vrDateToCheck].cost / pDailyScoresCalendar[vrDateToCheck].distance) * 100)
                        var vrAvgCost = pDailyScoresCalendar[vrDateToCheck].cost / pDailyScoresCalendar[vrDateToCheck].distance;
                        var mileType = "";
                        if (vrAvgCost >= pDailyScoresCalendar[vrDateToCheck].price_per_mile_current[vrSortCostDetails[0]] && vrAvgCost <= pDailyScoresCalendar[vrDateToCheck].price_per_mile_current[vrSortCostDetails[1]]) {
                            mileType = vrSortCostDetails[0];
                        } else if (vrAvgCost >= pDailyScoresCalendar[vrDateToCheck].price_per_mile_current[vrSortCostDetails[1]] && vrAvgCost <= pDailyScoresCalendar[vrDateToCheck].price_per_mile_current[vrSortCostDetails[2]]) {
                            mileType = vrSortCostDetails[1];
                        } else if (vrAvgCost >= pDailyScoresCalendar[vrDateToCheck].price_per_mile_current[vrSortCostDetails[2]] && vrAvgCost <= pDailyScoresCalendar[vrDateToCheck].price_per_mile_current[vrSortCostDetails[3]]) {
                            mileType = vrSortCostDetails[2];
                        } else if (vrAvgCost >= pDailyScoresCalendar[vrDateToCheck].price_per_mile_current[vrSortCostDetails[3]] && vrAvgCost <= pDailyScoresCalendar[vrDateToCheck].price_per_mile_current[vrSortCostDetails[4]]) {
                            mileType = vrSortCostDetails[3];
                        } else {
                            mileType = vrSortCostDetails[4];
                        }
                        calendarContent += '<div class="col"><div class="has-trip ' + mileType + '">' + pDailyScoresCalendar[vrDateToCheck].avgCost + '</div></div>';
                    }
                    price_per_category_safe_interstate.push(pDailyScoresCalendar[vrDateToCheck].price_per_category.safe_interstate);
                    price_per_category_safe_other.push(pDailyScoresCalendar[vrDateToCheck].price_per_category.safe_other);
                    price_per_category_aggressive.push(pDailyScoresCalendar[vrDateToCheck].price_per_category.aggressive);
                    price_per_category_risky.push(pDailyScoresCalendar[vrDateToCheck].price_per_category.risky);
                    price_per_category_dangerous.push(pDailyScoresCalendar[vrDateToCheck].price_per_category.dangerous);
                    pNoOfTrips.push(pDailyScoresCalendar[vrDateToCheck].trip_count);
                    pDistance.push(pDailyScoresCalendar[vrDateToCheck].distance);
                    pTime.push(pDailyScoresCalendar[vrDateToCheck].duration);
                } else {
                    calendarContent += '<div class="col"><i class="ion-record"></i></div>';
                    if (new Date(vrDateToCheck) < vrTodayDate) {
                        pNoOfTrips.push('');
                        pDistance.push('');
                        pTime.push('');
                        price_per_category_safe_interstate.push('');
                        price_per_category_safe_other.push('');
                        price_per_category_aggressive.push('');
                        price_per_category_risky.push('');
                        price_per_category_dangerous.push('');
                    }
                }
                vrDateToCheck = moment(new Date(vrCurYear, vrCurMonth, ++j)).format("YYYY-MM-DD");
            }
        }
        $scope.calendarContent = calendarContent + '</div>';
        $scope.trips_count = pNoOfTrips;
        $scope.trips_distance = pDistance;
        $scope.trips_time = pTime;
        $scope.cost_details.safe_interstate = price_per_category_safe_interstate;
        $scope.cost_details.safe_other = price_per_category_safe_other
        $scope.cost_details.aggressive = price_per_category_aggressive
        $scope.cost_details.risky = price_per_category_risky
        $scope.cost_details.dangerous = price_per_category_dangerous;
        var segmentColors = LocalStorage.getObject(LocalStorageKeys.MILE_CATEGORY_COLOR);
        $scope.segmentColors = LocalStorage.getObject(LocalStorageKeys.MILE_CATEGORY_COLOR);;
        DOMUtil.onElementReady('body', 100).then(function () {
            $('.col div.has-trip.safe_interstate').css('background-color', segmentColors.safe_interstate_color);
            $('.col div.has-trip.safe_other').css('background-color', segmentColors.safe_other_color);
            $('.col div.has-trip.aggressive').css('background-color', segmentColors.aggressive_color);
            $('.col div.has-trip.risky').css('background-color', segmentColors.risky_color);
            $('.col div.has-trip.dangerous').css('background-color', segmentColors.dangerous_color);
        });
    }
}
