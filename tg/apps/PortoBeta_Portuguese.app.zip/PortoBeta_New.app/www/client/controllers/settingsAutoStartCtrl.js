angular.module('controllers')
    .controller('AutoStartCtrl', AutoStartCtrl);

function AutoStartCtrl($rootScope, $scope, $ionicHistory, SettingsServices, LocalStorage, LocalStorageKeys, WebServiceCache, CordovaBroadcaster, PopupUtil, LoggerUtilType, $translate) {
    // SCOPE FUNCTION
    $scope.itemSelected = itemSelected;

    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    // SCOPE VARIABLES
    $scope.settings;
    $scope.choice;

    // FUNCTIONS
    function ionicViewBeforeEnter() {
        $scope.settings = LocalStorage.getObject(LocalStorageKeys.USER_APP_SETTINGS);
        switch ($scope.settings.auto_start) {
            case "0":
                // Off
                $scope.choice = "0";
                break
            case "1":
                // On
                $scope.choice = "1";
                break;
            case "2":
                // Only when plugged in
                $scope.choice = "2";
                break;
            default:
                // Off
                $scope.choice = "0";
                break;
        }
    }

    function itemSelected() {
        var settingsData = {
            auto_start: $scope.choice
        };
        $scope.settings["auto_start"] = settingsData.auto_start; //{auto_start:settingsData.auto_start};
        SettingsServices.setUserSettings(settingsData).then(function (result) {
            WebServiceCache.cleanseCache(6);

            SettingsServices.getUserSettings().then(function (settings) {
                $scope.settings = settings;
                LocalStorage.setObject(LocalStorageKeys.USER_APP_SETTINGS, settings.auto_start);
                var a;
                var v;
                if ($scope.choice == "0") {
                    a = false;
                    v = "Off";
                } else if ($scope.choice == "1") {
                    a = true;
                    v = "On";
                } else {
                    a = true;
                    v = "Charging";
                }
                CordovaBroadcaster.setAutoStartValue(a, v);
                $ionicHistory.goBack();
            });



        }, function (error) {
            PopupUtil.showSimpleAlert($translate.instant('error'), $translate.instant(error.data['i18n-key']));
        });
    }
}
