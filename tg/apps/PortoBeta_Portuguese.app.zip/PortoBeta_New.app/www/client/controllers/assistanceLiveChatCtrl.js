angular.module('controllers')
    .controller('LiveChatCtrl', LiveChatCtrl);

function LiveChatCtrl($state, $scope, $ionicHistory) {
    
    // SCOPE VARIABLES
    // --> All scope variables that are specific to that view will be defined here
    $scope.showOverlay = false;
    $scope.showChatEmailOverlay = false;
    $scope.showChatPicturesOverlay = false;
    $scope.showGobackOverlay = false;
    

    // SCOPE FUNCTIONS
    // --> All scope functions specific to that view are defined here
    $scope.showUploadOptions = showUploadOptions;
    $scope.closeOverlay = closeOverlay;
    $scope.goBack = goBack;
    

    // SCOPE LIFE CYCLE
    // --> All needed life cycle events specific to that view are defined here. Note that we do not write the function directly in it.
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    $scope.$on('$ionicView.enter', ionicViewEnter);
    
    // FUNCTIONS
    /* 
        name : ionicViewBeforeEnter
        desc : Will call web services and prepare an object for the screen
    */
    
    ////// Functionality when before entering into the view
    /* 
        name : ionicViewBeforeEnter
        desc : It will set the step number to handle the current step in before entering into the view. 
    */
    function ionicViewBeforeEnter() {

    }

    ////// Functionality when entering into the view
    function ionicViewEnter() {

    }
    
    /* 
        name : showUploadOptions
        parameters : pOptions
        desc : Show overlay background and options based on the parameters. 
    */
    function showUploadOptions(pOptions) {
        $scope.showOverlay = true;
        switch (pOptions) {
            case "email":
                $scope.showChatEmailOverlay = true;
                break;
            case "picture":
                $scope.showChatPicturesOverlay = true;
                break;
        }
    }
    
    /* 
        name : closeOverlay
        parameters : pOptions
        desc : Close overlay background and options based on the parameters. 
    */
    function closeOverlay(pOptions) {
        $scope.showOverlay = false;
        switch (pOptions) {
            case "email":
                $scope.showChatEmailOverlay = false;
                break;
            case "picture":
                $scope.showChatPicturesOverlay = false;
                break;
            case "goback":
                $scope.showGobackOverlay = false;
                break;
            case "leave":
                $scope.showGobackOverlay = false;
                $ionicHistory.goBack();
                break;
        }
    }
    
    /* 
        name : closeOverlay
        desc : Show overlay background and show the options Leave and Cancel for the confirmation to leave the chat. 
    */
    function goBack(){
        $scope.showOverlay = true;
        $scope.showGobackOverlay = true;
    }
}
