angular.module('controllers')
    .controller('TestdriveActivationCtrl', TestdriveActivationCtrl);

function TestdriveActivationCtrl($rootScope, $scope, $state, $timeout, $window, SettingsServices, LoadingUtil, LocalStorage, LocalStorageKeys, PopupUtil, GlobalConstants, CordovaBroadcaster) {
    // SCOPE FUNCTIONS
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    $scope.validateActivationField = validateActivationField;
    $scope.activateEnvironment = activateEnvironment;

    // SCOPE VARIABLES
    $scope.activation = {};
    $scope.showErrorMessage = false;
    $scope.formValid = false;

    // FUNCTIONS
    function ionicViewBeforeEnter() {
        console.log(ionic.Platform.is('browser'));
        var baseUrl = LocalStorage.get(LocalStorageKeys.BASE_URL_OVERRIDE, "");
        if (baseUrl != "") {
            // Urls are already set so we can redirect to login
            $state.go('login');
        }
    }

    function validateActivationField() {
        var code = "";
        if ($scope.activation.code == null) {
            code = "";
        } else {
            code = $scope.activation.code.toString();
        }

        if (code.length == 5) {
            $scope.formValid = true;
        } else {
            $scope.formValid = false;
        }
    }

    function activateEnvironment() {
        LoadingUtil.showLoader();

        SettingsServices.getEnvironment($scope.activation.code).then(function (response) {
            console.log(123123, response);

            LocalStorage.set(LocalStorageKeys.BASE_URL_OVERRIDE, response.data.baseUrl);
            LocalStorage.set(LocalStorageKeys.COLLECTOR_URL_OVERRIDE, response.data.collectorUrl);
            LocalStorage.set(LocalStorageKeys.COLLECTOR_URL_T2_OVERRIDE, response.data.ubiCollectorUrl);
            LocalStorage.set(LocalStorageKeys.PAS_URL_OVERRIDE, response.data.pasUrl);

            GlobalConstants.init();
            CordovaBroadcaster.sendPlatformReady();

            $timeout(function () {
                LoadingUtil.hideLoader();
                PopupUtil.showSimpleAlert("Restart Required", "<p>We have successfully unlocked your application. Please close your application and start it again for changes to be applied.</p>");
                //                $state.go('login');
                //$window.location.reload(true);
            }, 500);
        });

        //        $timeout(function () {
        //            var response = {
        //                baseUrl: "http://localhost:8100/baselineConsoleDefault",
        //                pasUrl: "http://localhost:8100/pasServices",
        //                collectrUrl: "http://localhost:8100/collectorDefault",
        //                ubiCollectorUrl: "http://localhost:8100/collectorDefaultT2"
        //            }
        //
        //            LocalStorage.set(LocalStorageKeys.BASE_URL_OVERRIDE, response.baseUrl);
        //            LocalStorage.set(LocalStorageKeys.COLLECTOR_URL_OVERRIDE, response.collectrUrl);
        //            LocalStorage.set(LocalStorageKeys.COLLECTOR_URL_T2_OVERRIDE, response.ubiCollectorUrl);
        //            LocalStorage.set(LocalStorageKeys.PAS_URL_OVERRIDE, response.pasUrl);
        //
        //            //        PopupUtil.showSimpleAlert("URL CHANGED", "<p>Reboot the app for the change to take place</p>");
        //            GlobalConstants.init();
        //            CordovaBroadcaster.sendPlatformReady(); // refresh the URl to the native side too
        //
        //            LoadingUtil.hideLoader();
        //            $state.go('login');
        //        }, 500);
    }
}
