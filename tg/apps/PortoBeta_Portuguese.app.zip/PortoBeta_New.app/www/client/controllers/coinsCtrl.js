angular.module('controllers')
    .controller('CoinsCtrl', CoinsCtrl);

function CoinsCtrl($state, $rootScope, $scope, $ionicSlideBoxDelegate, GamingServices, DateUtil) {
    $rootScope.activeMenuItem = "coins";
    $scope.selectedTab = 0;
    $scope.coinsTotal = null;

    $scope.selectTab = selectTab;
    $scope.onSlideChanged = onSlideChanged;

    $scope.contentHeight = $(window).height() - $('.bar-header').height() - $('section#selector').height() - 25;

    $scope.$on('$ionicView.loaded', ionicViewLoaded);

    $rootScope.activeMenuItem = "coins";

    function ionicViewLoaded() {
        GamingServices.getCoinsHistory().then(function (response) {
            $scope.earnedCoins = formatObject(response.earned);
            $scope.spentCoins = formatObject(response.spent);
        }, function (response) {});
        loadCoinsTotal();
    }

    function loadCoinsTotal() {
        console.log('load total');
        GamingServices.getCoinsTotal().then(function (response) {
            $scope.coinsTotal = response.coins.value;
        }, function (error) {
            console.log('ERROR', error);
        });
    }

    function selectTab(i) {
        $scope.selectedTab = i;
        $ionicSlideBoxDelegate.$getByHandle('coins-slider').slide(i);
    }

    function onSlideChanged(i) {
        $scope.selectedTab = i;
    }

    function formatObject(o) {
        if (o != null) {
            for (var i = 0; i < o.length; i++) {
                o[i].date = moment(o[i].date).format('dddd MMMM DD, YYYY');
                console.log(o[i]);
            }
        }
        return o;
    }
}
