angular.module('controllers')
    .controller('LeaderboardAddFacebookFriendsCtrl', LeaderboardAddFacebookFriendsCtrl);

function LeaderboardAddFacebookFriendsCtrl($state, $rootScope, $scope, $ionicHistory,LocalStorage,LocalStorageKeys,SocialUserService,LeaderBoardServices) {
    // SCOPE VARIABLES
        $scope.users=[];
        var fakeUsersData=[
            {
                name: "Tommy Bernard",
                isFriend:true
            },
            {
                name: "Jim Lush",
                isFriend:true
            },
            {
                name: "Sebastian Carrey",
                isFriend:false
            },
            {
                name: "Simon Smith",
                isFriend:false
            },
            {
                name: "Caroline Tramblay",
                isFriend:true
            }
        ];

    // SCOPE FUNCTIONS
        $scope.inviteFriend = inviteFriend;

    // SCOPE LIFE CYCLE EVENTS

    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    // FUNCTIONS
       /*
        name : ionicViewBeforeEnter
        desc : Fetches facebook friends those are using Basedrive 21 app.
               It fetches friends those are logged in facebook pauth in Basedrive21. 
    */
    function ionicViewBeforeEnter() {
        var accessToken = LocalStorage.get(LocalStorageKeys.FB_ACCESS_TOKEN);
            SocialUserService.getFacebookFriends(accessToken).then(function(response){
                $scope.users=response.friends.data;
            },function(error){
                $scope.users=fakeUsersData;
                fetchUsers();
            });
    }
    
    /*
        name : fetchUsers
        desc : Fetches leaderboard users those are connected with logged in user. 
    */
    function fetchUsers() {
        LeaderBoardServices.getLeaderBoardUsers().then(function(response){
           // $scope.users = response;    
        },function(error){
            //$scope.users = fakeUsersData;    
        });
    }
     
     /*
        name : inviteFriend
        desc : To send invite to the friend. 
    */
    function inviteFriend(pUser) {
      LeaderBoardServices.inviteFriend(pUser.name).then(function(response){
     
        },function(error){
      
        });
    }

}
