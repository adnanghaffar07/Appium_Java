angular.module('controllers')
    .controller('LeaderboardInvitesCtrl', LeaderboardInvitesCtrl);

function LeaderboardInvitesCtrl($state, $rootScope, $scope, $ionicHistory,LocalStorage,LocalStorageKeys,LeaderBoardServices) {
    // SCOPE VARIABLES
    $scope.invites=[];
        var fakeUsersData=[
            {
                name: "Tommy Bernard"
            },
            {
                name: "Jim Lush"
            },
            {
                name: "Sebastian Carrey"
            },
            {
                name: "Simon Smith"
            },
            {
                name: "Caroline Tramblay"
            }
        ];

    // SCOPE FUNCTIONS
       $scope.acceptInvite = acceptInvite;
       $scope.rejectInvite = rejectInvite;

    // SCOPE LIFE CYCLE EVENTS

    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    // FUNCTIONS

    function ionicViewBeforeEnter() {
          fetchInvites();
    }
    
    /*
        name : fetchInvites
        desc : Fetches leaderboard invites. 
    */
    function fetchInvites() {
        LeaderBoardServices.getInvites().then(function(response){
            $scope.invites = response;    
        },function(error){
            $scope.invites = fakeUsersData;    
        });
    }
     /*
        name : acceptInvite
        desc : On accepting invitation. 
    */
    function acceptInvite(i) {
      LeaderBoardServices.invitationStatus(1).then(function(response){
     $scope.invites.splice(i,1);
        },function(error){
      $scope.invites.splice(i,1);
        });
    }
    
    /*
        name : rejectInvite
        desc : On rejecting invite. 
    */
    function rejectInvite(i) {
      LeaderBoardServices.invitationStatus(0).then(function(response){
     $scope.invites.splice(i,1);
        },function(error){
      $scope.invites.splice(i,1);
        });
    }
}
