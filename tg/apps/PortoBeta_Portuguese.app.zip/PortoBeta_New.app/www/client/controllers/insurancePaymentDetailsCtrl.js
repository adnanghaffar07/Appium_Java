angular.module('controllers')
    .controller('InsurancePaymentDetailsCtrl', InsurancePaymentDetailsCtrl);
function InsurancePaymentDetailsCtrl($rootScope, $state, $scope, $stateParams, PaymentServices,PopupUtil,LoggerUtilType,LoadingUtil) {
    // SCOPE VARIABLES
    // --> All scope variables that are specific to that view will be defined here
    $scope.payment = {};

    // SCOPE FUNCTIONS
    // --> All scope functions specific to that view are defined here
    $scope.goToReportProblem = goToReportProblem;

    // SCOPE LIFE CYCLE
    // --> All needed life cycle events specific to that view are defined here. Note that we do not write the function directly in it.
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    $scope.$on('$ionicView.enter', ionicViewEnter);

    // FUNCTIONS
    /* 
        name : ionicViewBeforeEnter
        desc : Will call web services and prepare an object for the screen
    */
    function ionicViewBeforeEnter() {
        var payment = $stateParams.paymentId;
        var paymentData = {
            'paymentID': payment
        }
        /*
            description : a webservice call to get a particular detailed payment using payment id we are getting from state params.
        */
        LoadingUtil.showLoader();
        PaymentServices.getPayment(paymentData).then(function(response) {
            LoadingUtil.hideLoader();
            $scope.payment = response.data;
            $scope.payment.date = $scope.formatDate($scope.payment.date);
            $scope.address = $scope.payment.user_payment_method.address;
        }, function(error) {
            //Error
            LoadingUtil.hideLoader();
            PopupUtil.showSimpleAlert($translate.instant('error'),$translate.instant(error['i18n-key']));
        });
    }
    
    /* 
        name : ionicViewEnter
        desc : Will call web services and prepare an object for the screen every time user enters the screen
    */
    function ionicViewEnter() {
        
    }
    
    function goToReportProblem() {
        $state.go("app.settingsReportProblem");
    }
}