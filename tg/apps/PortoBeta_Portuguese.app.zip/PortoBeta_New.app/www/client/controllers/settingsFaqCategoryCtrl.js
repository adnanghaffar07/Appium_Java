angular.module('controllers')
    .controller('FaqCategoryCtrl', FaqCategoryCtrl);

function FaqCategoryCtrl($state, $scope, $translate, $stateParams) {

    // SCOPE VARIABLES
    // --> All scope variables that are specific to that view will be defined here
    $scope.category = $stateParams.category;

    // SCOPE FUNCTIONS
    // --> All scope functions specific to that view are defined here
    $scope.goToArticle = goToArticle;

    // SCOPE LIFE CYCLE
    // --> All needed life cycle events specific to that view are defined here. Note that we do not write the function directly in it.
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    // FUNCTIONS
    /* 
        name : ionicViewBeforeEnter
        desc : Will call web services and prepare an object for the screen
    */
    function ionicViewBeforeEnter() {
        console.log('load category', $scope.category);
    }

    function goToArticle(article) {
        $state.go('app.faqCategoryArticle', {
            article: article
        });
    }

}
