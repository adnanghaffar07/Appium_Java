angular.module('controllers')
    .controller('LeaderboardAddCtrl', LeaderboardAddCtrl);

function LeaderboardAddCtrl($state, $rootScope, $scope, $ionicHistory) {
    // SCOPE VARIABLES
    $scope.invitesCount = 4;

    // SCOPE FUNCTIONS
    $scope.goBack = goBack;
    $scope.navigateTo = navigateTo;
  
    // SCOPE LIFE CYCLE EVENTS

    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    // FUNCTIONS

    function ionicViewBeforeEnter() {
  
    }

    function goBack() {
        $ionicHistory.goBack();
    }

    function navigateTo(pState) {
        $state.go(pState);
    }
}
