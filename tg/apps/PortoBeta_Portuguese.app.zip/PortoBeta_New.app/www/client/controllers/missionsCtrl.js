angular.module('controllers')
    .controller('MissionsCtrl', MissionsCtrl);

function MissionsCtrl($scope, $rootScope, ExternalInteractionUtil, GamingServices, StringUtil, $translate, $state, FirebaseService, LocalStorage, LocalStorageKeys) {
    $scope.$on('$ionicView.enter', ionicViewLoaded);
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    $scope.missionClicked = missionClicked;
    $scope.closeDetails = closeDetails;

    $rootScope.activeMenuItem = "missions";
    $scope.missions = [{}];
    $scope.detailedMission = null;
    $scope.button = false;
    $scope.link = null;
    $scope.internal = false;
    $scope.button_label = null;
    $scope.tag = '';

    function ionicViewBeforeEnter() {
        $rootScope.activeMenuItem = "missions";
    }

    function ionicViewLoaded() {
        loadMissions();

        FirebaseService.logEvent("view_item", {
            item_name: "Missões", 
            custom_dimension2: "Missões",
            custom_dimension5: LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID) !== null ? "logged in" : "logged out"
        });
    }

    $scope.openUrl = function (url, tag) {
        console.log('openUrl');
        alertBackend(tag);
        ExternalInteractionUtil.openWebSite(url);
    };

    /*
        Name: loadMissions
        Desc: Call API to load and prepare mission for UI
    */
    function loadMissions() {
        GamingServices.getMissionsData().then(function (response) {
            for (var i = 0; i < response.length; i++) {
                response[i].coins = StringUtil.formatNumbers(response[i].coins);
                if (response[i].unlock_timestamp != null) {
                    var converted = calculateTimestamp(response[i].unlock_timestamp);
                    response[i].unlock_countdown = converted;
                }
            }

            $scope.missionsList = response;
        }, function (response) {
            console.log("ERROR", response);
        })
    }

    function calculateTimestamp(ts) {
        var date_future = ts * 1000;
        var date_now = moment().format('x');

        // get total seconds between the times
        var delta = Math.abs(date_future - date_now) / 1000;

        // calculate (and subtract) whole days
        var days = Math.floor(delta / 86400);
        delta -= days * 86400;

        // calculate (and subtract) whole hours
        var hours = Math.floor(delta / 3600) % 24;
        delta -= hours * 3600;

        // calculate (and subtract) whole minutes
        var minutes = Math.floor(delta / 60) % 60;
        delta -= minutes * 60;

        // what's left is seconds
        var seconds = delta % 60; // in theory the modulus is not required

        return days + "d " + hours + "h " + minutes + "m ";
    }

    
    function missionClicked(mission) {
        $scope.button = false;
        $scope.link = null;
        $scope.internal = false;

        $('#mission-view').css({
            "-webkit-filter": "blur(" + 2 + "px)",
            "filter": "blur(" + 2 + "px)"
        });

        $scope.detailedMission = mission;

        FirebaseService.logEvent("view_item", {
            item_name: "Detalhes " + $translate.instant(mission.tag), 
            custom_dimension2: "Missões",
            custom_dimension5: LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID) !== null ? "logged in" : "logged out"
        });

        switch (mission.id) {
            case '3f49866b-9f54-4035-b67b-f5ce861fb057' : // url
                $scope.button = true;
                $scope.link = mission.url;
                $scope.internal = false;
                $scope.button_label = 'missions_url_button';
                $scope.tag = mission.tag;
                break;
            case '687730be-9867-4ec3-8b41-6a212b4e923b' : // profile
                $scope.button = true;
                $scope.internal = 'app.profile';
                $scope.button_label = 'missions_profile_button';
                $scope.tag = mission.tag;
                break;
            case 'f53ad088-e03c-43cd-bde1-5b5bb87f817e' : // ranking
                $scope.button = true;
                $scope.internal = 'app.leaderboard';
                $scope.button_label = 'missions_ranking_button';
                $scope.tag = mission.tag;
                break;
            case '178fb513-9aa6-49b2-9759-bc8cc4549fab' : // share score
                $scope.button = true;
                $scope.internal = 'app.missions_score';
                $scope.button_label = 'missions_score_button';
                $scope.tag = mission.tag;
                break;
        }

    }

    function alertBackend(tagName) {
        if (tagName) {
            GamingServices.alertCoinTag(tagName).then(function (response) {
                loadMissions();
                console.log('alertBackend', response);
            }, function (error) {
                console.log('alertBackend error', error);
            });
        }
    }

    function clean() {
        $scope.detailedMission = null;
        $scope.button_label = null;
        $scope.button = false;
        $scope.link = null;
        $scope.internal = false;
        $('#mission-view').css({
            "-webkit-filter": "none",
            "filter": "none"
        });
    }

    $scope.openPage = function (link, tag) {
        
        FirebaseService.logEvent("select_content", {
            content_type: 'mission_completion',
            item_name: "Detalhes " + $translate.instant(tag), 
            custom_dimension2: "Missões",
            custom_dimension5: LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID) !== null ? "logged in" : "logged out",
            custom_dimension7: tag
        });


        clean();

        if (link === "app.missions_score") {
            $scope.share();
        } else {

            if (tag === "visit.ranking") {
                alertBackend(tag);
            }

            $state.go(link);
        }
    };

    $scope.share = function () {

        alertBackend('share.score');
        try {
            window.plugins.socialsharing.share(
                $translate.instant('share_message'),
                $translate.instant('share_title'),
                [],
                $translate.instant('share_link'));
        } catch (e) {
            console.log('Error Sharing');
        }
    };


    function closeDetails() {
        clean();
    }
}
