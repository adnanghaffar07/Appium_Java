angular.module('controllers')
    .controller('ProfilePicturesCtrl', ProfilePicturesCtrl);

function ProfilePicturesCtrl($rootScope, $scope,BooleanConstant,CameraCapture,$state,UploadImage,CameraUtil,InsuranceServices,LocalStorage,LocalStorageKeys,$ionicHistory) {
 // SCOPE FUNCTIONS
    $scope.viewPictureZoom = viewPictureZoom;
    $scope.optionSelected = optionSelected;
    $scope.showSelectOptions = showSelectOptions;
    $scope.goBack = goBack;
    $scope.selIndex="";
    //SCOPE VARIABLES
    $scope.showDelete = BooleanConstant.BOOL_FALSE;
    $scope.showPictureOverlay = BooleanConstant.BOOL_FALSE;
    $scope.pictures = [];
    $scope.pictures[2] ="client/images/profile/front.png"; 
    // ["client/images/profile/front.png", "client/images/profile/rear.png", "client/images/profile/left.png", "client/images/profile/right.png", "client/images/profile/interior.png", "client/images/profile/engine.png"];
    var cameraOptions = CameraCapture.IMAGE_SIZE;
    var imageData={};
    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    $scope.$on('$ionicView.enter', ionicViewEnter);
   // $scope.$on('$ionicView.beforeLeave', beforeLeave);
    //$scope.$on('$ionicView.loaded', onLoaded);

    // FUNCTIONS
    ////// Functionality when before entering into the view
    /*
        name : ionicViewBeforeEnter
        desc : will do the data binding to the scope before entering into the view
    */
    function ionicViewBeforeEnter() {
          if(parseInt($rootScope.deleteSpecificPic) >= 0){
              $scope.pictures[$rootScope.deleteSpecificPic]=null;
          }
          if(angular.isDefined($rootScope.updatedPic) && Object.keys($rootScope.updatedPic).length > 0){
              $scope.pictures[$rootScope.updatedPic.index]=$rootScope.updatedPic.imageKey;
          }
    }
    
    // FUNCTIONS
    ////// Functionality after entering into the view
    /*
        name : ionicViewEnter
        desc : Hides footer after entering in to screen.
    */
    function ionicViewEnter() {
        if ($scope.pictures.length == 0) {
            $scope.showPictureOverlay = BooleanConstant.BOOL_TRUE;
        }
    }
     /*
        name : beforeLeave
        desc : Binds specific data to scope before leaving screen.
    */
    function goBack(){
        var len=0;
        var arrPics=$scope.pictures;
        for(var i=0;i<arrPics.length;i++){
            if(angular.isDefined(arrPics[i]) && arrPics[i] != null && arrPics[i].length > 0){
                len+=1;
            }
        }
        $scope.profileData = LocalStorage.getObject(LocalStorageKeys.PROFILE_DATA);
        if(len > 0){
        $scope.profileData.user.picturescount=len;
        }else{
            $scope.profileData.user.picturescount="";
        }
        $scope.profileData.user.pictures=$scope.pictures;
        $rootScope.needToSaveProfile = BooleanConstant.BOOL_TRUE;
        LocalStorage.setObject(LocalStorageKeys.PROFILE_DATA, $scope.profileData);
        $ionicHistory.goBack();
    }
    
    /* 
       name: beforeEnter
       desc: Fetches required pictures
     */
    function beforeEnter(){
        var arrPics=$scope.pictures;
        for(var i=0;i<arrPics.length;i++){
            if(angular.isDefined(arrPics[i]) && arrPics[i] != null && arrPics[i].length > 0){
            InsuranceServices.getPicture(arrPics[i]).then(function (response) {
            
            }, function (error) {
                
            });
            }
        }
    }
    ////// Function to navigate to specific screen.
    /*
        name : goToSpecificPage
        parameter:State value
        desc : It navigates to specific screen.
    */
    function viewPictureZoom(index,title) {
        var selPicture={image:$scope.pictures[index],
                        title:title,
                        index:index};
        $state.go("app.profilePictureZoom",{
            specificPicture:selPicture
        });
    }
    
    // Function to navigate to People involved list screen after saving data.
    /*
        name : optionSelected
        parameter:Selected option
        desc : (Take Picture / Choose from Gallery / Cancel)
    */
    function optionSelected(option) {
        if (option == UploadImage.CANCEL) {
            $scope.showPictureOverlay = BooleanConstant.BOOL_FALSE;
        }else if(option == UploadImage.DELETE){
            $scope.pictures[$scope.selIndex]=null;
            $scope.showPictureOverlay = BooleanConstant.BOOL_FALSE;
        }else if(option==UploadImage.TAKE){
            takePhoto();
        }else if(option==UploadImage.CHOOSE){
            chooseFromLibrary();
        }
    }
     /*
        name   :  takePhoto  
        desc   :  It opens camera to take photo.
    */
    function takePhoto() {
        $scope.showPictureOverlay  = BooleanConstant.BOOL_FALSE;
        CameraUtil.takePicture(cameraOptions).then(function (image) {
            processImage(image);
        });
    }
    /*
        name   :  chooseFromLibrary  
        desc   :  It shows images in Gallery.
    */
    function chooseFromLibrary() {
        $scope.showPictureOverlay  = BooleanConstant.BOOL_FALSE;
        CameraUtil.getPicture(cameraOptions).then(function (image) {
            processImage(image);
        });
    }
    // Function to navigate to People involved list screen after saving data.
    /*
        name : showSelectOptions
        parameter:index, flag to show / hide delete option
        desc : Display footer to select options to upload picture.
    */
    function showSelectOptions(index, flag) {
        $scope.showPictureOverlay = BooleanConstant.BOOL_TRUE;
        $scope.showDelete = flag;
        $scope.selIndex=index;
    }
    /*
        name   :  processImage  
        desc   :  It will save saves picture to server.
    */
    function processImage(img){
        imageData.image = UploadImage.BASE_64 + img;
        imageData.title = "";
        InsuranceServices.postPicture(imageData).then(function (response) {       
              $scope.pictures[$scope.selIndex] = imageData.image;
            }, function (error) {

            });
    }
    
     /*
        name   :  deletePicture  
        desc   :  Delete selected picture from server.
    */
    function deletePicture(){
            imageData.id = ''; 
            imageData.image="";
            imageData.title = "";
            InsuranceServices.deletePicture(imageData).then(function (response) {
                $scope.pictures[$scope.selIndex]=null;                
            }, function (error) {

            });
    }
}
