angular.module('controllers')
    .controller('ProfileInsurancePremiumCtrl', ProfileInsurancePremiumCtrl);

function ProfileInsurancePremiumCtrl($rootScope, $scope, $state, $timeout, $ionicHistory, LocalStorage, LocalStorageKeys,BooleanConstant, ProfileServices, WebServiceCache, PopupUtil, $translate) {
    // SCOPE FUNCTIONS
    $scope.saveProfile = saveProfile;

    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    $scope.$on('$ionicView.loaded', ionicViewLoaded);

    // FUNCTIONS
    function ionicViewBeforeEnter() {
        $scope.profileData = LocalStorage.getObject(LocalStorageKeys.PROFILE_DATA);
    }

    function ionicViewLoaded() {
        $("#insurancePremium").maskMoney({prefix:'R$ ', allowNegative: true, thousands:'.', decimal:',', affixesStay: false});
    }
    
     /*
        name: saveProfile
        desc: Saves updated user name to local storage and server.
    */ 
    function saveProfile() {
        $rootScope.updateMenuHeader = true;

        $scope.profileData.Insurance.premium = $('#insurancePremium').val();
        
        ProfileServices.saveProfile("", $scope.profileData).then(function (response) {
            WebServiceCache.cleanseCache(2);
            LocalStorage.setObject(LocalStorageKeys.PROFILE_DATA, $scope.profileData);
            $ionicHistory.goBack();
        }, function (error) {
            PopupUtil.showSimpleAlert($translate.instant('error'),$translate.instant(error.data['i18n-key']));
        });
    }
}
