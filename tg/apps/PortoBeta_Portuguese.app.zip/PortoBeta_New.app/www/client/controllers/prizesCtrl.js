angular.module('controllers')
    .controller('PrizesCtrl', PrizesCtrl);

function PrizesCtrl($rootScope, $scope, $state, PrizesServices, $filter, $translate, PopupUtil, LoadingUtil, ContestStatus, WebServiceCache) {
    // SCOPE VARIABLES
    //Change "isPrizwWon" status to "won" / "lost" to see when there are no prizes lost / won.
    $scope.activeTab = 1;
    $scope.activeChallenges = [];
    $scope.wonChallenges = [];
    $scope.lostChallenges = [];
    // SCOPE FUNCTIONS
    $scope.setActiveTab = setActiveTab;
    $scope.goToPrizeDetail = goToPrizeDetail;
    $scope.removeLostChanllenge = removeLostChanllenge;
    $scope.filterdata = '';
    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    // FUNCTIONS
    ////// Functionality when before entering into the view
    /*
        name : ionicViewBeforeEnter
        desc : will do the data binding to the scope before entering into the view
    */
    function ionicViewBeforeEnter() {
        $rootScope.activeMenuItem = "prizes";
        $scope.contentHeight = $(window).height() - 88;
        console.log(8989, $scope.contentHeight);

        getActiveChallenges();
        getWonChallenges();
        getLostChallenges();
    }
    ////// Function to show enabled tab.
    /*
        name : setActiveTab
        parameter:Tab index, contest status
        desc : It filters data and enable current tab.
    */
    function setActiveTab(tab, status) {
        $scope.activeTab = tab;
        $scope.filterdata = status;
        // $scope.queryData = $filter('filter')($scope.prizes, status);
    }
    ////// Function to redirect to contest detail screen.
    /*
        name : goToPrizeDetail
        parameter:index
        desc : To navigate to contest detail screen by passing specific contest 
               data as state params.
    */
    function goToPrizeDetail(data) {
        if (!data.has_user_qualified) {
            return false;
        }
        $state.go('app.prizesDetail', {
            'specificContest': data
        });
    }

    /*
       name : removeItem
       parameter:index
       desc : Removes the selected item.
   */

    function removeLostChanllenge(pChallengeId) {
        // webservice need to be integrated here to delete a contest for a user
        LoadingUtil.showLoader();
        PrizesServices.deleteLostChallenge(pChallengeId).then(function (response) {
            LoadingUtil.hideLoader();
            //$scope.activeChallenges = response;
            WebServiceCache.cleanseCache(3);
            getLostChallenges();
        }, function (error) {
            LoadingUtil.hideLoader();
            var buttons = [{
                text: '<span> Ok </span>',
                onTap: function (e) {}
            }];
            var errorMsg = $translate.instant(error['i18n-key']);
            PopupUtil.showCustomPopupLocal("", "<h4>Error!</h4><h6>" + errorMsg + "</h6>", buttons, "", true);
        });
    }


    /*
        name : getActivePrizeDetails
        desc : To get list of active challenges from server.
    */
    function getActiveChallenges() {
        LoadingUtil.showLoader();
        PrizesServices.getActiveChallenges().then(function (response) {
            LoadingUtil.hideLoader();
            $scope.activeChallenges = response;
        }, function (error) {
            LoadingUtil.hideLoader();
            var buttons = [{
                text: '<span> Ok </span>',
                onTap: function (e) {}
            }];
            var errorMsg = $translate.instant(error['i18n-key']);
            PopupUtil.showCustomPopupLocal("", "<h4>Error!</h4><h6>" + errorMsg + "</h6>", buttons, "", true);
        });
    }

    /*
        name : getActivePrizeDetails
        desc : To get list of active challenges from server.
    */
    function getWonChallenges() {
        LoadingUtil.showLoader();
        PrizesServices.getWonChallenges().then(function (response) {
            LoadingUtil.hideLoader();
            $scope.wonChallenges = response;
        }, function (error) {
            LoadingUtil.hideLoader();
            var buttons = [{
                text: '<span> Ok </span>',
                onTap: function (e) {}
            }];
            var errorMsg = $translate.instant(error['i18n-key']);
            PopupUtil.showCustomPopupLocal("", "<h4>Error!</h4><h6>" + errorMsg + "</h6>", buttons, "", true);
        });
    }

    /*
        name : getActivePrizeDetails
        desc : To get list of active challenges from server.
    */
    function getLostChallenges() {
        LoadingUtil.showLoader();
        PrizesServices.getLostChallenges().then(function (response) {
            LoadingUtil.hideLoader();
            var vrLostChallenges = [];
            for (var i = 0; i < response.length; i++) {
                if (!response[i].is_hidden)
                    vrLostChallenges.push(response[i]);
            }
            $scope.lostChallenges = vrLostChallenges;
        }, function (error) {
            LoadingUtil.hideLoader();
            var buttons = [{
                text: '<span> Ok </span>',
                onTap: function (e) {}
            }];
            var errorMsg = $translate.instant(error['i18n-key']);
            PopupUtil.showCustomPopupLocal("", "<h4>Error!</h4><h6>" + errorMsg + "</h6>", buttons, "", true);
        });
    }
}
