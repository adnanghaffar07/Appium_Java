angular.module('controllers')
    .controller('InsuranceClaimsCollisionFormSignatureCtrl', InsuranceClaimsCollisionFormSignatureCtrl);

function InsuranceClaimsCollisionFormSignatureCtrl($state, $rootScope, $scope) {
   // SCOPE FUNCTIONS
   $scope.saveData = saveData;
   
   //SCOPE VARIABLES

    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    // FUNCTIONS
     ////// Functionality when before entering into the view
    /*
        name : ionicViewBeforeEnter
        desc : will do the data binding to the scope before entering into the view
    */
    function ionicViewBeforeEnter() {
    
    }
    
      ////// Function to navigate to Form screen after saving data.
    /*
        name : saveData
        parameter:State value
        desc : Saves signature and navigate to form screen.
    */
    
    function saveData(route){
        $state.go(route);
    }
    
    
}
