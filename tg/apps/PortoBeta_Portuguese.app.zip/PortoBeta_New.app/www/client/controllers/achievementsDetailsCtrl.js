angular.module('controllers')
    .controller('AchievementsDetailsCtrl', AchievementsDetailsCtrl);

function AchievementsDetailsCtrl($state, $rootScope, $scope, $stateParams, AchievementsServices, WebServiceCache, DateUtil, $translate, PopupUtil, LoadingUtil) {
    // SCOPE VARIABLES
    $scope.windowwidth = $(window).width();
    console.log($scope.windowwidth, $scope.windowwidth * 0.8);
    $scope.achievement = '';

    // SCOPE FUNCTIONS

    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    // FUNCITIONS
    /*
        name : ionicViewBeforeEnter
        description : It calls webservice to get detailed achievement progress and prepares the chart.
    */
    function ionicViewBeforeEnter() {
        $rootScope.activeMenuItem = "achievements";
        $scope.achievement = $stateParams.achievement;
        //        LoadingUtil.showLoader();
        //        AchievementsServices.getAchievementDetailProgress($scope.achievement.id).then(function(response) {
        //            LoadingUtil.hideLoader();
        //            //WebServiceCache.cleanseCache(1);
        //            bindachievementdetail(response.data);
        //        }, function(error) {
        //            LoadingUtil.hideLoader();
        //            // Handle error
        //            PopupUtil.showSimpleAlert($translate.instant('error'),$translate.instant(error['i18n-key']));
        //        });
    }

    /*
        name : bindachievementdetail
        description : It formats the date in a simple form and calls setupChart() method with two lists.
        params : It accepts a list of daily scores of an achievement
    */
    function bindachievementdetail(data) {
        var d = [];
        var c = 30;
        while (c >= 1) {
            // Loop for 30 days
            var month = moment().subtract(c, 'days').format('M');
            var cd = DateUtil.getOneMonth_small(month - 1) + ' ' + moment().subtract(c, 'days').format('D');

            var dd = {
                x: DateUtil.getOneMonth_small(month - 1) + ' ' + moment().subtract(c, 'days').format('D'),
                y: 0
            }

            d.push(dd);
            c--;
        }

        for (var i = 0; i < d.length; i++) {
            for (var j = 0; j < data.length; j++) {
                var month = moment(data[j].date).format("M");
                var day = moment(data[j].date).format("D");
                var date = DateUtil.getOneMonth_small(month - 1) + ' ' + day;
                if (d[i].x == date) {
                    d[i].y = data[j].score;
                } else {
                    continue;
                }
            }
        }
        setupChart(d);
    }

    /*
        name : setupChart
        description : It sets up the data and prepares the chart to be displayed
        params : It expects a list with x and y axis data.
        return : It displays the chart on the UI.
    */
    function setupChart(pData) {
        $('#achievementchart').css("width", $scope.windowwidth - 20);
        $('#achievementchart').css("height", $scope.windowwidth * 0.8);


        var Ys = [];
        var Xs = [];
        for (var i = 0; i < pData.length; i++) {
            Ys.push(pData[i].y);
            Xs.push(pData[i].x);
        }


        var data = {
            labels: Xs,
            datasets: [{
                fillColor: "rgba(1, 174, 240,0.3)",
                strokeColor: "rgba(0,0,0,0)",
                pointColor: $scope.themeColors.mainBackground,
                pointStrokeColor: "#fff",
                data: Ys
            }]
        };

        Chart.types.Line.extend({
            name: "LineAlt",
            initialize: function (data) {
                Chart.types.Line.prototype.initialize.apply(this, arguments);
                var xLabels = this.scale.xLabels;
                for (var i = 0; i < xLabels.length; i++)
                    if (i % 6 != 0)
                        xLabels[i] = '';
            }
        });

        var options = {
            // Boolean - If we want to override with a hard coded scale
            scaleOverride: true,

            //  Required if scaleOverride is true 
            // Number - The number of steps in a hard coded scale
            scaleSteps: 4,
            // Number - The value jump in the hard coded scale
            scaleStepWidth: 25,
            // Number - The scale starting value
            scaleStartValue: 0,

            scaleLabel: "<%= value + ' % '%>",

            ///Boolean - Whether grid lines are shown across the chart
            scaleShowGridLines: true,

            //String - Colour of the grid lines
            scaleGridLineColor: "rgba(0,0,0,0.1)",

            //Number - Width of the grid lines
            scaleGridLineWidth: 1,

            //Boolean - Whether to show horizontal lines (except X axis)
            scaleShowHorizontalLines: true,

            //Boolean - Whether to show vertical lines (except Y axis)
            scaleShowVerticalLines: false,

            //Boolean - Whether the line is curved between points
            bezierCurve: true,

            //Number - Tension of the bezier curve between points
            bezierCurveTension: 0.4,

            //Boolean - Whether to show a dot for each point
            pointDot: true,

            //Number - Radius of each point dot in pixels
            pointDotRadius: 5,

            //Number - Pixel width of point dot stroke
            pointDotStrokeWidth: 3,

            //Number - amount extra to add to the radius to cater for hit detection outside the drawn point
            pointHitDetectionRadius: 20,

            //Boolean - Whether to show a stroke for datasets
            datasetStroke: true,

            //Number - Pixel width of dataset stroke
            datasetStrokeWidth: 2,

            //Boolean - Whether to fill the dataset with a colour
            datasetFill: true,

            // Boolean - Determines whether to draw tooltips on the canvas or not
            showTooltips: false
        }

        var ctx = document.getElementById("achievementchart").getContext("2d");
        new Chart(ctx).LineAlt(data, options);
    }
}
