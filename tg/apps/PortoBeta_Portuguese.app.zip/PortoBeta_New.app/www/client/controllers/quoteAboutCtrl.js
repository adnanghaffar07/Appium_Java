angular.module('controllers')
    .controller('QuoteAboutCtrl', QuoteAboutCtrl);

function QuoteAboutCtrl($rootScope, $state, $scope, LocalStorage, QuoteStatus, ProfileServices, $ionicHistory, AppDocumentServices, $translate, $sce, BooleanConstant, $filter, CountryName, Profile, LocalStorageKeys, $timeout, $ionicScrollDelegate) {

    // SCOPE VARIABLES
    // --> All scope variables that are specific to that view will be defined here

    /*
        name : requiredFields
        use  : It is a list of fields in template that are to be validated.
    */
    var requiredFields = ['first_name', 'last_name', 'date_of_birth', 'street_name', 'postal_code', 'city_name', 'state'];
    var statesList = [];
    $scope.policyText = "";
    //    
    $scope.userData = {};
    $scope.objgender = Profile.GENDER_OPTIONS;

    // SCOPE FUNCTIONS
    // --> All scope functions specific to that view are defined here
    $scope.goState = goState;
    $scope.gotoSelectInfo = gotoSelectInfo;
    $scope.gotoGender = gotoGender;

    // SCOPE LIFE CYCLE
    // --> All needed life cycle events specific to that view are defined here. Note that we do not write the function directly in it.
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    $scope.$on('$ionicView.enter', ionicViewEnter);
    $scope.$on('$ionicView.beforeLeave', ionicViewBeforeLeave);

    // FUNCTIONS

    // Webservice call to get list of states.
    ProfileServices.getStatesList(CountryName.USA).then(function (response) {
        statesList = $filter('orderBy')(response, 'name');
        var states = [];
        for (var i = 0; i < statesList.length; i++) {
            states.push(statesList[i].name);
        }
        statesList = states;
    }, function (error) {

    });

    // Webservice call to get the document in about screen.
    AppDocumentServices.getDocument("GAQAboutYouText").then(function (response) {
        var preferedLanguage = $translate.use();
        var html = response['AppDocument'][preferedLanguage];
        $scope.policyText = $sce.trustAsHtml(html);
    }, function (error) {
        $scope.policyText = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus eu massa accumsan, euismod purus eget, tincidunt turpis. Proin porttitor risus sit amet egestas fermentum. Sed volutpat quis leo at hendrerit. Vestibulum nec odio vitae odio tempor ullamcorper. Donec ac risus ut ligula congue elementum. Integer venenatis pulvinar mollis. Suspendisse efficitur non purus in bibendum. Morbi vehicula dui odio, sit amet mattis nunc aliquet euismod. Vestibulum ac metus vel augue bibendum tempor. Vestibulum sed facilisis nisi. Quisque eget arcu hendrerit, fringilla ipsum id, vestibulum libero. Nullam consectetur quam eget auctor cursus. Proin pretium massa a egestas laoreet. Suspendisse potenti.";
    });

    /* 
        name : ionicViewBeforeLeave
        desc : This will be executed when user is leaving this screen.
    */
    function ionicViewBeforeLeave() {
        if (!ionic.Platform.isIOS()) {
              ionic.Platform.isFullScreen = false;
        }
    }

    /* 
        name : ionicViewBeforeEnter
        desc : Will prepopulate the data in GAQ-About with user data filled in his profile.
    */
    function ionicViewBeforeEnter() {
        if (!ionic.Platform.isIOS()) {
              ionic.Platform.isFullScreen = true;
        }
        $scope.submitted = BooleanConstant.BOOL_FALSE;
        var userProfile = JSON.parse(JSON.stringify($scope.profileData.user));
        var filledProfile = $rootScope.quoteData['user'];
        if (filledProfile) {
            filledProfile = JSON.parse(JSON.stringify(filledProfile));
        }
        if (angular.isDefined(userProfile.date_of_birth)) {
            userProfile.date_of_birth = new Date(userProfile.date_of_birth);
        }
        if (angular.isDefined(filledProfile) && angular.isDefined(filledProfile.date_of_birth)) {
            filledProfile.date_of_birth = new Date(filledProfile.date_of_birth);
        }
        $scope.userData = filledProfile || userProfile;

        var vrSelectedType = $scope.selectedType;
        var vrSelectedVal = $rootScope.selectedValue;
        $scope.selectedType = null;
        $rootScope.selectedValue = null;
        if ($rootScope.steps.about.length == 0) {
            $rootScope.steps.about = QuoteStatus.PROCESS;
        }
        if (vrSelectedVal == null)
            return false;
        switch (vrSelectedType) {
            case 'states':
                $scope.userData.state = vrSelectedVal;
                $rootScope.quoteData['user'] = $scope.userData;
                break;
            case 'gender':
                $scope.userData.gender = vrSelectedVal[0];
                $rootScope.quoteData['user'] = $scope.userData;
                break;
        }

    }

    /* 
        name : ionicViewEnter
        desc : Will call a method that is to define present step number and name to display in header.
    */
    function ionicViewEnter() {
        $scope.navigateTo(1);
    }

    /*
        name   :  validateData
        params :  An object.
        desc   :  Will check for null and empty values in the given object
        return :  It will return true if all mandatory fields are filled, 
                  and false if any fields listed in mandatory fields array are not filled.
    */
    function validateData(data) {
        var isError = BooleanConstant.BOOL_FALSE;
        if (data) {
            for (var i = 0; i < requiredFields.length; i++) {
                if (angular.isUndefined(data[requiredFields[i]]) || data[requiredFields[i]] === '' || data[requiredFields[i]] === null) {
                    console.log(123123123, data[requiredFields[i]]);
                    isError = BooleanConstant.BOOL_TRUE;
                    break;
                }
            };
        } else {
            isError = BooleanConstant.BOOL_TRUE;
        }
        return isError;
    }

    /*
        name   :  goState
        params :  state number ex: 1 for about, 2 for vehicles etc.
        desc   :  Will validate the details and navigate the user to required state.
    */
    function goState(link) {
        $scope.submitted = BooleanConstant.BOOL_TRUE;
        console.log(141414, $scope.userData);
        var error = validateData($scope.userData);
        if (!error) {
            $rootScope.quoteData['user'] = $scope.userData;
            var driverDetails = {};
            driverDetails.first_name = $scope.userData.first_name;
            driverDetails.last_name = $scope.userData.last_name;
            driverDetails.license_state = $scope.userData.state;
            driverDetails.email = LocalStorage.get(LocalStorageKeys.LOGIN_EMAIL);
            driverDetails.user_id = LocalStorage.get(LocalStorageKeys.LOGIN_USER_ID);
            driverDetails.driver_type_id = "1";
            driverDetails.driver_type = "Primary";
            driverDetails.gender = $scope.userData.gender;
            driverDetails.aboutHadIncident = 'off';
            driverDetails.incidents = [];
            $rootScope.quoteData.drivers[0] = driverDetails;
            $rootScope.steps.about = QuoteStatus.DONE;
            $scope.navigateTo(link);
        } else {
            $timeout(function () {
                var anchorScrollId = $('.required-error').first().attr('id');
                var quotePosition = $('#' + anchorScrollId).offset();
                $ionicScrollDelegate.scrollBy("", quotePosition.top - 100);
            }, 100);
        }
    }

    /*
        name   :  gotoSelectInfo  
        desc   :  It will save the user data filled till this moment and navigates the user to a screen where he will select a state.
    */
    function gotoSelectInfo() {
        $rootScope.quoteData['user'] = $scope.userData;
        $scope.selectedType = 'states';
        if (statesList.length > 0) {
            $state.go('app.selectInfo', { 'list': statesList ,'selectedValue': $scope.userData.state});
        }
    }

    /*
        name   :  gotoGender  
        desc   :  It will save the user data filled till this moment and navigates the user to a screen where he will select a gender.
    */
    function gotoGender() {
        $rootScope.quoteData['user'] = $scope.userData;
        $scope.selectedType = 'gender';
        $state.go('app.selectInfo', { 'list': Profile.GENDER_OPTIONS ,'selectedValue': Profile.GENDER_OPTIONS[$rootScope.quoteData['user'].gender]});
    }
}
