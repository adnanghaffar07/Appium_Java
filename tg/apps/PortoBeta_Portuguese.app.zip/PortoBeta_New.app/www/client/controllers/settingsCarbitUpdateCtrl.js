angular.module('controllers')
    .controller('CarbitUpdateCtrl', CarbitUpdateCtrl);

function CarbitUpdateCtrl($rootScope, $scope, $ionicHistory, LocalStorage, LocalStorageKeys, CordovaBroadcaster) {
    // SCOPE VARIABLES
    
    // SCOPE FUNCTION

    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);


    // FUNCTIONS
    function ionicViewBeforeEnter() {

    }
}
