angular.module('controllers')
    .controller('InsurancePaymentsCtrl', InsurancePaymentsCtrl);
function InsurancePaymentsCtrl($rootScope, $state, $scope, DateUtil, PaymentServices,LoggerUtilType,PopupUtil, LoadingUtil,$translate) {
    // SCOPE VARIABLES
    // --> All scope variables that are specific to that view will be defined here
    $scope.payments = [];

    // SCOPE FUNCTIONS
    // --> All scope functions specific to that view are defined here
    $scope.goToPaymentDetails = goToPaymentDetails;

    // SCOPE LIFE CYCLE
    // --> All needed life cycle events specific to that view are defined here. Note that we do not write the function directly in it.
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    $scope.$on('$ionicView.enter', ionicViewEnter);

    // FUNCTIONS
    /* 
        name : ionicViewBeforeEnter
        desc : Will call web services and prepare an object for the screen
    */
    function ionicViewBeforeEnter() {
        /*
            description : a webservice call to get payment methods for a policy.
        */
        LoadingUtil.showLoader();
        PaymentServices.getUserPayments().then(function(response) {
            LoadingUtil.hideLoader();
            $scope.payments = response.data;
            for (var i=0;i<$scope.payments.length;i++) {
                $scope.payments[i].date = $scope.formatDate($scope.payments[i].date);
            }
        }, function(error) {
            // ERROR
            LoadingUtil.hideLoader();
            PopupUtil.showSimpleAlert($translate.instant('error'),$translate.instant(error['i18n-key']));
        });
    }

    /* 
        name : ionicViewEnter
        desc : Will call web services and prepare an object for the screen every time user enters the screen
    */
    function ionicViewEnter() {
        
    }
    
    /*
        name : goToPaymentDetails
        params : It takes payment id as a parameter
        description : It redirects the user to payment-details screen by passing payment id as state parameter
    */
    function goToPaymentDetails(paymentId) {
        $state.go('app.insurancePaymentDetails', {
            'paymentId': paymentId
        })
    }
}