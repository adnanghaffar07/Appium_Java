angular.module('controllers')
    .controller('ProfileDriversLicenseCtrl', ProfileDriversLicenseCtrl);

function ProfileDriversLicenseCtrl($rootScope, $scope, $state, $timeout, $ionicHistory, LocalStorage, LocalStorageKeys,BooleanConstant) {
    // SCOPE FUNCTIONS
    $scope.saveProfile = saveProfile;

    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    // FUNCTIONS
    /*
        name:ionicViewBeforeEnter
        desc: Populate the profile data in corresponding fields
    */ 
    function ionicViewBeforeEnter() {
        $scope.profileData = LocalStorage.getObject(LocalStorageKeys.PROFILE_DATA);
    }

    /*
        name:saveProfile
        desc: Store the data to be saved in database in rootscope.
              Storing the details in local storage.
    */ 
    function saveProfile() {
        $rootScope.needToSaveProfile = BooleanConstant.BOOL_TRUE;
        LocalStorage.setObject(LocalStorageKeys.PROFILE_DATA, $scope.profileData);
        $ionicHistory.goBack();
    }
}
