angular.module('controllers')
    .controller('QuoteVehiclesCtrl', QuoteVehiclesCtrl);
function QuoteVehiclesCtrl($rootScope, $state, $scope, QuoteStatus, GaqConstants) {
    // SCOPE VARIABLES
    // --> All scope variables that are specific to that view will be defined here
    //$rootScope.quoteData.vehicles = {};
    $scope.vehicles = $rootScope.quoteData.vehicles;
    $scope.disableContinue = false;

    // SCOPE FUNCTIONS
    // --> All scope functions specific to that view are defined here
    $scope.goNextStep = goNextStep;

    // SCOPE LIFE CYCLE
    // --> All needed life cycle events specific to that view are defined here. Note that we do not write the function directly in it.
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    $scope.$on('$ionicView.enter', ionicViewEnter);

    // FUNCTIONS
        
    ////// Function to make calls in before view enter
    /* 
        name : ionicViewBeforeEnter
        desc : It will set the step number to handle the current step in before entering into the view. 
    */
    function ionicViewBeforeEnter() {
        if (Object.keys($rootScope.quoteData.vehicles).length == 0) {
            if ($scope.profileData.cars[0].year != "") {
                $rootScope.steps.vehicle = QuoteStatus.PROCESS;
                $rootScope.quoteData.vehicles[0] = $scope.profileData.cars[0];
                $rootScope.quoteData.vehicles[0]['annual_mileage'] = GaqConstants.AnnualMileage;
            }
        }
        $scope.vehicles = $rootScope.quoteData.vehicles;
        $scope.showAddVehicle = true;
        if (angular.isDefined($scope.vehicles[0]) && angular.isDefined($scope.vehicles[0].year)) {
            $scope.showAddVehicle = false;
        }
        if ($rootScope.steps.vehicle.length == 0 || Object.keys($scope.vehicles).length == 0) {
            $scope.disableContinue = true;
            $rootScope.steps.vehicle = QuoteStatus.PROCESS;
        } else {
            $scope.disableContinue = false;
            $rootScope.steps.vehicle = QuoteStatus.PROCESS;
        }
    }
    
    ////// Function to make calls in view enter
      /* 
        name : ionicViewEnter
        desc : To load data or call webservices after page load, those will be written here. 
    */
    function ionicViewEnter() {
        $scope.navigateTo(2);
        console.log($scope.profileData);
    }
    
    ////// Function to go to Drivers screen
    /* 
        name : ionicViewBeforeEnter
        parameter : val
        desc : It will navigate to paritcualr screen when click on the header based on the val.
    */
    function goNextStep(val) {
        $rootScope.quoteData["annual_mileage"] = $rootScope.quoteData.vehicles[0].annual_mileage;
        $rootScope.steps.vehicle = QuoteStatus.DONE;
        $scope.navigateTo(val);
    }
}