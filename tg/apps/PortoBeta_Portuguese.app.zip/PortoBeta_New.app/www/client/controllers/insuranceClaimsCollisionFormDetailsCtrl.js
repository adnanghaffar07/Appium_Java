angular.module('controllers')
    .controller('InsuranceClaimsCollisionFormDetailsCtrl', InsuranceClaimsCollisionFormDetailsCtrl);

function InsuranceClaimsCollisionFormDetailsCtrl($state, $rootScope, $scope, $stateParams) {
    // SCOPE FUNCTIONS
   
    //SCOPE VARIABLES

    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    // FUNCTIONS
    ////// Functionality when before entering into the view
    /*
        name : ionicViewBeforeEnter
        desc : will do the data binding to the scope before entering into the view
    */
    function ionicViewBeforeEnter() {
        //if (!angular.equals({}, $rootScope.claimDetails.form)) {
            $rootScope.form.details = $stateParams.details;
        //}
    }
}