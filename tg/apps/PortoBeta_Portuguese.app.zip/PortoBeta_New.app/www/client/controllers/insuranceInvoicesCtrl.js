angular.module('controllers')
    .controller('InsuranceInvoicesCtrl', InsuranceInvoicesCtrl);
function InsuranceInvoicesCtrl($rootScope, $state, $scope, DateUtil, InsuranceServices,PopupUtil,LoggerUtilType, LoadingUtil,$translate) {
    // SCOPE VARIABLES
    // --> All scope variables that are specific to that view will be defined here
    $scope.remainingBalance = 0;

    // SCOPE FUNCTIONS
    // --> All scope functions specific to that view are defined here
    $scope.goToInvoiceDetails = goToInvoiceDetails;

    // SCOPE LIFE CYCLE
    // --> All needed life cycle events specific to that view are defined here. Note that we do not write the function directly in it.
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);
    $scope.$on('$ionicView.enter', ionicViewEnter);

    // FUNCTIONS
    /* 
        name : ionicViewBeforeEnter
        desc : Will call web services and prepare an object for the screen
    */
    function ionicViewBeforeEnter() {
         /*
            description : a webservice call to get invoices generated for a policy.
        */
        LoadingUtil.showLoader();
        InsuranceServices.getInvoices().then(function(response) {
            LoadingUtil.hideLoader();
            var invoices = response.data;
            for (var i = 0; i < invoices.length; i++) {
                 invoices[i].issued_date = $scope.formatDate(invoices[i].issued_date);
                 invoices[i].date_from = $scope.formatDate(invoices[i].date_from);
                 invoices[i].date_to = $scope.formatDate(invoices[i].date_to);
           }
           $scope.invoices = invoices;
        }, function(error) {
           $scope.invoices = [];
           LoadingUtil.hideLoader();
           PopupUtil.showSimpleAlert($translate.instant('error'),$translate.instant(error['i18n-key']));
        })
    }
    
    /* 
        name : ionicViewEnter
        desc : Will call web services and prepare an object for the screen every time user enters the screen
    */
    function ionicViewEnter() {
       
    }

    /*
        name : goToInvoiceDetails
        params : It takes invoice id as a parameter
        description : It redirects the user to invoice-details screen by passing invoice id as state parameter.
    */
    function goToInvoiceDetails(invoiceId) {
        $state.go('app.insuranceInvoiceDetails', {
            'invoiceId': invoiceId
        })
    }
}