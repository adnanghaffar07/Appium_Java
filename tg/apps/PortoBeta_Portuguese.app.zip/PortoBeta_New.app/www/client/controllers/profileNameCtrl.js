angular.module('controllers')
    .controller('ProfileNameCtrl', ProfileNameCtrl);

function ProfileNameCtrl($rootScope, $scope, $state, $timeout, $ionicHistory, LocalStorage, LocalStorageKeys,BooleanConstant) {
    // SCOPE FUNCTIONS
    $scope.saveProfile = saveProfile;
    //$scope.goToPrevious = goToPrevious;
    // SCOPE LIFE CYCLE
    $scope.$on('$ionicView.beforeEnter', ionicViewBeforeEnter);

    // FUNCTIONS
    function ionicViewBeforeEnter() {
        $scope.profileData = LocalStorage.getObject(LocalStorageKeys.PROFILE_DATA);
    }

    /*
        name:saveProfile
        desc: Store the data to be saved in database in rootscope.
              Storing the details in local storage.
    */ 
    function saveProfile() {
        $rootScope.updateMenuHeader = true;
        $rootScope.needToSaveProfile = BooleanConstant.BOOL_TRUE;
        LocalStorage.setObject(LocalStorageKeys.PROFILE_DATA, $scope.profileData);
        $ionicHistory.goBack();
    }
    
    // function goToPrevious(){
    //     $ionicHistory.goBack();
    // }
}
