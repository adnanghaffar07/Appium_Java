﻿angular.module('constants')
    .constant("ScoreThresholdColor", {
        LOW: 0,
        HIGH: 100
    })
    .constant("ConsentStatus", {
        CONSENT_ACCEPTED: "accepted",
        CONSENT_REJECTED: "rejected"
    })
    .constant("TripDefaultValues", {
        HEADER_WEEKS: ["lblWeek_Small_Sunday", "M", "T", "W", "T", "F", "S"],
        TOTAL_DAYS: 7,
        FIRST_DAY_OF_MONTH: 1,
        MONTHS_HEADERS_DETAIL: ["lblMonth_Full_January", "lblMonth_Full_February", "lblMonth_Full_March", "lblMonth_Full_April", "lblMonth_Full_May", "lblMonth_Full_June", "lblMonth_Full_July", "lblMonth_Full_August", "lblMonth_Full_September", "lblMonth_Full_October", "lblMonth_Full_November", "lblMonth_Full_December"],
        WEEK_HEADERS_DETAIL: ["lblWeek_Full_Sunday", "lblWeek_Full_Monday", "lblWeek_Full_Tuesday", "lblWeek_Full_Wednesday", "lblWeek_Full_Thursday", "lblWeek_Full_Friday", "lblWeek_Full_Saturday"]
    })
    .constant("Ranking", {
        RANKING_FLAG: ["", "expert", "intermediate", "novice"]
    })
    .constant("DeviceModel", {
        TYPE_VIRTUAL: "VIRTUAL",
        TYPE_3G: "3G"
    })
    .constant("DrivingAccess", {
        LIMITED: "limited",
        UNLOCKED: "unlocked",
        LOCKED: "locked",
    }).constant("NoNetwork", {
        NO_NETWORK_LANGUAGE:["en-US","fr-CA","es-ES"],
        NO_NETWORK_TITLE:["No Network Connection","Pas de connexion réseau","Sin conexión de red"],
        NO_NETWORK_CONTENT:["Please check your network connection.","S'il vous plaît vérifier votre connexion réseau.","Por favor, compruebe la conexión de red."]
        
    })
    .constant("PaymentType", {
        VISA:'Visa',
        PAYPAL:'PayPal'
    })
    .constant("ScanField", {
        SCAN_VIN:'SCAN_VIN',
        SCAN_LICENSE:'SCAN_LICENSE',
        VEHICLE_INFO:"VEHICLE_INFO"
    }).constant("ChangePassword", {
        IS_CHANGE_PASSWORD:'IS_CHANGE_PASSWORD'
    }).constant("PrizeStatus", {
        LOST:'lost',
        WON:'won',
        NOTYET:'notyet',
        LOCKED:'locked'
    })
    .constant("NewClaims", {
        COLLISION:'Collision',
        STOLEN_VEHICLE:'Stolen Vehicle'            
    })
    .constant("ClaimTypes", {
        PICTURE:'PICTURE',
        LOCATION:'LOCATION',
        POSITION:'POSITION',
        FORM:'FORM'
    })
    .constant("APPLICATION", {
         APPTYPE: "ERIE"
     })
     .constant("ApplicationMode", {
         TBYB: "TBYB",
         CLIENT:"CLIENT"
     })
     .constant("QuoteDetails", {
            ESTIMATE_ANNUAL_MILEAGE : 12000
     })
     .constant("PaymentMethodId", {
            PayPal : "33460634-dc00-11e5-b4ac-5254000fd008",
            Visa : "3346004c-dc00-11e5-b4ac-5254000fd008",
            Debit: "b9184720-f5d9-11e5-9a3f-5254000fd008",
            ACH : "b91858db-f5d9-11e5-9a3f-5254000fd008"
     })
     .constant("NumberSuffixArray", {
            SUFFIXES:["","ST","ND","RD","TH"]
     })
      .constant("QuoteStatus", {
            DONE:"done", 
            PROCESS:"process"
     });