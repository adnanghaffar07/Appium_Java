angular.module('constants')
    .service("GlobalConstants", GlobalConstants);

function GlobalConstants(LocalStorage, LocalStorageKeys) {
    this.API_VERSION = "1.0";
    this.COLLECTOR_URL = "http://localhost:8100/collectorDefault";
    this.PAS_URL = "http://localhost:8100/pasServices";
    this.COLLECTOR_URL_T2 = "http://localhost:8100/collectorDefaultT2";
    this.BASE_URL = "http://localhost:8100/baselineConsoleDefault";
    this.ZENDESK_API = "http://localhost:8100/baselineZendeskApi"


    this.init = function () {
        var override = LocalStorage.get(LocalStorageKeys.BASE_URL_OVERRIDE);
        if (override != null && override != this.BASE_URL) {
            console.log("[GLOBAL_CONSTANTS] BaseURL override", override);
            this.BASE_URL = override;
        }
        override = LocalStorage.get(LocalStorageKeys.COLLECTOR_URL_OVERRIDE);
        if (override != null && override != this.COLLECTOR_URL) {
            console.log("[GLOBAL_CONSTANTS] CollectorUrl override", override);
            this.COLLECTOR_URL = override;
        }
        override = LocalStorage.get(LocalStorageKeys.COLLECTOR_URL_T2_OVERRIDE);
        if (override != null && override != this.COLLECTOR_URL_T2) {
            console.log("[GLOBAL_CONSTANTS] CollectorUrlT2 override", override);
            this.COLLECTOR_URL_T2 = override;
        }
        override = LocalStorage.get(LocalStorageKeys.PAS_URL_OVERRIDE);
        if (override != null && override != this.PAS_URL) {
            console.log("[GLOBAL_CONSTANTS] PAS Url override", override);
            this.PAS_URL = override;
        }
        override = LocalStorage.get(LocalStorageKeys.ZENDESK_API_OVERRIDE);
        if (override != null && override != this.ZENDESK_API) {
            console.log("[GLOBAL_CONSTANTS] Zendesk Api override", override);
            this.ZENDESK_API = override;
        }
    }
}
